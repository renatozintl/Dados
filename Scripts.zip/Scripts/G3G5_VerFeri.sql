CREATE OR REPLACE FUNCTION sqlprocG3G5_fer (data varchar2, cPlanta varchar2, Descr out varchar2) 
   RETURN NUMBER IS
   Ret    NUMBER;

BEGIN
    Ret := 1;
    Descr := ' ';
    
    BEGIN
    	SELECT desc_fer INTO Descr
			FROM FERIADO
			WHERE ((TO_CHAR(data_fer, 'ddmmrr') = data) 
					and 
				   ((TO_NUMBER(planta_fer) = TO_NUMBER(cPlanta)) or (planta_fer is null) or (TO_NUMBER(planta_fer) = 0))
				  );

    EXCEPTION
		WHEN NO_DATA_FOUND then Ret := 0;
		WHEN OTHERS then Ret := -1;
    END;
    
    return (Ret);

END sqlprocG3G5_fer;
/

