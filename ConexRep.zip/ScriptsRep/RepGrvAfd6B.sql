CREATE OR REPLACE PROCEDURE sqlgrava_rep6interj (NumRep in VARCHAR2, Registro in VARCHAR2, cEndIp in VARCHAR2, cInterj in NUMBER, cRep671 in number, nTamAdendo in NUMBER, RegAdendo in VARCHAR2) IS
	
Nsr CHAR(9);
TipoReg CHAR(1);
TipoAdendo char(2);
nNumTipoAd NUMBER;
nTamInfoAd NUMBER;
nTamAd NUMBER;
cAuxPis VARCHAR2(12);
cAuxDta VARCHAR2(12);

BEGIN
	
	Nsr := SUBSTR (Registro, 1, 9);	
	TipoReg := SUBSTR (Registro, 10, 1);	
	
	
	
	if TipoReg not IN ('1', '2', '3', '4', '5', '6', '7', '9') then
		INSERT INTO REPAFD004 
			(END_IP, REP, NSR, TIPO_REG, STATUS, INFORM) VALUES
			(cEndIp, NumRep, Nsr, TipoReg, '0', Registro);
	else
		BEGIN
			INSERT INTO REPAFD001 
				(END_IP, REP, NSR, TIPO_REG, STATUS, INFORM) VALUES
				(cEndIp, NumRep, Nsr, TipoReg, '0', Registro);
		EXCEPTION
			WHEN PROGRAM_ERROR THEN
				INSERT INTO REPAFD004 
					(END_IP, REP, NSR, TIPO_REG, STATUS, INFORM) VALUES
					(cEndIp, NumRep, Nsr, TipoReg, '0', Registro);
			WHEN OTHERS THEN
				INSERT INTO REPAFD004 
					(END_IP, REP, NSR, TIPO_REG, STATUS, INFORM) VALUES
					(cEndIp, NumRep, Nsr, TipoReg, '0', Registro);
		END;			

		IF (TipoReg = '3') then
			INSERT INTO REPAFD003 
				(END_IP, REP, NSR, TIPO_REG, STATUS, INFORM) VALUES
				(cEndIp, NumRep, Nsr, TipoReg, '0', Registro);
	
			-- para Controle de Acesso Interjornada
			IF (cInterj = 1) THEN 		
				IF (cRep671 = 1) THEN 	-- REP que obedece Portaria 671 (recebe CPF em dados de funcionarios, no lugar de PIS; e tem novo formato de dados na parte de datahora)
					cAuxPis := SUBSTR (Registro, 35, 12);		-- pis
					-- ddmmyyyyhhmi
					cAuxDta := SUBSTR (Registro, 19, 2)||SUBSTR (Registro, 16, 2)||SUBSTR (Registro, 11, 4)||
							   SUBSTR (Registro, 22, 2)||SUBSTR (Registro, 25, 2);		
				ELSE
					cAuxPis := SUBSTR (Registro, 23, 12);		-- pis
					cAuxDta := SUBSTR (Registro, 11, 12);		-- ddmmyyyyhhmi
				END IF;
				 --sqlrepPto_interj2 (cAuxPis, cAuxDta);
				 sqlrepPto_interj3 (cAuxPis, cAuxDta);
			END IF;

		END IF;	
		
		-- VERIFICA SE TEM INFORMA��ES ADICIONAIS 
		nTamAd := nTamAdendo;
		WHILE (nTamAd > 0) LOOP
			nNumTipoAd := to_number(SUBSTR (RegAdendo, 1, 2));	-- tipo tem 2 digitos
			nTamInfoAd := to_number(SUBSTR (RegAdendo, 3, 3));	-- tamanho da informacao tem 3 digitos
			IF (nTamInfoAd > 200) THEN
				nTamInfoAd := 200;
			END IF;
			
			INSERT INTO REPADNSR001 
				(END_IP, REP, NSR, TIPO_INFO, STATUS, INFORM) VALUES
				(cEndIp, NumRep, Nsr, nNumTipoAd, '0', SUBSTR (RegAdendo, 6, nTamInfoAd));

							
			nTamAd := nTamAd - (5 + nTamInfoAd);
		END LOOP;
		-- fim de INFORMA��ES ADICIONAIS

		
	end if;
	
	
END sqlgrava_rep6interj;
/
