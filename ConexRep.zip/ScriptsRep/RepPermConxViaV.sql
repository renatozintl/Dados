CREATE OR REPLACE FUNCTION sqlrperm_ConxViaV (cNumRep varchar2, cCnpjEqpto varchar2) 
   RETURN NUMBER IS

Ret    NUMBER;
cCnpjTab VARCHAR2(20);
cStatus VARCHAR2(1);
   
BEGIN
	
    Ret := 1;		-- assume que tem permissao de conexao
	
	BEGIN
		SELECT IDENT, STATUS INTO cCnpjTab,  cStatus
			FROM REPVIAV001
			WHERE REP = cNumRep FOR UPDATE NOWAIT;
		
		IF (cStatus = '0') then
			-- valida Num.Rep e CNPJ provenientes do Rep com o que est� cadastrado
			IF (cCnpjEqpto != cCnpjTab) then
				UPDATE REPVIAV001 SET STATUS = '1' WHERE REP = cNumRep;
				Ret := 0;
			END IF;
			
		ELSIF (cStatus = '1') then		-- JA ESTA ALARMADO E NAO FOI TRATADO
			Ret := 0;
			
		ELSIF (cStatus = '2') then		-- FOI TRATADO, ENTAO VAI PERMITIR CONEXAO PARA POSSIVEL ALTERACAO DE CNPJ DO EQUIPAMENTO
			UPDATE REPVIAV001 SET STATUS = '0' WHERE REP = cNumRep;
			Ret := 1;
		END IF;
		
		
	EXCEPTION
		-- CASO NAO ENCONTRE, INDICA QUE TEM PERMISSAO 
		WHEN NO_DATA_FOUND then Ret := 1;
		WHEN OTHERS then Ret := 0;
	END;
	
	COMMIT;
	
   	return (Ret);		

END sqlrperm_ConxViaV;
/

