CREATE OR REPLACE PROCEDURE sqlrepPto_interj3 (--cPis in VARCHAR2, 
cPisOrCpf in VARCHAR2, cDataHora in VARCHAR2) IS
	
xDtaHoraTab	DATE;
offxDtaHoraTab	DATE;
cAuxFunc VARCHAR2(12);
cAuxPis VARCHAR2(12);
cAuxCpf VARCHAR2(11);
dDtaHorPto DATE;
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);
ret NUMBER;

/*
-- cursor que coleta os  ICARDS  com o mesmo PIS
cursor CURSOR_IFUNCPIS is
	select 
		IFUNC, PIS 
	from REPEMPR002 
	WHERE PIS = cPis 
	ORDER BY IFUNC;    

cursor CURSOR_IFUNCCPF is
	select 
		IFUNC, CPF 
	from REPEMPR002 
	WHERE CPF = substr(cPis,2,11) 
	ORDER BY IFUNC;    
	
*/

cursor CURSOR_IFUNCPISCPF is
	select 
		IFUNC, PIS, CPF 
	from REPEMPR002 
	WHERE PIS = cPisOrCpf OR
		  CPF = substr(cPisOrCpf,2,11) 
	ORDER BY IFUNC;    


BEGIN

	-- CONEXREP
		-- coletara do REPEMPR002 todos os IFUNCS q foram cadastrados com o mesmo PIS
		-- guardar� em REPPONTO, todos esses IFUNCS+ PIS com a DATA e HORA da marcacao de Ponto. Exemplo: titular e varios provis�rios com o mesmo valor de PIS
	-- FIM CONEXREP
	
	
	-- CONEX ACESSO:
		-- situacao 1: o Conex Acesso ao passar o crach� Titular, procurara pelo Icard  em REPPONTO e far� a validacao de datahora para interjornada
		-- situacao 2: o Conex Acesso ao passar o crach� Provis�rio, procurara pelo Icard (agora do Titular)  em REPPONTO e far� a validacao de datahora para interjornada
		-- ou seja, apesar de ter sido armazenado em REPPONTO v�rios Icards com mesmo PIs, o Conex s� procurar� pelo Icard (q � do Titular)
	-- FIM CONEX ACESSO
	
	
	ret := 1;
	dDtaHorPto := to_date (cDataHora, 'ddmmyyyyhh24mi');
	
	
	OPEN CURSOR_IFUNCPISCPF;
	LOOP
		-- coletara do REPEMPR002 todos os IFUNCS q foram cadastrados com o mesmo PIS
		fetch CURSOR_IFUNCPISCPF INTO cAuxFunc, cAuxPis, cAuxCpf;
		EXIT when CURSOR_IFUNCPISCPF%NOTFOUND;
		
		BEGIN
			-- NESTE LOOP. guardar� em REPPONTO, todos esses IFUNCS+ PIS + CPF com a DATA e HORA da marcacao de Ponto
			SELECT DTAHORAREP into xDtaHoraTab FROM REPPONTO
				WHERE (IFUNC = cAuxFunc AND PIS = cAuxPis AND PIS <> '000000000000')  OR
					  (IFUNC = cAuxFunc AND CPF = cAuxCpf AND CPF <> '00000000000')
					FOR UPDATE NOWAIT;
			
			-- verifica se a data/hora que chega do rep � maior que do armazenado
			IF (dDtaHorPto > xDtaHoraTab) THEN
				UPDATE REPPONTO SET DTAHORAREP = dDtaHorPto 
					WHERE (IFUNC = cAuxFunc AND PIS = cAuxPis  AND PIS <> '000000000000') OR  
					      (IFUNC = cAuxFunc AND CPF = cAuxCpf AND CPF <> '00000000000') ;
			
			-- verifica se se a data/hora que chega do rep � menor que do armazenado
			ELSIF (dDtaHorPto < xDtaHoraTab) THEN 
				BEGIN
					SELECT DTAHORAREP into offxDtaHoraTab FROM OFFREPPONTO
						WHERE (IFUNC = cAuxFunc AND PIS = cAuxPis AND PIS <> '000000000000') OR  
						      (IFUNC = cAuxFunc AND CPF = cAuxCpf AND CPF <> '00000000000') 
						FOR UPDATE NOWAIT;

					IF (offxDtaHoraTab != dDtaHorPto) THEN
						UPDATE OFFREPPONTO SET DTAHORAREP = dDtaHorPto 
							WHERE (IFUNC = cAuxFunc AND PIS = cAuxPis  AND PIS <> '000000000000') OR  
								  (IFUNC = cAuxFunc AND CPF = cAuxCpf AND CPF <> '00000000000') ;
					END IF;
			
				EXCEPTION  			
					WHEN NO_DATA_FOUND then 
						INSERT INTO OFFREPPONTO (IFUNC, PIS, CPF, DTAHORAREP) values (cAuxFunc, cAuxPis, cAuxCpf, dDtaHorPto);
					WHEN reco_lock then ret := 0;

					WHEN others then ret := 0;

				END;
			
			END IF;
		
		EXCEPTION  			
			WHEN NO_DATA_FOUND then 
				INSERT INTO REPPONTO (IFUNC, PIS, CPF, DTAHORAREP) values (cAuxFunc, cAuxPis, cAuxCpf, dDtaHorPto);
			WHEN reco_lock then ret := 0;
			
			WHEN others then ret := 0;

		END;
		
		COMMIT;
		
	END LOOP;
	CLOSE CURSOR_IFUNCPISCPF;
		
	
END sqlrepPto_interj3;
/
