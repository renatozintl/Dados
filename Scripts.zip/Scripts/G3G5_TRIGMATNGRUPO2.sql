CREATE OR REPLACE TRIGGER TrgMatNGrupo
    AFTER INSERT OR DELETE OR UPDATE OF GRUPO ON MATNGRUPOS
    FOR EACH ROW
    
declare 
qtd number;
auxSt char(1);

BEGIN

    IF (inserting) THEN
		update COUNT_BY_ICARDG set cnt = cnt+1 where icard = :new.icard;

		IF (sql%rowcount = 0) THEN
			insert into COUNT_BY_ICARDG(icard,cnt) values (:new.icard,1);
			insert into COUNT_BY_ICARDGRUPO(icard,GRUPO, cnt) values (:new.icard,:NEW.GRUPO, 1);

			UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
			UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
			UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :NEW.ICARD;
			UPDATE CONTDIG_OUTROS  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;

		ELSE
			update COUNT_BY_ICARDGRUPO set cnt = cnt+1 where icard = :new.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:NEW.GRUPO);
			IF (sql%rowcount = 0) THEN
				insert into COUNT_BY_ICARDGRUPO(icard,GRUPO, cnt) values (:new.icard,:NEW.GRUPO, 1);				
			
				UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
				UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
				UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :NEW.ICARD;
				UPDATE CONTDIG_OUTROS  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
			ELSE
				select cnt into qtd from COUNT_BY_ICARDGRUPO where icard= :NEW.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:NEW.GRUPO);
				if (QTD = 1) then	
					UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
					UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
					UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :NEW.ICARD;
					UPDATE CONTDIG_OUTROS  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
				END IF;
			END IF;
			
		END IF;
    END IF;
    
    
    IF (DELETING) THEN
	    select cnt into qtd from COUNT_BY_ICARDG where icard= :old.icard;
    	IF (sql%rowcount = 0)   THEN 		-- nao tem 'linha' na tabela de contadores de matricula
			select cnt into qtd from COUNT_BY_ICARDGRUPO where icard= :old.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:old.GRUPO);
			IF (sql%rowcount = 0) THEN 		-- nao tem 'linha' na tabela de contadores de matricula e grupo
				NULL;
			ELSE
				if (QTD = 0) then			-- contador esta com valor zero
				 	NULL;
				ELSE
					update COUNT_BY_ICARDGRUPO set cnt = cnt-1 where icard= :old.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:old.GRUPO);					
				END IF;
			END IF;
		
		ELSE
			if (QTD = 0) then		-- contador da matricula esta com valor zero
				select cnt into qtd from COUNT_BY_ICARDGRUPO where icard= :old.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:old.GRUPO);
				IF (sql%rowcount = 0) THEN 	-- nao tem 'linha' na tabela de contadores de matricula e grupo
					NULL;
				ELSE
					if (QTD = 0) then		-- contador de matricula e grupo esta com valor zero
						NULL;
					ELSE
						update COUNT_BY_ICARDGRUPO set cnt = cnt-1 where icard= :old.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:old.GRUPO);					
					END IF;
				END IF;
			else
				update COUNT_BY_ICARDG set cnt = cnt-1 where icard= :old.icard;					
				select cnt into qtd from COUNT_BY_ICARDGRUPO where icard= :old.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:old.GRUPO);
				
				IF (sql%rowcount = 0) THEN 
					NULL;
				ELSE				
					if (QTD = 0) then
						NULL;
	
					ELSE
						update COUNT_BY_ICARDGRUPO set cnt = cnt-1 where icard= :old.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:old.GRUPO);	
						select cnt into qtd from COUNT_BY_ICARDGRUPO where icard= :old.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:old.GRUPO);
						IF (qtd = 0) THEN
							UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :OLD.ICARD;
							UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :OLD.ICARD;
							UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :OLD.ICARD;
							UPDATE CONTDIG_OUTROS  	SET STATUS = '3' WHERE ICARD = :OLD.ICARD;
						END IF;
					end if;
					
				END IF;
			end if;
		END IF;
	end if;


	-- alterando grupo
	IF (:OLD.GRUPO != :NEW.GRUPO) THEN
		-- se apos a modifica��o, o grupo ANTIGO ainda existe na tabela para esta matricula, entao nao ir� excluir deste grupo, mas ir� verificar o NOVO Grupo para verificar se insere neste novo grupo. 
		-- Se NOVO grupo j� existir na table, nada faz 
		-- Se NOVO grupo N�O existir na table, entao STATUS das biometrias ficara '3' para esta matricula ( nao ser� '8', pois nao se quer excluir de nenhum grupo)
							
		-- se apos a modifica��o, o grupo ANTIGO N�O existe na tabela, N�O importa se o NOVO Grupo existe ou nao, ser� alterado com status '3', para exclusao e carga

		update COUNT_BY_ICARDGRUPO set cnt = cnt-1 where icard= :old.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:old.GRUPO);
		IF (sql%rowcount = 0) THEN 
			-- ATUALIZA GRUPO NOVO
			update COUNT_BY_ICARDGRUPO set cnt = cnt+1 where icard= :NEW.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:NEW.GRUPO);

			IF (sql%rowcount = 0) THEN 
				insert into COUNT_BY_ICARDGRUPO(icard,GRUPO, cnt) values (:new.icard,:NEW.GRUPO, 1);				

				UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
				UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
				UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :NEW.ICARD;
				UPDATE CONTDIG_OUTROS  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;

			ELSE
				select cnt into qtd from COUNT_BY_ICARDGRUPO where icard= :NEW.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:NEW.GRUPO);	
				IF (QTD = 1) THEN 
					UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
					UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
					UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :NEW.ICARD;
					UPDATE CONTDIG_OUTROS  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
				END IF;
			END IF;			


			UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :OLD.ICARD;
			UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :OLD.ICARD;
			UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :OLD.ICARD;
			UPDATE CONTDIG_OUTROS  	SET STATUS = '3' WHERE ICARD = :OLD.ICARD;
			
		ELSE				
			select cnt into qtd from COUNT_BY_ICARDGRUPO where icard= :old.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:old.GRUPO);
			if (QTD = 0) then
				UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :OLD.ICARD;
				UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :OLD.ICARD;
				UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :OLD.ICARD;
				UPDATE CONTDIG_OUTROS  	SET STATUS = '3' WHERE ICARD = :OLD.ICARD;
			
				-- ATUALIZA GRUPO NOVO
				update COUNT_BY_ICARDGRUPO set cnt = cnt+1 where icard= :NEW.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:NEW.GRUPO);
				IF (sql%rowcount = 0) THEN 
					insert into COUNT_BY_ICARDGRUPO(icard,GRUPO, cnt) values (:new.icard,:NEW.GRUPO, 1);				
				END IF;			
			

			ELSE
				-- VAI ANALISAR GRUPO NOVO
				update COUNT_BY_ICARDGRUPO set cnt = cnt+1 where icard= :NEW.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:NEW.GRUPO);
				IF (sql%rowcount = 0) THEN 
					insert into COUNT_BY_ICARDGRUPO(icard,GRUPO, cnt) values (:new.icard,:NEW.GRUPO, 1);				
					UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
					UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
					UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :NEW.ICARD;
					UPDATE CONTDIG_OUTROS  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
					
				ELSE
					select cnt into qtd from COUNT_BY_ICARDGRUPO where icard= :NEW.icard AND TO_NUMBER(GRUPO) = TO_NUMBER(:NEW.GRUPO);
					IF (QTD = 1) THEN
					
						UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
						UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
						UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :NEW.ICARD;
						UPDATE CONTDIG_OUTROS  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
					END IF;
				END IF;
			END IF;
		END IF;
	END IF;
	
END;
/
