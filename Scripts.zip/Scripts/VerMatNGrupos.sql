CREATE OR REPLACE FUNCTION SQLVERMAT_NGRUPOS (cMatric VARCHAR2, cEndIp VARCHAR2, cHoraCodin VARCHAR2, cTipoDia VARCHAR2, nLaces out NUMBER)
RETURN NUMBER IS

i number;
achou number;
k number;
ini number;
fim number;
fx_ini varchar2(6);
fx_fim varchar2(6);


BEGIN
	achou := 0;
	nLaces := -1;	
	-- PROCURA POR TODOS OS GRUPOS DO USUARIO DE ACORDO COM O TIPO DE DATA (cTipoDia) , SE DOMINGO, SABADO, FERIADO OU 2a. A 6a.
 	for r in 
		( 
		select 
			a.grupo, a.fxperm, a.laces 
		from 
			TABGRPSETFX a, MATNGRUPOS b 
		where a.end_ip = cEndIp and 
			b.icard = cMatric and
			TO_NUMBER(b.grupo) = TO_NUMBER(a.grupo) and 
			b.DIA_TIPO = cTipoDia
		) loop

		achou := 2;
		nLaces := to_number(r.laces);
		i := 0;
		
		-- para cada grupo encontrado, verifica se o hor�rio de passagem do usu�rio est� dentro de uma das 7 faixas de permissao de acesso 
		loop
			
			k := 8 * i;
			ini := k + 1;
			fim := k + 5;

			fx_ini := substr(r.fxperm, ini, 4);
			fx_fim := substr(r.fxperm, fim, 4);
			if fx_ini = '2400' then fx_ini := '2359'; end if;
			if fx_fim = '2400' then fx_fim := '2359';  end if;

			if (to_date (fx_ini, 'hh24mi') <= to_date (cHoraCodin, 'hh24mi') and
				to_date (fx_fim, 'hh24mi') >= to_date (cHoraCodin, 'hh24mi')) then
				i := 7;
				achou := 1;		
			else
				i := i + 1;
			end if;
			exit when i > 6;
		end loop;
		exit when achou = 1;
	end loop;
	
	Return (achou);		-- 0:nao tem permissao, 1: tem permissao com horario , 2: tem permissao mas nao tem horario
	
END SQLVERMAT_NGRUPOS;
/
