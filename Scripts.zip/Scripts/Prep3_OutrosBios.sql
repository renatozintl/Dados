CREATE OR REPLACE  PROCEDURE PREP3_OUTROSBIOS
IS

TYPE icard_type IS TABLE OF CONTDIG_OUTROS.ICARD%TYPE 
	INDEX BY binary_integer;
TYPE status_type IS TABLE OF CONTDIG_OUTROS.STATUS%TYPE 
	INDEX BY binary_integer;
TYPE biotipo_type IS TABLE OF CONTDIG_OUTROS.BIO_TIPO%TYPE 
	INDEX BY binary_integer;
	
l_icard icard_type;
l_status status_type;
l_biotipo biotipo_type;
p_rec DIG004%rowtype;

total number;
aux_icard char(12) := '000000000000';
nCont number;
nAchouGrupo number;

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock,-54);  -- erro quando registro lockado 
tem_deadlock EXCEPTION; 
PRAGMA EXCEPTION_INIT (tem_deadlock, -60); 
	
BEGIN

	SELECT ICARD, STATUS, BIO_TIPO
		BULK COLLECT INTO l_icard, l_status, l_biotipo
	from 
		CONTDIG_OUTROS 
	where 
		STATUS = '1' or STATUS = '3' or STATUS = '8';
		
	total := l_icard.count;
	
	-- ******************************************************************
	-- PARA TODOS AS BIOMETRIAS  CADASTRADOS/INSERIDOS/DELETADOS
	FOR indx IN 1 .. total     
	LOOP
		nAchouGrupo := 0;		-- presupoe q nao tem ICARDfunc x grupo correspondente em tab DAT08 X DAT07
		
		-- *************************************************************************
		-- prepara os ids excluidos (controle.situa = invalido) ou grupos da controle alterados, retirando as biometrias de todos os equipamentos 
		IF (l_status(indx) = '3' or l_status(indx) = '8' ) THEN		-- alterados grupos (3) ou situa invalidos  (8)
		
			-- MONTA temporaria matricula x equipamentos BIOTIPO
			INSERT INTO TMP_DIG104 (ICARD, END_IP, STATUS, BIO_TIPO) 		
				SELECT distinct l_icard(indx), DAT07.end_ip, '0', l_biotipo(indx)
				FROM DAT07
				WHERE BIO_TIPO = l_biotipo(indx)  and END_IP <> '000.000.000.000';

			-- *****************************************************************
			-- COMO ESTA EXCLUINDO O FUNCIONARIO DA EMPRESA (CONTROLE.SITUA = '1' INVALIDO), TIRA DA LISTA DE INCLUSAO DE TODOS OS equipamentos DE QUALQUER biotipo
			-- COMO ALTEROU O GRUPO, TIRA DA LISTA DE INCLUSAO DE TODOS OS equipamentos biotipo

			for c1 in (select rowid from DIG004 
				WHERE ICARD = l_icard(indx) AND (STATUS = '0' OR STATUS = '1') AND BIO_TIPO = l_biotipo(indx))
			loop
				BEGIN
					select * into p_rec from DIG004 where rowid = c1.rowid for update nowait;		
					delete from DIG004 where rowid = c1.rowid;

				EXCEPTION
					when reco_lock then NULL ;
					when tem_deadlock then NULL ;
					when NO_DATA_FOUND then NULL;
					when OTHERS then NULL;
				END;
			end loop;					

			-- ******************************************************************
			-- obs : nao excluo das temporarias de exclusao porque elas estao vazias

		END IF;

		
		IF (l_status(indx) = '1' or l_status(indx) = '3' ) THEN		-- incluido/alterado BIOMETRIA (1)   ou   alterados grupos (3) 

			-- ******************************************************************
			-- para todos icards q alteraram digital, distribui nos equipamentos de acordo com o grupo cadastrado em 
			-- CONTROLE, DAT07,DAT08 
			-- MONTA temporaria matricula com codins com permissao acesso

			INSERT into TMP_DIG004 (ICARD, END_IP, STATUS, BIO_TIPO)
				SELECT distinct l_icard(indx), end_ip, '0', bio_tipo
					FROM 
						(
						-- seleciona os equipamentos que fazem parte dos grupos do usu�rio
						SELECT distinct l_icard(indx),  dat07.end_ip, '0', dat07.bio_tipo
							from dat07, dat08
							where
								(dat07.end_ip <> '000.000.000.000' and
								 TO_NUMBER(dat08.grupo) in (
										--select TO_NUMBER(grupo) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT <> '1')		-- ERA (SITUA = '0' OR SITUA = '7')
										select TO_NUMBER(grupo) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT = '2')		-- VER_DIGIT 2 = BIO(1:N)
										  union
										--select TO_NUMBER(grupo1) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT <> '1')
										select TO_NUMBER(grupo1) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT = '2')		-- VER_DIGIT 2 = BIO(1:N)
										  union	
										--select TO_NUMBER(grupo2) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT <> '1')
										select TO_NUMBER(grupo2) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT = '2')		-- VER_DIGIT 2 = BIO(1:N)
										  union
										--select TO_NUMBER(grupo3) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT <> '1')
										select TO_NUMBER(grupo3) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT = '2')		-- VER_DIGIT 2 = BIO(1:N)
										  union
										--select TO_NUMBER(grupo_sab) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT <> '1')
										select TO_NUMBER(grupo_sab) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT = '2')		-- VER_DIGIT 2 = BIO(1:N)
										  union
										--select TO_NUMBER(grupo_dom) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT <> '1')
										select TO_NUMBER(grupo_dom) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT = '2')		-- VER_DIGIT 2 = BIO(1:N)
										  union
										--select TO_NUMBER(grupo_fer) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT <> '1')
										select TO_NUMBER(grupo_fer) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT = '2')		-- VER_DIGIT 2 = BIO(1:N)
										  union
										--select TO_NUMBER(A.grupo) from MATNGRUPOS A, CONTROLE B where A.ICARD = l_icard(indx) AND B.ICARD = l_icard(indx) AND (B.SITUA <> '1') AND (B.VER_DIGIT <> '1')
										select TO_NUMBER(A.grupo) from MATNGRUPOS A, CONTROLE B where A.ICARD = l_icard(indx) AND B.ICARD = l_icard(indx) AND (B.SITUA <> '1') AND (B.VER_DIGIT = '2')		-- VER_DIGIT 2 = BIO(1:N)
										  union
										--select TO_NUMBER(A.grupo) from MATGRUPO A, CONTROLE B where A.ICARD = l_icard(indx) AND B.ICARD = l_icard(indx) AND (B.SITUA <> '1') AND (B.VER_DIGIT <> '1')
										select TO_NUMBER(A.grupo) from MATGRUPO A, CONTROLE B where A.ICARD = l_icard(indx) AND B.ICARD = l_icard(indx) AND (B.SITUA <> '1') AND (B.VER_DIGIT = '2')		-- VER_DIGIT 2 = BIO(1:N)
										) and 
								TO_NUMBER(dat07.laces) = TO_NUMBER(dat08.laces) and
								TO_NUMBER(dat07.planta) = TO_NUMBER(dat08.planta) and
								dat07.bio_tipo = l_biotipo(indx)) 							
					UNION
						SELECT distinct l_icard(indx),  dat07.end_ip, '0', dat07.bio_tipo
							from dat07, dat08, matcodin 
							where
								matcodin.icard = l_icard(indx) and
								matcodin.end_ip <> '000.000.000.000' and 
								matcodin.end_ip = dat07.end_ip and 
								dat07.bio_tipo = l_biotipo(indx)
						);

			IF (l_status(indx) = '3') THEN  
				-- ******************************************************************
				-- deve-se excluir da tabela de exclusao temporaria as biometrias TSI1 que fazem parte do novo grupo
			
				DELETE FROM TMP_DIG104
				WHERE EXISTS
					(SELECT TMP_DIG004.icard 
						FROM TMP_DIG004
						WHERE TMP_DIG004.icard = TMP_DIG104.icard and
								TMP_DIG004.END_IP = TMP_DIG104.END_IP  and
								TMP_DIG004.icard = l_icard(indx)
					);

				-- ******************************************************************
				-- deve-se excluir da tabela de exclusao final as biometrias  que fazem parte do novo grupo
				
				for c1 in (select rowid from DIG104 
					WHERE ICARD = l_icard(indx) AND (STATUS = '0' OR STATUS = '1') AND BIO_TIPO = l_biotipo(indx))
				loop
					BEGIN
						SELECT * into p_rec from DIG104 where rowid = c1.rowid for update nowait;		
						DELETE from DIG104 where rowid = c1.rowid;

					EXCEPTION
						when reco_lock then NULL ;
						when tem_deadlock then NULL ;
						when NO_DATA_FOUND then NULL;
						when OTHERS then NULL;
					END;
				end loop;					
								
			END IF;
		END IF;

		-- ****************************************************	
		-- PREPARA TABELA DE INCLUSAO DE BIOMETRIA TSI1
		
		SELECT count(*) into nCont from TMP_DIG004;					
		IF (nCont != 0) then
			-- insere na tabela final DIG004  os ICARD x equipamentos e STATUS de carga (0 / 1= a carregar)
			FOR x in (select ICARD, END_IP, STATUS, BIO_TIPO from TMP_DIG004) loop
				BEGIN
					SELECT icard into aux_icard from DIG004 
						WHERE ICARD = x.ICARD and
							END_IP = x.END_IP for update nowait;

					UPDATE DIG004 SET STATUS = '1' 
						WHERE  ICARD = x.ICARD and
							   END_IP = x.END_IP;
				EXCEPTION
					WHEN NO_DATA_FOUND THEN
						INSERT INTO DIG004 (ICARD, END_IP, STATUS, BIO_TIPO) 
									values (x.ICARD, x.END_IP, '1', x.BIO_TIPO);
				END;
			END LOOP;
				
			nAchouGrupo := 1;

			-- coloca o equipamento na tab. DIG002 (CARGA LISTA) q n�o existir
			insert into DIG002 (END_IP, DATA_LOAD, STATUS, BIO_TIPO)
				select distinct END_IP, sysdate(), '0', BIO_TIPO
				from
					DIG004
				where
					END_IP not in ( select END_IP from DIG002 );


		END IF;

		-- ******************************************************************
		-- PREPARA TABELA TEMPORARIA DE EXCLUSAO COM OS ENDERE�OS IP DOS EQUIPAMENTOS

		SELECT count(*) into nCont from TMP_DIG104;					
		IF (nCont != 0) then
			-- insere na tabela final DIG104  os ID COM STATUS de carga (0 / 1= a excluir)
			FOR x in (select ICARD, END_IP, BIO_TIPO from TMP_DIG104) loop
				BEGIN
					SELECT icard into aux_icard from DIG104 
						WHERE ICARD = x.icard AND
							END_IP = x.END_IP AND 
							BIO_TIPO = x.BIO_TIPO for update nowait;

					UPDATE DIG104 SET STATUS = '1' 
						WHERE ICARD = x.icard AND
							END_IP = x.END_IP AND 
							BIO_TIPO = x.BIO_TIPO;
				EXCEPTION
					WHEN NO_DATA_FOUND THEN
						INSERT INTO DIG104 (ICARD, END_IP, STATUS, BIO_TIPO) 
						values (x.icard, x.END_IP, '1', x.BIO_TIPO);
				END;
			END LOOP;

			nAchouGrupo := 1;
				
			-- coloca o equipamento na tab. DIG102 (CARGA LISTA) o equipamento q n�o existir
			INSERT into DIG102 (END_IP, DATA_LOAD, STATUS, BIO_TIPO)
				SELECT distinct END_IP, SYSDATE(), '0', BIO_TIPO
				from
					DIG104
				where
					END_IP not in ( select END_IP from DIG102 );
		END IF;

		-- atualiza status da matricula, como tratado
		IF (nAchouGrupo = 1) THEN 
			UPDATE CONTDIG_OUTROS SET STATUS = '0' 
				where ICARD = l_icard(indx) AND 
					BIO_TIPO = l_biotipo(indx);
		END IF;
		
		COMMIT;

	END LOOP;
	
end PREP3_OUTROSBIOS;
/
