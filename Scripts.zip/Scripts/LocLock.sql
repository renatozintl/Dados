CREATE OR REPLACE FUNCTION sqllocaliza_lock (nSid NUMBER)
RETURN NUMBER IS

   nSeqLock NUMBER;
   nRetorno NUMBER;
   CURSOR cursor_RegLock is SELECT ID1 FROM SYS.V_$LOCK
	    WHERE sid = nSid AND
                  type = 'UL' AND
                  ctime > 10;

BEGIN
    nRetorno := 0;

    -- abre cursor
    OPEN cursor_RegLock;
    
    LOOP
	FETCH cursor_RegLock into nSeqLock;
	EXIT WHEN cursor_RegLock%NOTFOUND;

	nRetorno := dbms_lock.release (nSeqLock);

    END LOOP;
    CLOSE cursor_RegLock;
    return (nRetorno);

END sqllocaliza_lock;
/
