-- INICIO2TCPARL.SQL : Criacao de tabelas de Controle de Acesso,
--               Sinonimos de tabelas, role de uso em tabelas

-- OBS: Se voce ja' tiver tabelas criadas, nao rode este script, pois apagara'
--      o que ja' tem.  Para criar as novas tabelas verifique dentro do
--      script Criatab.sql os comandos de interesse e execute-os.


SPOOL RESULT2.LOG;
CONNECT CP_TELEMAT/TELEMAT;

-- compilacao de funcao TO_IDENTIF
--@@to_identif.plb;

-- Criacao de tabelas
@@CRIATABAT18;

-- DROP E CRIACAO DAS ROLES
CREATE ROLE EXECFUNTCP;
CREATE ROLE EXECFUNARL;
CREATE ROLE EXECFUNPRI;


SPOOL OFF;

-- continue com INICIO3.SQL : criacao de funcoes
