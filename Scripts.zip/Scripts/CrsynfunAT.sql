
-- EXCLUIR SINONIMOS
DROP SYNONYM REQUEST_LOCK;
DROP SYNONYM RELEASE_LOCK;

DROP SYNONYM SP_CARTAOATUALIZADO;
DROP SYNONYM SP_CRIARLISTALIMPAOFF;
DROP SYNONYM SP_CRIARPENDENCIAS;

DROP SYNONYM SP2A_STATUSOFF;
DROP SYNONYM SP2A_STATUSON;
DROP SYNONYM SP2_CRIARLISTAPENDENCIA;
DROP SYNONYM SP2_CRIARLISTAPENDENCIA_OFF;
DROP SYNONYM SP2_EXPIROUPENDENCIA;
DROP SYNONYM SQLLIMP_EXCED;


DROP SYNONYM SQLALARME_CODIN_TCP;
DROP SYNONYM SQLATU2_PENDON002;

DROP SYNONYM SQLATU_GEOMOK_CNX;
DROP SYNONYM sqlatualiza_veri_digital_tcp;
DROP SYNONYM SQLATU_VERI_CNX;
DROP SYNONYM SQLSM_ATUALIZADO;
DROP SYNONYM SQLINS_PENDON007;
DROP SYNONYM SQLATU_FORCDAT07;
DROP SYNONYM SQLATU_GERAL4;

DROP SYNONYM SQLATU_MAPABIO_TCP;
DROP SYNONYM SQLATU_PENDON002;
DROP SYNONYM SQLATU_PENDON002_LPZ;
DROP SYNONYM SQLATU_PENDON002_OFF;
DROP SYNONYM SQLATU_PENDON002_ONOFF;
DROP SYNONYM sqlatG3G5_dados_smart;
DROP SYNONYM SQLAT_STATCOLETOR;

DROP SYNONYM sqlatG3G5_tab_acessoSeg;
DROP SYNONYM sqlatG3G5_tab_acesso_geral;
DROP SYNONYM SQLAT_TAB_BENEF2;
DROP SYNONYM SQLAT_TAB_DATAHORA2;

DROP SYNONYM SQLAVISA_CPBB_NOVELL_TCP;
DROP SYNONYM SQLAV_NOVELL2;
DROP SYNONYM SQLBLOCO_BACKUP_SMART_TCP2;
DROP SYNONYM SQLBLOCO_COL_DEV_TCP;
DROP SYNONYM SQLBLOCO_PEND_SMART_TCP2;
DROP SYNONYM SQLCONS_BENEF2;
DROP SYNONYM sqlconsG3G5_contplanta;

DROP SYNONYM SQLCON_COACAO_OMOK;                                                

DROP SYNONYM SQLCON_LISTA_NEGRA;                                                
DROP SYNONYM SQLCON_SAD_BLOQ;                                                   
DROP SYNONYM SQLCON_TIPO_BLOQ;                                                  
                                    

DROP SYNONYM SQLENTRADA_CODIN;                                                  
                                         
DROP SYNONYM SQLEXISTE_TABELA;                                                  
                                                 
DROP SYNONYM SQLFUSO_HORARIO_TCPITP;                                              
DROP SYNONYM SQLGET_DH;                                                         
                            
DROP SYNONYM SQLGRAVA_CP_NOVELL_APPL;
                                              
DROP SYNONYM SQLGRP_SET_FX_TCP;                                                 
DROP SYNONYM SQLIDENT_CONEX;                                                    
DROP SYNONYM SQLIDENT_NIV_TEMPLATE_TCP;                                         
DROP SYNONYM SQLIDENT_VERI_NIV_TEMPLATE_TCP;                                    
DROP SYNONYM SQLINS_CREDLOG;                                                    
DROP SYNONYM SQLINS_EXPIREATUSMART;                                             
DROP SYNONYM SQLINS_LIMPATUSMART;                                               
DROP SYNONYM SQLLER_ATUPENDON2;                                                 
DROP SYNONYM SQLLER_ATUSMART2;                                                  
DROP SYNONYM SQLLER_PENDON003;                                                  
DROP SYNONYM SQLLER_PENDON004;                                                  
DROP SYNONYM SQLLER_PENDON005;                                                  
                                               
DROP SYNONYM SQLLE_INFO_BLOQ;                                                   
DROP SYNONYM SQLLIM_TEMPO_CRED2;                                                
DROP SYNONYM SQLLOCALIZA_LOCK;                                                  
                                          
                                                      
DROP SYNONYM SQLLST_EXC_SAD;                                                    
DROP SYNONYM SQLLST_EXC_TIPO;                                                   
DROP SYNONYM SQLNAO_TABLOC;                                                     
DROP SYNONYM SQLOLHA_ALARME_APPL;  
DROP SYNONYM SQLOLHA_OVERWRITE_APPL;                                              
DROP SYNONYM sqlprocG3G5_fer;                                                      


                      
--DROP SYNONYM SQLTIP_VERI_TCP_PLANTA;                                            
                                          
DROP SYNONYM SQLVER_FUNCMAT;                                                    
                        
DROP SYNONYM SQLVER_LISTA_B_TCP;                                                
DROP SYNONYM sqlverG3G5_matcodin_tcp;                                               
DROP SYNONYM SQLVER_MATVEI2;                                                    
DROP SYNONYM SQLVER_MENSAGEM;
DROP SYNONYM TO_IDENTIF;                                                        
DROP SYNONYM RET_IDENTIF;   
DROP SYNONYM sqlproc_matmens;

DROP SYNONYM SQLAPL_RECARGA;

DROP SYNONYM sqlatu_sagem_cnx2;
DROP SYNONYM SQLCON_COACAO_SAGEM;
DROP SYNONYM SQLNIVEL_GEOMOKSAG2;

DROP SYNONYM SQLLOAD_LISTADIG4;
DROP SYNONYM SQLFIM_LDIG;
--DROP SYNONYM SQLAPL_DIGAUTO;

DROP SYNONYM sqlbloq_numserial;
DROP SYNONYM sqlbloco_col_dam99_tcp;

DROP SYNONYM sqlatualiza_handkey_tcp;
DROP SYNONYM sqlcon_handkey_tcp2;
DROP SYNONYM sqlproc_handkey_template_tcp;

DROP SYNONYM sqlatu_tsi1_cnx2;
DROP SYNONYM sqlcon_coacao_tsi1;



DROP SYNONYM sqlver_matplaca;
DROP SYNONYM sqlver_matbmens;
DROP SYNONYM sqlver_TitMat;

DROP SYNONYM sqlver_RepPonto;
DROP SYNONYM sqlfxa_jornspontoantpos;
DROP SYNONYM sqlsel_oldrepponto;


DROP SYNONYM sqlconsG3G5_term_geral_tcp18;
--DROP SYNONYM sqlconsG3G5_term_repp_tcpoff18;


-- CRIACAO DE SINONIMOS
CREATE SYNONYM REQUEST_LOCK FOR cp_telemat.REQUEST_LOCK;
CREATE SYNONYM RELEASE_LOCK FOR cp_telemat.RELEASE_LOCK;

CREATE SYNONYM SP_CARTAOATUALIZADO FOR cp_telemat.SP_CARTAOATUALIZADO;             
CREATE SYNONYM SP_CRIARLISTALIMPAOFF FOR cp_telemat.SP_CRIARLISTALIMPAOFF;         
CREATE SYNONYM SP_CRIARPENDENCIAS FOR cp_telemat.SP_CRIARPENDENCIAS;               

CREATE SYNONYM SP2A_STATUSOFF  FOR cp_telemat.SP2A_STATUSOFF;
CREATE SYNONYM SP2A_STATUSON FOR cp_telemat.SP2A_STATUSON;
CREATE SYNONYM SP2_CRIARLISTAPENDENCIA  FOR cp_telemat.SP2_CRIARLISTAPENDENCIA;
CREATE SYNONYM SP2_CRIARLISTAPENDENCIA_OFF  FOR cp_telemat.SP2_CRIARLISTAPENDENCIA_OFF;
CREATE SYNONYM SP2_EXPIROUPENDENCIA  FOR cp_telemat.SP2_EXPIROUPENDENCIA;
CREATE SYNONYM SQLLIMP_EXCED FOR cp_telemat.SQLLIMP_EXCED;


CREATE SYNONYM SQLALARME_CODIN_TCP FOR cp_telemat.SQLALARME_CODIN_TCP;             
CREATE SYNONYM SQLATU2_PENDON002 FOR cp_telemat.SQLATU2_PENDON002;                 
   
CREATE SYNONYM SQLATU_GEOMOK_CNX FOR cp_telemat.SQLATU_GEOMOK_CNX;
CREATE SYNONYM sqlatualiza_veri_digital_tcp FOR cp_telemat.sqlatualiza_veri_digital_tcp;
CREATE SYNONYM SQLATU_VERI_CNX FOR cp_telemat.SQLATU_VERI_CNX;
CREATE SYNONYM SQLSM_ATUALIZADO FOR cp_telemat.SQLSM_ATUALIZADO;
CREATE SYNONYM SQLINS_PENDON007 FOR cp_telemat.SQLINS_PENDON007;                 
CREATE SYNONYM SQLATU_FORCDAT07 FOR cp_telemat.SQLATU_FORCDAT07;                   
CREATE SYNONYM SQLATU_GERAL4 FOR cp_telemat.SQLATU_GERAL4;                           

CREATE SYNONYM SQLATU_MAPABIO_TCP FOR cp_telemat.SQLATU_MAPABIO_TCP;               
CREATE SYNONYM SQLATU_PENDON002 FOR cp_telemat.SQLATU_PENDON002;                   
CREATE SYNONYM SQLATU_PENDON002_LPZ FOR cp_telemat.SQLATU_PENDON002_LPZ;           
CREATE SYNONYM SQLATU_PENDON002_OFF FOR cp_telemat.SQLATU_PENDON002_OFF;           
CREATE SYNONYM SQLATU_PENDON002_ONOFF FOR cp_telemat.SQLATU_PENDON002_ONOFF;       
CREATE SYNONYM sqlatG3G5_dados_smart FOR cp_telemat.sqlatG3G5_dados_smart;
CREATE SYNONYM SQLAT_STATCOLETOR FOR cp_telemat.SQLAT_STATCOLETOR;                 
   
CREATE SYNONYM sqlatG3G5_tab_acessoSeg FOR cp_telemat.sqlatG3G5_tab_acessoSeg;                 
CREATE SYNONYM sqlatG3G5_tab_acesso_geral FOR cp_telemat.sqlatG3G5_tab_acesso_geral;
CREATE SYNONYM SQLAT_TAB_BENEF2 FOR cp_telemat.SQLAT_TAB_BENEF2;                   
CREATE SYNONYM SQLAT_TAB_DATAHORA2 FOR cp_telemat.SQLAT_TAB_DATAHORA2;
    
CREATE SYNONYM SQLAVISA_CPBB_NOVELL_TCP FOR cp_telemat.SQLAVISA_CPBB_NOVELL_TCP;   
CREATE SYNONYM SQLAV_NOVELL2 FOR cp_telemat.SQLAV_NOVELL2;                         

CREATE SYNONYM SQLBLOCO_BACKUP_SMART_TCP2 FOR cp_telemat.SQLBLOCO_BACKUP_SMART_TCP2;
CREATE SYNONYM SQLBLOCO_COL_DEV_TCP FOR cp_telemat.SQLBLOCO_COL_DEV_TCP;           
   
CREATE SYNONYM SQLBLOCO_PEND_SMART_TCP2 FOR cp_telemat.SQLBLOCO_PEND_SMART_TCP2;   
CREATE SYNONYM SQLCONS_BENEF2 FOR cp_telemat.SQLCONS_BENEF2;                       
CREATE SYNONYM sqlconsG3G5_contplanta FOR cp_telemat.sqlconsG3G5_contplanta;               


            
CREATE SYNONYM SQLCON_COACAO_OMOK FOR cp_telemat.SQLCON_COACAO_OMOK;               

CREATE SYNONYM SQLCON_LISTA_NEGRA FOR cp_telemat.SQLCON_LISTA_NEGRA;               
CREATE SYNONYM SQLCON_SAD_BLOQ FOR cp_telemat.SQLCON_SAD_BLOQ;                     
CREATE SYNONYM SQLCON_TIPO_BLOQ FOR cp_telemat.SQLCON_TIPO_BLOQ;                   

                           
CREATE SYNONYM SQLENTRADA_CODIN FOR cp_telemat.SQLENTRADA_CODIN;                   
   
CREATE SYNONYM SQLEXISTE_TABELA FOR cp_telemat.SQLEXISTE_TABELA;                   
                    
CREATE SYNONYM SQLFUSO_HORARIO_TCPITP FOR cp_telemat.SQLFUSO_HORARIO_TCPITP;           
CREATE SYNONYM SQLGET_DH FOR cp_telemat.SQLGET_DH;                                 

CREATE SYNONYM SQLGRAVA_CP_NOVELL_APPL FOR cp_telemat.SQLGRAVA_CP_NOVELL_APPL;       
        
CREATE SYNONYM SQLGRP_SET_FX_TCP FOR cp_telemat.SQLGRP_SET_FX_TCP;                 
CREATE SYNONYM SQLIDENT_CONEX FOR cp_telemat.SQLIDENT_CONEX;                       
CREATE SYNONYM SQLIDENT_NIV_TEMPLATE_TCP FOR cp_telemat.SQLIDENT_NIV_TEMPLATE_TCP; 
CREATE SYNONYM SQLIDENT_VERI_NIV_TEMPLATE_TCP FOR cp_telemat.SQLIDENT_VERI_NIV_TEMPLATE_TCP;
CREATE SYNONYM SQLINS_CREDLOG FOR cp_telemat.SQLINS_CREDLOG;                       
CREATE SYNONYM SQLINS_EXPIREATUSMART FOR cp_telemat.SQLINS_EXPIREATUSMART;         
CREATE SYNONYM SQLINS_LIMPATUSMART FOR cp_telemat.SQLINS_LIMPATUSMART;             
CREATE SYNONYM SQLLER_ATUPENDON2 FOR cp_telemat.SQLLER_ATUPENDON2;                 
CREATE SYNONYM SQLLER_ATUSMART2 FOR cp_telemat.SQLLER_ATUSMART2;                   
CREATE SYNONYM SQLLER_PENDON003 FOR cp_telemat.SQLLER_PENDON003;                   
CREATE SYNONYM SQLLER_PENDON004 FOR cp_telemat.SQLLER_PENDON004;                   
CREATE SYNONYM SQLLER_PENDON005 FOR cp_telemat.SQLLER_PENDON005;                   
           
CREATE SYNONYM SQLLE_INFO_BLOQ FOR cp_telemat.SQLLE_INFO_BLOQ;                     
CREATE SYNONYM SQLLIM_TEMPO_CRED2 FOR cp_telemat.SQLLIM_TEMPO_CRED2;               
CREATE SYNONYM SQLLOCALIZA_LOCK FOR cp_telemat.SQLLOCALIZA_LOCK;                   
                 
                         
CREATE SYNONYM SQLLST_EXC_SAD FOR cp_telemat.SQLLST_EXC_SAD;                       
CREATE SYNONYM SQLLST_EXC_TIPO FOR cp_telemat.SQLLST_EXC_TIPO;                     
CREATE SYNONYM SQLNAO_TABLOC FOR cp_telemat.SQLNAO_TABLOC;                         
CREATE SYNONYM SQLOLHA_ALARME_APPL FOR cp_telemat.SQLOLHA_ALARME_APPL;               
CREATE SYNONYM SQLOLHA_OVERWRITE_APPL  FOR cp_telemat.SQLOLHA_OVERWRITE_APPL;
CREATE SYNONYM sqlprocG3G5_fer FOR cp_telemat.sqlprocG3G5_fer;                           



--CREATE SYNONYM SQLTIP_VERI_TCP_PLANTA FOR cp_telemat.SQLTIP_VERI_TCP_PLANTA;       

CREATE SYNONYM SQLVER_FUNCMAT FOR cp_telemat.SQLVER_FUNCMAT;                       
             
CREATE SYNONYM SQLVER_LISTA_B_TCP FOR cp_telemat.SQLVER_LISTA_B_TCP;               
CREATE SYNONYM sqlverG3G5_matcodin_tcp FOR cp_telemat.sqlverG3G5_matcodin_tcp;             
CREATE SYNONYM SQLVER_MATVEI2 FOR cp_telemat.SQLVER_MATVEI2;                       
CREATE SYNONYM SQLVER_MENSAGEM FOR cp_telemat.SQLVER_MENSAGEM;
CREATE SYNONYM TO_IDENTIF FOR cp_telemat.TO_IDENTIF;                               
CREATE SYNONYM RET_IDENTIF FOR cp_telemat.RET_IDENTIF;                               
CREATE SYNONYM sqlproc_matmens FOR cp_telemat.sqlproc_matmens;

CREATE SYNONYM SQLAPL_RECARGA FOR cp_telemat.SQLAPL_RECARGA;

CREATE SYNONYM sqlatu_sagem_cnx2 FOR cp_telemat.sqlatu_sagem_cnx2;
CREATE SYNONYM SQLCON_COACAO_SAGEM FOR cp_telemat.SQLCON_COACAO_SAGEM;
CREATE SYNONYM SQLNIVEL_GEOMOKSAG2 FOR cp_telemat.SQLNIVEL_GEOMOKSAG2;


CREATE SYNONYM SQLLOAD_LISTADIG4 FOR cp_telemat.SQLLOAD_LISTADIG4;
CREATE SYNONYM SQLFIM_LDIG FOR cp_telemat.SQLFIM_LDIG;
--CREATE SYNONYM SQLAPL_DIGAUTO FOR cp_telemat.SQLAPL_DIGAUTO;


DROP SYNONYM sqlfim_ExcAutoDigit3;
DROP SYNONYM sqller_autoLoadDigit3;
DROP SYNONYM sqller_autoExclDigit3;
DROP SYNONYM sqlresp_autopalmv;
DROP SYNONYM sqlfim_LdigPalmv;

CREATE SYNONYM sqlfim_ExcAutoDigit3 FOR cp_telemat.sqlfim_ExcAutoDigit3;
CREATE SYNONYM sqller_autoLoadDigit3 FOR cp_telemat.sqller_autoLoadDigit3;
CREATE SYNONYM sqller_autoExclDigit3 FOR cp_telemat.sqller_autoExclDigit3;
CREATE SYNONYM sqlresp_autopalmv FOR cp_telemat.sqlresp_autopalmv;
CREATE SYNONYM sqlfim_LdigPalmv FOR cp_telemat.sqlfim_LdigPalmv;


CREATE SYNONYM sqlbloq_numserial FOR cp_telemat.sqlbloq_numserial;
CREATE SYNONYM sqlbloco_col_dam99_tcp for cp_telemat.sqlbloco_col_dam99_tcp;

CREATE SYNONYM sqlatualiza_handkey_tcp FOR cp_telemat.sqlatualiza_handkey_tcp;
CREATE SYNONYM sqlcon_handkey_tcp2 FOR cp_telemat.sqlcon_handkey_tcp2;
CREATE SYNONYM sqlproc_handkey_template_tcp FOR cp_telemat.sqlproc_handkey_template_tcp;

CREATE SYNONYM sqlatu_tsi1_cnx2 for cp_telemat.sqlatu_tsi1_cnx2;
CREATE SYNONYM sqlcon_coacao_tsi1 for cp_telemat.sqlcon_coacao_tsi1;

CREATE SYNONYM sqlver_matplaca  FOR cp_telemat.sqlver_matplaca;
CREATE SYNONYM sqlver_matbmens FOR cp_telemat.sqlver_matbmens;
CREATE SYNONYM sqlver_TitMat FOR cp_telemat.sqlver_TitMat;

CREATE SYNONYM sqlver_RepPonto FOR cp_telemat.sqlver_RepPonto;
CREATE SYNONYM sqlfxa_jornspontoantpos FOR cp_telemat.sqlfxa_jornspontoantpos;
CREATE SYNONYM sqlsel_oldrepponto FOR cp_telemat.sqlsel_oldrepponto;

CREATE SYNONYM sqlconsG3G5_term_geral_tcp18 FOR cp_telemat.sqlconsG3G5_term_geral_tcp18;
CREATE SYNONYM sqlconsG3G5_term_repp_tcpoff18 FOR cp_telemat.sqlconsG3G5_term_repp_tcpoff18;


drop synonym sqlfim_ExcAutoPalmv;
create synonym sqlfim_ExcAutoPalmv for cp_telemat.sqlfim_ExcAutoPalmv;

drop synonym sqlfim_InsAutoPalmv;
create synonym sqlfim_InsAutoPalmv for cp_telemat.sqlfim_InsAutoPalmv;

drop synonym sqlLeBD_PalmVein;
create synonym sqlLeBD_PalmVein for cp_telemat.sqlLeBD_PalmVein;

drop synonym sqlGravaBD_PalmVein;
create synonym sqlGravaBD_PalmVein for cp_telemat.sqlGravaBD_PalmVein;

drop synonym sqller_autoLoadPalmV;
create synonym sqller_autoLoadPalmV for cp_telemat.sqller_autoLoadPalmV;

drop synonym sqller_autoExclPalmV;
create synonym sqller_autoExclPalmV for cp_telemat.sqller_autoExclPalmV;

DROP SYNONYM sqlat_bloq_revista;
create synonym sqlat_bloq_revista for cp_telemat.sqlat_bloq_revista;

DROP SYNONYM sqlconG3G5_ace_usuario10;
create synonym sqlconG3G5_ace_usuario10 for cp_telemat.sqlconG3G5_ace_usuario10;

DROP SYNONYM sqlproc_icardNS;
create synonym sqlproc_icardNS for cp_telemat.sqlproc_icardNS;

DROP SYNONYM sqlbloco_col_dam00_new5;
create synonym sqlbloco_col_dam00_new5 for cp_telemat.sqlbloco_col_dam00_new5;

DROP SYNONYM sqlbloco_col_dam01_new2;
create synonym sqlbloco_col_dam01_new2 for cp_telemat.sqlbloco_col_dam01_new2;

DROP SYNONYM sqlbloco_col_dam02_new2;
create synonym sqlbloco_col_dam02_new2 for cp_telemat.sqlbloco_col_dam02_new2;


DROP SYNONYM sqlbloco_col_dam03_new1;
create synonym sqlbloco_col_dam03_new1 for cp_telemat.sqlbloco_col_dam03_new1;

DROP SYNONYM sqlle_IcardNSOrd;
CREATE SYNONYM sqlle_IcardNSOrd FOR cp_telemat.sqlle_IcardNSOrd;

DROP SYNONYM sqlprep_ordIcardNS;
CREATE SYNONYM sqlprep_ordIcardNS FOR cp_telemat.sqlproc_ordIcardNS;

drop synonym sqlAtuVagas_Estac3;
CREATE SYNONYM sqlAtuVagas_Estac3 FOR cp_telemat.sqlAtuVagas_Estac3;

drop synonym sqlConsVagas_Estac3;
CREATE SYNONYM sqlConsVagas_Estac3 FOR cp_telemat.sqlConsVagas_Estac3;

drop synonym sqlcon_sagem_digital4It;
CREATE SYNONYM sqlcon_sagem_digital4It FOR cp_telemat.sqlcon_sagem_digital4It;

drop synonym sqlnivel_sagemit;
CREATE SYNONYM sqlnivel_sagemit FOR cp_telemat.sqlnivel_sagemit;

drop synonym SQLMAT_GRUPO_tcp;
CREATE SYNONYM SQLMAT_GRUPO_tcp FOR cp_telemat.SQLMAT_GRUPO_tcp;

DROP SYNONYM sqlBusca_Veri_biomet2;
CREATE SYNONYM sqlBusca_Veri_biomet2 FOR cp_telemat.sqlBusca_Veri_biomet2; 

DROP SYNONYM sqlBusca_Omok_biomet;
CREATE SYNONYM sqlBusca_Omok_biomet FOR cp_telemat.sqlBusca_Omok_biomet; 

DROP SYNONYM sqlBusca_Sagem_biomet2;
CREATE SYNONYM sqlBusca_Sagem_biomet2 FOR cp_telemat.sqlBusca_Sagem_biomet2;

DROP SYNONYM sqlBusca_Tsi1_biomet2;
CREATE SYNONYM sqlBusca_Tsi1_biomet2 for cp_telemat.sqlBusca_Tsi1_biomet2;

DROP SYNONYM sqlatu_outrosbios_CNX;
CREATE SYNONYM sqlatu_outrosbios_CNX for cp_telemat.sqlatu_outrosbios_CNX;

DROP SYNONYM sqlBusca_Outros_biomet;
CREATE SYNONYM sqlBusca_Outros_biomet for cp_telemat.sqlBusca_Outros_biomet;

DROP SYNONYM sqlproc_digitPALMV;
CREATE SYNONYM sqlproc_digitPALMV for cp_telemat.sqlproc_digitPALMV;

DROP SYNONYM sqlproc_digitBinaryBios;
CREATE SYNONYM sqlproc_digitBinaryBios FOR cp_telemat.sqlproc_digitBinaryBios;

DROP SYNONYM sqlGravaBD_BinaryBios;
CREATE SYNONYM sqlGravaBD_BinaryBios FOR cp_telemat.sqlGravaBD_BinaryBios;

DROP SYNONYM sqlfim_InsAutoBinBios;
CREATE SYNONYM sqlfim_InsAutoBinBios FOR cp_telemat.sqlfim_InsAutoBinBios;

drop synonym SQLVERMAT_NGRUPOS;
create synonym SQLVERMAT_NGRUPOS for cp_telemat.SQLVERMAT_NGRUPOS;

drop synonym sqlver_TamG3G5;
create synonym sqlver_TamG3G5 for cp_telemat.sqlver_TamG3G5;

DROP SYNONYM sqlvermat_nrefeit3;
CREATE SYNONYM sqlvermat_nrefeit3 FOR cp_telemat.sqlvermat_nrefeit3;
 
DROP SYNONYM sqlat_tab_refplanta;
CREATE SYNONYM sqlat_tab_refplanta FOR cp_telemat.sqlat_tab_refplanta;

DROP SYNONYM sqlver_tipobio;
CREATE SYNONYM sqlver_tipobio FOR cp_telemat.sqlver_tipobio;

DROP SYNONYM sqlhist_bio;
CREATE SYNONYM sqlhist_bio FOR cp_telemat.sqlhist_bio;

DROP SYNONYM sqldig_rejeit;
CREATE SYNONYM sqldig_rejeit FOR cp_telemat.sqldig_rejeit;

DROP SYNONYM sqlCons_ListaVagEstac;
CREATE SYNONYM sqlCons_ListaVagEstac FOR cp_telemat.sqlCons_ListaVagEstac;

drop synonym sqlgrava_apoc;
create synonym sqlgrava_apoc for cp_telemat.sqlgrava_apoc;

drop synonym sqlle_apoc2;
create synonym sqlle_apoc2 for cp_telemat.sqlle_apoc2;

drop synonym sqlConsCont512_bdcc;
CREATE SYNONYM sqlConsCont512_bdcc FOR cp_telemat.sqlConsCont512_bdcc;

drop synonym sqlAtuCont512_bdcc;
CREATE SYNONYM sqlAtuCont512_bdcc FOR cp_telemat.sqlAtuCont512_bdcc;

drop synonym sqlgrava_ListaMat;
CREATE SYNONYM sqlgrava_ListaMat FOR cp_telemat.sqlgrava_ListaMat;

drop synonym sqlInfo_ErroListaDig;
CREATE SYNONYM sqlInfo_ErroListaDig FOR cp_telemat.sqlInfo_ErroListaDig;


