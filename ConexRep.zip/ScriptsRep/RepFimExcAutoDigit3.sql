CREATE or REPLACE FUNCTION sqlfim_rExcAutoDigit3 (cEndIp in VARCHAR2, cStat in VARCHAR2, cBioTipo in VARCHAR2) 
RETURN NUMBER IS

xCont NUMBER;
ret NUMBER;
cAux VARCHAR2(1);
cStInc VARCHAR2(1);
cNovoStat VARCHAR2(1);

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

cursor lexcdig_rcur1 is 
	SELECT IFUNC, STATUS FROM RDIG101 
		WHERE END_IP = cEndIp AND STATUS = '2' 
		order by IFUNC for update of STATUS;

cursor lexcdig_cur2 is 
	SELECT IFUNC, STATUS FROM RDIG103 
		WHERE END_IP = cEndIp AND STATUS = '2' 
		order by IFUNC for update of STATUS;

cursor lexcdig_cur3 is 
	SELECT IFUNC, STATUS FROM RDIG104 
		WHERE END_IP = cEndIp AND STATUS = '2' 
		order by IFUNC for update of STATUS;

begin
    xCont := 0;
    ret := 0;
	cNovoStat := cStat;

	IF (cBioTipo = '6') or (cBioTipo = '7') THEN
		-- atualiza o status somente dos IFUNC q estavam sendo excluidos (sofrendo o comando de exlucsao no conex - BIOMETRIA SAGEM)
		for r in lexcdig_rcur1 LOOP

			-- ******* NOVO
			-- SE ESTIVER PENDENTE, DEVE VERIFICAR SE H� ALGUM COMANDO DE INCLUSAO DESSA DIGITALO PARA O EQUIPAMENTO A SER EXECUTADO.
			-- SE HOUVER, DEVE-SE IGNORAR ESTA PENDENCIA DE EXCLUSAO E TORNA-LA STATUS '4', PARA QUE O GERENCIADOR DE CARGA AUTOM�TICA ANULE ESTA PENDENCIA
			if (cStat = '3') then
				BEGIN 
					SELECT STATUS INTO cStInc FROM RDIG001 
						WHERE IFUNC = r.IFUNC and END_IP = cEndIp AND STATUS <> '0' ;

					-- ENCONTROU COMANDO MAIS RECENTE DE INCLUSAO, ENT�O NOVO VALOR DE 	RDIG101.STATUS SER� '4' PARA QUE ESTA EXCLUSAO SEJA DESCARTADA, E N�O SER� TRATADA COMO PENDENCIA.					
					cNovoStat := '4';
						
				EXCEPTION
					WHEN NO_DATA_FOUND then 
						null;
					WHEN OTHERS then 
						null;
				END;
			end if;
			-- ******* FIM NOVO
		
			--update RDIG101 set STATUS = cStat where current of lexcdig_rcur1 ;
			update RDIG101 set STATUS = cNovoStat where current of lexcdig_rcur1 ;		-- ******* NOVO
			
			xCont := xCont+1;
		END LOOP;

	ELSIF (cBioTipo = '8') THEN
		-- atualiza o status somente dos IFUNC q estavam sendo excluidos (sofrendo o comando de exlucsao no conex - BIOMETRIA TSI1)
		for r in lexcdig_cur2 LOOP
		
			-- ******* NOVO
			-- SE ESTIVER PENDENTE, DEVE VERIFICAR SE H� ALGUM COMANDO DE INCLUSAO DESSA DIGITALO PARA O EQUIPAMENTO A SER EXECUTADO.
			-- SE HOUVER, DEVE-SE IGNORAR ESTA PENDENCIA DE EXCLUSAO E TORNA-LA STATUS '4', PARA QUE O GERENCIADOR DE CARGA AUTOM�TICA ANULE ESTA PENDENCIA
			if (cStat = '3') then
				BEGIN 
					SELECT STATUS INTO cStInc FROM RDIG003 
						WHERE IFUNC = r.IFUNC and END_IP = cEndIp AND STATUS <> '0' ;

					-- ENCONTROU COMANDO MAIS RECENTE DE INCLUSAO, ENT�O NOVO VALOR DE 	RDIG103.STATUS SER� '4' PARA QUE ESTA EXCLUSAO SEJA DESCARTADA, E N�O SER� TRATADA COMO PENDENCIA.					
					cNovoStat := '4';
						
				EXCEPTION
					WHEN NO_DATA_FOUND then 
						null;
					WHEN OTHERS then 
						null;
				END;
			end if;
			-- ******* FIM NOVO
		
			--update RDIG103 set STATUS = cStat where current of lexcdig_cur2 ;
			update RDIG103 set STATUS = cNovoStat where current of lexcdig_cur2 ;		-- ******* NOVO
			
			xCont := xCont+1;
		END LOOP;

	--ELSIF (cBioTipo = '9') THEN
	ELSIF (cBioTipo != '0') THEN
		-- atualiza o status somente dos IFUNC q estavam sendo excluidos (sofrendo o comando de exlucsao no conex - BIOMETRIA VIRDI)
		for r in lexcdig_cur3 LOOP
		
			-- ******* NOVO
			-- SE ESTIVER PENDENTE, DEVE VERIFICAR SE H� ALGUM COMANDO DE INCLUSAO DESSA DIGITALO PARA O EQUIPAMENTO A SER EXECUTADO.
			-- SE HOUVER, DEVE-SE IGNORAR ESTA PENDENCIA DE EXCLUSAO E TORNA-LA STATUS '4', PARA QUE O GERENCIADOR DE CARGA AUTOM�TICA ANULE ESTA PENDENCIA
			if (cStat = '3') then
				BEGIN 
					SELECT STATUS INTO cStInc FROM RDIG004 
						WHERE IFUNC = r.IFUNC and END_IP = cEndIp AND STATUS <> '0' ;

					-- ENCONTROU COMANDO MAIS RECENTE DE INCLUSAO, ENT�O NOVO VALOR DE 	RDIG104.STATUS SER� '4' PARA QUE ESTA EXCLUSAO SEJA DESCARTADA, E N�O SER� TRATADA COMO PENDENCIA.					
					cNovoStat := '4';
						
				EXCEPTION
					WHEN NO_DATA_FOUND then 
						null;
					WHEN OTHERS then 
						null;
				END;
			end if;
			-- ******* FIM NOVO
		
			--update RDIG104 set STATUS = cStat where current of lexcdig_cur3 ;
			update RDIG104 set STATUS = cNovoStat where current of lexcdig_cur3 ;		-- ******* NOVO
			
			xCont := xCont+1;
		END LOOP;
	END IF;
	
	BEGIN
		SELECT STATUS into cAux   
			FROM RDIG102 
			WHERE END_IP = cEndIp for update nowait;

		UPDATE RDIG102 SET STATUS = cStat WHERE END_IP = cEndIp;


	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			ret := 0;
		WHEN reco_lock THEN
			ret := (0);
		WHEN OTHERS THEN
			ret := -1;
	END;
    
	
	COMMIT;
	return (ret);
		
END sqlfim_rExcAutoDigit3;
/

