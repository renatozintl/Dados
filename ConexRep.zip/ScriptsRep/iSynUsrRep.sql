DROP SYNONYM sqlrident_conex;
CREATE SYNONYM sqlrident_conex for cp_telemat.sqlrident_conex;

DROP SYNONYM sqlravisa_cpbb_novell_tcp;
CREATE SYNONYM sqlravisa_cpbb_novell_tcp FOR cp_telemat.sqlravisa_cpbb_novell_tcp;

DROP SYNONYM sqlrget_dh;
CREATE SYNONYM sqlrget_dh FOR cp_telemat.sqlrget_dh;

DROP SYNONYM sqlrentrada_codin;
CREATE SYNONYM sqlrentrada_codin FOR cp_telemat.sqlrentrada_codin;

--DROP SYNONYM sqlrfuso_horario_tcp2;
--CREATE SYNONYM sqlrfuso_horario_tcp2 FOR cp_telemat.sqlrfuso_horario_tcp2;

DROP SYNONYM sqlrfuso_timestamp;
CREATE SYNONYM sqlrfuso_timestamp FOR cp_telemat.sqlrfuso_timestamp;

--DROP SYNONYM sqlrnivel_geomoksag;
--CREATE SYNONYM sqlrnivel_geomoksag FOR cp_telemat.sqlrnivel_geomoksag;

DROP SYNONYM sqlrsit_coletor;
CREATE SYNONYM sqlrsit_coletor FOR cp_telemat.sqlrsit_coletor;

DROP SYNONYM sqlrcon_coacao_sagem;
CREATE SYNONYM sqlrcon_coacao_sagem FOR cp_telemat.sqlrcon_coacao_sagem ;

DROP SYNONYM sqlratualiza_sagem_digital2;
CREATE SYNONYM sqlratualiza_sagem_digital2 FOR cp_telemat.sqlratualiza_sagem_digital2;

DROP SYNONYM sqlrproc_sagem_template2;
CREATE SYNONYM sqlrproc_sagem_template2 FOR cp_telemat.sqlrproc_sagem_template2;

DROP SYNONYM sqlratualiza_tsi1_digital2;
CREATE SYNONYM sqlratualiza_tsi1_digital2 FOR cp_telemat.sqlratualiza_tsi1_digital2;

DROP SYNONYM sqlrcon_coacao_tsi1;
CREATE SYNONYM sqlrcon_coacao_tsi1 FOR cp_telemat.sqlrcon_coacao_tsi1;

DROP SYNONYM sqlrproc_tsi1_template2;
CREATE SYNONYM sqlrproc_tsi1_template2 FOR cp_telemat.sqlrproc_tsi1_template2;

DROP SYNONYM sqlrgrava_cp_novell_APPL;
CREATE SYNONYM sqlrgrava_cp_novell_APPL FOR cp_telemat.sqlrgrava_cp_novell_APPL;

DROP SYNONYM sqlrolha_overwrite_appl;
CREATE SYNONYM sqlrolha_overwrite_appl FOR cp_telemat.sqlrolha_overwrite_appl;

--DROP SYNONYM sqlrolha_alarme_appl;
--CREATE SYNONYM sqlrolha_alarme_appl FOR cp_telemat.sqlrolha_alarme_appl;

DROP SYNONYM sqlrcons_term_fer_tcp6;
CREATE SYNONYM sqlrcons_term_fer_tcp6 FOR cp_telemat.sqlrcons_term_fer_tcp6;

--DROP SYNONYM sqlrepPto_interj;
--CREATE SYNONYM sqlrepPto_interj FOR cp_telemat.sqlrepPto_interj;

DROP SYNONYM sqlrepPto_interj3;
CREATE SYNONYM sqlrepPto_interj3 FOR cp_telemat.sqlrepPto_interj3;


--DROP SYNONYM sqlgrava_rep4interj;
--CREATE SYNONYM sqlgrava_rep4interj FOR cp_telemat.sqlgrava_rep4interj;

DROP SYNONYM sqlgrava_rep6interj;
CREATE SYNONYM sqlgrava_rep6interj FOR cp_telemat.sqlgrava_rep6interj;

DROP SYNONYM sqlproc_empregador2;
CREATE SYNONYM sqlproc_empregador2 FOR cp_telemat.sqlproc_empregador2;

DROP SYNONYM sqlproc_funcionario;
CREATE SYNONYM sqlproc_funcionario FOR cp_telemat.sqlproc_funcionario;

DROP SYNONYM sqlins_idpis;
CREATE SYNONYM sqlins_idpis FOR cp_telemat.sqlins_idpis;

DROP SYNONYM sqllimpa_idpis;
CREATE SYNONYM sqllimpa_idpis FOR cp_telemat.sqllimpa_idpis;

DROP SYNONYM sqlproc_dadosfunc3;
CREATE SYNONYM sqlproc_dadosfunc3 FOR cp_telemat.sqlproc_dadosfunc3;

DROP SYNONYM sqlsinal_statidpis;
CREATE SYNONYM sqlsinal_statidpis FOR cp_telemat.sqlsinal_statidpis;

DROP SYNONYM sqllog_loadfunc;
CREATE SYNONYM sqllog_loadfunc FOR cp_telemat.sqllog_loadfunc;

DROP SYNONYM sqlrepara_comando_appl;
CREATE SYNONYM sqlrepara_comando_appl FOR cp_telemat.sqlrepara_comando_appl;


-- 10 dig tsi1
DROP SYNONYM sqlcons_10dig ;
CREATE SYNONYM sqlcons_10dig FOR cp_telemat.sqlcons_10dig;

DROP SYNONYM sqlatu_10tsi1_clob;
CREATE SYNONYM sqlatu_10tsi1_clob FOR cp_telemat.sqlatu_10tsi1_clob;

-- carga automatica
drop synonym sqlrep_fimInsAuto3;
create synonym sqlrep_fimInsAuto3 for cp_telemat.sqlrep_fimInsAuto3;

drop synonym sqlrep_fimExcAuto4;
create synonym sqlrep_fimExcAuto4 for cp_telemat.sqlrep_fimExcAuto4;

drop synonym sqlrep_autoIns4;
create synonym sqlrep_autoIns4 for cp_telemat.sqlrep_autoIns4;

drop synonym sqlrep_autoExc5;
create synonym sqlrep_autoExc5 for cp_telemat.sqlrep_autoExc5;


-- INMETRO
drop synonym sqlinform_rep;
create synonym sqlinform_rep for cp_telemat.sqlinform_rep;

drop synonym SQLOLHA_INME_ALARME_APPL;
create synonym SQLOLHA_INME_ALARME_APPL for cp_telemat.SQLOLHA_INME_ALARME_APPL;

drop synonym SQLGRV_LOGERROS;
create synonym SQLGRV_LOGERROS for cp_telemat.SQLGRV_LOGERROS;

drop synonym sqlrep_alarme;
create synonym sqlrep_alarme for cp_telemat.sqlrep_alarme;

drop synonym sqlrnivel_biomet2;
create synonym sqlrnivel_biomet2 for cp_telemat.sqlrnivel_biomet2;

--DROP SYNONYM sqlrproc_outrosbios;
--CREATE SYNONYM sqlrproc_outrosbios FOR cp_telemat.sqlrproc_outrosbios;

DROP SYNONYM sqlrproc_binarybios;
CREATE SYNONYM sqlrproc_binarybios FOR cp_telemat.sqlrproc_binarybios;


--DROP SYNONYM sqlratu_outrosbios;
--CREATE SYNONYM sqlratu_outrosbios FOR cp_telemat.sqlratu_outrosbios;

DROP SYNONYM sqlratu_binarybios;
CREATE SYNONYM sqlratu_binarybios FOR cp_telemat.sqlratu_binarybios;

drop synonym sqlrinfo_comcpf;
create synonym sqlrinfo_comcpf for cp_telemat.sqlrinfo_comcpf;

drop synonym sqlproc_PisNome2;
CREATE SYNONYM sqlproc_PisNome2 FOR cp_telemat.sqlproc_PisNome2;

drop synonym sqlproc_icardpis4;
CREATE SYNONYM sqlproc_icardpis4 FOR cp_telemat.sqlproc_icardpis4;

drop synonym sqlrproc_AColetivo;
CREATE SYNONYM sqlrproc_AColetivo FOR cp_telemat.sqlrproc_AColetivo;

DROP SYNONYM sqlprephist_RStF;
CREATE SYNONYM sqlprephist_RStF FOR cp_telemat.sqlprephist_RStF;

DROP SYNONYM sqlfinal_histRStF;
CREATE SYNONYM sqlfinal_histRStF FOR cp_telemat.sqlfinal_histRStF;

DROP SYNONYM sqlhist_RfuncInme;
CREATE SYNONYM sqlhist_RfuncInme FOR cp_telemat.sqlhist_RfuncInme;

DROP SYNONYM sqlrperm_novocomando;
CREATE SYNONYM sqlrperm_novocomando FOR cp_telemat.sqlrperm_novocomando;

DROP SYNONYM sqlrdig_rejeit2;
CREATE SYNONYM  sqlrdig_rejeit2 FOR cp_telemat.sqlrdig_rejeit2;




-- dig auto
drop synonym sqlfim_rExcAutoDigit3;
CREATE SYNONYM sqlfim_rExcAutoDigit3 for cp_telemat.sqlfim_rExcAutoDigit3 ;

drop synonym sqlfim_rLdig;
CREATE SYNONYM sqlfim_rLdig for cp_telemat.sqlfim_rLdig;

drop synonym sqller_RautoLoadDigit5;
CREATE SYNONYM sqller_RautoLoadDigit5 for cp_telemat.sqller_RautoLoadDigit5;

drop synonym sqller_RautoExclDigit4;
CREATE SYNONYM sqller_RautoExclDigit4 for cp_telemat.sqller_RautoExclDigit4;

drop synonym sqlload_Rlistadig4;
CREATE SYNONYM sqlload_Rlistadig4 for cp_telemat.sqlload_Rlistadig4;

DROP SYNONYM sqlhist_Rfunc2;
CREATE SYNONYM sqlhist_Rfunc2 for cp_telemat.sqlhist_Rfunc2;

DROP SYNONYM sqlhist_Rbio3;
CREATE SYNONYM sqlhist_Rbio3 for cp_telemat.sqlhist_Rbio3;

DROP SYNONYM sqlgrava_repManEsp;
CREATE SYNONYM sqlgrava_repManEsp for cp_telemat.sqlgrava_repManEsp;

DROP SYNONYM sqlrhora_gerbiof3;
CREATE SYNONYM sqlrhora_gerbiof3 FOR cp_telemat.sqlrhora_gerbiof3;

-- viav
DROP SYNONYM sqlrperm_ConxViaV;
CREATE SYNONYM sqlrperm_ConxViaV FOR cp_telemat.sqlrperm_ConxViaV;

DROP SYNONYM sqlrep_ExistLisTab;
CREATE SYNONYM sqlrep_ExistLisTab  FOR cp_telemat.sqlrep_ExistLisTab;

DROP SYNONYM sqlrep_LeFuncTab;
CREATE SYNONYM sqlrep_LeFuncTab  FOR cp_telemat.sqlrep_LeFuncTab;

DROP SYNONYM sqlgrava_RepListaMat;
CREATE SYNONYM sqlgrava_RepListaMat FOR cp_telemat.sqlgrava_RepListaMat;
