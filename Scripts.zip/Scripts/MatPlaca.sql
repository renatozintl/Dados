CREATE OR REPLACE FUNCTION sqlver_matplaca (cMatric varchar2, cDataRec in out varchar2, cPlaca in out varchar2)
   RETURN NUMBER IS
   dDataPlaca date;
   Ret    NUMBER;

BEGIN
	Ret := 1;
	cDataRec := '1111111111';
	cPlaca := '000000000000000';
   
    -- procura pela Matricula em DAT10
    BEGIN
		SELECT replace(upper(PLACA), ' ',''), to_char(HORAREC, 'ddmmyyhh24mi') INTO cPlaca, cDataRec  
			FROM DAT10  
	    WHERE ICARD = cMatric;
    EXCEPTION
		WHEN NO_DATA_FOUND then 
			Ret := 0;
		WHEN OTHERS then
		    Ret := -1;
    END;
    
	return (Ret);
	
END sqlver_matplaca;
/

