CREATE OR REPLACE FUNCTION sqlatG3G5_tab_acesso_geral (cRegistro in VARCHAR2, Posic in VARCHAR2, cReg_dthora in VARCHAR2) 
   RETURN NUMBER IS
      --NumMat VARCHAR2(12);
      NumMat CHAR(12);
      VarAux VARCHAR2(12);
      IniHA DATE;
      FimHA DATE;
      IniIJ DATE;
      FimIJ DATE;
      HorAntD DATE;
      IniNR36 DATE;
      FimNR36 DATE;
      cDiasSuc VARCHAR2(2);
      cSubnv VARCHAR2(9);
      cPlanta VARCHAR2(9);
      nTamG NUMBER;
      reco_lock EXCEPTION;
      PRAGMA EXCEPTION_INIT (reco_lock, -54);  
      Retorno NUMBER;
BEGIN
	Retorno := 0;      
	NumMat := substr(cRegistro, 1, 12);
	IniHA := TO_DATE (substr(cReg_dthora, 1, 12), 'DDMMRRHH24MISS');
	FimHA := TO_DATE (substr(cReg_dthora, 13, 12), 'DDMMRRHH24MISS');
	IniIJ := TO_DATE (substr(cReg_dthora, 25, 12), 'DDMMRRHH24MISS');
	FimIJ := TO_DATE (substr(cReg_dthora, 37, 12), 'DDMMRRHH24MISS');
	HorAntD := TO_DATE (substr(cReg_dthora, 49, 12), 'DDMMRRHH24MISS');
	cDiasSuc := substr(cReg_dthora, 61, 2);
	IniNR36 := TO_DATE (substr(cReg_dthora, 63, 12), 'DDMMRRHH24MISS');
	FimNR36 := TO_DATE (substr(cReg_dthora, 75, 12), 'DDMMRRHH24MISS');
	
	BEGIN
		select data_length INTO nTamG 
			from   user_tab_columns
			where  table_name = 'CONTROLE' and	column_name = 'GRUPO';
	EXCEPTION
		WHEN OTHERS THEN 
			nTamG := 3;		-- ASSUME TAMANHO DO CAMPO LACES COM 3 DIGITOS
	END;
	
	
	IF (nTamG = 5) then							
		cSubnv :=  substr(cRegistro, 14, 7);
		cPlanta := substr(cRegistro, 21,5);
	ELSE
		cSubnv := SUBSTR (substr(cRegistro, 14, 7), 1, 5);
		cPlanta := SUBSTR (substr(cRegistro, 21,5), 1, 3);
	END IF;
	
	-- atualiza tab.CONTROLE
	BEGIN
		SELECT Icard into VarAux from Controle 
			--WHERE rowid = chartorowid (Posic) for update nowait;
			WHERE Icard = NumMat for update nowait;

		UPDATE controle 
			SET Situa = substr(cRegistro, 13, 1),
				--Subnv = substr(cRegistro, 14, 5),
				--PLANTA = substr(cRegistro, 21,3),
				Subnv = cSubnv,
				PLANTA = cPlanta,
				Ultrs = substr(cRegistro, 24+2, 25),
				Fx_Dta = substr(cRegistro, 49+2, 11),
				Qtd_Mens = substr(cRegistro, 60+2, 2),
				Cred_Fx1 = substr(cRegistro, 62+2, 2),
				Cred_Fx2 = substr(cRegistro, 64+2, 2),
				Cred_Fx3 = substr(cRegistro, 66+2, 2),
				Cred_Fx4 = substr(cRegistro, 68+2, 2),
				Cred_Fx5 = substr(cRegistro, 70+2, 2),
				Cred_Fx6 = substr(cRegistro, 72+2, 2),
				UltPas_Ref = substr(cRegistro, 74+2, 10),
				ULTRSEG = substr(cRegistro, 84+2, 2),
				VER_RET = substr(cRegistro, 86+2, 1)
				
		--WHERE rowid = chartorowid (Posic);
		WHERE Icard = NumMat;
		COMMIT;
	
	EXCEPTION
		WHEN reco_lock THEN           -- reg. ja'lockado
			Retorno := -3;
		WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
			Retorno := -1;
		WHEN OTHERS THEN
			Retorno := -1;
	END;
 
	-- atualiza tab.DATAHORA
	BEGIN
		SELECT Icard into VarAux from DATAHORA 
			WHERE Icard = NumMat for update nowait;
   
		UPDATE DATAHORA 
			SET Ini_Halm = IniHA,
				Fim_Halm = FimHA,
				Ini_Intj = IniIJ,
				Fim_Intj = FimIJ,
				Fim_AntiD = HorAntD,
				Dias_Suc = cDiasSuc ,
				Ini_NR36 = IniNR36, 
				Fim_NR36 = FimNR36
   	 	WHERE Icard = NumMat;
		COMMIT;
   
	EXCEPTION
		WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
			INSERT INTO DATAHORA (Icard, Ini_Halm, Fim_Halm, Ini_Intj, Fim_Intj, Fim_AntiD, Dias_Suc, Ini_NR36, Fim_NR36) 
         				  values (NumMat, IniHA, FimHA, IniIJ, FimIJ, HorAntD, cDiasSuc, IniNR36, FimNR36);
			COMMIT;
		WHEN OTHERS THEN
			Retorno := -1;
	END;
	return (Retorno);
END sqlatG3G5_tab_acesso_geral;
/


