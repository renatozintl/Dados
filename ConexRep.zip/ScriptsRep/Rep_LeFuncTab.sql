CREATE OR REPLACE FUNCTION sqlrep_LeFuncTab (cEndIp VARCHAR2, cNomeArq VARCHAR2, cMatProc VARCHAR2, cLisFunc OUT VARCHAR2, cUltMat OUT VARCHAR2, nTotal NUMBER)   
RETURN NUMBER IS

nCont NUMBER;
XFunc VARCHAR2(12);



cursor CURSOR_FUNC is
select LINHA
  from
( select LINHA 
    from LISTA WHERE END_IP = cEndIp AND upper(ARQUIVO) = upper(cNomeArq) AND LINHA > cMatProc order by LINHA )
 		where ROWNUM <= nTotal
   		order by LINHA ;


BEGIN

	cLisFunc := '';
	XFunc := '000000000000';
	nCont := 0;
	
	OPEN CURSOR_FUNC;
	LOOP
		FETCH CURSOR_FUNC  INTO XFunc;
		EXIT WHEN CURSOR_FUNC%NOTFOUND;
	
		cLisFunc := cLisFunc ||XFunc;
		nCont := nCont+1;
	END LOOP;
	
	cUltMat := XFunc;
    close CURSOR_FUNC;	
	
	return (nCont);
	
END sqlrep_LeFuncTab;
/


