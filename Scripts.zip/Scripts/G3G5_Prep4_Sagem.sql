CREATE OR REPLACE  PROCEDURE G3G5_PREP4_SAGEM 
IS

TYPE icard_type IS TABLE OF CONTDIG_SAGEM.icard%TYPE 
	INDEX BY binary_integer;
TYPE status_type IS TABLE OF CONTDIG_SAGEM.status%TYPE 
	INDEX BY binary_integer;
	
l_icard icard_type;
l_status status_type;
p_rec DIG001%rowtype;

total number;
aux_icard char(12) := '000000000000';
nCont number;
nAchouGrupo number;

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock,-54);  -- erro quando registro lockado 
tem_deadlock EXCEPTION; 
PRAGMA EXCEPTION_INIT (tem_deadlock, -60); 
	
BEGIN

	SELECT ICARD, STATUS 
		BULK COLLECT INTO l_icard, l_status  
	from 
		CONTDIG_SAGEM 
	where 
		STATUS = '1' or STATUS = '3' or STATUS = '8';
		
	total := l_icard.count;
	
	-- ******************************************************************
	-- PARA TODOS AS BIOMETRIAS  CADASTRADOS/INSERIDOS/DELETADOS
	FOR indx IN 1 .. total     
	LOOP
		nAchouGrupo := 0;		-- presupoe q nao tem ICARDfunc x grupo correspondente em tab DAT08 X DAT07
		
		-- *************************************************************************
		-- prepara os ids excluidos (controle.situa = invalido) ou grupos da controle alterados, retirando as biometrias de todos os equipamentos 
		IF (l_status(indx) = '3' or l_status(indx) = '8' ) THEN		-- alterados grupos (3) ou situa invalidos  (8)
		
			-- MONTA temporaria matricula x equipamentos sagem
			INSERT INTO TMP_DIG101 (ICARD, END_IP, STATUS, BIO_TIPO) 		
				SELECT distinct l_icard(indx), DAT07.end_ip, '0', DAT07.BIO_TIPO
				FROM DAT07
				WHERE (BIO_TIPO = '6' OR BIO_TIPO = '7') and END_IP <> '000.000.000.000';

			-- *****************************************************************
			-- COMO ESTA EXCLUINDO O FUNCIONARIO DA EMPRESA (CONTROLE.SITUA = '1' INVALIDO), TIRA DA LISTA DE INCLUSAO DE TODOS OS equipamentos SAGEM
			-- COMO ALTEROU O GRUPO, TIRA DA LISTA DE INCLUSAO DE TODOS OS equipamentos SAGEM

			-- ALTERACAO ABAIXO
			-- VAI DELETAR A MATRICULA DE QUALQUER STATUS PORQUE PODE CAIR NA SITUACAO EM QUE HA INCLUSAO DA MATRICULA, MAS NAO VAI PORQUE O EQUIPAMENTO 'ESTA OCUPADO' (nova resposta do microdimarms).
			-- SE HOUVER POSTERIORMENTE EXCLUSAO DESSA MESMA MATRICULA, DEVE=-SE EXCLUIR A INCLUSAO DESSA MATRICULA DA TABELA
			
			for c1 in (select rowid from DIG001 
				--WHERE ICARD = l_icard(indx) AND (STATUS = '0' OR STATUS = '1') )
				WHERE ICARD = l_icard(indx) )
			loop
				BEGIN
					select * into p_rec from DIG001 where rowid = c1.rowid for update nowait;		
					delete from DIG001 where rowid = c1.rowid;

				EXCEPTION
					when reco_lock then NULL ;
					when tem_deadlock then NULL ;
					when NO_DATA_FOUND then NULL;
					when OTHERS then NULL;
				END;
			end loop;					

			-- ******************************************************************
			-- obs : nao excluo das temporarias de exclusao porque elas estao vazias

		END IF;

		
		IF (l_status(indx) = '1' or l_status(indx) = '3' ) THEN		-- incluido/alterado BIOMETRIA (1)   ou   alterados grupos (3) 

			-- ******************************************************************
			-- para todos icards q alteraram digital, distribui nos equipamentos de acordo com o grupo cadastrado em 
			-- CONTROLE, DAT07,DAT08 
			-- MONTA temporaria matricula com codins com permissao acesso

			INSERT into TMP_DIG001 (ICARD, END_IP, STATUS, BIO_TIPO)
				SELECT distinct l_icard(indx), end_ip, '0', bio_tipo
					FROM 
						(
						-- seleciona os equipamentos que fazem parte dos grupos do usu�rio
						SELECT distinct l_icard(indx),  dat07.end_ip, '0', dat07.bio_tipo
							from dat07, dat08
							where
								(dat07.end_ip <> '000.000.000.000' and
								 TO_NUMBER(dat08.grupo) in (
										--select TO_NUMBER(grupo) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT <> '1')			-- ERA (SITUA = '0' OR SITUA = '7')
										select TO_NUMBER(grupo) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT = '2')				-- VER_DIGIT 2 = BIO(1:N)
										  union
										--select TO_NUMBER(grupo1) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT <> '1')
										select TO_NUMBER(grupo1) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT = '2')				-- VER_DIGIT 2 = BIO(1:N)
										  union	
										--select TO_NUMBER(grupo2) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT <> '1')
										select TO_NUMBER(grupo2) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT = '2')				-- VER_DIGIT 2 = BIO(1:N)
										  union
										--select TO_NUMBER(grupo3) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT <> '1')
										select TO_NUMBER(grupo3) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT = '2')				-- VER_DIGIT 2 = BIO(1:N)
										  union
										--select TO_NUMBER(grupo_sab) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT <> '1')
										select TO_NUMBER(grupo_sab) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT = '2')				-- VER_DIGIT 2 = BIO(1:N)
										  union
										--select TO_NUMBER(grupo_dom) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT <> '1')
										select TO_NUMBER(grupo_dom) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT = '2')				-- VER_DIGIT 2 = BIO(1:N)
										  union
										--select TO_NUMBER(grupo_fer) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT <> '1')
										select TO_NUMBER(grupo_fer) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1') AND (VER_DIGIT = '2')				-- VER_DIGIT 2 = BIO(1:N)
										  union
										--select TO_NUMBER(A.grupo) from MATNGRUPOS A, CONTROLE B where A.ICARD = l_icard(indx) AND B.ICARD = l_icard(indx) AND (B.SITUA <> '1') AND (B.VER_DIGIT <> '1')
										select TO_NUMBER(A.grupo) from MATNGRUPOS A, CONTROLE B where A.ICARD = l_icard(indx) AND B.ICARD = l_icard(indx) AND (B.SITUA <> '1') AND (B.VER_DIGIT = '2')				-- VER_DIGIT 2 = BIO(1:N)
										  union
										--select TO_NUMBER(A.grupo) from MATGRUPO A, CONTROLE B where A.ICARD = l_icard(indx) AND B.ICARD = l_icard(indx) AND (B.SITUA <> '1') AND (B.VER_DIGIT <> '1')
										select TO_NUMBER(A.grupo) from MATGRUPO A, CONTROLE B where A.ICARD = l_icard(indx) AND B.ICARD = l_icard(indx) AND (B.SITUA <> '1') AND (B.VER_DIGIT = '2')				-- VER_DIGIT 2 = BIO(1:N)
										) and 
								TO_NUMBER(dat07.laces) = TO_NUMBER(dat08.laces) and
								TO_NUMBER(dat07.planta) = TO_NUMBER(dat08.planta) and
								(dat07.bio_tipo = '6' or dat07.bio_tipo = '7')) 							
					UNION
						SELECT distinct l_icard(indx),  dat07.end_ip, '0', dat07.bio_tipo
							from dat07, dat08, matcodin 
							where
								matcodin.icard = l_icard(indx) and
								matcodin.end_ip <> '000.000.000.000' and 
								matcodin.end_ip = dat07.end_ip and 
								(dat07.bio_tipo = '6' or dat07.bio_tipo = '7') 
						);

			-- para quem incluiu/alterou digital (status 1) ou mudou de grupo (status 3)
			--IF (l_status(indx) = '3') THEN  
			IF (l_status(indx) = '1' OR l_status(indx) = '3') THEN
				-- ******************************************************************
				-- deve-se excluir da tabela de exclusao temporaria as biometrias sagem que fazem parte do novo grupo
			
				DELETE FROM TMP_DIG101
				WHERE EXISTS
					(SELECT TMP_DIG001.icard 
						FROM TMP_DIG001
						WHERE TMP_DIG001.icard = TMP_DIG101.icard and
								TMP_DIG001.END_IP = TMP_DIG101.END_IP  and
								TMP_DIG001.icard = l_icard(indx)
					);

				-- ******************************************************************
				-- deve-se excluir da tabela de exclusao final as biometrias  que fazem parte do novo grupo

				-- ALTERACAO ABAIXO
				-- VAI DELETAR A MATRICULA DE QUALQUER STATUS PORQUE PODE CAIR NA SITUACAO EM QUE HA INCLUSAO DA MATRICULA, MAS NAO VAI PORQUE O EQUIPAMENTO 'ESTA OCUPADO' (nova resposta do microdimarms).
				-- SE HOUVER POSTERIORMENTE EXCLUSAO DESSA MESMA MATRICULA, DEVE=-SE EXCLUIR A INCLUSAO DESSA MATRICULA DA TABELA
				
				for c1 in (select rowid from DIG101 
					--WHERE ICARD = l_icard(indx) AND (STATUS = '0' OR STATUS = '1') )
					WHERE ICARD = l_icard(indx) )
				loop
					BEGIN
						SELECT * into p_rec from DIG101 where rowid = c1.rowid for update nowait;		
						DELETE from DIG101 where rowid = c1.rowid;

					EXCEPTION
						when reco_lock then NULL ;
						when tem_deadlock then NULL ;
						when NO_DATA_FOUND then NULL;
						when OTHERS then NULL;
					END;
				end loop;					
								
			END IF;
		END IF;

		-- ****************************************************	
		-- PREPARA TABELA DE INCLUSAO DE BIOMETRIA SAGEM
		
		SELECT count(*) into nCont from TMP_DIG001;					
		IF (nCont != 0) then
			-- insere na tabela final DIG001  os ICARD x equipamentos e STATUS de carga (0 / 1= a carregar)
			FOR x in (select ICARD, END_IP, STATUS, BIO_TIPO from TMP_DIG001) loop
				BEGIN
					SELECT icard into aux_icard from DIG001 
						WHERE ICARD = x.ICARD and
							END_IP = x.END_IP for update nowait;

					UPDATE DIG001 SET STATUS = '1' 
						WHERE  ICARD = x.ICARD and
							   END_IP = x.END_IP;
				EXCEPTION
					WHEN NO_DATA_FOUND THEN
						INSERT INTO DIG001 (ICARD, END_IP, STATUS, BIO_TIPO) 
						values (x.ICARD, x.END_IP, '1', x.BIO_TIPO);
				END;
			END LOOP;
				
			nAchouGrupo := 1;

			-- coloca o equipamento na tab. DIG002 (CARGA LISTA) q n�o existir
			insert into DIG002 (END_IP, DATA_LOAD, STATUS, BIO_TIPO)
				select distinct END_IP, sysdate(), '0', BIO_TIPO
				from
					DIG001
				where
					END_IP not in ( select END_IP from DIG002 );


		END IF;

		-- ******************************************************************
		-- PREPARA TABELA TEMPORARIA DE EXCLUSAO COM OS ENDERE�OS IP DOS EQUIPAMENTOS

		SELECT count(*) into nCont from TMP_DIG101;					
		IF (nCont != 0) then
			-- insere na tabela final DIG101  os ID COM STATUS de carga (0 / 1= a excluir)
			FOR x in (select ICARD, END_IP, BIO_TIPO from TMP_DIG101) loop
				BEGIN
					SELECT icard into aux_icard from DIG101 
						WHERE ICARD = x.icard AND
							END_IP = x.END_IP for update nowait;

					UPDATE DIG101 SET STATUS = '1' 
						WHERE  ICARD = x.icard AND
							   END_IP = x.END_IP;
				EXCEPTION
					WHEN NO_DATA_FOUND THEN
						INSERT INTO DIG101 (ICARD, END_IP, STATUS, BIO_TIPO) 
						values (x.icard, x.END_IP, '1', x.BIO_TIPO);
				END;
			END LOOP;

			nAchouGrupo := 1;
				
			-- coloca o equipamento na tab. DIG102 (CARGA LISTA) o equipamento q n�o existir
			INSERT into DIG102 (END_IP, DATA_LOAD, STATUS, BIO_TIPO)
				SELECT distinct END_IP, SYSDATE(), '0', BIO_TIPO
				from
					DIG101
				where
					END_IP not in ( select END_IP from DIG102 );
		END IF;

		-- atualiza status da matricula, como tratado
		IF (nAchouGrupo = 1) THEN 
			UPDATE CONTDIG_SAGEM SET STATUS = '0' 
				where ICARD = l_icard(indx);
		END IF;
		
		COMMIT;

	END LOOP;
	
end G3G5_PREP4_SAGEM;
/
