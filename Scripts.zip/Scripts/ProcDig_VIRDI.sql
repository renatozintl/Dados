CREATE or REPLACE FUNCTION sqlproc_digitVIRDI (MATRIC VARCHAR2, cEndIp VARCHAR2, cBioTipo in VARCHAR2, nQtdBytes in NUMBER, 
cTempl_Tit1 IN OUT VARCHAR2, cTempl_Tit2 IN OUT VARCHAR2, cTempl_Tit3 IN OUT VARCHAR2, cTempl_Tit4 IN OUT VARCHAR2, 
cTempl_Tit5 IN OUT VARCHAR2, cTempl_Tit6 IN OUT VARCHAR2, cTempl_Tit7 IN OUT VARCHAR2, 
cTempl_Alt1 IN OUT VARCHAR2, cTempl_Alt2 IN OUT VARCHAR2, cTempl_Alt3 IN OUT VARCHAR2, cTempl_Alt4 IN OUT VARCHAR2, 
cTempl_Alt5 IN OUT VARCHAR2, cTempl_Alt6 IN OUT VARCHAR2, cTempl_Alt7 IN OUT VARCHAR2) 
RETURN NUMBER IS

Retfun NUMBER;
nNumDig NUMBER;
total NUMBER;
RECO_LOCK EXCEPTION;
PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);
Alt NUMBER;
Pad NUMBER;

i NUMBER; 
tam NUMBER; 
pos NUMBER; 
cDigital VARCHAR2(1200);

begin
    Pad := 0;
    Alt := 0;
    Retfun := 3;      -- sem templ padrao e sem templ alternativo
    
	-- PROCURA PELO PADRAO
	BEGIN
		SELECT TPDIG, TO_CHAR(DIGITAL)  into nNumDig, cDigital FROM CONTDIG_BIOMET  
		WHERE ICARD = MATRIC AND 
		  	  BIO_TIPO = cBioTipo  AND 
		  	  TPDIG = 0;		-- digital Padrao (0)
		  	  
		Pad := 1;
		total := length (cDigital);
		
		-- verifica se digital armazenada � do tipo q se esta procurando, atraves da qtde de bytes
		IF (total = (nQtdBytes * 2)) THEN 
			i := 1;
			tam := 0;
			pos := 1 + tam;

			WHILE (total >= 160) LOOP
				IF (i = 1)    THEN cTempl_Tit1 := substr (cDigital, pos, 160);
				ELSIF (i = 2) THEN cTempl_Tit2 := substr (cDigital, pos, 160);
				ELSIF (i = 3) THEN cTempl_Tit3 := substr (cDigital, pos, 160);
				ELSIF (i = 4) THEN cTempl_Tit4 := substr (cDigital, pos, 160);
				ELSIF (i = 5) THEN cTempl_Tit5 := substr (cDigital, pos, 160);
				ELSIF (i = 6) THEN cTempl_Tit6 := substr (cDigital, pos, 160);
				ELSIF (i = 7) THEN cTempl_Tit7 := substr (cDigital, pos, 160);
				END IF;

				tam := tam+160;
				i := i+1;
				total := total-160;
				pos := 1 + tam;
			END LOOP;

			IF (total > 0) THEN
				IF (i = 1)    THEN cTempl_Tit1 := substr (cDigital, pos, total);
				ELSIF (i = 2) THEN cTempl_Tit2 := substr (cDigital, pos, total);
				ELSIF (i = 3) THEN cTempl_Tit3 := substr (cDigital, pos, total);
				ELSIF (i = 4) THEN cTempl_Tit4 := substr (cDigital, pos, total);
				ELSIF (i = 5) THEN cTempl_Tit5 := substr (cDigital, pos, total);
				ELSIF (i = 6) THEN cTempl_Tit6 := substr (cDigital, pos, total);
				ELSIF (i = 7) THEN cTempl_Tit7 := substr (cDigital, pos, total);
				END IF;
			END IF;
		
		ELSE		-- nao � a digital procurada ou foi armazenada errada
			Pad := 0;
		END IF;
		
		
	EXCEPTION
		WHEN NO_DATA_FOUND THEN 
			Pad := 0;
		WHEN OTHERS THEN 
			Pad := 0;
	END;
	
	
	-- PROCURA PELO ALTERNATIVO
	BEGIN
		SELECT TPDIG, TO_CHAR(DIGITAL)  into nNumDig, cDigital FROM CONTDIG_BIOMET  
			WHERE ICARD = MATRIC AND 
			  	  BIO_TIPO = cBioTipo  AND 
			  	  TPDIG = 1;		-- digital Alternativo (1)
			  	  
		Alt := 1;
		total := length (cDigital);
			
		-- verifica se digital armazenada � do tipo q se esta procurando, atraves da qtde de bytes
		IF (total = (nQtdBytes * 2)) THEN 
			i := 1;
			tam := 0;
			pos := 1 + tam;
	
			WHILE (total >= 160) LOOP
				IF (i = 1)    THEN cTempl_Alt1 := substr (cDigital, pos, 160);
				ELSIF (i = 2) THEN cTempl_Alt2 := substr (cDigital, pos, 160);
				ELSIF (i = 3) THEN cTempl_Alt3 := substr (cDigital, pos, 160);
				ELSIF (i = 4) THEN cTempl_Alt4 := substr (cDigital, pos, 160);
				ELSIF (i = 5) THEN cTempl_Alt5 := substr (cDigital, pos, 160);
				ELSIF (i = 6) THEN cTempl_Alt6 := substr (cDigital, pos, 160);
				ELSIF (i = 7) THEN cTempl_Alt7 := substr (cDigital, pos, 160);
				END IF;
	
				tam := tam+160;
				i := i+1;
				total := total-160;
				pos := 1 + tam;
			END LOOP;
	
			IF (total > 0) THEN
				IF (i = 1)    THEN cTempl_Alt1 := substr (cDigital, pos, total);
				ELSIF (i = 2) THEN cTempl_Alt2 := substr (cDigital, pos, total);
				ELSIF (i = 3) THEN cTempl_Alt3 := substr (cDigital, pos, total);
				ELSIF (i = 4) THEN cTempl_Alt4 := substr (cDigital, pos, total);
				ELSIF (i = 5) THEN cTempl_Alt5 := substr (cDigital, pos, total);
				ELSIF (i = 6) THEN cTempl_Alt6 := substr (cDigital, pos, total);
				ELSIF (i = 7) THEN cTempl_Alt7 := substr (cDigital, pos, total);
				END IF;
			END IF;
			
		ELSE		-- nao � a digital procurada ou foi armazenada errada
			Alt := 0;
		END IF;
			
			
	EXCEPTION
		WHEN NO_DATA_FOUND THEN 
			Alt := 0;
		WHEN OTHERS THEN 
			Alt := 0;
	END;


	-- PREPARA RESULTADO	
	if (Pad = 1) then
	    if (Alt = 1) then
			Retfun := 0;   -- tem padrao e tem alternativo
		else 
			Retfun := 1;   -- tem padrao e nao tem alternativo
    	end if;
	end if;
	if (Pad = 0) then
	    if (Alt = 1) then
			Retfun := 2;   -- nao tem padrao e tem alternativo
		else 
			Retfun := 3;   -- nao tem padrao e nao tem alternativo
    	end if;
	end if;

	IF (Retfun = 3)	then 	-- digital nao cadastrado
		INSERT INTO DIGLOAD001 (END_IP, ICARD, BIO_TIPO) 
			VALUES (cEndIp, MATRIC, cBioTipo);
				
		COMMIT;
	END IF;
	
	return (Retfun);
	
	
END sqlproc_digitVIRDI;
/

