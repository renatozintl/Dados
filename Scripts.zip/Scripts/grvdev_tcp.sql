CREATE OR REPLACE FUNCTION sqlbloco_col_dev_tcp (Registro in VARCHAR2)
   RETURN NUMBER IS
      Ret NUMBER;

BEGIN
   INSERT INTO TABDEV (ICARD, DIAM, MESM, ANOM, HORAM, SEGUNDO, END_IP, LISTA, STATUS) 
      VALUES (SUBSTR(Registro, 1, 12), SUBSTR(Registro, 13, 2),
              SUBSTR(Registro, 15, 2), SUBSTR(Registro, 17, 2),
	      SUBSTR(Registro, 19, 4), SUBSTR(Registro, 23, 2),
              SUBSTR(Registro, 25, 15), SUBSTR(Registro, 40, 15),               SUBSTR(Registro, 55, 1));
   Return (0);
END sqlbloco_col_dev_tcp;
/
