CREATE or REPLACE FUNCTION sqller_RautoLoadDigit5 (cEndIp in VARCHAR2, cListaMat in out VARCHAR2, nTotal in NUMBER, nAutoGerFun NUMBER, nAutoComFun NUMBER ) 
RETURN NUMBER IS

xCont NUMBER;
cStatus VARCHAR2(1);
cBio_Tipo VARCHAR2(1);
cAux VARCHAR2(12);
nPendExcFun NUMBER;
nExec NUMBER;

nQtdPendFun NUMBER;
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

--SAGEM
cursor ldigit_cur1 is 
	SELECT IFUNC, STATUS FROM RDIG001 
	--WHERE END_IP = cEndIp AND STATUS != '0' AND STATUS != '2' 
	WHERE END_IP = cEndIp AND STATUS != '0'
	order by IFUNC for update of STATUS;

--TSI1
cursor ldigit_cur2 is 
	SELECT IFUNC, STATUS FROM RDIG003 
	--WHERE END_IP = cEndIp AND STATUS != '0' AND STATUS != '2' 
	WHERE END_IP = cEndIp AND STATUS != '0'
	order by IFUNC for update of STATUS;

--VIRDI
cursor ldigit_cur3 is 
	SELECT IFUNC, STATUS FROM RDIG004 
	--WHERE END_IP = cEndIp AND STATUS != '0' AND STATUS != '2' 
	WHERE END_IP = cEndIp AND STATUS != '0'
	order by IFUNC for update of STATUS;

begin
    xCont := 0;
    cListaMat := '';
    nQtdPendFun := 0;
    nExec := 1;

	BEGIN
		SELECT STATUS, BIO_TIPO into cStatus, cBio_Tipo
			FROM RDIG002 
			WHERE END_IP = cEndIp for update nowait;

		IF (cStatus = '1') THEN 
		
			-- NOVO
			-- ANTES DE ENVIAR CARGA DE LISTA BIOMETRIA, DEVE-SE VERIFICAR SE H� CARGA DE FUNCIONARIOS AINDA A SER FEITA EM REPAUTO011
			BEGIN
				SELECT 1 into nQtdPendFun FROM REPAUTO011 WHERE END_IP = cEndIp AND STATUS <> '0' ;
				--UPDATE RDIG002 SET STATUS = '0' WHERE END_IP = cEndIp;
				
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					NULL;
				
				WHEN OTHERS THEN
					nExec := 0;
			END;
			
			IF (nQtdPendFun = 0) OR       	-- NAO HA CARGA DE FUNCION�RIOS OU
			   (nQtdPendFun <> 0 AND nAutoGerFun = 0) OR    	-- HA CARGA DE FUNCION�RIOS MAS NAO H� GERENCIMENTO AUTOMATICO DE CARGA AUTOMATICA
			   (nQtdPendFun <> 0 AND nAutoComFun = 0)  THEN   	-- HA CARGA DE FUNCION�RIOS MAS NAO H� ENVIO DE CARGA/EXCLUSAO DE FUNCION�RIOS AO EQUIPAMENTO
				
				IF (nExec = 1)	THEN 	-- nao houve erro em BD
					IF (cBio_Tipo = '6') OR (cBio_Tipo = '7') THEN		-- SAGEM
						FOR r in ldigit_cur1 LOOP
							cListaMat := cListaMat || r.IFUNC;
							update RDIG001 set STATUS = '2' where current of ldigit_cur1 ;
							xCont := xCont+1;
							--IF (xCont >= 20) THEN 
							--IF (xCont >= 200) THEN 
							IF (xCont >= nTotal) THEN 
								Exit;
							END IF;
						END LOOP;
					ELSIF (cBio_Tipo = '8') THEN						-- TSI1
						FOR r in ldigit_cur2 LOOP
							cListaMat := cListaMat || r.IFUNC;
							update RDIG003 set STATUS = '2' where current of ldigit_cur2 ;
							xCont := xCont+1;
							--IF (xCont >= 20) THEN
							--IF (xCont >= 200) THEN 
							IF (xCont >= nTotal) THEN 
								Exit;
							END IF;
						END LOOP;
					--ELSIF (cBio_Tipo = '9') THEN						-- VIRDI
					ELSIF (cBio_Tipo != '0') THEN						-- VIRDI / OUTROS
						FOR r in ldigit_cur3 LOOP
							cListaMat := cListaMat || r.IFUNC;
							update RDIG004 set STATUS = '2' where current of ldigit_cur3 ;
							xCont := xCont+1;
							--IF (xCont >= 20) THEN 
							--IF (xCont >= 200) THEN 
							IF (xCont >= nTotal) THEN 
								Exit;
							END IF;
						END LOOP;
					END IF;


					IF (xCont = 0) THEN
						UPDATE RDIG002 SET STATUS = '0' WHERE END_IP = cEndIp;
					ELSE
						cListaMat := cListaMat || ';';
						UPDATE RDIG002 SET STATUS = '2', DATA_LOAD = SYSDATE WHERE END_IP = cEndIp;
					END IF;
				
				ELSE
					UPDATE RDIG002 SET STATUS = '0' WHERE END_IP = cEndIp;
				END IF;
			ELSE
				UPDATE RDIG002 SET STATUS = '0' WHERE END_IP = cEndIp;
			END IF;
		ELSE
			COMMIT;
			return (0);
		END IF;					

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			xCont := 0;
		WHEN reco_lock THEN
			xCont := 0;
		WHEN OTHERS THEN
			xCont := 0;
	END;
	
	COMMIT;
	return (xCont);
		
END sqller_RautoLoadDigit5;
/

