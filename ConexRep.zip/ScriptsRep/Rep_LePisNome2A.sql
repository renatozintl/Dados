CREATE OR REPLACE FUNCTION sqlproc_PisNome2 (cEndIp VARCHAR2, nTotal NUMBER, cUltPis VARCHAR2, cTipoCarga VARCHAR2,  cLisPis IN OUT VARCHAR2, cLisNome IN OUT VARCHAR2)   
RETURN NUMBER IS

nCont NUMBER;
XPis VARCHAR2(12);
XNome VARCHAR2(52);


--cursor CURSOR_PISNOME is
--select PIS, NOME 
--  from
--( select *
--    from REPAUXEMPR WHERE END_IP = cEndIp AND TIPO = cTipoCarga AND PIS > cUltPis 
--   order by PIS )
-- where ROWNUM <= nTotal;   

-- FOI ALTERADO O CURSOR PARA SELECT DISTINCT PORQUE CASO HAJA SITUA��O EM QUE HAJA MATRICULAS DIFERENTES COM MESMO PIS (QUE � PERMITIDO), NAO TENHA 
-- NECESSIDADE DE ENVIAR <n> VEZES O MESMO PIS+NOME AO REP QUANDO CARGA DE FUNCION�RIOS

-- ESTE CURSOR FOI CORRIGIDO : NAO COLETAVA A QTDE CORRETA DE LINHAS
--cursor CURSOR_PISNOME is
--select DISTINCT PIS, NOME 
--  from
--( select *
--    from REPAUXEMPR WHERE END_IP = cEndIp AND TIPO = cTipoCarga AND PIS > cUltPis )
-- 		where ROWNUM <= nTotal 
--   		order by PIS ;

cursor CURSOR_PISNOME is
select DISTINCT PIS, NOME
  from
( select *
    from REPAUXEMPR WHERE END_IP = cEndIp AND TIPO = cTipoCarga AND PIS > cUltPis order by PIS )
 		where ROWNUM <= nTotal
   		order by PIS ;


BEGIN

	cLisPis := '';
	cLisNome := '';
	nCont := 0;
	OPEN CURSOR_PISNOME;
	LOOP
		FETCH CURSOR_PISNOME  INTO XPis, XNome;
		EXIT WHEN CURSOR_PISNOME%NOTFOUND;
	
		cLisPis := cLisPis ||XPis;
		cLisNome := cLisNome || XNome || ';' ;
		nCont := nCont+1;
	END LOOP;
    close CURSOR_PISNOME;	
	

	
	return (nCont);
	
END sqlproc_PisNome2;
/


