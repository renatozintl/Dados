CREATE OR REPLACE FUNCTION sqlfuso_horario_tcpItp (cEndIp varchar2, cData in out varchar2) 
   RETURN NUMBER IS
   Ret    NUMBER;
   cFuso varchar2(8);
   cDia varchar2(1);
   Minutos NUMBER;

BEGIN
	
    Ret := 1;
    cFuso := '0000';
    cData := '01/01/2001 00:00:0001';
    Minutos := 0;
    
    BEGIN
    	SELECT Fuso INTO cFuso
		FROM DAT07
		WHERE End_Ip = cEndIp;
    EXCEPTION
		WHEN NO_DATA_FOUND then Ret := 0;
		WHEN OTHERS then Ret := -1;
    END;

    IF (Ret >= 0) THEN
		Minutos := to_number(cFuso);
		
   		select case to_char (sysdate+(Minutos/1440), 'FmDay', 'nls_date_language=english')
		          when 'Monday' then 2
		          when 'Tuesday' then 3
		          when 'Wednesday' then 4
		          when 'Thursday' then 5
		          when 'Friday' then 6
		          when 'Saturday' then 7
		          when 'Sunday' then 1
		       end d
       	    INTO cDia FROM dual;
       	    
		SELECT TO_CHAR (sysdate+(Minutos/1440), 'DD/MM/YYYY HH24:MI:SS') || '0' || cDia 
			into cData from dual; 
    END IF;
    return (Ret);

END sqlfuso_horario_tcpItp;
/

