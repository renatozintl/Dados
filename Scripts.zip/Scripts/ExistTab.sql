CREATE or REPLACE FUNCTION sqlexiste_tabela (cObjeto in VARCHAR2) 
RETURN NUMBER IS

cAux VARCHAR2(30);

BEGIN
    BEGIN
    SELECT TABLE_NAME INTO cAux FROM USER_TABLES
	WHERE TABLE_NAME = cObjeto;
    RETURN (1);		-- retorna marcacao ja realizada

    EXCEPTION
	WHEN NO_DATA_FOUND THEN
	    RETURN (0);
	WHEN OTHERS THEN
	    RETURN (-1);
    END;

END sqlexiste_tabela;
/ 


