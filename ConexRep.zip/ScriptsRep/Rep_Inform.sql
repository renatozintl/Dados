CREATE OR REPLACE FUNCTION sqlinform_rep (cEndIp in varchar2, cNumRep in varchar2, inicio in number, Info in VARCHAR2) 
   RETURN NUMBER IS
	nRet NUMBER;
	cAux VARCHAR2(30);
	reco_unique EXCEPTION;
	PRAGMA EXCEPTION_INIT (reco_unique, -1);  -- erro quando registro DUPLICADO 
	
    reco_lock EXCEPTION;
    PRAGMA EXCEPTION_INIT (reco_lock, -54);  
	

BEGIN
	nRet := 0;
	IF (inicio = 0) THEN
		BEGIN
			DELETE REPINFO001 
				WHERE REP = cNumRep;
		EXCEPTION
			WHEN NO_DATA_FOUND THEN nRet := 0;
			WHEN OTHERS THEN nRet := 0;
		END;
	
	END IF;
	
	BEGIN
		INSERT INTO REPINFO001 (END_IP, REP, DATINFO, INFORM) VALUES (cEndIp, cNumRep, SYSDATE, Info);
	
	EXCEPTION
		WHEN OTHERS THEN 
			nRet := 0;
	END;
	

	COMMIT;
    return (nRet);
    
END sqlinform_rep;
/
