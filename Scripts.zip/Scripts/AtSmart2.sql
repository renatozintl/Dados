CREATE or REPLACE FUNCTION sqller_atusmart2(
cIdentif in VARCHAR2,
cNSerial in out VARCHAR2,
cRegCampo in out VARCHAR2,
cRegValor in out VARCHAR2) RETURN NUMBER IS


	XCONT NUMBER;
	XIDENTIF CHAR(14);
	XNUMSERIAL CHAR(10);
	XNUMCPO CHAR(2);
	XINFORM VARCHAR2(56);

     CURSOR CURSOR_LEATUALI IS
            SELECT   IDENTIF, NUMSERIAL, NUMCPO, INFORM
            FROM     ATUALI
            WHERE    IDENTIF = cIdentif 
            ORDER BY IDENTIF, TO_NUMBER(NUMSERIAL), TO_NUMBER(NUMCPO);

BEGIN

     XCONT := 0;
     /* AGRUPA COMANDOS DO BLUEB */
     OPEN CURSOR_LEATUALI;
     LOOP
          FETCH CURSOR_LEATUALI INTO XIDENTIF, XNUMSERIAL, XNUMCPO, XINFORM;
          EXIT WHEN CURSOR_LEATUALI%NOTFOUND;

	  cRegCampo := cRegCampo || XNUMCPO || '[';
	  cRegValor := cRegValor || XINFORM || '[';

	  XCONT := XCONT+1;
	
     END LOOP;
     cRegCampo := cRegCampo || ';';
     cRegValor := cRegValor || ';';
     cNSerial := XNUMSERIAL;
     CLOSE CURSOR_LEATUALI;

     --DBMS_OUTPUT.PUT_LINE('cRegCampo =  ' || cRegCampo);   
     --DBMS_OUTPUT.PUT_LINE('cRegValor =  ' || cRegValor);   


     IF (XCONT = 0) THEN
	     RETURN (0);
     ELSE
	RETURN (1);
     END IF;
END sqller_atusmart2;
/
