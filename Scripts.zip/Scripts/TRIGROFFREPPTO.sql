CREATE OR REPLACE TRIGGER trgOffRepPto
   AFTER INSERT OR UPDATE OF DTAHORAREP ON OFFREPPONTO
   FOR EACH ROW

DECLARE
	NovoDHPto date;
	DHMenor date;
	DHMaior date;
   
	cMatAux varchar(12) := NULL;
	nCont number;	
   
	reco_lock EXCEPTION;
	tem_deadlock EXCEPTION; 
	PRAGMA EXCEPTION_INIT (reco_lock, -54);  
	PRAGMA EXCEPTION_INIT (tem_deadlock, -60); 

BEGIN
	nCont := 0;
	NovoDHPto := :NEW.DTAHORAREP;

	BEGIN
		-- procura pela menor data/hora do usuario
		SELECT MIN(DTAHORAREP) into DHMenor FROM ULTREPPONTO 
			WHERE IFUNC = :NEW.IFUNC GROUP BY IFUNC;		
	
		-- procura pela maior data/hora do usuario
		SELECT MAX(DTAHORAREP) into DHMaior FROM ULTREPPONTO 
			WHERE IFUNC = :NEW.IFUNC GROUP BY IFUNC;		
	
		-- verifica as marcaoes existentes
		IF (DHMenor = DHMaior) THEN
			-- datas s�o iguais, significa que h� somente 1 marca��o de ponto.
			IF (NovoDHPto != DHMenor) THEN 	-- verifica se � a mesma marca��o
				-- cinsere esta nova marcacao de ponto 
				INSERT INTO ULTREPPONTO (IFUNC, DTAHORAREP) VALUES (:NEW.IFUNC, :NEW.DTAHORAREP);		
			END IF;

		ELSE	-- tem mais de 1 marca��o para o usuario, verifica se esta nova marca��o j� existe ou precisa ser inserida na tabela apos analise de data
			BEGIN
				SELECT IFUNC into cMatAux			-- procurar pela marcacao  em tabela ULTREPPONTO
					FROM ULTREPPONTO 
					WHERE IFUNC = :NEW.IFUNC AND 
						  DTAHORAREP = NovoDHPto;
				
				-- como ja existe a marcacao, nada faz
						  
			EXCEPTION
				WHEN NO_DATA_FOUND then 		-- NAO EXISTE A MESMA MARCACAO EM ULTREPPONTO
					BEGIN
						-- verifica qtde de marcacoes na tabela ULTREPPONTO para este usuario
						SELECT count(*) into nCont FROM ULTREPPONTO WHERE IFUNC = :NEW.IFUNC;

						-- verifica se ha 8 marcacoes ou mais
						IF (nCont >= 8) THEN				-- VERIFICA SE TEM MAIS DE 8 MARCACOES		
							-- verifica se esta nova marcacao � maior do que a menor data para este usuario
							IF (NovoDHPto > DHMenor) THEN 
								-- atualiza a data mais antiga com esta nova
								SELECT IFUNC into cMatAux			-- procurar pela marcacao  em tabela ULTREPPONTO
									FROM ULTREPPONTO 
									WHERE IFUNC = :NEW.IFUNC AND 
									  	  DTAHORAREP = DHMenor FOR UPDATE NOWAIT;
				
								UPDATE ULTREPPONTO SET DTAHORAREP = NovoDHPto 
									WHERE IFUNC = :NEW.IFUNC AND DTAHORAREP = DHMenor;	

							-- se for menor, nada faz pois j� tem  a qtde.maxima (8)
							
							END IF;															
						-- tem qtde de marca��es menor que o m�ximo (8)
						ELSE
							-- insere esta nova marca��o, pois ainda nao atingiu a qtde  maxima (8)
							INSERT INTO ULTREPPONTO (IFUNC, DTAHORAREP) VALUES (:NEW.IFUNC, :NEW.DTAHORAREP);		
						END IF;

					END;
					
				WHEN others then NULL;
			END;
			
		END IF;
		
	EXCEPTION
		WHEN NO_DATA_FOUND then 		-- NAO EXISTE A MESMA MARCACAO EM ULTREPPONTO
			-- insere esta nova marca��o, pois ainda nao atingiu a qtde  maxima (8)
			INSERT INTO ULTREPPONTO (IFUNC, DTAHORAREP) VALUES (:NEW.IFUNC, :NEW.DTAHORAREP);		

		WHEN others then NULL;
	END;
END;
/



