CREATE OR REPLACE FUNCTION sqlsel_oldrepponto (cMatric VARCHAR2, cRegDatas IN OUT VARCHAR2) 
RETURN NUMBER IS

dDtaHorUlt DATE;
cData varchar2(12);
xCont NUMBER;

-- cursor que coleta os horarios de Pontos da mesmo Matricula
cursor CURSOR_ULTREPPTO is
	SELECT 	DTAHORAREP  
		from ULTREPPONTO 
		WHERE IFUNC = cMatric 
		ORDER BY DTAHORAREP DESC;    


BEGIN
	xCont := 0;
	cRegDatas := '';
	
	OPEN CURSOR_ULTREPPTO;
	LOOP
		fetch CURSOR_ULTREPPTO INTO dDtaHorUlt;
		EXIT when CURSOR_ULTREPPTO%NOTFOUND;
		
		IF (xCont < 8) THEN
			cData := TO_CHAR (dDtaHorUlt, 'HH24MISSDDMMYY') ;
			cRegDatas := cRegDatas || cData	;
			xCont := xCont+1;
		END IF;
		
	END LOOP;
	CLOSE CURSOR_ULTREPPTO;
		
	return xCont;
	
END sqlsel_oldrepponto;
/
	
