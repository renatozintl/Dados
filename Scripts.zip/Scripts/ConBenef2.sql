CREATE OR REPLACE FUNCTION sqlcons_benef2 (ind IN VARCHAR2, cMatric IN VARCHAR2, cCreditos OUT VARCHAR2, mensagem OUT VARCHAR2, posic OUT VARCHAR2) 
   RETURN NUMBER IS
   RetFun NUMBER;
   num_cred NUMBER;		
   pos VARCHAR2(50);
   xcreditos VARCHAR2(5);
   num_ind NUMBER;

   reco_lock EXCEPTION;
   PRAGMA EXCEPTION_INIT (reco_lock, -54);  -- erro quando registro lockado 
BEGIN
   RetFun := 0;
   num_ind := to_number(ind);   

BEGIN
   if (num_ind = 0) then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos 
	from LBENEF00 WHERE ICARD = cMatric;

   elsif (num_ind = 1) then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos 
	from LBENEF01 WHERE ICARD = cMatric;

   elsif num_ind = 2 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos 
	from LBENEF02 WHERE ICARD = cMatric;

   elsif num_ind = 3 then 
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos 
	from LBENEF03 WHERE ICARD = cMatric;

   elsif num_ind = 4 then 
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF04 WHERE ICARD = cMatric;

   elsif num_ind = 5 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF05 WHERE ICARD = cMatric;

   elsif num_ind = 6 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF06 WHERE ICARD = cMatric;

   elsif num_ind = 7 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF07 WHERE ICARD = cMatric;

   elsif num_ind = 8 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF08 WHERE ICARD = cMatric;

   elsif num_ind = 9 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF09 WHERE ICARD = cMatric;

   elsif num_ind = 10 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF10 WHERE ICARD = cMatric;

   elsif num_ind = 11 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF11 WHERE ICARD = cMatric;

   elsif num_ind = 12 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF12 WHERE ICARD = cMatric;

   elsif num_ind = 13 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF13 WHERE ICARD = cMatric;

   elsif num_ind = 14 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF14 WHERE ICARD = cMatric;

   elsif num_ind = 15 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF15 WHERE ICARD = cMatric;

   elsif num_ind = 16 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF16 WHERE ICARD = cMatric;

   elsif num_ind = 17 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF17 WHERE ICARD = cMatric;

   elsif num_ind = 18 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF18 WHERE ICARD = cMatric;

   elsif num_ind = 19 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF19 WHERE ICARD = cMatric;

   elsif num_ind = 20 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF20 WHERE ICARD = cMatric;

   elsif num_ind = 21 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF21 WHERE ICARD = cMatric;

   elsif num_ind = 22 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF22 WHERE ICARD = cMatric;

   elsif num_ind = 23 then
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from LBENEF23 WHERE ICARD = cMatric;

   else
     SELECT creditos, rowidtochar(rowid) into xcreditos, pos
       from BENEFICIO WHERE ICARD = cMatric;

   end if;

   EXCEPTION
      WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
         RetFun := -2;
         mensagem := 'Matricula ' || cMatric || ' nao encontrado !! Retorno = '|| TO_CHAR(RetFun);
 	 return (RetFun);

      WHEN reco_lock THEN
	 RetFun := -4;
         mensagem := 'registro lockado';
 	 return (RetFun);

      WHEN OTHERS THEN              -- outros erros
         RetFun := -1;
         mensagem := 'Outros erros encontrados!! Retorno = '|| TO_CHAR(RetFun);
 	 return (RetFun);
   END;

   mensagem := 'Registro encontrado';
   posic := pos;
   num_cred := to_number(xcreditos);
   IF num_cred > 0 then
	RetFun := 0;
   ELSE 
	RetFun := -3;
        mensagem:= 'credito esgotado';
        cCreditos := lpad (to_char(num_cred), 2, '0');		
        return( RetFun );
   END IF;	
   cCreditos := lpad (to_char(num_cred), 2, '0');		



   RETURN (RetFun);
END sqlcons_benef2;
/

