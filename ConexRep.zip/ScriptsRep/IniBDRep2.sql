

SPOOL INIREP2.LOG;
CONNECT CP_TELEMAT/0102chtec@;

-- Criacao de tabelas
@@iCriaTabRep;

-- Compilacao 
@@iCompRep;

-- Compilacao triggers carga automatica : JA ESTAO SENDO COMPILADOS EM iCompRep.sql
--@@iCompTrgAuto;


-- Privilegios Usutcp
@@iPrivUsrRep;

-- Privilegios Causu
@@iPrivPriRep;

-- Atualiza��o de Versao
@@Rep_versao_090702.sql

-- SINONIMOS Causu
CONNECT SERVCAUSU/SERVCAUSUX@;
@@iSynPriRep;

-- SINONIMOS Usutcp
CONNECT SERVUSUTCP01/USUTCP@;
@@iSynUsrRep;


SPOOL OFF;