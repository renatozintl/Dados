CREATE or REPLACE FUNCTION sqlrep_fimInsAuto3 (cEndIp in VARCHAR2, cStat in VARCHAR2) 
RETURN NUMBER IS

nErr NUMBER;
xCont NUMBER;
cAux VARCHAR2(20);
cStExc VARCHAR2(1);
cNovoStat VARCHAR2(1);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

cursor lfim011_cur is 
	SELECT IFUNC, STATUS FROM REPAUTO011 
		WHERE END_IP = cEndIp AND STATUS = '2' 
		order by IFUNC for update of STATUS;

begin
    xCont := 0;
    nErr := 0;
    cNovoStat := cStat;

	BEGIN
		-- atualiza o status somente dos funcionarios do rep q estavam sendo incluidos (sofrendo o comando de inclusao no conex)
		for r in lfim011_cur LOOP
			if (cStat = '0') then
				delete REPAUTO011 where current of lfim011_cur ;
			else
				-- *************  NOVO
				-- SE ESTIVER PENDENTE, DEVE VERIFICAR SE H� ALGUM COMANDO DE EXCLUSAO DESSE FUNCION�RIO PARA O EQUIPAMENTO A SER EXECUTADO.
				-- SE HOUVER, DEVE-SE IGNORAR ESTA PENDENCIA DE INCLUSAO E TORNA-LA STATUS '4', PARA QUE O GERENCIADOR DE CARGA AUTOM�TICA ANULE ESTA PENDENCIA
				if (cStat = '3') then
					BEGIN 
						SELECT STATUS INTO cStExc FROM REPAUTO012 
							WHERE IFUNC = r.IFUNC and END_IP = cEndIp AND STATUS <> '0' ;

						-- ENCONTROU COMANDO MAIS RECENTE DE EXCLUSAO, ENT�O NOVO VALOR DE 	REPAUTO011.STATUS SER� '4', PARA ESTA CARGA SER DESCARTADA, E N�O TRATAR� COMO PENDENCIA.					
						cNovoStat := '4';
						
					EXCEPTION
						WHEN NO_DATA_FOUND then 
							null;
						WHEN OTHERS then 
							null;
					END;
				end if;
				-- *************  FIM NOVO

				--update REPAUTO011 set STATUS = cStat where current of lfim011_cur ;
				update REPAUTO011 set STATUS = cNovoStat where current of lfim011_cur ;
				
			end if;
			xCont := xCont+1;
		END LOOP;

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			nErr := 0;
		WHEN reco_lock THEN
			nErr := 1;
		WHEN OTHERS THEN
			nErr := 1;
	END;
    
	
	BEGIN
		SELECT END_IP into cAux FROM REPAUTO001 
			where END_IP = cEndIp for update nowait;
		UPDATE REPAUTO001 SET STATUS = cStat WHERE END_IP = cEndIp;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			nErr := 0;
		WHEN reco_lock THEN
			nErr := 1;
		WHEN OTHERS THEN
			nErr := 1;
	END;
	
	COMMIT;
	return (xCont);
		
END sqlrep_fimInsAuto3;
/

