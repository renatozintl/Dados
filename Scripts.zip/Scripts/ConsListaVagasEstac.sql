CREATE OR REPLACE FUNCTION sqlCons_ListaVagEstac (nTotal NUMBER, cListaGrp VARCHAR2, cListaVagasFixas IN OUT VARCHAR2, cListaVagasRotat IN OUT VARCHAR2)
RETURN NUMBER IS
Ret  NUMBER;
cGrEstac VARCHAR2(6);
nMaxFixo NUMBER;
nContFixo NUMBER;
nMaxRot NUMBER;
nContRot NUMBER;

nPos NUMBER;
nCont NUMBER;
nVagasFixas NUMBER;
nVagasRotat NUMBER;

BEGIN

    Ret := 0;
    nCont :=0;
    nVagasFixas := 0;
    nVagasRotat := 0;
    cListaVagasFixas := '';
    cListaVagasRotat := '';


	WHILE (nCont < nTotal) LOOP
		nPos := (nCont * 6) + 1;
		cGrEstac := SUBSTR (cListaGrp, nPos, 6);


		BEGIN

			-- PROCURA PELO GRUPO DE ESTACIONAMENTO PARA COLETAR AS QUANTIDADES VAGAS
			--SELECT (MAX_FIXO-CONT_FIXO), (MAX_ROT - CONT_ROT)
			--	INTO nVagasFixas, nVagasRotat
			SELECT MAX_FIXO,CONT_FIXO, MAX_ROT, CONT_ROT
				INTO nMaxFixo, nContFixo, nMaxRot, nContRot
				FROM ESTAC002 WHERE TO_NUMBER(GREST) = TO_NUMBER(cGrEstac);

			IF (nContFixo < 0) THEN nContFixo := 0;  end if;
			IF (nContRot < 0) THEN nContRot := 0;  end if;

			nVagasFixas := (nMaxFixo - nContFixo);
			nVagasRotat := (nMaxRot - nContRot);

			IF (nVagasFixas < 0) then nVagasFixas := 0; end if;
			IF (nVagasRotat < 0) then nVagasRotat := 0; end if;

			Ret := 1;

		EXCEPTION
			WHEN NO_DATA_FOUND then
			    nVagasFixas := 0;
			    nVagasRotat := 0;

			WHEN others then
				Ret := -1;
				cListaVagasFixas := '';
				cListaVagasRotat := '';
				return Ret;
		END;

		cListaVagasFixas := cListaVagasFixas || LPAD (TO_CHAR(nVagasFixas), 5, '0');
		cListaVagasRotat := cListaVagasRotat || LPAD (TO_CHAR(nVagasRotat), 5, '0');
		nCont := nCont + 1;

	END LOOP;

	return Ret;
END sqlCons_ListaVagEstac;
/
