CREATE OR REPLACE FUNCTION sqlconG3G5_ace_usuario10 (cMatricNS CHAR, cInform VARCHAR2, cTipTerm VARCHAR2, cEndIp VARCHAR2, cDataOcorr VARCHAR2, cVisita VARCHAR2, cRegistro IN OUT VARCHAR2, 
cFxaDomTot OUT VARCHAR2, cFxaSegTot OUT VARCHAR2, cFxaTerTot OUT VARCHAR2, cFxaQuaTot OUT VARCHAR2, 
cFxaQuiTot OUT VARCHAR2, cFxaSexTot OUT VARCHAR2, cFxaSabTot OUT VARCHAR2, cFxaRefTot OUT VARCHAR2, 
cFxa1Tot OUT VARCHAR2, cFxa2Tot OUT VARCHAR2, cFxa3Tot OUT VARCHAR2, cFxa4Tot OUT VARCHAR2, 
cFxa5Tot OUT VARCHAR2, cFxa6Tot OUT VARCHAR2, 
posic OUT VARCHAR2, cRegNovo OUT VARCHAR2, cRegHAIntj OUT VARCHAR2, cRegInfo OUT VARCHAR2, cRegEscolt OUT VARCHAR2, cTamG3G5 in out varchar2) 
RETURN NUMBER IS

RetFun    NUMBER;
Result    NUMBER;
VarAux    CHAR(12);
cMatric   CHAR(12);
cMatBusca    CHAR(12);
r         NUMBER;
cIcard    VARCHAR2(12);
cCodig    VARCHAR2(6);
cTpFis    VARCHAR2(1);
cSitua    VARCHAR2(1);
cDataHora VARCHAR2(10);
cUltrs    VARCHAR2(25);
cDatIni   VARCHAR2(6);
cDatFim   VARCHAR2(6);
cTitular  VARCHAR2(12);
cFx_Flg   VARCHAR2(1); 
cFx_Dta   VARCHAR2(11); 
cFx_Alm   VARCHAR2(3);
cMensagem VARCHAR2(32); 
cDta_mens VARCHAR2(6);
cQtd_mens VARCHAR2(2);
cCred_Fx1 VARCHAR2(2); 
cCred_Fx2 VARCHAR2(2);
cCred_Fx3 VARCHAR2(2);
cCred_Fx4 VARCHAR2(2);
cCred_Fx5 VARCHAR2(2);
cCred_Fx6 VARCHAR2(2);
cUltPasR  VARCHAR2(10);
cDatIniG1 VARCHAR2(10);
cDatFimG1 VARCHAR2(10);
cDatIniG2 VARCHAR2(10);
cDatFimG2 VARCHAR2(10);
cDatIniG3 VARCHAR2(10);
cDatFimG3 VARCHAR2(10);
cAnti_D   VARCHAR2(1);
cBloq     VARCHAR2(1);
cVHora    VARCHAR2(1);
cVLocal   VARCHAR2(1);
cVValid   VARCHAR2(1);
cVAfast   VARCHAR2(1);
cVCred    VARCHAR2(1);
cVisEsp   VARCHAR2(1);
cVPonto   VARCHAR2(1);
cPonto    VARCHAR2(1);	
cVDigit   VARCHAR2(1);
cPne    	VARCHAR2(1);	
cBloqRev    VARCHAR2(1);	
cvViaRep  VARCHAR2(1);
cEmFixa	  VARCHAR2(1);
cRegra	  VARCHAR2(1);
cVEstat   VARCHAR2(1);


cGrupo    VARCHAR2(9);	-- novo
cSubNv    VARCHAR2(9);	-- novo
cGrupo1   VARCHAR2(9);	-- novo
cGrupo2   VARCHAR2(9);	-- novo
cGrupo3   VARCHAR2(9);	-- novo
cGpoSab   VARCHAR2(9);	-- novo
cGpoDom   VARCHAR2(9);	-- novo
cGpoFer   VARCHAR2(9);	-- novo
cAdBuf CHAR(2);			-- novo
nTamG NUMBER; 

cfx_dom_a VARCHAR(56);
cfx_seg_a VARCHAR(56);
cfx_ter_a VARCHAR(56);
cfx_qua_a VARCHAR(56);
cfx_qui_a VARCHAR(56);
cfx_sex_a VARCHAR(56);
cfx_sab_a VARCHAR(56);

cfx_dom_p VARCHAR(56);
cfx_seg_p VARCHAR(56);
cfx_ter_p VARCHAR(56);
cfx_qua_p VARCHAR(56);
cfx_qui_p VARCHAR(56);
cfx_sex_p VARCHAR(56);
cfx_sab_p VARCHAR(56);
      
cFxCred   VARCHAR2(10);      -- guarda espacos de faixa horaria de refeicao
cFxDiaEsp VARCHAR2(40);      -- guarda espacos de faixa horaria dia
cFxDia   VARCHAR2(250);     -- guarda 7 * faixas horarias 

cTpoIntj VARCHAR2(3); 
cTolIntj VARCHAR2(3); 
cInterj  VARCHAR2(1);
cIniHalm VARCHAR2(12);
cFimHalm VARCHAR2(12);
cIniIntj VARCHAR2(12);
cFimIntj VARCHAR2(12);
cFimAntiD VARCHAR2(12);
cIniNr36 VARCHAR2(12);
cFimNr36 VARCHAR2(12);


cTpoJorn VARCHAR2(3);
cSaidaMax VARCHAR2(1);
mensagem VARCHAR2(100);
cNumSerial CHAR(10);
cBloqBDCC VARCHAR2(1);
cUltrSeg VARCHAR2(2);

cCPF VARCHAR2(11);
cTipoDoc   VARCHAR2(1);

cVnDias VARCHAR2(2);
cDiasSuc VARCHAR(2);


dDataBD DATE;
dDataOcor DATE;

seq       NUMBER;
retLock NUMBER;
pos NUMBER;


cModo CHAR(1);
cFazLock CHAR(1);
cDesbloqRev CHAR(1);
cVerNumS CHAR(1);
cBDCC CHAR(1);
cLeBDCC CHAR(1);

nGrEstFixa number;
nGrEstEquip number;
cGrEstDatAjuste CHAR(12);

cEscoltado CHAR(12);
cEscolta CHAR(12);
cTemEsc CHAR(1);
cEhEscolta CHAR(1);
cProcurado CHAR(12);
cArea CHAR(9); 
cSentido CHAR(1);
nCont Number;

nAuxArea NUMBER;
AuxSentido CHAR(1);
nContArea NUMBER;
cFinalSentido CHAR(1);
cAuxEscoltado CHAR(12);
cAux2Area NUMBER;

cSituaAux CHAR(1);

cursor escolt_cur is
	SELECT AREA, SENTIDO FROM ESCOLT002 
		WHERE END_IP = cEndIp
		ORDER by AREA;
		

reco_lock EXCEPTION;
ICARD_VAZIO EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);  -- erro quando registro lockado

BEGIN
	RetFun := 0;
	
	cMatric := substr(cMatricNS, 1, 12);
	
	cModo := substr(cInform, 1, 1);  -- TIPO DE PESQUISA
	-- cModo = 0 :icard; 
	-- cModo = 1 :numero serial
	-- cModo = 2 :cpf

	cBDCC 	:= 		substr(cInform, 2, 1);  -- SE BDCC
	cFazLock := 	substr(cInform, 3, 1);  -- SE CONSULTA ONLINE
	cDesbloqRev := 	substr(cInform, 4, 1);  -- SE DESBLOQUEIO REVISTA
	cVerNumS := 	substr(cInform, 5, 1);  -- SE verificacao de icard + numserial
	cEhEscolta :=  	substr(cInform, 6, 1);	-- SE � INDICADOR DE ESCOLTA
	cLeBDCC :=  	substr(cInform, 7, 1);	-- SE � EQUIPAMENTO QUE LE BDCC

	Result := 1;	
	cMatBusca := '000000000000';
	cTipoDoc := '0';
	cBloqBDCC := '0';
	
	BEGIN
		select data_length INTO nTamG 
			from   user_tab_columns
			where  table_name = 'CONTROLE' and	column_name = 'GRUPO';
	EXCEPTION
		WHEN OTHERS THEN 
			nTamG := 3;		-- ASSUME TAMANHO DO CAMPO LACES COM 3 DIGITOS
	END;
	
	SELECT (TO_DATE (cDataOcorr, 'HH24MIDDMMRR')) into dDataOcor from dual;
	
	IF (cModo = '2') THEN			-- CPF
		BEGIN
			SELECT a.Icard, c.CPF, c.TipoDoc 
				INTO cIcard, cCPF, cTipoDoc 
			FROM ContCPF c 
			INNER JOIN CONTROLE a
				ON c.CPF = substr(cMatric, 2, 11) and 
				   c.icard = a.icard ;
			
			cMatBusca := cIcard;
			
			if (cIcard is Null) then 
				cMatBusca := '000000000000';	-- 12 zeros
				RAISE ICARD_VAZIO;
			end if;
			
		EXCEPTION
			WHEN reco_lock THEN           -- lockado
				RetFun := -3;
				mensagem := 'registro lockado!! Retorno = '|| TO_CHAR(RetFun);
				Result := 0;	
			WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
				cIcard := '000000000000';	-- 12 zeros
				RetFun := -2;
				mensagem := 'Matricula ' || cMatric || ' nao encontrado !! Retorno = '|| TO_CHAR(RetFun);
				Result := 0;	
			WHEN ICARD_VAZIO THEN			
				RetFun := -2;
				mensagem := 'NumSerial ' || cMatric || ' nao encontrado !! Retorno = '|| TO_CHAR(RetFun);
				Result := 0;	
			WHEN OTHERS THEN              -- outros erros
				RetFun := -1;
				mensagem := 'Outros erros encontrados!! Retorno = '|| TO_CHAR(RetFun);
				Result := 0;	
		END;
		
	ELSIF (cModo = '0') THEN  			-- ICARD
		IF (cVerNumS = '1') THEN
			BEGIN
				SELECT a.Icard, a.NUMSERIAL 
					INTO cIcard, cNumSerial
				FROM CONTROLE a 
				WHERE a.ICard = cMatric and 
					  a.NumSerial = substr(cMatricNS, 13, 10);

				cMatBusca := cIcard;
	
			EXCEPTION
				WHEN reco_lock THEN           -- lockado
					RetFun := -3;
					mensagem := 'registro lockado!! Retorno = '|| TO_CHAR(RetFun);
					Result := 0;	
				WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
					-- SITUACAO SURICATO: VARIOS CARTOES SM COM MESMO ICARD, E NA CONTROLE ESTAO OS VALORES DE NUM.SERIAL NA COLUNA ICARD, TODOS COM O MESMO VALOR DO TITULAR
					-- A BUSCA PRIMEIRO SERA FEITA ICARD+NUMSERIAL. SE N�O ACHOU(SURICATO NAO PREENCHE CONTROLE.NUMSERIAL, FICANDO COM VALOR ZERADO), QUE � ONDE SE ENCONTRA AGORA, A BUSCA SER� SOBRE TITULAR+ICARD. QDO ENCONTRAR, O VALOR DE
					-- CMATBUSCA SER� O VALOR DO CAMPO ICARD
				
					BEGIN
						SELECT a.TITULAR, a.ICARD, a.SITUA 
							INTO cIcard, VarAux, cSituaAux 
						FROM CONTROLE a 
						WHERE a.TITULAR = cMatric and 
							  a.ICARD = '00'||substr(cMatricNS, 13, 10);

						-- FOI COMENTADO A ATRIBUI��O DE cMatBusca'00'||substr(cMatricNS, 13, 10)  DEVIDO � SITUA��O DE PROVIS�RIO, que ocorria erro, pois o Titular assumido � o valor do ICARD l�gico do provis�rio, 
						-- E QUANDO CONEX VAI CONSULTAR DADOS PELA '2A.' VEZ, COLETAR� OS DADOS DA LINHA DO PROVIS�RIO, CUJOS VALORES NA CONTROLE EST�O 'ZERADOS', POIS O QUE VALE � DO TITULAR
						-- CONSEQUENCIAS: EM CONSULTA A CRACH�S MULTITECNOLOGIA SURICATO, ESTE SCRIPT J� DEVOLVE OS DADOS DO CRACH� DO TITULAR (END.LOGICO), 
						-- N�O RETORNANDO COM SITUA.4 (PROVISORIO), POIS J� FAZ A PESQUISA DO TITULAR, OU SEJA, N�O TEM A RECONSULTA PARA O TITULAR.
						-- COM ESTA SITUA��O, O CRACH� QUE EST� PASSANDO � ASSUMIDO EM DAM00, O CRACH� DO TITULAR 
						-- MAS NA SITUA��O EM QUE H� PROVIS�RIO,  O ICARD QUE PASSOU SERIA O ICARD L�GICO DO PROVIS�RIO. 
						-- Corrigiu fazendo cMatBusca := cIcard;
						--cMatBusca := '00'||substr(cMatricNS, 13, 10);

						-- antes de atribuir cMatBusca := cIcard, deve-se verificar se a situa��o � invalida. Se invalida, 	cMatBusca := VarAux, para que retorne situa��o invalida ao Conex										
						--cMatBusca := cIcard;
						
						IF (cSituaAux = '1') THEN		-- INVALIDO SITUACAO
							cMatBusca := VarAux;
						ELSE
							cMatBusca := cIcard;
						END IF;

					EXCEPTION
						WHEN reco_lock THEN           -- lockado
							RetFun := -3;
							mensagem := 'registro lockado!! Retorno = '|| TO_CHAR(RetFun);
							Result := 0;	
						WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
							cIcard := '000000000000';	-- 12 zeros
							RetFun := -2;
							mensagem := 'Matricula ' || cMatric || ' nao encontrado !! Retorno = '|| TO_CHAR(RetFun);
							Result := 0;	
					END;
				WHEN OTHERS THEN              -- outros erros
					RetFun := -1;
					mensagem := 'Outros erros encontrados!! Retorno = '|| TO_CHAR(RetFun);
					Result := 0;	
			END;
		
		ELSE
			IF ((cLeBDCC = '1') or (cBDCC = '1') ) THEN		-- � cartao Normal que passa em eqpto.BDCC   OU  � cart�o BDCC
				BEGIN
					SELECT a.Icard, c.Bloqueado
						INTO cIcard, cBloqBDCC 
					FROM bdcc_cracha c 
						INNER JOIN CONTROLE a
							ON c.Cracha = cMatric and 
								c.Cracha = a.ICARD  ;
		
					cMatBusca := cIcard;

				EXCEPTION
					WHEN reco_lock THEN           -- lockado
						RetFun := -3;
						mensagem := 'registro lockado!! Retorno = '|| TO_CHAR(RetFun);
						Result := 0;	
		
					WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
						IF (cBDCC != '1') THEN
							cBloqBDCC := '2';		-- valor '2' indicar� que o cart�o N�O � BDCC   E   N�O EST� EM TAB.BDCC_CRACHA
						END IF;
						
						cMatBusca := cMatric;		
		
					WHEN OTHERS THEN              -- outros erros
						RetFun := -1;
						mensagem := 'Outros erros encontrados!! Retorno = '|| TO_CHAR(RetFun);
						Result := 0;	
				END;
		
			ELSE 
				BEGIN		-- BUSCA PELO ICARD
					SELECT a.Icard, a.TITULAR, a.SITUA 
						INTO cIcard, cTitular, cSitua
						FROM CONTROLE a 
						WHERE a.ICard = cMatric ;
						
					-- VERIFICA SE � PROVIS�RIO . SE PROVIS�RIO FAZ UMA SEGUNDA BUSCA (OU SEJA, A 2A.BUSCA � FEITA PELO TITULAR NO CAMPO ICARD). 
						-- SE NESTA SEGUNDA BUSCA TAMB�M FOR PR�VISORIO , A MATRICULA DE BUSCA SER� ESSA RESULTANTE DA 2A. BUSCA
						-- SE NESTA SEGUNDA BUSCA NAO FOR PROVIS�RIO, A MATRICULA DE BUSCA SER� A MATRICULA ANTERIOR, OU SEJA, DA MATRICULA ORIGINAL Q FOI ENVIADO PELO EQUIPAMENTO
					IF (cSitua = '4') THEN 		-- verifica se Provis�rio
						BEGIN		-- BUSCA PELO TITULAR NO CAMPO ICARD
							SELECT a.Icard, a.SITUA 
								INTO cIcard, cSitua
								FROM CONTROLE a 
								WHERE a.ICard = cTitular;
								
							IF (cSitua = '4') THEN					-- IR� DEVOLVER AO CONEX O  "2o.Provis�rio"
								cMatBusca := cTitular;								
							ELSE
								cMatBusca := cMatric;				-- IR� DEVOLVER AO CONEX O  "1o.Provis�rio (provis�rio original) "
							END IF;
						EXCEPTION
							WHEN reco_lock THEN           -- lockado
								RetFun := -3;
								mensagem := 'registro lockado!! Retorno = '|| TO_CHAR(RetFun);
								Result := 0;	
							WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
								cMatBusca := cMatric;
						END;

					ELSE 
						cMatBusca := cMatric;
					END IF;
					
					
				EXCEPTION
					WHEN reco_lock THEN           -- lockado
						RetFun := -3;
						mensagem := 'registro lockado!! Retorno = '|| TO_CHAR(RetFun);
						Result := 0;	
					WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
						cMatBusca := cMatric;
				END;
			END IF;		
		END IF;		
	
	ELSIF (cModo = '1') THEN  			-- NUMERO SERIAL
		BEGIN
			SELECT a.Icard, a.NUMSERIAL 
				INTO cIcard, cNumSerial
			FROM CONTROLE a 
				WHERE a.NumSerial = substr(cMatric, 3, 10);
			
			cMatBusca := cIcard;
			
			if (cIcard is Null) then 
				cMatBusca := '000000000000';	-- 12 zeros
				RAISE ICARD_VAZIO;
			end if;
			
			
		EXCEPTION
			WHEN reco_lock THEN           -- lockado
				RetFun := -3;
				mensagem := 'registro lockado!! Retorno = '|| TO_CHAR(RetFun);
				Result := 0;	
			WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
				cIcard := '000000000000';	-- 12 zeros
				RetFun := -2;
				mensagem := 'Matricula ' || cMatric || ' nao encontrado !! Retorno = '|| TO_CHAR(RetFun);
				Result := 0;	
			WHEN ICARD_VAZIO THEN			
				RetFun := -2;
				mensagem := 'NumSerial ' || cMatric || ' nao encontrado !! Retorno = '|| TO_CHAR(RetFun);
				Result := 0;	
			WHEN OTHERS THEN              -- outros erros
				RetFun := -1;
				mensagem := 'Outros erros encontrados!! Retorno = '|| TO_CHAR(RetFun);
				Result := 0;	
		END;
			
		
--	ELSIF (cModo = '3') THEN  			-- BDCC
--		BEGIN
--			SELECT a.Icard, c.Bloqueado
--				INTO cIcard, cBloqBDCC 
--			FROM bdcc_cracha c 
--				INNER JOIN CONTROLE a
--					ON c.Cracha = cMatric and 
--					c.Cracha = a.ICARD  ;

--			cMatBusca := cIcard;


--		EXCEPTION
--			WHEN reco_lock THEN           -- lockado
--				RetFun := -3;
--				mensagem := 'registro lockado!! Retorno = '|| TO_CHAR(RetFun);
--				Result := 0;	
--			WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
--				RetFun := -2;
--				mensagem := 'Matricula ' || cMatric || ' nao encontrado !! Retorno = '|| TO_CHAR(RetFun);
--				Result := 0;	
--			WHEN OTHERS THEN              -- outros erros
--				RetFun := -1;
--				mensagem := 'Outros erros encontrados!! Retorno = '|| TO_CHAR(RetFun);
--				Result := 0;	
--		END;
	END IF;

	IF (Result = 1) THEN
		BEGIN	
			SELECT a.Icard, a.Grupo, a.Codig, a.TpFis, a.Situa, a.SubNv, 
				a.DataHora, a.Ultrs, a.Fx_Flg, a.Fx_Dta, a.Tempo_alm,
				a.DatIni, a.DatFim, a.Titular, a.Mensagem, a.Dta_mens, a.Qtd_mens,
				a.Cred_Fx1, a.Cred_Fx2, 
				a.Cred_Fx3, a.Cred_Fx4,
				a.Cred_Fx5, a.Cred_Fx6,
				a.Fx_1, a.Fx_2, a.Fx_3, a.Fx_4, a.Fx_5, a.Fx_6, 
				a.UltPas_Ref,
				a.Grupo1, a.DatIniG1, a.DatFimG1, 
				a.Grupo2, a.DatIniG2, a.DatFimG2, 
				a.Grupo3, a.DatIniG3, a.DatFimG3,
				a.Grupo_sab, a.Grupo_Dom, a.Grupo_Fer,
				a.Anti_dupla, a.Bloq_Falta, 
				a.Ver_Hora, a.Ver_Local, a.Ver_Valid, a.Ver_Afast, a.Ver_Cred, a.Vis_Esp, 
				--	  a.Ver_Ponto, a.Ponto,
				a.Ver_Digit,
				a.TEMPO_RET,
				a.TOLER_RET,
				a.VER_RET,
				a.TEMPO_JORNADA,
				a.VER_SAIDAMAX,
				a.ULTRSEG,
				a.VER_NDIAS,
				a.PNE,
				a.BLOQREV, a.VER_VIAREP, 
				a.VER_ESTAT,
				rowidtochar (a.rowid), a.sequencia,
				b.fx_dom_p, b.fx_seg_p, b.fx_ter_p, b.fx_qua_p, b.fx_qui_p, b.fx_sex_p, b.fx_sab_p, 
				b.fx_dom_a, b.fx_seg_a, b.fx_ter_a, b.fx_qua_a, b.fx_qui_a, b.fx_sex_a, b.fx_sab_a,
				b.fx_ref
			INTO 
				cIcard, cGrupo, cCodig, cTpFis, cSitua, cSubNv, 
				cDataHora, cUltrs, cFx_Flg, cFx_Dta, cFx_Alm,
				cDatIni, cDatFim, cTitular, cMensagem, cDta_mens, cQtd_mens,
				cCred_Fx1, cCred_Fx2, 
				cCred_Fx3, cCred_Fx4,
				cCred_Fx5, cCred_Fx6,
				cFxa1Tot, cFxa2Tot, cFxa3Tot, cFxa4Tot, cFxa5Tot, cFxa6Tot, 
				cUltPasR,
				cGrupo1, cDatIniG1, cDatFimG1,
				cGrupo2, cDatIniG2, cDatFimG2,
				cGrupo3, cDatIniG3, cDatFimG3,
				cGpoSab, cGpoDom, cGpoFer,
				cAnti_D, cBloq,
				cVHora, cVLocal, cVValid, cVAfast, cVCred, cVisEsp, 
				-- cVPonto, cPonto,
				cVDigit,
				cTpoIntj, cTolIntj, cInterj,
				cTpoJorn, cSaidaMax, cUltrSeg,
				cVnDias,			
				cPne, 
				cBloqRev, cvViaRep,
				cVEstat,
				posic, seq,
				cfx_dom_p, cfx_seg_p, cfx_ter_p, cfx_qua_p, cfx_qui_p, cfx_sex_p, cfx_sab_p,
				cfx_dom_a, cfx_seg_a, cfx_ter_a, cfx_qua_a, cfx_qui_a, cfx_sex_a, cfx_sab_a,
				cFxaRefTot
			FROM CONTROLE a, FxHoraria b
				WHERE a.ICard = cMatBusca and b.icard = cMatBusca ;
				-- for UPDATE NOWAIT;

			IF (cTipTerm = '3')  then      -- Ponto
				cFxaDomTot := cfx_dom_p;
				cFxaSegTot := cfx_seg_p;
				cFxaTerTot := cfx_ter_p;
				cFxaQuaTot := cfx_qua_p;
				cFxaQuiTot := cfx_qui_p;
				cFxaSexTot := cfx_sex_p;
				cFxaSabTot := cfx_sab_p;
			ELSE				  -- Acesso
				cFxaDomTot := cfx_dom_a;
				cFxaSegTot := cfx_seg_a;
				cFxaTerTot := cfx_ter_a;
				cFxaQuaTot := cfx_qua_a;
				cFxaQuiTot := cfx_qui_a;
				cFxaSexTot := cfx_sex_a;
				cFxaSabTot := cfx_sab_a;
			END IF;


			if (cSitua = '4') or (cFazLock = '0') then	-- se Provisorio, n�o 'bloqueia'. Sera 'bloqueado' o Titular
				retLock := 0;
			else
				retLock := request_lock  (cIcard, cEndIp);
			end if;

			IF (retLock = 0) then

				if (cCodig is Null) then 
					  cCodig := '      ';	-- 6 espacos
				end if;
				if (cTpFis is Null) then
					cTpFis := ' ';		-- 1 espaco
				end if;
				if (cSubNv is Null) then
					IF (nTamG = 3) then 
						cSubNv := '00   ';	-- 3 espacos
					ELSE
						cSubNv := '00     ';	-- 5 espacos
					END IF;				
				end if;
				if (cDataHora is Null) then
					cDataHora := '3112492359';	-- 10 espacos
				end if;
				if (cUltrs is Null) then
					cUltrs := '0101102359               ';	-- 25 espacos
				end if;
				if (cFx_Flg is Null) then 
					cFx_Flg := '0';		-- 1 espaco
				end if;
				if (cFx_Dta is Null) then 
					cFx_Dta := '           ';		-- 11 espacos
				end if;
				if (cFx_Alm is Null) then 
					cFx_Alm := '   ';		-- 3 espacos
				end if;
				if (cDatIni is Null) then
					cDatIni := '      ';	-- 6 espacos
				end if;
				if (cDatFim is Null) then
					cDatFim := '      ';	-- 6 espacos
				end if;
				if (cTitular is Null) then
					cTitular := '            ';	-- 12 espacos
				end if;
				if (cMensagem is Null) then 
					cMensagem := '                                ';		-- 32 espacos
				end if;
				if (cDta_mens is Null) then 
					cDta_mens := '      ';		-- 6 espacos
				end if;
				if (cQtd_mens is Null) then 
					cQtd_mens := '  ';		-- 2
				end if;
				if (cCred_Fx1 is Null) then 
					cCred_Fx1 := '00';		-- 2
				end if;
				if (cCred_Fx2 is Null) then 
					cCred_Fx2 := '00';		-- 2
				end if;
				if (cCred_Fx3 is Null) then 
					cCred_Fx3 := '00';		-- 2
				end if;
				if (cCred_Fx4 is Null) then 
					cCred_Fx4 := '00';		-- 2
				end if;
				if (cCred_Fx5 is Null) then 
					cCred_Fx5 := '00';		-- 2
				end if;
				if (cCred_Fx6 is Null) then 
					cCred_Fx6 := '00';		-- 2
				end if;
				if (cUltPasR is Null) then 
					cUltPasR := '          ';	-- 10 espacos
				end if;
				if (cGrupo1 is Null) then
					IF (nTamG = 3) then 
						cGrupo1 := '000';		-- 3
					ELSE
						cGrupo1 := '00000';		-- 5
					END IF;
				end if;
				if (cDatIniG1 is Null) then
					cDatIniG1 := '          ';	-- 10
				end if;
				if (cDatFimG1 is Null) then
					cDatFimG1 := '          ';	-- 10
				end if;
				if (cGrupo2 is Null) then
					IF (nTamG = 3) then 
						cGrupo2 := '000';		-- 3
					ELSE
						cGrupo2 := '00000';		-- 5
					END IF;
				end if;
				
				if (cDatIniG2 is Null) then
					cDatIniG2 := '          ';	-- 10
				end if;
				if (cDatFimG2 is Null) then
					cDatFimG2 := '          ';	-- 10
				end if;
				if (cGrupo3 is Null) then
					IF (nTamG = 3) then 
						cGrupo3 := '000';		-- 3
					ELSE
						cGrupo3 := '00000';		-- 5
					END IF;
				end if;
				if (cDatIniG3 is Null) then
					cDatIniG3 := '          ';	-- 10
				end if;
				if (cDatFimG3 is Null) then
					cDatFimG3 := '          ';	-- 10
				end if;
				if (cGpoSab is Null) then
					IF (nTamG = 3) then 
						cGpoSab := '000';		-- 3
					ELSE
						cGpoSab := '00000';		-- 5
					END IF;
				end if;
				if (cGpoDom is Null) then
					IF (nTamG = 3) then 
						cGpoDom := '000';		-- 3
					ELSE
						cGpoDom := '00000';		-- 5
					END IF;
				end if;
				if (cGpoFer is Null) then
					IF (nTamG = 3) then 
						cGpoFer := '000';		-- 3
					ELSE
						cGpoFer := '00000';		-- 5
					END IF;
				end if;
				if (cVisEsp is Null) then
					cVisEsp := '0';		-- 1
				end if;
		--		if (cVPonto is Null) then
		--			cVPonto := '0';		-- 1
		--		end if;
		--		if (cPonto is Null) then
		--			cPonto := '0';		-- 1
		--		end if;
				if (cVDigit is Null) then
					cVDigit := '2';		-- 1
				end if;
				if (cTpoIntj is Null) then
					cTpoIntj := '000';	-- 3
				end if;
				if (cTolIntj is Null) then
					cTolIntj := '000';	-- 3
				end if;
				if (cInterj is Null) then
					cInterj := '0';		-- 1
				end if;
				if (cTpoJorn is Null) then
					cTpoJorn := '000';	-- 3
				end if;
				if (cSaidaMax is Null) then
					cSaidaMax := '0';		-- 1
				end if;
				if (cVnDias is Null) then
					cVnDias := '00';		-- 2
				end if;
				if (cTipoDoc is Null) then
					cTipoDoc := '0';		-- 1
				end if;
				if (cPNE is Null) then
					cPNE := '0';		-- 1
				end if;
				if (cBloqRev is Null) then
					cBloqRev := '0';		-- 1
				end if;
				if (cvViaRep is Null) then
					cvViaRep := '0';		-- 1
				end if;
				if (cVEstat is Null) then
					cVEstat := '0';		-- 1
				end if;
				
				if (cFxa1Tot is Null) then
					cFxa1Tot := '24002400';		-- 8
				end if;
				if (cFxa2Tot is Null) then
					cFxa2Tot := '24002400';		-- 8
				end if;
				if (cFxa3Tot is Null) then
					cFxa3Tot := '24002400';		-- 8
				end if;
				if (cFxa4Tot is Null) then
					cFxa4Tot := '24002400';		-- 8
				end if;
				if (cFxa5Tot is Null) then
					cFxa5Tot := '24002400';		-- 8
				end if;
				if (cFxa6Tot is Null) then
					cFxa6Tot := '24002400';		-- 8
				end if;

				IF (nTamG = 3) then
					cAdBuf := '  ';		-- 2 esp�os
				ELSE
					cAdBuf := NULL;
				END IF;


				cFxDiaEsp := '                            ';   -- 28 espacos em branco
				cFxCred   := '    ';			    --  4 espacos em branco
				cFxDia := cFxDiaEsp ||cFxDiaEsp ||cFxDiaEsp ||cFxDiaEsp ||cFxDiaEsp ||cFxDiaEsp ||cFxDiaEsp;

				cRegistro := cIcard ||cGrupo || cAdBuf ||cCodig ||cTpFis ||cSitua ||cSubNv || cAdBuf ||			-- LOCAL ACESSO podera ter 3 ou 5 digitos na BD
							'000  ' || 																			-- planta podera ter 3 ou 5 digitos na BD, MAS ENVIA SEMPRE '000  '
							cFxDia ||															
							cDataHora || cUltrs ||cFx_Flg ||cFx_Dta ||cFx_Alm ||cFxDiaEsp ||	
							cDatIni ||cDatFim ||cMensagem ||cDta_mens ||cQtd_mens ||			
							cCred_Fx1 ||cFxCred ||cCred_Fx2 ||cFxCred ||						
							cCred_Fx3 ||cFxCred ||cCred_Fx4 ||cFxCred ||
							cCred_Fx5 ||cFxCred ||cCred_Fx6 ||cFxCred ||						
							cUltPasR || cTitular ||												
							cGrupo1 || cAdBuf ||cDatIniG1 ||cDatFimG1 ||
							cGrupo2 || cAdBuf ||cDatIniG2 ||cDatFimG2 ||
							cGrupo3 || cAdBuf ||cDatIniG3 ||cDatFimG3 ||									
							cGpoSab || cAdBuf ||
							cGpoDom || cAdBuf ||
							cGpoFer || cAdBuf ||										
							cAnti_D ||cBloq ||cVHora ||cVLocal ||cVValid ||cVAfast ||cVCred ||	
							cVisEsp ;															

				IF (cDesbloqRev = '1')  THEN 
					cBloqRev := '0';
				END IF;

				--cRegNovo := cIcard || '0' || '0' || cVDigit ||
				cRegNovo := cIcard || cvViaRep || '0' || cVDigit ||
							cTpoIntj || cTolIntj || cInterj ||
							cTpoJorn || cSaidaMax || cTipoDoc || 
							'00' || cVnDias ||							-- '00' refere-se a ultrseg(q nao � lida da BD) mas � passada para a estrutura
							cPNE || cBloqRev ||
							cVEstat;
				mensagem := 'ok';

			ELSE
				RetFun := -3;
				mensagem := 'registro lockado!! Retorno = '|| TO_CHAR(RetFun);
			END IF;

		EXCEPTION
			WHEN reco_lock THEN           -- lockado
				RetFun := -3;
				mensagem := 'registro lockado!! Retorno = '|| TO_CHAR(RetFun);
			WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
				RetFun := -2;
				mensagem := 'Matricula ' || cMatric || ' nao encontrado !! Retorno = '|| TO_CHAR(RetFun);
			WHEN ICARD_VAZIO THEN			
				RetFun := -2;
				mensagem := 'NumSerial ' || cMatric || ' nao encontrado !! Retorno = '|| TO_CHAR(RetFun);
			WHEN OTHERS THEN              -- outros erros
				RetFun := -1;
				mensagem := 'Outros erros encontrados!! Retorno = '|| TO_CHAR(RetFun);
		END;

	END IF;
	
	cRegInfo := cBloqBDCC;	-- posic 0
	IF (RetFun < 0) then 
		cIcard := '000000000000';	-- 12 zeros
		cRegNovo := cIcard || '0' || '0' || '0' ||
					'000' || '000' || '0' ||
					'000' || '0' || '0' || 
					'00' || '00' ||							-- '00' refere-se a ultrseg(q nao � lida da BD) mas � passada para a estrutura
					'0' || '0' ||
					'0';
	END IF;
	
	-- verifica tabela DATAHORA
	BEGIN
		SELECT  TO_CHAR (a.Ini_Halm, 'DDMMYYHH24MISS'), TO_CHAR (a.Fim_Halm, 'DDMMYYHH24MISS'), 
				TO_CHAR (a.Ini_Intj, 'DDMMYYHH24MISS'), TO_CHAR (a.Fim_Intj, 'DDMMYYHH24MISS'),
				TO_CHAR (a.FIM_ANTID, 'DDMMYYHH24MISS'), a.Dias_Suc ,
				TO_CHAR (a.Ini_Nr36, 'DDMMYYHH24MISS'), TO_CHAR (a.Fim_Nr36, 'DDMMYYHH24MISS'), 
					b.icard 
		INTO cIniHalm, cFimHalm, cIniIntj, cFimIntj, cFimAntiD, cDiasSuc, 
			 cIniNr36, cFimNr36, 
			 VarAux
		FROM DATAHORA a , CONTROLE b
		WHERE a.Icard = cMatBusca and b.icard = cMatBusca;

		cRegHAIntj := cIcard || cIniHalm || cFimHalm || cIniIntj || cFimIntj || cFimAntiD || cDiasSuc || 
					  cIniNr36 || cFimNr36;

	EXCEPTION
		WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
			cIniHalm := '010106000000';	-- 01/01/06
			cFimHalm := '010106000000';	-- 01/01/06
			cIniIntj := '010106000000';	-- 01/01/06
			cFimIntj := '010106000000';	-- 01/01/06
			cFimAntiD := '010106000000';	-- 01/01/06
			cDiasSuc := '00';
			cIniNr36 := '010106000000';	-- 01/01/06
			cFimNr36 := '010106000000';	-- 01/01/06
			
			cRegHAIntj := cIcard || cIniHalm || cIniHalm || cIniHalm || cIniHalm || cFimAntiD || cDiasSuc || cIniNr36 || cFimNr36 ;
			
		WHEN OTHERS THEN
			RetFun := -1;
	END;

	IF (RetFun = 0 AND 
		Result = 1 AND 
		cDesbloqRev = '1') THEN
			
			IF (cFazLock = '0') THEN		-- marcacao offline
				pos := INSTR (cUltrs, ' ');		-- VERIFICA SE data armazenada em BD tem valor em branco
				IF (pos <= 10) and (pos > 0)  THEN
					dDataBD := dDataOcor;		-- assume temporariamente a mesma data de ocorrencia para que haja tualiza��o
				ELSE
					SELECT (TO_DATE (substr (cUltrs, 1, 10), 'DDMMRRHH24MI')) into dDataBD from dual;
				END IF;
				
				IF (dDataOcor >= dDataBD) then			-- atualiza BD porque a marcacao offline � mais recente que est� em BD
					UPDATE CONTROLE SET BLOQREV = '0' WHERE ICARD = cMatBusca;
				END IF;
			ELSE	-- marcacao online
				UPDATE CONTROLE SET BLOQREV = '0' WHERE ICARD = cMatBusca;
			END IF;
	END IF;


	-- verifica grupo do Estacionamento
	nGrEstFixa := 0;
	nGrEstEquip := 0;
	cEmFixa := '0';
	cRegra := '0';
	cGrEstDatAjuste := '010101010101';
	
	BEGIN
		SELECT to_number(GREST) INTO nGrEstEquip 			-- VERIFICA SE O EQUIPAMENTO PERTENCE A ALGUM ESTACIONAMENTO
			FROM ESTAC001 
			WHERE END_IP = cEndIp;
			
		
		BEGIN
			SELECT GREST, EMFIXA into nGrEstFixa, cEmFixa  					-- VERIFICA SE A MATRICULA POSSUI VAGA FIXA NESTE ESTACIONAMENTO
			FROM ESTAC003 
			WHERE ICARD = cMatBusca AND to_number(GREST) = to_number(nGrEstEquip);

		EXCEPTION
			WHEN NO_DATA_FOUND then
				nGrEstFixa := 0;
				cEmFixa := '0';
			WHEN OTHERS then
				nGrEstFixa := 0;
				cEmFixa := '0';
		END;
			
	
	EXCEPTION
		WHEN NO_DATA_FOUND then
			nGrEstFixa := 0;
			nGrEstEquip := 0;
			cGrEstDatAjuste := '010101010101';
		WHEN OTHERS then
			nGrEstFixa := 0;
			nGrEstEquip := 0;
			cGrEstDatAjuste := '010101010101';
	END;
	
	-- verifica numero da regra, se equipamento pertencer a �rea de vagas
	IF (nGrEstEquip != 0) THEN
		BEGIN
			SELECT REGRA, TO_CHAR(DT_AJUSTE, 'DDMMYYHH24MISS') 
				into cRegra, cGrEstDatAjuste
			FROM ESTAC002 
				WHERE to_number(GREST) = to_number(nGrEstEquip);
				
		EXCEPTION
			WHEN NO_DATA_FOUND then
				null;
			WHEN OTHERS then
				null;
		END;
	END IF;
	
	
	
	--cRegNovo := cRegNovo || LPAD (to_char(nGrEstFixa),3, 0) ;
	cRegNovo := cRegNovo || LPAD (to_char(nGrEstFixa),6, 0) ;
	cRegNovo := cRegNovo || cEmFixa;								

	--cRegInfo := cRegInfo || LPAD (to_char(nGrEstEquip),3, 0);		-- posic 1 a 3
	cRegInfo := cRegInfo || LPAD (to_char(nGrEstEquip),6, 0);		-- posic 1 a 6
	cRegInfo := cRegInfo || cRegra;									-- posic 7
	cRegInfo := cRegInfo || cGrEstDatAjuste;						-- posic 8 A 19 (DDMMYYHHMISS)

	-- ANALISE DE ESCOLTA
	cTemEsc := '0';
	nCont := 0;
	cEscoltado := cMatBusca;
	cEscolta := '000000000000';
	cTemEsc := '0';
	cSentido := '0';
	
	IF (cEhEscolta = '0') THEN		-- n�o � a escolta
		cProcurado := cMatBusca;
		nContArea := 0;
		cFinalSentido := '0';
		
		cEscoltado := cMatBusca;
		cEscolta := '000000000000';
		cTemEsc := '0';
		cSentido := '0';
		
		
		OPEN escolt_cur;
		LOOP
			fetch escolt_cur INTO nAuxArea, AuxSentido;
			EXIT when escolt_cur%NOTFOUND;
			
			nContArea := nContArea + 1;
			
			-- localiza a AREA e MATRICULA NA TABELA DE PESSOAS A SEREM ESCOLTADAS

			SELECT count(*) INTO nCont 
				FROM ESCOLT001 
				WHERE ICARD_ESCOLTADO = cProcurado AND
					  AREA = nAuxArea;

			IF (nCont > 0) then
				IF (cFinalSentido = '0') THEN
					cFinalSentido := AuxSentido;
				ELSE 
					IF (cFinalSentido = '1') THEN
						IF (AuxSentido = '2' OR  AuxSentido = '3') THEN 
							cFinalSentido := '3';
						END IF;
					ELSE 
						IF (cFinalSentido = '2') THEN 
							IF (AuxSentido = '1' OR  AuxSentido = '3') THEN 
								cFinalSentido := '3';
							END IF;
						END IF;
					END IF;
				END IF;

				cTemEsc := '1';
				cSentido := cFinalSentido;
			END IF;
				
		END LOOP;
		CLOSE escolt_cur;
		
	ELSE
		-- � A ESCOLTA
		-- VERIFICA SE A MATRICULA � AUTORIZADA A SER  ESCOLTA 
		nCont := 0;

		nContArea := 0;
		cEscoltado := cVisita;
		cEscolta := '000000000000';
		cTemEsc := '0';
		cSentido := '0';
	
		OPEN escolt_cur;
		LOOP
			fetch escolt_cur INTO nAuxArea, AuxSentido;
			EXIT when escolt_cur%NOTFOUND;
			
			nContArea := nContArea + 1;

			-- VERIFICA SE A MATRICULA � AUTORIZADA A SER  ESCOLTA 
			BEGIN
				SELECT ICARD_ESCOLTADO, AREA 
					INTO cAuxEscoltado, cAux2Area 
					FROM ESCOLT001 
					WHERE ICARD_ESCOLTADO = cEscoltado AND
					   	  ICARD_GUARDA = cMatBusca AND 
					      AREA = nAuxArea;

				cEscoltado := cVisita;
				cEscolta := cMatBusca;
				cTemEsc := '0'	;
				EXIT;
					      
					      
			EXCEPTION
				WHEN NO_DATA_FOUND then 
					null;
				WHEN OTHERS then 
					EXIT;
			END;

		END LOOP;
		CLOSE escolt_cur;
			
	END IF;
	

	cRegEscolt := cEscoltado || cEscolta || cTemEsc || cSentido;
	
	cTamG3G5 := TO_CHAR(nTamG);
	

	COMMIT;
	Return (RetFun);
	
END sqlconG3G5_ace_usuario10;
/
