CREATE OR REPLACE FUNCTION sqlgrava_apoc (templ1 in VARCHAR2) 
   RETURN NUMBER IS

Ret    NUMBER;
nTotal    NUMBER;
cAux VARCHAR2(50);	

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);  

   
BEGIN
	
    Ret := 0;
    nTotal := 0;
    
    
    
    BEGIN
		SELECT count(*) into nTotal 
			FROM DAT12 ;
	EXCEPTION 
		WHEN NO_DATA_FOUND then 
			return (-2);
	END ;
    
    IF (nTotal = 1) then 
    	UPDATE DAT12 set XDSC = templ1;
    	Ret := 1;
	END IF;
	
    IF (nTotal = 0) then 
    	INSERT INTO DAT12 (XDSC) VALUES (templ1);
    	Ret := 0;
	END IF;
	
    IF (nTotal > 1) then 
    	DELETE FROM DAT12;
    	INSERT INTO DAT12 (XDSC) VALUES (templ1);
    	Ret := -1;
	END IF;
	COMMIT;
	
	return (Ret);
	
END sqlgrava_apoc;
/

