CREATE OR REPLACE FUNCTION sqlverG3G5_matcodin_tcp (cMatric varchar2, cEndIp varchar2, cDiaSem varchar2, cFaixa in out varchar2, cRespLaces in out varchar, cTamG3G5 in out varchar2)
   RETURN NUMBER IS
   Ret    NUMBER;
   Ret1   NUMBER;
   cDia_1 VARCHAR(1);
   cDia_2 VARCHAR(1);
   nDia   NUMBER;
   nTamG NUMBER;
   cAdBuf CHAR(2);
   cLaces VARCHAR(5);

BEGIN
	Ret := 1;
   
    cDia_1 := substr (cDiaSem, 1,1);
    cDia_2 := substr (cDiaSem, 2,1);

	BEGIN
		select data_length INTO nTamG 
			from   user_tab_columns
			where  table_name = 'DAT07' and	column_name = 'LACES';
	EXCEPTION
		WHEN OTHERS THEN 
			nTamG := 3;		-- ASSUME TAMANHO DO CAMPO LACES COM 3 DIGITOS
	END;

	if (nTamG = 5) then
		cLaces := '00000';
		cAdBuf := NULL;
	else
		cLaces := '000';
		cAdBuf := '  ';		-- 2 esp�os
	end if;
	
    cTamG3G5 := TO_CHAR(nTamG);
	

    -- verifica a qual laces pertence o codin
    BEGIN
		SELECT LACES INTO cLaces FROM DAT07 
	    WHERE END_IP = cEndIp;
    EXCEPTION
		WHEN NO_DATA_FOUND then 
			--cLaces := '000';
			Ret := 1;
		WHEN OTHERS then
		    Ret := -1;
    END;
    
    
    cRespLaces := cLaces || cAdBuf;
    
    IF (Ret = -1) then
		return (Ret);
    END IF;
	
    -- verifica tabela MATCODIN (MATRICULA X CODIN), procurando pelo feriado ou dia da semana
    BEGIN
		SELECT FxPerm INTO cFaixa
		FROM MATCODIN
		WHERE Icard = cMatric AND
		      End_Ip = cEndIp AND
		      DiaSem = cDia_1;
		Ret := 1;
    EXCEPTION
		WHEN NO_DATA_FOUND then 
			Ret := 0;
		WHEN OTHERS then 
			Ret := -1;
    END;


    -- verifica se a primeira busca e�por feriado e n�o encontrou, continua busca pelo dia da semana
    IF (Ret = 0 AND cDia_1 = '8')  THEN
		BEGIN
			SELECT FxPerm INTO cFaixa
			FROM MATCODIN
			WHERE Icard = cMatric AND
				End_Ip = cEndIp AND
				DiaSem = cDia_2;
			Ret := 1;
		EXCEPTION
			WHEN NO_DATA_FOUND then Ret := 0;
			WHEN OTHERS then Ret := -1;
		END;
	END IF;
	
	
	
    IF (Ret = 0 AND cDia_2 > '1' AND cDia_2 < '7')  THEN
		BEGIN
			Ret1 := 1;
			SELECT FxPerm INTO cFaixa
			FROM MATCODIN
			WHERE Icard = cMatric AND
				  End_Ip = cEndIp AND
				  DiaSem = '0';
		EXCEPTION
			WHEN NO_DATA_FOUND THEN Ret1 := 0;
			WHEN OTHERS THEN Ret1 := -1;
		END;
		return (Ret1);
    ELSE
		return (Ret);
    END IF;

END sqlverG3G5_matcodin_tcp;
/

