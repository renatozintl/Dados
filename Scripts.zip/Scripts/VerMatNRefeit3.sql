CREATE OR REPLACE FUNCTION sqlvermat_nrefeit3 (cMatric VARCHAR2, cEndIp VARCHAR2, cPlanta IN OUT VARCHAR2, cRegFaixa IN OUT VARCHAR2, cRegCred IN OUT VARCHAR2, cUltPasRef IN OUT VARCHAR2)
RETURN NUMBER IS

nCont number; nMax number;
--cRegFaixa 	-- maximo 15 faixas horarias (15*8 = 120)
--cRegCred  	-- maximo 15 creditos (15*2 = 30)
--cUltPasRef 	-- DDMMYYHHMI


BEGIN
	nMax := 15;
	nCont := 0;
	cRegFaixa := '';
	cRegCred  := '';
	cUltPasRef := '          ';			-- 10 espaco;
	cPlanta := '00000';

	-- verifica qual planta ao qual o equipamento pertence
	BEGIN
		SELECT PLANTA INTO cPlanta FROM DAT07 WHERE END_IP = cEndIp;
	EXCEPTION
		WHEN NO_DATA_FOUND then
			cPlanta := '00000';
		WHEN OTHERS then
			cPlanta := '00000';
	END;
		
	-- PROCURA POR TODOS AS FAIXAS DE REFEITORIO DO USUARIO DE ACORDO COM A PLANTA DO QUAL O EQUIPAMENTO FAZ PARTE
 	for r in 
		( SELECT FX_REF, CRED_FXREF  
			FROM MATNREFEIT  
			WHERE ICARD = cMatric  AND to_number(PLANTA) = to_number(cPlanta)  ORDER BY FX_REF ASC
		) loop

		cRegFaixa := cRegFaixa || r.FX_REF;
		cRegCred  := cRegCred || r.CRED_FXREF;
		nCont := nCont + 1;
	
		if (nCont >= nMax) then
			exit;
		end if;	
	end loop;
	
	-- PROCURA PELA ULTIMA PASSAGEM EM REFEITORIO FEITA PELA MATRICULA NESTA PLANTA
	IF (nCont != 0) then
		BEGIN
			SELECT ULTPAS_REF into cUltPasRef  
				FROM AUXMATNREFEIT  
				WHERE ICARD = cMatric AND 
				      to_number(PLANTA) = to_number(cPlanta) AND 
					  ULTPAS_REF is not null ;
		EXCEPTION
			WHEN NO_DATA_FOUND then
				null;
			WHEN OTHERS then
				null;
		END;				
	end if;
			
	Return (nCont);		-- 0:nao tem especificacao de refeitorio do usuario x planta; n: tem especificacao de refeitorio do usuario x planta
	
END sqlvermat_nrefeit3;
/
