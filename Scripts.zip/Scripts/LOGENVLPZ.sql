CREATE OR REPLACE TRIGGER LOGENVLPZ BEFORE
INSERT OR UPDATE OF STATUS_LPZ ON PEND_ON002LPZ
	FOR EACH ROW

BEGIN
			------------------------------------------------
			-- I N I C I O   D A   P A R T E   L I M P E Z A
			------------------------------------------------

--------------------------------------------------------------------
-- L I S T A   D E   L I M P E Z A   E M   P R O C E S S A M E N T O 
--------------------------------------------------------------------
	IF :new.STATUS_LPZ = '2' then 
    	:new.DATA_INILPZ := sysdate ;
    
--------------------------------------------------------------
-- S U C E S S O   N O   E N V I O   L I S T A   L I M P E Z A
--------------------------------------------------------------
	ELSIF :new.STATUS_LPZ = '3' THEN
		update PEND_ON008LPZ set STATUS_LPZ = '3' where END_IP = :new.END_IP;
	
	
----------------------------------------------------------------------------------
-- F A L H A   N A   T R A N S M I S S � O   D A   L I S T A   D E   L I M P E Z A
----------------------------------------------------------------------------------

	ELSIF :new.STATUS_LPZ = '4' THEN
		update PEND_ON008LPZ set STATUS_LPZ = '4' where END_IP = :new.END_IP;
  	END IF;

END;
/

			-------------------------------------------
			-- F I M    D A   P A R T E   L I M P E Z A
			-------------------------------------------

