CREATE OR REPLACE FUNCTION sqlrep_ExistLisTab (cEndIp VARCHAR2, cNomeArq VARCHAR2, cTipo VARCHAR2, nTotal OUT NUMBER)   
RETURN NUMBER IS

nRet NUMBER;
nCont NUMBER;
x number;

BEGIN

	nRet := 0;
	nCont := 0;
	nTotal := 0;
	BEGIN
		-- verifica se h� dados na lista a serem enviados ao equipamento
		SELECT 1 into nCont 
			FROM LISTA 
			WHERE END_IP = cEndIp AND
			      upper(ARQUIVO) = upper(cNomeArq) AND 
			      ROWNUM = 1;
	
		IF (cTipo = 1) THEN 
			-- CONTA quantidade de linhas
			SELECT COUNT(*) into nTotal  
				FROM LISTA 
				WHERE END_IP = cEndIp AND upper(ARQUIVO) = upper(cNomeArq);
		END IF;
		
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			nCont := 0;
		WHEN OTHERS THEN
			nCont := -1;
	END;
	
	return (nCont);
	
END sqlrep_ExistLisTab;
/


