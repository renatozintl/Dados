CREATE OR REPLACE TRIGGER TRGREPFUNC_IU before
UPDATE OR INSERT ON REPEMPR002 
FOR EACH ROW

DECLARE
	cTipo CHAR(1);
	
BEGIN
	
	cTipo := '0';		-- assume altera��o completa (pis, cpf, nome)
	if (updating) then
		if ((:NEW.ifunc <> :OLD.ifunc) OR (:NEW.nome <> :OLD.nome)) THEN
			cTipo := '0';
		else 
			if (:NEW.pis <> :OLD.pis) then
				if (:NEW.cpf <> :OLD.cpf) then
					cTipo := '0';	-- alterou 'tudo'
				else
					cTipo := '1';	-- alterou somente PIS
				end if;
			else
				if (:NEW.cpf <> :OLD.cpf) then
					cTipo := '2';		-- alterou somente CPF
				end if;
			end if;
		end if;
	end if;

	-- ESTA TRIGGER INSERIRA�EM TAB.REPNDIGAUTO000, OS GRUPOS QUE A MATRICULA FAZ PARTE, PARA QUE NOS EQUIPTOS DESTE GRUPO SEJA INCLUIDA A DIGITAL DA MATRICULA
	Auxtrg_repFunc2 (:NEW.ifunc, '3', cTipo);
	
	-- carga automatica de digitais 
	if (inserting) then
		Auxtrg_repDig2 (:NEW.ifunc, '3', '0');	
	end if;	
END;
/
