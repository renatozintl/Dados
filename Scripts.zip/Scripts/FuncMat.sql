CREATE OR REPLACE FUNCTION sqlver_funcmat (cMat IN VARCHAR2, nCodFunc IN NUMBER) 
   RETURN NUMBER IS
      MatAux   VARCHAR2(12);
      FuncAux  VARCHAR2(2);
      reco_lock EXCEPTION;
      PRAGMA EXCEPTION_INIT (reco_lock, -54);  -- erro quando registro lockado 
BEGIN
	BEGIN
		SELECT Icard into MatAux FROM CONTFUNC
		WHERE Icard = cMat;
       	BEGIN
			SELECT Icard, CodFunc into MatAux, FuncAux FROM CONTFUNC
	       		WHERE Icard = cMat AND TO_NUMBER(CodFunc) = nCodFunc;
				return (1);              -- reg. com f� unica
		 	EXCEPTION
				WHEN NO_DATA_FOUND THEN  -- reg. nao encontrado
					return (0);
				WHEN OTHERS THEN         -- outros erros
					return (-1);
		END;
		EXCEPTION
			WHEN NO_DATA_FOUND THEN          -- reg. nao encontrado
				return (1);
			WHEN OTHERS THEN                 -- mais de uma f�
			begin
			SELECT Icard, CodFunc into MatAux, FuncAux FROM CONTFUNC
	       		WHERE Icard = cMat AND TO_NUMBER(CodFunc) = nCodFunc;
				return (1);              -- reg. encontrado e com + f�s
		 	EXCEPTION
				WHEN NO_DATA_FOUND THEN  -- reg. nao encontrado com a f�, so com outras
					return (0);
				WHEN OTHERS THEN         -- outros erros
					return (-1);
			END;
	END;
END sqlver_funcmat;
/

