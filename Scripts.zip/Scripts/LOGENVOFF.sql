CREATE OR REPLACE TRIGGER LOGENVOFF BEFORE
UPDATE ON PEND_ON002OFF
	FOR EACH ROW

BEGIN
			------------------------------------------------
			-- I N I C I O   D A   P A R T E   O F F   L I N E
			------------------------------------------------


-----------------------------------
-- E M   P R O C E S S A M E N T O 
-----------------------------------
	IF :new.STATUS_OFF = '2' then 

    	:new.DATA_INIOFF := sysdate ;

-----------------------------------
-- S U C E S S O   N O   E N V I O 
-----------------------------------
	ELSIF :new.STATUS_OFF = '3' THEN
		update PEND_ON008OFF set STATUS_OFF = '3',
			   QHOR_EXPOFF = :new.QHOR_EXPOFF 
		where END_IP = :new.END_IP;

----------------------------------------------------------
-- F A L H A   N A   T R A N S M I S S � O 
----------------------------------------------------------
	ELSIF :new.STATUS_OFF = '4' THEN
		update PEND_ON008OFF set STATUS_OFF = '4' 
		where END_IP = :new.END_IP;

------------------------------------------------
-- E X C E D E U   L I M I T E   D E   L I S T A 
------------------------------------------------
	ELSIF :new.STATUS_OFF = '5' THEN 
		update PEND_ON008OFF set STATUS_OFF = '5' 
		where END_IP = :new.END_IP;
					
--------------------------------------------
-- R E C A R R E G O U   A P L I C A T I V O 
--------------------------------------------
	ELSIF :new.STATUS_OFF = '6' THEN 
		update PEND_ON008OFF set STATUS_OFF = '6' 
		where END_IP = :new.END_IP;
		
------------------------------------------------
-- L I M P O U   M E M O R I A   D O   C O D I N com aplicativo
------------------------------------------------
	ELSIF :new.STATUS_OFF = '7' THEN 
		update PEND_ON008OFF set STATUS_OFF = '7' 
		where END_IP = :new.END_IP;

------------------------------------------------
-- L I M P O U   M E M O R I A   D O   C O D I N  TOTAL 
------------------------------------------------
	ELSIF :new.STATUS_OFF = '8' THEN 
		update PEND_ON008OFF set STATUS_OFF = '8' 
		where END_IP = :new.END_IP;

	END IF;
END;
/
		
			-------------------------------------------
			-- F I M    D A   P A R T E   O F F   L I N E
			-------------------------------------------

