CREATE OR REPLACE FUNCTION sqlconsG3G5_term_geral_tcp18 (cEndIp in varchar2, cData in varchar2, cBuffer in out varchar2, cTamG3G5 in out varchar2, cBufFrig in out varchar2) 
   RETURN NUMBER IS

Ret    NUMBER;
--cPlanta CHAR(3);
cPlanta VARCHAR2(9);
cTip_Term CHAR(1);
--cLaces CHAR(3);
cLaces VARCHAR2(9);
cBiotipo CHAR(1);
cRast CHAR(1);
cInih CHAR(1);
cFimh CHAR(1);
cVal CHAR(1);
cSMAx CHAR(1); 
cTleit CHAR(1); 
cDescr VARCHAR(30);
cPosVPlaca CHAR(1);
cPosMBloq CHAR(1);
cValDiasSuc CHAR(1);
cParidRep CHAR(1);
cQtdMult CHAR(2);
cLMinimo CHAR(4);
cLMaximo CHAR(4);
cQtdAtual CHAR(4);
nTamG NUMBER;
cAdBuf CHAR(2);	
cRepP CHAR(1);
cFrig CHAR(1);
cTempoTrab CHAR(4); 
cTempoRepouso CHAR(4);


BEGIN
    Ret := 1;
	cTip_Term := '1';
	--cLaces := '000';
	cBiotipo := '0';
	--cPlanta := '000';
	cRast := '0';
	cInih := '0';
	cFimh := '0';
	cVal := '0';
	cSMAx := '0'; 
	cTleit := '0'; 
    cPosVPlaca := '0';
    cPosMBloq := '0';
    cValDiasSuc := '0';
    cParidRep := '0';
	cQtdMult := '00';
    cLMinimo := '0000';
	cLMaximo := '0000';
	cQtdAtual := '0000';

	cLaces := NULL;
	cPlanta := NULL;
	
	cRepP := '0';

	cFrig := '0';
	cTempoTrab := '0000';
	cTempoRepouso := '0000';
	
	BEGIN
		select data_length INTO nTamG 
			from   user_tab_columns
			where  table_name = 'DAT07' and	column_name = 'LACES';
	EXCEPTION
		WHEN OTHERS THEN 
			nTamG := 3;		-- ASSUME TAMANHO DO CAMPO LACES COM 3 DIGITOS
	END;
	

    BEGIN
		SELECT Tip_Term, laces, bio_tipo, planta, rastreador, pos_inihalm, pos_fimhalm, valid_ret, VALID_SAIDAMAx, 
			tip_leit, PosValPlaca, PosMensBloq, Valid_NDias, ParidRep, QtdMult ,
			LPAD (to_char(LMINIMO),4, 0), LPAD (to_char(LMAXIMO),4, 0), LPAD (to_char(QTDATUAL),4, 0) 
		INTO cTip_Term,	cLaces,	cBiotipo, cPlanta, cRast, cInih, cFimh, cVal, cSMAx, 
			cTleit, cPosVPlaca, cPosMBloq, cValDiasSuc, cParidRep, cQtdMult,
			cLMinimo, cLMaximo, cQtdAtual 
		FROM DAT07
		WHERE End_Ip = cEndIp;

		IF (cData != '000000') THEN
		-- verifica se data e�de Feriado
		BEGIN
			SELECT desc_fer INTO cDescr	FROM FERIADO
			WHERE (to_char(data_fer, 'ddmmrr') = cData and
				  (TO_NUMBER(planta_fer) = TO_NUMBER(cPlanta) or planta_fer is null or TO_NUMBER(planta_fer) = 0));
			Ret := 2;
		EXCEPTION
			WHEN NO_DATA_FOUND THEN Ret := 1;
			WHEN OTHERS then Ret := -1;
		END;
		END IF;	

	EXCEPTION
		WHEN NO_DATA_FOUND then Ret := 0;
		WHEN OTHERS then Ret := -1;
	END;
	
	if (cTip_Term is Null) then
		cTip_Term := '1';
	end if;

	if (cLaces is Null) then
		if (nTamG = 3)	then
			cLaces := '000';
		else
			cLaces := '00000';
		end if;
	end if;

	if (cBiotipo is Null) then
		cBiotipo := '0';
	end if;

	if (cPlanta is Null) then
		if (nTamG = 3)	then
			cPlanta := '000';
		else
			cPlanta := '00000';
		end if;
		
	end if;

	if (cRast is Null) then
		cRast := '0';
	end if;

	if (cInih is Null) then
		cInih := '0';
	end if;

	if (cFimh is Null) then
		cFimh := '0';
	end if;

	if (cVal is Null) then
		cVal := '0';
	end if;

	if (cSMAx is Null) then
		cSMAx := '0';
	end if;

	if (cTleit is Null) then
		cTleit := '0';
	end if;
	
	if (cPosVPlaca is Null) then
		cPosVPlaca := '0';
	end if;

	if (cPosMBloq is Null) then
		cPosMBloq := '0';
	end if;

	if (cValDiasSuc is Null) then
		cValDiasSuc := '0';
	end if;

	if (cParidRep is Null) then
		cParidRep := '0';
	end if;

	if (cQtdMult is Null) then
		cQtdMult := '00';
	end if;
	
	if (cLMinimo is Null) then
		cLMinimo := '0000';
	end if;
		
	if (cLMaximo is Null) then
		cLMaximo := '0000';
	end if;
	if (cQtdAtual is Null) then
		cQtdAtual := '0000';
	end if;

	IF (nTamG = 3) then
		cAdBuf := '  ';		-- 2 esp�os
	ELSE
		cAdBuf := NULL;
	END IF;

    -- VERIFICA SE REP_P
    BEGIN
		--SELECT REP_P
		--	INTO cRepP
		--	FROM DAT07REPP
		--	WHERE End_Ip = cEndIp;
		SELECT '1'
			INTO cRepP
			FROM DAT07REPP
			WHERE End_Ip = cEndIp and rownum = 1;
	
	EXCEPTION 
		WHEN NO_DATA_FOUND THEN
			cRepP := '0';
		WHEN OTHERS THEN
			cRepP := '0';
	END;
    
    cBuffer := cTip_Term || cLaces || cAdBuf ||
    		   cBiotipo || cPlanta || cAdBuf ||
    		   cRast || cInih || cFimh || cVal || cSMAx || 
    		   '00' || '00' || cTleit || cPosVPlaca || cPosMBloq || cValDiasSuc || cParidRep ||
    		   cQtdMult || cLMinimo || cLMaximo || cQtdAtual || 
    		   cRepP;

    cTamG3G5 := TO_CHAR(nTamG);
    
    -- VERIFICA SE C�MARA FRIGORIFICA
    BEGIN
		--SELECT to_char(TEMPO_TRABALHO, '0000'), to_char(TEMPO_REPOUSO, '0000')   
		SELECT LPAD (to_char(TEMPO_TRABALHO),4, 0),  LPAD (to_char(TEMPO_REPOUSO),4, 0)
			INTO cTempoTrab, cTempoRepouso 
			FROM DATNR36FRIG
			WHERE End_Ip = cEndIp;
		cFrig := '1';
		
	EXCEPTION 
		WHEN NO_DATA_FOUND THEN
			cFrig := '0';
		WHEN OTHERS THEN
			cFrig := '0';
	END;

	cBufFrig := cFrig || cTempoTrab || cTempoRepouso;

    return (Ret);

END sqlconsG3G5_term_geral_tcp18;
/
