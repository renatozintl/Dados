CREATE OR REPLACE FUNCTION sqlbloco_col_dam99_tcp2 (Registro in VARCHAR2, RegDoc in VARCHAR2)
   RETURN NUMBER IS

Ret NUMBER;
dado_veic CHAR(15);
C1 char(12); C2 char(2); C3 char(2);
C4 char(2); C5 char(4); C6 char(2); 
C7 char(2); C8 char(1); C9 char(15); 
C10 char(2); C11 char(1); C12 char(15);
C13 char(2);
C14 char(10); C15 char(10) ;
C16 CHAR (6); C17 char(7); C18 char(7); C19 char(2); C20 char(1);

BEGIN
	dado_veic := '               ';	-- 15 espacos
	
	C1 := SUBSTR(Registro, 1, 12);
	C2 := SUBSTR(Registro, 13, 2);
	C3 := SUBSTR(Registro, 15, 2);
	C4 := SUBSTR(Registro, 17, 2);
	C5 := SUBSTR(Registro, 19, 4);
	C6 := SUBSTR(Registro, 23, 2);
	C7 := SUBSTR(Registro, 25, 2);
	C8 := SUBSTR(Registro, 27, 1);
	C9 := SUBSTR(Registro, 28, 15);
	C10 := SUBSTR(Registro, 43, 2);
	C11 := SUBSTR(Registro, 45, 1);
	C12 := SUBSTR(Registro, 46, 15);	-- VEICULO
	C13 := SUBSTR(Registro, 61, 2);
	C14 := SUBSTR(Registro, 63, 10);
	C15 := SUBSTR(Registro, 73, 10);
	C16 := SUBSTR(Registro, 83, 6);
	C17 := SUBSTR(Registro, 89, 7);
	C18 := SUBSTR(Registro, 96, 7);
	C19 := SUBSTR(Registro, 103, 2);
	C20 := SUBSTR(Registro, 105, 1);

	INSERT INTO DAM00 (ICARD, DIAM, MESM, ANOM, HORAM, SEGUNDO,CODAC, POSIC, END_IP, CODFNC, 
						ONOFF, VEICULO, TIPODOC, ICARD_NS, VEICULO_NS,
						BIO1N)
	
		values (C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, 
				C11, C12, C13, C14, C15,
				C20)  ;

	INSERT INTO DAM99 (ICARD, DIAM, MESM, ANOM, HORAM,SEGUNDO, CODAC, POSIC, END_IP, CODFNC, ONOFF, VEICULO,
						NUMSERIAL, DOC_TIPO, DOCUMENTO, PLACA)
               
               VALUES (C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, C11,
		       			dado_veic,
		       			SUBSTR(RegDoc, 13, 10), SUBSTR(RegDoc, 23, 1),
		       			SUBSTR(RegDoc, 24, 14), SUBSTR(RegDoc, 38, 10)
		       			);
		       			
	
					
		

   Return (0);
END sqlbloco_col_dam99_tcp2;
/


