CREATE OR REPLACE FUNCTION sqlAtuVagas_Estac3 (cMatric VARCHAR2, cGrEstac VARCHAR2, cTipoVaga IN CHAR, nModoAlt IN NUMBER, cRegra IN CHAR) 
RETURN NUMBER IS
Ret  NUMBER;
grAux VARCHAR(8);
cFlag CHAR(1);
cNewTipoVaga CHAR(1);
nMaxFix NUMBER;
nMaxRot NUMBER;
nOcupfix NUMBER;
nOcupRot NUMBER;
nOcupados NUMBER;
nMaxVagas NUMBER;
RECO_LOCK EXCEPTION;
PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);


BEGIN
	
    Ret := 1;
    
    -- REGRA 1 : ESTACIONAMENTO ROTATIVO / FIXO
	-- USUARIO se cadastrado com vaga fixa: 
	--	 se houver vaga em area fixa, entra e estaciona em vaga fixa. Incrementa contador de vaga fixa. atualiza que entrou em estacionamento via area fixa
	--   se n�o houver vaga em area fixa e se houver vaga em rotativo, entra e estaciona em vaga rotativa. Incrementa contador de vaga rotativa. atualiza que entrou em estacionamento usando vaga rotativa
	-- USUARIO NAO cadastrado com vaga fixa:
	--	 s� pode entrar em estacionamento se houver vaga rotativa disponivel
    IF (cRegra = '1') THEN
    	-- verifica se tipo de vaga � Fixa e � Entrada		
		IF (cTipoVaga = 'F') and (nModoAlt > 0) then		
			cFlag := '1';								-- para informar que houve ocupacao da vaga fixa
		ELSE
			cFlag := '0';								-- para informar que n�o houve ocupa��o da vaga fixa
		END IF;

    
		BEGIN
			SELECT GREST INTO grAux 
				FROM ESTAC003 
				WHERE ICARD = cMatric and to_number(GREST) = to_number(cGrEstac) FOR UPDATE; --NOWAIT;


			UPDATE ESTAC003 SET EMFIXA = cFlag WHERE ICARD = cMatric and to_number(GREST) = to_number(cGrEstac);
			COMMIT;


		EXCEPTION
			WHEN NO_DATA_FOUND then
				Ret := 1;
				ROLLBACK;
			WHEN RECO_LOCK then
				ROLLBACK;
				Ret := 1;
			WHEN OTHERS then
				ROLLBACK;
				Ret := 0;			
		END;

	
		IF (Ret = 0) then 
			return (Ret);
		END IF;

		cNewTipoVaga := cTipoVaga;
		
		BEGIN
			-- Procura pelo Grupo de Estacionamento para atualizar quantidade de vagas
			SELECT MAX_FIXO, CONT_FIXO, MAX_ROT, CONT_ROT INTO 
					nMaxFix, nOcupFix, nMaxRot, nOcupRot 
				FROM ESTAC002 WHERE to_number(GREST) = to_number(cGrEstac); 

			-- variavel nOcupados e nMaxVagas ser�o considerados o contador e maximo de vagas dependendo de Fixo ou Rotativo
			IF (cTipoVaga = 'F') then
				nOcupados := nOcupFix;		
				nMaxVagas := nMaxFix;
			ELSE
				nOcupados := nOcupRot;
				nMaxVagas := nMaxRot;
			END IF;

			-- nOcupados ser� incrementado ou decrementado dependendo do valor de nModoAlt (que pode ser:-1, 0, 1)	
			nOcupados := nOcupados + nModoAlt;

			-- verifica vagas ocupadas com valor negativo
			if (nOcupados < 0) then 
				if (cTipoVaga = 'F') then	-- vaga fixa nao fica negativa, troca para rotativa  
					nOcupados := nOcupRot;
					nMaxVagas := nMaxRot;
					nOcupados := nOcupados + nModoAlt;
					cNewTipoVaga := 'R';
				end if;

			elsif (nOcupados > nMaxVagas) then
				if (cTipoVaga = 'F') then	-- vaga fixa nao fica negativa, troca para rotativa
					nOcupados := nOcupRot;
					nMaxVagas := nMaxRot;
					nOcupados := nOcupados + nModoAlt;
					cNewTipoVaga := 'R';
				end if;
			end if;


			-- atualiza contador
			IF (nModoAlt != 0) then
				SELECT GREST into grAux 
					FROM ESTAC002 WHERE to_number(GREST) = to_number(cGrEstac) FOR UPDATE;
			
					IF (cNewTipoVaga = 'F') then
						UPDATE ESTAC002 SET CONT_FIXO = nOcupados WHERE to_number(GREST) = to_number(cGrEstac);
					ELSE
						UPDATE ESTAC002 SET CONT_ROT = nOcupados WHERE to_number(GREST) = to_number(cGrEstac);
					END IF;
				COMMIT;
			END IF;


		EXCEPTION
			WHEN NO_DATA_FOUND then 
				Ret := 0;
				ROLLBACK;
			WHEN RECO_LOCK then
				ROLLBACK;
				Ret := 0;
			WHEN OTHERS then
				ROLLBACK;
				Ret := 0;			
		END;

    -- REGRA 2 : VAGAS REFEITORIO COMUM/VIP
	-- USUARIO se cadastrado com vaga Vip: 
	--	 se houver vaga em area Comum, entra . Incrementa contador de vagas Ocupadas. 
	--	 se nao houver vaga em area Comum mas tem vaga em �rea Vip, entra . Incrementa contador de vagas Ocupadas. 
	--	 se nao houver vaga em area Comum e n�o tem vaga em �rea Vip, � bloqueado. 
	-- USUARIO N�O cadastrado com vaga Vip: 
	--	 se houver vaga em area Comum, entra . Incrementa contador de vagas Ocupadas. 
	--	 se nao houver vaga em area Comum mas tem vaga em �rea Vip, � bloqueado. 
	--	 se nao houver vaga em area Comum e n�o tem vaga em �rea Vip, � bloqueado. 
	ELSIF (cRegra = '2') THEN
		nOcupados := 0;
		IF (nModoAlt != 0) then
			BEGIN
				-- Procura pelo Grupo de Estacionamento para atualizar quantidade de vagas
				SELECT MAX_FIXO, MAX_ROT, CONT_ROT INTO 
						nMaxFix, nMaxRot, nOcupados 
					FROM ESTAC002 WHERE to_number(GREST) = to_number(cGrEstac); -- FOR UPDATE NOWAIT;

				-- nOcupados ser� incrementado ou decrementado dependendo do valor de nModoAlt (que pode ser:-1, 0, 1)	
				nOcupados := nOcupados + nModoAlt;

				-- nao deixa qtde vagas ocupadas ficar negativo
				if (nOcupados < 0) then 
					nOcupados := 0;
				end if;

				-- nao deixa qtde vagas ocupadas ficar maior que o permitido
				-- TIREI. ACHO Q DEVE SER COLOCADO A QTDE Q TEM NA AREA, MESMO QUE TENHA ULTRAPASSADO DO M�XIMO PERMITIDO
--				IF (nOcupados > (nMaxFix + nMaxRot)) then 
--					nOcupados := (nMaxFix + nMaxRot);
--				end if;

				SELECT GREST into grAux 
					FROM ESTAC002 WHERE to_number(GREST) = to_number(cGrEstac) FOR UPDATE;
			

				UPDATE ESTAC002 SET CONT_ROT = nOcupados WHERE to_number(GREST) = to_number(cGrEstac);
				COMMIT;

			EXCEPTION
				WHEN NO_DATA_FOUND then 
					Ret := 0;
					ROLLBACK;
				WHEN RECO_LOCK then
					ROLLBACK;
					Ret := 0;
				WHEN OTHERS then
					ROLLBACK;
					Ret := 0;			
			END;
		END IF;
	END IF;
	COMMIT;
	
	return Ret;
	
END sqlAtuVagas_Estac3;
/


