-- INICIO6TcpArl.SQL: Criacao de Sinonimos privados

SPOOL RESULT6.LOG;

-- Conectar-se como usuario final
-- Criar sinonimo privado de tabelas para usuario
-- cria sinonimos de funcoes e procedures

-- ************************ usuario INICIAL  **************************

CONNECT CAUSU/CAUSUX;
@@CRSYNPRI;



-- ************************   TCP/IP   **************************
-- ************************ usuario USUTCP01 **************************

CONNECT USUTCP01/USUTCP;
@@PTABAT;
@@CRSYNFUNAT;

-- ************************ usuario USUTCP02 **************************

CONNECT USUTCP02/USUTCP;
@@PTABAT;
@@CRSYNFUNAT;




SPOOL OFF;
-- fim.
