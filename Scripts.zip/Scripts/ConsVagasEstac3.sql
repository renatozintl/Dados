CREATE OR REPLACE FUNCTION sqlConsVagas_Estac3 (cGrEstac VARCHAR2, nVagasFixasLivres OUT NUMBER, nVagasRotatLivres OUT NUMBER, cSoFixa OUT VARCHAR) 
RETURN NUMBER IS
Ret  NUMBER;
nMaxFixo NUMBER;
nContFixo NUMBER;
nMaxRot NUMBER;
nContRot NUMBER;
nVal NUMBER;
cRegra VARCHAR2(1);

BEGIN
	
    Ret := 0;
    nVagasFixasLivres := 0;
    nVagasRotatLivres := 0;
    cRegra := '0';
    cSoFixa := '0';


	BEGIN
		-- PROCURA PELO GRUPO DE ESTACIONAMENTO PARA COLETAR AS QUANTIDADES VAGAS
		SELECT MAX_FIXO, CONT_FIXO, MAX_ROT,  CONT_ROT, SOFIXO, REGRA  
			INTO nMaxFixo, nContFixo, nMaxRot, nContRot, cSoFixa, cRegra  
			FROM ESTAC002 WHERE TO_NUMBER(GREST) = TO_NUMBER(cGrEstac);
			
			
		IF (cRegra = '1') then 		-- REGRA DE ESTACIONAMENTO (FIXOS E ROTATIVOS)
			IF (nContFixo < 0) THEN nContFixo := 0; END IF;
			IF (nContRot < 0) THEN nContFixo := 0; END IF;
		
		
			nVagasFixasLivres := (nMaxFixo - nContFixo);
			nVagasRotatLivres := (nMaxRot - nContRot);
			IF (nVagasFixasLivres < 0) then nVagasFixasLivres := 0; end if;
			IF (nVagasRotatLivres < 0) then nVagasRotatLivres := 0; end if;
		
		ELSIF (cRegra = '2') then 	-- REGRA DE REFEIT�RIO (COMUM E VIP)
			IF (nContRot < 0) THEN nContFixo := 0; END IF;
			nVal := (nMaxRot - nContRot);
			IF (nVal > 0) then
				nVagasRotatLivres := nVal;
				nVagasFixasLivres := nMaxFixo;
			ELSE
				nVagasRotatLivres := 0;
				IF ((nMaxFixo + nMaxRot) > nContRot) THEN 
					nVagasFixasLivres := (nMaxFixo + nVal);
				ELSE
					nVagasFixasLivres := 0;
				END IF;
			END IF;
		END IF;
		Ret := 1;


	EXCEPTION
		WHEN NO_DATA_FOUND then Ret := 0;
		WHEN others then Ret := -1;

	END;

	return Ret;
END sqlConsVagas_Estac3
;
/


