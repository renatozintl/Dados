CREATE or REPLACE FUNCTION sqlfim_InsAutoBinBios (cEndIp in VARCHAR2, cStat in VARCHAR2, cBioTipo in VARCHAR2) 
RETURN NUMBER IS

nErr NUMBER;
xCont NUMBER;
cAux VARCHAR2(20);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

cursor lfimbiooutros_cur is 
	SELECT ICARD, STATUS FROM DIG004 
		WHERE END_IP = cEndIp AND 
			  STATUS = '2' AND 
			  BIO_TIPO = cBioTipo
		order by ICARD 
		for update of STATUS;

begin
    xCont := 0;
    nErr := 0;

	BEGIN
		-- atualiza o status somente dos funcionarios do rep q estavam sendo incluidos (sofrendo o comando de inclusao no conex)
		for r in lfimbiooutros_cur LOOP
			update DIG004 set STATUS = cStat where current of lfimbiooutros_cur ;
			xCont := xCont+1;
		END LOOP;

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			nErr := 0;
		WHEN reco_lock THEN
			nErr := 1;
		WHEN OTHERS THEN
			nErr := 1;
	END;
    
	
	BEGIN
		SELECT END_IP into cAux FROM DIG002 
			where END_IP = cEndIp for update nowait;
		
		UPDATE DIG002 SET STATUS = cStat WHERE END_IP = cEndIp;
	
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			nErr := 0;
		WHEN reco_lock THEN
			nErr := 1;
		WHEN OTHERS THEN
			nErr := 1;
	END;
	
	COMMIT;
	return (xCont);
		
END sqlfim_InsAutoBinBios;
/

