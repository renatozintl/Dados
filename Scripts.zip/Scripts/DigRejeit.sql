CREATE or REPLACE FUNCTION sqldig_rejeit (cDigRejeit in VARCHAR2) 
RETURN NUMBER IS

ret NUMBER;
cEndIP CHAR(15);
cMat CHAR(12);
dDataHora DATE;
cBioTipo char(1);
cErro char(1);

BEGIN

	ret := 0;
	cEndIP 		:= SUBSTR (cDigRejeit, 1, 15);
	cMat 		:= SUBSTR (cDigRejeit, 16, 12);
	dDataHora 	:= TO_DATE (SUBSTR (cDigRejeit, 28, 12), 'DDMMYYHH24MISS');
	cBioTipo 	:= SUBSTR (cDigRejeit, 40, 1);
	cErro 		:= SUBSTR (cDigRejeit, 41, 1);
	
	INSERT INTO DIGLOAD002 (END_IP, ICARD, BIO_TIPO, DATA_INS, NERRO) 
					VALUES (cEndIP , cMat, cBioTipo, dDataHora, cErro);
	COMMIT;

	return (ret);
		
END sqldig_rejeit;
/


