CREATE OR REPLACE FUNCTION release_lock (cMatric VARCHAR2, QuemPediu VARCHAR2)
RETURN NUMBER IS

ret NUMBER;
cUsu VARCHAR2(15);

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);  -- erro quando registro lockado

BEGIN
	ret := 0;
	
	BEGIN
		-- locka matricula se esta nao estiver lockada
		select USUARIO into cUsu from TABLOCKS where ICARD = cMatric for update nowait;

		if (cUsu = QuemPediu) then 
			delete from TABLOCKS where ICARD = cMatric;
			ret := 0;
		else 
			ret := -2;
		end if;

	EXCEPTION 		
		WHEN NO_DATA_FOUND then       -- reg. nao encontrado
			ret := 0;

		WHEN reco_lock THEN           -- lockado
			ret := 0;

		WHEN OTHERS then
			ret := 0;
	END;
	COMMIT;
	
	return (ret);
END release_lock;
/

