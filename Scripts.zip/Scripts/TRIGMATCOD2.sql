CREATE OR REPLACE TRIGGER trgmatcod
    AFTER INSERT OR UPDATE OF ICARD, END_IP ON MATCODIN 
    FOR EACH ROW

	call Auxtrg_digmatcod2(:new.icard, :new.end_ip)
/
	