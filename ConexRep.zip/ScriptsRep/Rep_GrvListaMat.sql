CREATE or REPLACE FUNCTION sqlgrava_RepListaMat (cEndIp in VARCHAR2, cNumRep in VARCHAR2, cListaMat in VARCHAR2, cTpLis in VARCHAR2, cDataCol in VARCHAR2, cInicio in VARCHAR2) 
RETURN NUMBER IS

Tam NUMBER;
Pos NUMBER;
ret NUMBER;
RetAux NUMBER;
cAcao VARCHAR2(1);
cBio CHAR(1);

RECO_LOCK EXCEPTION;
PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);
BEGIN


	ret := 1;
	RetAux := 0;      
	cBio := ' ';
	
	IF (cInicio = '1') THEN 
		IF (cTpLis = '1') THEN			-- LISTA DE FUNCIONARIOS
			BEGIN
				DELETE REPFUNCOR WHERE END_IP = cEndIp;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					RetAux := 0;
				WHEN OTHERS THEN
					RetAux := 0;
			END;
		ELSE
			BEGIN
				DELETE REPDIGCOR WHERE END_IP = cEndIp;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					RetAux := 0;
				WHEN OTHERS THEN
					RetAux := 0;
			END;
		END IF;
	END IF;
	
	
	
	Tam := LENGTH (cListaMat) ;
	
	-- VERIFICA SE H� LISTA A SER INSERIDA	
	IF (Tam > 0) THEN
	
		-- VERIFICA O TIPO DE BIOMETRIA, SE HOUVER
		BEGIN
			SELECT BIO_TIPO INTO cBio FROM DAT07 WHERE END_IP = cEndIp;
			IF (cBio is Null) then
				cBio := ' ';
			END IF;

		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				cBio := ' ';
			WHEN OTHERS THEN
				cBio := ' ';
		END;
	

		-- inicializa a posicao	
		Pos := 1;
		
		IF (cTpLis = '1') THEN			-- LISTA DE FUNCIONARIOS
			WHILE (Pos < Tam) LOOP
				INSERT INTO REPFUNCOR (END_IP, REP, IFUNC, BIO_TIPO, DATA_COLETA) 
					VALUES (cEndIp, cNumRep, SUBSTR (cListaMat, Pos, 12) , cBio, to_date (cDataCol, 'ddmmyyhh24miss'));
				Pos := Pos + 12;
			END LOOP;
		END IF;	
		
		IF (cTpLis = '2') THEN			-- LISTA DE DIGITAIS
			WHILE (Pos < Tam) LOOP
				INSERT INTO REPDIGCOR (END_IP, REP, IFUNC, BIO_TIPO, DATA_COLETA) 
					VALUES (cEndIp, cNumRep, SUBSTR (cListaMat, Pos, 12) , cBio, to_date (cDataCol, 'ddmmyyhh24miss'));
				Pos := Pos + 12;
			END LOOP;
		END IF;		
	END IF;
	
	COMMIT;

	return (ret);
		
END sqlgrava_RepListaMat;
/


