CREATE OR REPLACE TRIGGER trgusuveic
    AFTER INSERT OR UPDATE OF icardv OR DELETE ON CONTVEI
    FOR EACH ROW
BEGIN
    IF (inserting or updating) THEN
	update COUNT_BY_VEIC set cnt = cnt+1 where icardv = :new.icardv;
	IF (sql%rowcount = 0) THEN
	    insert into count_by_veic(icardv,cnt) values (:new.icardv,1);
	END IF;
    END IF;
    IF (updating or deleting) THEN
        update count_by_veic set cnt = cnt-1 where icardv = :old.icardv;
    END IF;
END;
/
