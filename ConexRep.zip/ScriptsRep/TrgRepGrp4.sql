-- ESTA TRIGGER SER� EXECUTADO QUANDO INSERT /UPDATE /DELETE NA TABELA REPGRPF 
-- (EX: EXCLUS�O DE GRUPO PARA O FUNCIONARIO, ALTERA��O DO VALOR DO GRUPO PARA O FUNCIONARIO, INCLUSAO DE NOVO GRUPO PARA O FUNCIONARIO)

CREATE OR REPLACE TRIGGER TRGREPGRP_UDI before
UPDATE OF GRUPO OR DELETE OR INSERT ON REPGRPF 
FOR EACH ROW


DECLARE
	dDataAux DATE;
	Aux CHAR(1);
	cAuxDocTipo CHAR(1);
          
	reco_lock EXCEPTION;
	tem_deadlock EXCEPTION; 
	PRAGMA EXCEPTION_INIT (reco_lock, -54);  
	PRAGMA EXCEPTION_INIT (tem_deadlock, -60); 

	
BEGIN

	-- ******************** ATUALIZANDO REGISTRO EM REPGRPF ********************
	IF (updating) THEN
	
		-- para CARGA AUTOMATICA DE FUNCIONARIOS
		-- ******************** analisa grupo 'VELHO' ***********************
		BEGIN
			-- procura em REPNAUTO000 se o Funcionario x GrupoVelho que foi modificado j� est� em tabela para ser Excluido (status '8').
			-- Se estiver presente , nada faz
			SELECT STATUS INTO Aux 
				FROM REPNAUTO000 
				WHERE REPNAUTO000.IFUNC = :OLD.IFUNC and 
					  to_number (REPNAUTO000.GRUPO) = to_number(:OLD.GRUPO) and 
					  REPNAUTO000.STATUS = '8'	;
					  
		
		EXCEPTION
			WHEN NO_DATA_FOUND then
				-- nao encontrou Funcionario para ser excluido do grupo, verifica qual o status se estiver em tabela 
				BEGIN
					SELECT STATUS into Aux FROM REPNAUTO000 
						WHERE REPNAUTO000.IFUNC = :OLD.IFUNC and 
							  to_number(REPNAUTO000.GRUPO) = to_number(:OLD.GRUPO);
							  
					-- verifica se est� na tabela para ainda ser processado para inclusao ou j� incluido
					IF (Aux = '3' OR Aux = '0') then
						-- como est� para ser incluido, altera para status de exclusao, atualizando a data
						SELECT sysdate into dDataAux from dual;
						UPDATE REPNAUTO000 SET STATUS = '8' , DATA_INS = sysdate , DOC_TIPO = '0'  
							WHERE REPNAUTO000.IFUNC = :OLD.IFUNC and 
							  	  to_number(REPNAUTO000.GRUPO) = to_number(:OLD.GRUPO);
					END IF;

				EXCEPTION
					-- esta matricula nao sofreu nenhuma inclusao ou exclusao, ent�o insere na tabela REPNAUTO000 como Exclusao. 
					-- A data/hora (DATA_INS) �ser� atualizada com a dta corrente
					WHEN NO_DATA_FOUND then
						INSERT INTO REPNAUTO000 (IFUNC, STATUS, GRUPO, DOC_TIPO) 
									VALUES    	(:OLD.IFUNC, '8', :OLD.GRUPO, '0');
									
					WHEN reco_lock then NULL;
					WHEN OTHERS then NULL;
				END;

			WHEN reco_lock then NULL;
			WHEN OTHERS then NULL;
		END;
			

		-- *********************** analisa grupo 'NOVO' ***********************
		BEGIN

			-- procura em REPNAUTO000 se o Funcionario x GrupoNovo  j� est� em tabela para ser Incluido (status '3').
			-- Se estiver presente , nada faz
			
			SELECT STATUS, DOC_TIPO INTO Aux , cAuxDocTipo 
				FROM REPNAUTO000 
				WHERE REPNAUTO000.IFUNC = :OLD.IFUNC and 
					  to_number(REPNAUTO000.GRUPO) = to_number(:NEW.GRUPO) and
					  REPNAUTO000.STATUS = '3' FOR UPDATE NOWAIT;
					  
			IF (cAuxDocTipo <> '0') THEN  		-- VERIFICA SE H� ATUALIZACAO ESPECIFICA, SE HOUVER MUDA PARA ALTERACAO TOTAL ('0') (CPF E PIS)
				UPDATE REPNAUTO000 SET DOC_TIPO = '0'
					WHERE REPNAUTO000.IFUNC = :OLD.IFUNC and 
						  to_number(REPNAUTO000.GRUPO) = to_number(:NEW.GRUPO) and
						  REPNAUTO000.STATUS = '3';				
			END IF;
			
		EXCEPTION
			WHEN NO_DATA_FOUND then
				-- nao encontrou Funcionario para ser incluido no grupo, verifica qual o status se estiver em tabela 
				BEGIN
					SELECT STATUS into Aux FROM REPNAUTO000 
						WHERE REPNAUTO000.IFUNC = :OLD.IFUNC and 
							  to_number(REPNAUTO000.GRUPO) = to_number(:NEW.GRUPO);
					
					-- verifica se est� na tabela para ainda ser processado para exclusao ou j� excluido
					IF (Aux = '8' OR Aux = '0') then
						
						-- como est� para ser excluido, altera para status de inclusao, atualizando a data COM 1 SEGUNDO  MAIS , POIS PRIMEIRO DELETA , DEPOIS INCLUI
						--( NA SITUA��O DE TROCAR PARA MESMO GRUPO)
						SELECT SYSDATE+(1/24/60/60) into dDataAux FROM DUAL;
						UPDATE REPNAUTO000 SET STATUS = '3' , DATA_INS = dDataAux, DOC_TIPO = '0' 
							WHERE REPNAUTO000.IFUNC = :OLD.IFUNC and 
								to_number(REPNAUTO000.GRUPO) = to_number(:NEW.GRUPO);
					END IF;
							  
				EXCEPTION
					-- este (funcionario x grupo) nao sofreu nenhuma inclusao ou exclusao, ent�o insere na tabela REPNAUTO000 como Inclusao. 
					-- A data/hora (DATA_INS) �ser� atualizada com a dta corrente
					WHEN NO_DATA_FOUND then
						SELECT SYSDATE+(1/24/60/60) into dDataAux FROM DUAL;
						INSERT INTO REPNAUTO000 (IFUNC, STATUS, GRUPO, DOC_TIPO, DATA_INS) 
										VALUES 	(:OLD.IFUNC, '3', :NEW.GRUPO, '0', dDataAux);
					
					WHEN reco_lock then NULL;
					WHEN OTHERS then NULL;
				END;

			WHEN reco_lock then NULL;
			WHEN OTHERS then NULL;
		END;
	
	
		-- para CARGA AUTOMATICA DE DIGITAIS
		-- ******************** analisa grupo 'VELHO' ***********************
		BEGIN
			-- procura em REPNDIGAUTO000 se o Funcionario x GrupoVelho que foi modificado j� est� em tabela para ser Excluido (status '8').
			-- Se estiver presente , nada faz
			SELECT STATUS INTO Aux 
				FROM REPNDIGAUTO000 
				WHERE REPNDIGAUTO000.IFUNC = :OLD.IFUNC and 
					  REPNDIGAUTO000.BIO_TIPO = '0' and 
					  to_number (REPNDIGAUTO000.GRUPO) = to_number(:OLD.GRUPO) and
					  REPNDIGAUTO000.STATUS = '8'	;
					  
		
		EXCEPTION
			WHEN NO_DATA_FOUND then
				-- nao encontrou Funcionario para ser excluido do grupo, verifica qual o status se estiver em tabela 
				BEGIN
					SELECT STATUS into Aux FROM REPNDIGAUTO000 
						WHERE REPNDIGAUTO000.IFUNC = :OLD.IFUNC and 
							REPNDIGAUTO000.BIO_TIPO = '0' and 
							to_number(REPNDIGAUTO000.GRUPO) = to_number(:OLD.GRUPO);
							  
					-- verifica se est� na tabela para ainda ser processado para inclusao ou j� incluido
					IF (Aux = '3' OR Aux = '0') then
						-- como est� para ser incluido, altera para status de exclusao, atualizando a data
						SELECT sysdate into dDataAux from dual;
						UPDATE REPNDIGAUTO000 SET STATUS = '8' , DATA_INS = sysdate  
							WHERE REPNDIGAUTO000.IFUNC = :OLD.IFUNC and 
								REPNDIGAUTO000.BIO_TIPO = '0' and 
								to_number(REPNDIGAUTO000.GRUPO) = to_number(:OLD.GRUPO);
					END IF;

				EXCEPTION
					-- esta matricula nao sofreu nenhuma inclusao ou exclusao, ent�o insere na tabela REPNDIGAUTO000 como Exclusao. 
					-- A data/hora (DATA_INS) �ser� atualizada com a dta corrente
					WHEN NO_DATA_FOUND then
						INSERT INTO REPNDIGAUTO000 (IFUNC, STATUS, GRUPO, BIO_TIPO) 
									VALUES    	(:OLD.IFUNC, '8', :OLD.GRUPO, '0');
									
					WHEN reco_lock then NULL;
					WHEN OTHERS then NULL;
				END;

			WHEN reco_lock then NULL;
			WHEN OTHERS then NULL;
		END;
			

		-- *********************** analisa grupo 'NOVO' ***********************
		BEGIN

			-- procura em REPNDIGAUTO000 se o Funcionario x GrupoNovo  j� est� em tabela para ser Incluido (status '3').
			-- Se estiver presente , nada faz
		
			SELECT STATUS INTO Aux 
				FROM REPNDIGAUTO000 
				WHERE REPNDIGAUTO000.IFUNC = :OLD.IFUNC and 
					REPNDIGAUTO000.BIO_TIPO = '0' and 
					to_number(REPNDIGAUTO000.GRUPO) = to_number(:NEW.GRUPO) and
					REPNDIGAUTO000.STATUS = '3';
					  
		EXCEPTION
			WHEN NO_DATA_FOUND then
				-- nao encontrou Funcionario para ser incluido no grupo, verifica qual o status se estiver em tabela 
				BEGIN
					SELECT STATUS into Aux FROM REPNDIGAUTO000 
						WHERE REPNDIGAUTO000.IFUNC = :OLD.IFUNC and 
							REPNDIGAUTO000.BIO_TIPO = '0' and 						
							to_number(REPNDIGAUTO000.GRUPO) = to_number(:NEW.GRUPO);
					
					-- verifica se est� na tabela para ainda ser processado para exclusao ou j� excluido
					IF (Aux = '8' OR Aux = '0') then
						
						-- como est� para ser excluido, altera para status de inclusao, atualizando a data COM 1 SEGUNDO  MAIS , POIS PRIMEIRO DELETA , DEPOIS INCLUI
						--( NA SITUA��O DE TROCAR PARA MESMO GRUPO)
						SELECT SYSDATE+(1/24/60/60) into dDataAux FROM DUAL;
						UPDATE REPNDIGAUTO000 SET STATUS = '3' , DATA_INS = dDataAux
							WHERE REPNDIGAUTO000.IFUNC = :OLD.IFUNC and 
								REPNDIGAUTO000.BIO_TIPO = '0' and 
								to_number(REPNDIGAUTO000.GRUPO) = to_number(:NEW.GRUPO);
					END IF;
							  
				EXCEPTION
					-- este (funcionario x grupo) nao sofreu nenhuma inclusao ou exclusao, ent�o insere na tabela REPNDIGAUTO000 como Inclusao. 
					-- A data/hora (DATA_INS) �ser� atualizada com a dta corrente
					WHEN NO_DATA_FOUND then
						SELECT SYSDATE+(1/24/60/60) into dDataAux FROM DUAL;
						INSERT INTO REPNDIGAUTO000 (IFUNC, STATUS, GRUPO, BIO_TIPO, DATA_INS) 
										VALUES 	(:OLD.IFUNC, '3', :NEW.GRUPO, '0', dDataAux);
					
					WHEN reco_lock then NULL;
					WHEN OTHERS then NULL;
				END;

			WHEN reco_lock then NULL;
			WHEN OTHERS then NULL;
		END;
		
	
	
	-- ********************  EXCLUINDO REGISTRO EM REPGRPF  ********************
	
	ELSIF (deleting) THEN
		-- para CARGA AUTOMATICA DE FUNCIONARIOS
		BEGIN
			-- procura em REPNAUTO000 se o Funcionario x GrupoVelho que est� excluindo j� est� em tabela 
			-- Se estiver presente , nada faz
			SELECT STATUS into Aux FROM REPNAUTO000 
				WHERE REPNAUTO000.IFUNC = :OLD.IFUNC and 
					  to_number(REPNAUTO000.GRUPO) = to_number(:OLD.GRUPO) ;
					  
			-- verifica se (funcionario x grupo) est� na tabela para ainda ser processado para inclusao ou j� incluido
			IF (Aux = '3' OR Aux = '0') then
				-- como est� para ser incluido, altera para status de exclusao, atualizando a data
				UPDATE REPNAUTO000 SET STATUS = '8' , DATA_INS = sysdate , DOC_TIPO = '0' 
					WHERE REPNAUTO000.IFUNC = :OLD.IFUNC and 
						  to_number(REPNAUTO000.GRUPO) = to_number(:OLD.GRUPO);
			END IF;
			
		EXCEPTION
			WHEN NO_DATA_FOUND then
				-- este (funcionario x grupo) nao sofreu nenhuma inclusao ou exclusao, ent�o insere na tabela REPNAUTO000 como Exclusao. 
				-- A data/hora (DATA_INS) �ser� atualizada com a dta corrente
				INSERT INTO REPNAUTO000 (IFUNC, STATUS, GRUPO, DOC_TIPO) 
								VALUES 	(:OLD.IFUNC, '8', :OLD.GRUPO, '0');

			WHEN reco_lock then NULL;
			WHEN OTHERS then NULL;
		END;	
	

		-- para CARGA AUTOMATICA DE DIGITAIS
		BEGIN
			-- procura em REPNDIGAUTO000 se o Funcionario x GrupoVelho que est� excluindo j� est� em tabela 
			-- Se estiver presente , nada faz
			SELECT STATUS into Aux FROM REPNDIGAUTO000 
				WHERE REPNDIGAUTO000.IFUNC = :OLD.IFUNC and 
					  REPNDIGAUTO000.BIO_TIPO = '0' and 
					  to_number(REPNDIGAUTO000.GRUPO) = to_number(:OLD.GRUPO) ;
					  
			-- verifica se (funcionario x grupo) est� na tabela para ainda ser processado para inclusao ou j� incluido
			IF (Aux = '3' OR Aux = '0') then
				-- como est� para ser incluido, altera para status de exclusao, atualizando a data
				UPDATE REPNDIGAUTO000 SET STATUS = '8' , DATA_INS = sysdate 
					WHERE REPNDIGAUTO000.IFUNC = :OLD.IFUNC and 
						  REPNDIGAUTO000.BIO_TIPO = '0' and 
						  to_number(REPNDIGAUTO000.GRUPO) = to_number(:OLD.GRUPO);
			END IF;
			
		EXCEPTION
			WHEN NO_DATA_FOUND then
				-- este (funcionario x grupo) nao sofreu nenhuma inclusao ou exclusao, ent�o insere na tabela REPNDIGAUTO000 como Exclusao. 
				-- A data/hora (DATA_INS) �ser� atualizada com a dta corrente
				INSERT INTO REPNDIGAUTO000 (IFUNC, STATUS, GRUPO, BIO_TIPO) 
								VALUES 	(:OLD.IFUNC, '8', :OLD.GRUPO, '0');

			WHEN reco_lock then NULL;
			WHEN OTHERS then NULL;
		END;	
	
	
	-- ********************  INSERINDO REGISTRO EM REPGRPF  ********************
	
	ELSIF (inserting) THEN
		-- para CARGA AUTOMATICA DE FUNCIONARIOS
		BEGIN
			-- procura em REPNAUTO000 se o Funcionario x Grupo que est� INSERINDO j� est� em tabela 
			-- Se estiver presente , nada faz
			SELECT STATUS, DOC_TIPO INTO Aux, cAuxDocTipo  
				FROM REPNAUTO000 
				WHERE REPNAUTO000.IFUNC = :NEW.IFUNC and 
					TO_NUMBER(REPNAUTO000.GRUPO) = TO_NUMBER(:NEW.GRUPO) ;
					
			IF (Aux = '8' OR Aux = '0') THEN
				-- como est� para ser excluido, altera para status de inclusao, atualizando a data
				UPDATE REPNAUTO000 SET STATUS = '3' , DATA_INS = sysdate , DOC_TIPO = '0' 
					WHERE REPNAUTO000.IFUNC = :NEW.IFUNC and 
						TO_NUMBER(REPNAUTO000.GRUPO) = TO_NUMBER(:NEW.GRUPO);
			ELSE
				IF (cAuxDocTipo <> '0') THEN
					UPDATE REPNAUTO000 SET STATUS = '3' , DATA_INS = sysdate, DOC_TIPO = '0' 
						WHERE REPNAUTO000.IFUNC = :NEW.IFUNC and 
							TO_NUMBER(REPNAUTO000.GRUPO) = TO_NUMBER(:NEW.GRUPO);
				END IF;			
			
			
			END IF;

		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				-- este (funcionario x grupo) nao sofreu nenhuma inclusao ou exclusao, ent�o insere na tabela REPNAUTO000 como Inclusao. 
				-- A data/hora (DATA_INS) �ser� atualizada com a dta corrente
				INSERT INTO REPNAUTO000 (IFUNC, STATUS, GRUPO, DOC_TIPO) 
								VALUES 	(:NEW.IFUNC, '3', :NEW.GRUPO, '0');
								
			WHEN reco_lock THEN	NULL;
			WHEN OTHERS THEN NULL;

		END;	

		-- para CARGA AUTOMATICA DE DIGITAIS
		BEGIN
			-- procura em REPNDIGAUTO000 se o Funcionario x Grupo que est� INSERINDO j� est� em tabela 
			-- Se estiver presente , nada faz
			SELECT STATUS INTO Aux 
				FROM REPNDIGAUTO000 
				WHERE REPNDIGAUTO000.IFUNC = :NEW.IFUNC and 
					REPNDIGAUTO000.BIO_TIPO = '0' and 
					TO_NUMBER(REPNDIGAUTO000.GRUPO) = TO_NUMBER(:NEW.GRUPO) ;

			IF (Aux = '8' OR Aux = '0') THEN
				-- como est� para ser excluido, altera para status de inclusao, atualizando a data
				UPDATE REPNDIGAUTO000 SET STATUS = '3' , DATA_INS = sysdate 
					WHERE REPNDIGAUTO000.IFUNC = :NEW.IFUNC and 
						REPNDIGAUTO000.BIO_TIPO = '0' and 
						TO_NUMBER(REPNDIGAUTO000.GRUPO) = TO_NUMBER(:NEW.GRUPO);
			END IF;

		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				-- este (funcionario x grupo) nao sofreu nenhuma inclusao ou exclusao, ent�o insere na tabela REPNDIGAUTO000 como Inclusao. 
				-- A data/hora (DATA_INS) �ser� atualizada com a dta corrente
				INSERT INTO REPNDIGAUTO000 (IFUNC, STATUS, GRUPO, BIO_TIPO) 
								VALUES 	(:NEW.IFUNC, '3', :NEW.GRUPO, '0');
								
			WHEN reco_lock THEN	NULL;
			WHEN OTHERS THEN NULL;

		END;	
	
	END IF;
		
END;	
/



