CREATE OR REPLACE FUNCTION sqlatu_outrosbios_CNX (cMatric in VARCHAR2, cTempl in VARCHAR2, nTipoPadAlt in NUMBER, nQtdBytes in NUMBER, cBioTipo in VARCHAR2)
   RETURN NUMBER IS
   cAuxMat VARCHAR2(15);
   nNovo NUMBER;
   nDedo NUMBER;
   nRetorno NUMBER;
   cAux   VARCHAR2(15);
   reco_lock EXCEPTION;
   PRAGMA EXCEPTION_INIT (reco_lock,-54);  -- erro quando registro lockado 

BEGIN

	nRetorno := 1;

	BEGIN
		SELECT Icard INTO cAuxMat FROM CONTDIG_OUTROS
			WHERE Icard = cMatric AND 				-- matricula
				  BIO_TIPO = cBioTipo 			-- identificador  do biometrico 
		FOR UPDATE NOWAIT;
		
		IF (nTipoPadAlt = 0) THEN			-- ATUALIZANDO PADRAO
			UPDATE CONTDIG_OUTROS
				SET DIGITAL_PAD = to_clob(cTempl) ,
					Status = '1', Status_rep = '1'
			WHERE Icard = cMatric AND 				-- matricula
				  BIO_TIPO = cBioTipo ;		-- identificador  do biometrico 
		ELSE
			UPDATE CONTDIG_OUTROS
				SET DIGITAL_ALT = to_clob(cTempl) ,
					Status = '1', Status_rep = '1'
			WHERE Icard = cMatric AND 				-- matricula
				  BIO_TIPO = cBioTipo ;			-- identificador  do biometrico 
		END IF;		
		
		
	EXCEPTION
		WHEN reco_lock THEN nRetorno:= -1;
		WHEN NO_DATA_FOUND THEN 
			nRetorno := 0;
		WHEN OTHERS THEN nRetorno := -1;
	END;

	
	
	IF (nRetorno = 0) THEN          -- matricula NAO existe, INSERE a digital
		IF (nTipoPadAlt = 0) THEN			-- INSERINDO PADRAO
			INSERT INTO CONTDIG_OUTROS (ICARD, DIGITAL_PAD, BIO_TIPO, STATUS, STATUS_REP) values 
										(cMatric, to_clob(cTempl), cBioTipo, '1', '1');
		ELSE
			INSERT INTO CONTDIG_OUTROS (ICARD, DIGITAL_ALT, BIO_TIPO, STATUS, STATUS_REP) values 
										(cMatric, to_clob(cTempl), cBioTipo, '1', '1');
		END IF;
		nRetorno := 1;
		
	END IF;
	
	COMMIT;    
	
	
    return (nRetorno);

END sqlatu_outrosbios_CNX;
/

