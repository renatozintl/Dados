-- *****************   TABELA  DAM00NR36
DROP TABLE DAM00NR36 ;

CREATE TABLE DAM00NR36 (
  ICARD      CHAR(12)  NOT NULL,									-- icard do Titular
  DATA_OCORR DATETIME  NOT NULL,									-- Data/Hora da Ocorrencia (Marca��o)
  POSIC      CHAR(1)   NOT NULL,									-- Entrada (0) ou Saida (1)
  END_IP     CHAR(15)  DEFAULT '000.000.000.000' NOT NULL,			-- Ender.IP do equipamento
  ONOFF      CHAR(1)   NOT NULL,									-- Marca��o Online (1), Offline (0)
  DATA_INS   DATETIME  DEFAULT getdate() NOT NULL, 					-- data/hora da inclusao do registro na tabela
  CTRL 		 VARCHAR(100)												-- controle de processamento
)
GO

CREATE INDEX DAM00NR36_IND1 ON DAM00NR36 (CTRL) 
GO
