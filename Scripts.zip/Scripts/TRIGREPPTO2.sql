CREATE OR REPLACE TRIGGER trgRepPto
   BEFORE INSERT OR UPDATE OF DTAHORAREP ON REPPONTO
   FOR EACH ROW

DECLARE
   cMat varchar(12) := NULL;
   cMatOld varchar(12) := NULL;
   NovoDHPto date;
   OldDHPto date;
   DHAntigo date;
   nSegundos number;
   
   cMatAux varchar(12) := NULL;
   nCont number;	
   
	reco_lock EXCEPTION;
	tem_deadlock EXCEPTION; 
	PRAGMA EXCEPTION_INIT (reco_lock, -54);  
	PRAGMA EXCEPTION_INIT (tem_deadlock, -60); 

BEGIN
	--cMat 	  := :NEW.IFUNC;
	--NovoDHPto := :NEW.DTAHORAREP;
	
	--cMatOld  := :OLD.IFUNC;
	--OldDHPto := :OLD.DTAHORAREP;
	
	nSegundos := 77;		-- 77 segundos
	IF (:OLD.IFUNC = :NEW.IFUNC)	THEN		-- VERIFICA SE JA EXISTIA MATRICULA EM TABELA REPPONTO
		IF (:NEW.DTAHORAREP > (:OLD.DTAHORAREP + nSegundos/86400)) THEN 			-- 86400 = 24 * 60 * 60 (qtde segundos em 1 dia)
			BEGIN
				SELECT IFUNC into cMatAux			-- procurar pela marcacao  em tabela ULTREPPONTO
					FROM ULTREPPONTO 
					WHERE IFUNC = :NEW.IFUNC AND 
						  DTAHORAREP = :OLD.DTAHORAREP;

			EXCEPTION

				WHEN NO_DATA_FOUND then 		-- NAO EXISTE A MESMA MARCACAO EM ULTREPPONTO, VAI INSERIR
				begin
					SELECT count(*) into nCont FROM ULTREPPONTO WHERE IFUNC = :NEW.IFUNC;
					IF (nCont >= 8) then				-- VERIFICA SE TEM MAIS DE 8 MARCACOES
						-- procura pela marcacao mais antiga deste usuario, para que seja deletada 
						SELECT MIN(DTAHORAREP) into DHAntigo FROM ULTREPPONTO 
							WHERE IFUNC = :NEW.IFUNC;		

						-- DELETA MARCACAO MAIS ANTIGA
						DELETE FROM ULTREPPONTO WHERE IFUNC = :NEW.IFUNC AND DTAHORAREP = DHAntigo;		
					END IF;

					-- TRANSFERE MARCACAO QUE ESTAVA EM REPPONTO PARA ULTREPPONTO
					INSERT INTO ULTREPPONTO (IFUNC, DTAHORAREP) VALUES (:NEW.IFUNC, :OLD.DTAHORAREP);		
				end;

				WHEN others then NULL;
			END;
		END IF;
	END IF;
END;
/



