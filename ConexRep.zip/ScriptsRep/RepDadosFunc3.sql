CREATE OR REPLACE FUNCTION sqlproc_dadosfunc3 (cEndIp VARCHAR2, cNumRep VARCHAR2, nTotal NUMBER, cLisMat VARCHAR2, cTipoRep4000 CHAR, cLisOKMat IN OUT VARCHAR2, cLisPis IN OUT VARCHAR2, cLisNome IN OUT VARCHAR2, cErrMat IN OUT VARCHAR2)   
RETURN NUMBER IS

Retfun NUMBER;
nCont NUMBER;
nContOK NUMBER;
nPos NUMBER;
cFunc VARCHAR2(12);
cPis VARCHAR2(12);
cCpf VARCHAR2(11);
cNome VARCHAR2(52);
nInsLista NUMBER;
cCpf VARCHAR2(11);


BEGIN

	Retfun := 0;      -- assume que achou o icard
	cLisOkMat := '';		-- assume lista vazia de matriculas ok
	cLisPis := '';
	cLisNome := '';
	cErrMat := '';
	nCont := 0;
	nContOK := 0;
	
	WHILE (nCont < nTotal) LOOP
		nPos := (nCont * 12) + 1;
		cFunc := SUBSTR (cLisMat, nPos, 12);

		nInsLista := 1;

		BEGIN
			-- procura pelo nome e PIS contendo somente 12 digitos
			--SELECT PIS, NOME  
			SELECT PIS, NOME, CPF   
				INTO cPis, cNome, cCpf   
			FROM REPEMPR002 WHERE (IFUNC = cFunc) and 
								  (translate(PIS,'A0123456789', 'A') is null and length(PIS) = 12) and
								  (translate(CPF,'A0123456789', 'A') is null and length(CPF) = 11);
			
			IF (cTipoRep4000 = '1') THEN
				IF (cCpf = '00000000000') THEN 
					INSERT INTO REPLOAD001 (END_IP, REP, IFUNC, DIA) 
						VALUES (cEndIp, cNumRep, cFunc, SYSDATE);
					nInsLista := 0;
					
				ELSE
					cPis := '0'|| cCpf;
				END IF;
			ELSE
				IF (cPis = '000000000000') THEN 
					INSERT INTO REPLOAD001 (END_IP, REP, IFUNC, DIA) 
						VALUES (cEndIp, cNumRep, cFunc, SYSDATE);
					nInsLista := 0;
				END IF;
			END IF;
			
			
			IF (nInsLista = 1) THEN 
				cLisOkMat := cLisOkMat || cFunc ;
				cLisPis := cLisPis || cPis ;
				cLisNome := cLisNome || cNome || ';';
				nContOK := nContOK + 1;
			END IF;
			

		EXCEPTION
			WHEN NO_DATA_FOUND THEN 
				BEGIN
					INSERT INTO REPLOAD001 (END_IP, REP, IFUNC, DIA) 
						VALUES (cEndIp, cNumRep, cFunc, SYSDATE);

				EXCEPTION
					WHEN OTHERS THEN 
						Retfun := -1;
				END;
				if (cErrMat is null) then 
					cErrMat := cFunc ;
				end if;					
				
				
			WHEN OTHERS THEN 
				BEGIN
					INSERT INTO REPLOAD001 (END_IP, REP, IFUNC, DIA) 
						VALUES (cEndIp, cNumRep, cFunc, SYSDATE);
				EXCEPTION
					WHEN OTHERS THEN 
						Retfun := -1;
				END;
				if (cErrMat = null) then 
					cErrMat := cFunc ;
				end if;
				
				Retfun := -1;
		END;
		nCont := nCont + 1;

	END LOOP;
	
	COMMIT;
	
	if (Retfun < 0 ) then 
		return (Retfun);
	else
		return (nContOK);
	end if;
	
END sqlproc_dadosfunc3;
/


