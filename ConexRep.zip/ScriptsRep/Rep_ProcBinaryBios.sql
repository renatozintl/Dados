
CREATE OR REPLACE FUNCTION sqlrproc_binarybios (MATRIC VARCHAR2, cEndIp VARCHAR2, cNumRep VARCHAR2, cBioTipo in VARCHAR2, cDados1 out blob, cDados2 out blob, len1 out number, len2 out number)
   RETURN NUMBER IS
cAux   VARCHAR2(15);
Retfun NUMBER;
Alt NUMBER;
Pad NUMBER;
RECO_LOCK EXCEPTION;
PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);

BEGIN

	cDados1 := null;
	cDados2 := null;
	len1 := 0;
	len2 := 0;
    Pad := 0;
    Alt := 0;
    Retfun := 3;      -- sem templ padrao e sem templ alternativo

	begin
		select icard, DIGITALBIN_PAD, dbms_lob.getlength(DIGITALBIN_PAD), DIGITALBIN_ALT, dbms_lob.getlength(DIGITALBIN_ALT)
			into cAux, cDados1, len1, cDados2, len2  
		from CONTDIG_OUTROS 
		WHERE ICARD = MATRIC AND 
		  	  BIO_TIPO = cBioTipo;

		IF ((len1 is NULL) OR (cDados1 is NULL)) THEN 
			len1 := 0;
			Pad := 0;
		END IF;
		
		IF ((len2 is NULL) OR (cDados2 is NULL)) THEN 
			len2 := 0;
			Alt := 0;
		end if;
		
		IF (len1 > 0) THEN 
			Pad := 1;
		end if;

		IF (len2 > 0) THEN 
			Alt := 1;
		end if;
		
	exception
		when NO_DATA_FOUND then	
			Pad := 0;
			Alt := 0;
		when OTHERS then	
			Pad := 0;
			Alt := 0;
	end;

	-- PREPARA RESULTADO	
	if (Pad = 1) then
	    if (Alt = 1) then
			Retfun := 0;   -- tem padrao e tem alternativo
		else 
			Retfun := 1;   -- tem padrao e nao tem alternativo
    	end if;
	else
		if (Alt = 1) then
			Retfun := 2;   -- nao tem padrao e tem alternativo
		else 
			Retfun := 3;   -- nao tem padrao e nao tem alternativo
		end if;
	end if;
	
	IF (Retfun = 3)	then 	-- digital nao cadastrado
		INSERT INTO REPDIGLOAD001 (END_IP, REP, IFUNC, BIO_TIPO) 
			VALUES (cEndIp, cNumRep, MATRIC, cBioTipo);
		COMMIT;
	END IF;
	
	return (Retfun);
END sqlrproc_binarybios;
/

