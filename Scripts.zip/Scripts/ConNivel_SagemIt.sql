CREATE OR REPLACE FUNCTION sqlnivel_sagemit (cMatric VARCHAR2,  
cNivel IN OUT VARCHAR2, cNivel2 IN OUT VARCHAR2) 
RETURN NUMBER IS

RetFun    NUMBER;
cNivAux VARCHAR2(2);
cNivAux2 VARCHAR2(2);

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);  -- erro quando registro lockado

BEGIN
	RetFun := 0;
	cNivel := '00';
	cNivel2 := '00';
	
	BEGIN
		SELECT 
			NUM_DEDO_PAD, NUM_DEDO_ALT 
		INTO 
			cNivAux, cNivAux2  
		FROM CONTDIG_SAGEM 
		WHERE Icard = cMatric ;
			
		if (cNivAux is not Null) then
			cNivel := cNivAux;
		end if;

		if (cNivAux2 is not Null) then
			cNivel2 := cNivAux2;
		end if;
			
	EXCEPTION
		WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
			RetFun := -1;
			return (RetFun);
		WHEN OTHERS THEN              -- outros erros
			RetFun := -1;
			return (RetFun);
	END;
		
	Return (RetFun);

END sqlnivel_sagemit;
/
