CREATE OR REPLACE  PROCEDURE AntePrep2_ROutrosBios (nQtd NUMBER)  
IS

TYPE icard_type IS TABLE OF CONTDIG_OUTROS.icard%TYPE 
	INDEX BY binary_integer;
TYPE statusrep_type IS TABLE OF CONTDIG_OUTROS.status_rep%TYPE 
	INDEX BY binary_integer;
TYPE biotipo_type IS TABLE OF CONTDIG_OUTROS.bio_tipo%TYPE 
	INDEX BY binary_integer;
	
l_icard icard_type;
l_statusrep statusrep_type;
l_biotipo biotipo_type;

total number;

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock,-54);  -- erro quando registro lockado 
tem_deadlock EXCEPTION; 
PRAGMA EXCEPTION_INIT (tem_deadlock, -60); 
	
	
BEGIN
	SELECT ICARD, STATUS_REP, BIO_TIPO  
		BULK COLLECT INTO l_icard, l_statusrep, l_biotipo 
	from 
		CONTDIG_OUTROS 
	where 
		STATUS_REP = '1' or STATUS_REP = '3' or STATUS_REP = '8';
		
	total := l_icard.count;
	
	-- NOVO
	--IF (total > 5) then
	--	total := 5;
	
	IF (total > nQtd) then
		total := nQtd;
	END IF;

	-- ******************************************************************
	-- PARA TODOS AS BIOMETRIAS  CADASTRADOS/INSERIDOS/DELETADOS
	FOR indx IN 1 .. total     
	LOOP
		IF (l_statusrep(indx) =  '1' OR l_statusrep(indx) =  '3' OR l_statusrep(indx) =  '8' ) THEN
			Auxtrg_repDig2 (l_icard(indx), l_statusrep(indx), l_biotipo(indx));

			UPDATE CONTDIG_OUTROS SET STATUS_REP = '0' 
					where ICARD = l_icard(indx) and
						BIO_TIPO = l_biotipo(indx);
		END IF;
	
	END LOOP;

	COMMIT;
	
end AntePrep2_ROutrosBios;
/
