CREATE OR REPLACE FUNCTION SQLMAT_GRUPO_tcp (cMatric VARCHAR2, cData VARCHAR2, cEndIp VARCHAR2)
RETURN NUMBER IS

i number;
achou number;
k number;
ini number;
fim number;
fx_ini varchar2(6);
fx_fim varchar2(6);


BEGIN
	achou := 0;
 	for r in 
		( 
		select 
			a.grupo, a.fxperm 
		from 
			tabgrpsetfx a, matgrupo b 
		where a.end_ip = cEndIp and 
			b.icard = cMatric and
			TO_NUMBER(b.grupo) = TO_NUMBER(a.grupo) and 
			to_date (cData, 'ddmmyyhh24mi') >= b.datini and
			to_date (cData, 'ddmmyyhh24mi') <= b.datfim
		) loop

		achou := 2;
		i := 0;
		loop
			k := 8 * i;
			ini := k + 1;
			fim := k + 5;

			fx_ini := substr(r.fxperm, ini, 4);
			fx_fim := substr(r.fxperm, fim, 4);
			if fx_ini = '2400' then fx_ini := '2359'; end if;
			if fx_fim = '2400' then fx_fim := '2359';  end if;

			if (to_date (fx_ini, 'hh24mi') <= to_date (substr(cData,7,4), 'hh24mi') and
				to_date (fx_fim, 'hh24mi') >= to_date (substr(cData,7,4), 'hh24mi')) then
				i := 7;
				achou := 1;		
			else
				i := i + 1;
			end if;
			exit when i > 6;
		end loop;
		exit when achou = 1;
	end loop;
	Return (achou);
	
END SQLMAT_GRUPO_tcp;
/
