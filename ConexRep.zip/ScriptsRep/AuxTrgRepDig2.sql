-- ESTA AUXILIAR DA TRIGGER (INSERT/UPDATE/DELETE) DA TAB. REPEMPR002
-- INSERIR� NA TAB.REPNDIGAUTO000, A MATRICULA COM OS GRUPOS AOS QUAIS PERTENCEM, COM STATUS DE INCLUS�O('3') OU EXCLUS�O('8')

CREATE OR REPLACE PROCEDURE Auxtrg_repDig2 (cFunc in CHAR, cStatus in CHAR, cBioTipo in CHAR) IS

Aux CHAR(1);
cVelhoStat CHAR(1);
cNovoStatus CHAR(1);
dDataAux DATE;

CURSOR cur_DigRep000 IS select GRUPO from REPGRPF WHERE IFUNC = cFunc;

BEGIN


	-- VERIFICA SE EXISTE DIGITAL PARA A MATRICULA


	IF (cStatus = '1') or (cStatus = '3')THEN 		-- FUNCION�RIO FOI INSERIDO NA TAB.REPEMPR002
		cNovoStatus := '3';
		cVelhoStat := '8';

	ELSE								-- FUNCION�RIO FOI EXCLUIDO DA TAB.REPEMPR002
		cNovoStatus := '8';
		cVelhoStat := '3';
	END IF;	

	for r in cur_DigRep000 
	LOOP
		BEGIN
			SELECT STATUS into Aux FROM REPNDIGAUTO000 
				WHERE REPNDIGAUTO000.IFUNC = cFunc and 
					REPNDIGAUTO000.BIO_TIPO = cBioTipo and 
					to_number(REPNDIGAUTO000.GRUPO) = to_number(r.Grupo);

			-- verifica se est� na tabela para ainda ser processado para INCLUSAO OU EXCLUSAO OU SE J� SOFREU O PROCESSAMENTO
			IF (Aux = cVelhoStat OR Aux = '0') then

				-- como ainda est� para ser incluido (OU excluido), altera para status de exclusao (OU inclusao), atualizando a data
				SELECT sysdate into dDataAux from dual;

				UPDATE REPNDIGAUTO000 SET STATUS = cNovoStatus , DATA_INS = SYSDATE  
					WHERE REPNDIGAUTO000.IFUNC = cFunc and 
						REPNDIGAUTO000.BIO_TIPO = cBioTipo and 
						to_number(REPNDIGAUTO000.GRUPO) = to_number(r.Grupo);
			END IF;

		EXCEPTION
			WHEN NO_DATA_FOUND then
				-- como nao existe, inserir� na tab.REPNDIGAUTO000, a matricula com o grupo ao qual pertence, com status de inclusao ou exclus�o (cNovoStatus)
				INSERT INTO REPNDIGAUTO000 (IFUNC, STATUS, GRUPO, BIO_TIPO) 
								VALUES  (cFunc, cNovoStatus, r.Grupo, cBioTipo);

			WHEN OTHERS then NULL;
		END;
	END LOOP;


END Auxtrg_repDig2;	
/


