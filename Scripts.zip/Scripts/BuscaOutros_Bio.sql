CREATE or REPLACE FUNCTION sqlBusca_Outros_biomet (cMatric VARCHAR2, cBioTipo in VARCHAR2, cEndIp VARCHAR2, cTipoCons VARCHAR2, nQtdBytes in NUMBER, 
cTempl_Tit IN OUT VARCHAR2, cTempl_Alt IN OUT VARCHAR2) 
RETURN NUMBER IS

Retfun NUMBER;
nNumDig NUMBER;
total NUMBER;
RECO_LOCK EXCEPTION;
PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);
Alt NUMBER;
Pad NUMBER;
TamPad NUMBER;
TamAlt NUMBER;

i NUMBER; 
tam NUMBER; 
pos NUMBER; 
cDigital VARCHAR2(1200);
cVDigit    VARCHAR2(1);	
cAchou    NUMBER;	


begin
    Pad := 0;
    Alt := 0;
    TamPad := 0;
    TamAlt := 0;
    cTempl_Tit := NULL;
    cTempl_Alt := NULL;
	cAchou := 0;
	cVDigit := '2';		-- 1
    
    Retfun := 3;      -- sem templ padrao e sem templ alternativo


	IF (cTipoCons = '1') THEN		-- TIPO DE CONSULTA � ONLINE, E DEVER� SER CONSULTADO JUNTAMENTE COM A TAB.CONTROLE. NAO DEVER� SER GRAVADO EM DIGLOAD001
	
		BEGIN
			SELECT 
				TO_CHAR(c.DIGITAL_PAD), TO_CHAR(c.DIGITAL_ALT), 
				a.Ver_Digit
			INTO
				cTempl_Tit, cTempl_Alt, cVDigit 
				FROM CONTDIG_OUTROS c, CONTROLE a 
				WHERE c.ICARD = cMatric and
					  c.BIO_TIPO = cBioTipo and
					  a.Icard = cMatric 
				FOR UPDATE NOWAIT;

			cAchou := 1;
			COMMIT;

		EXCEPTION
			WHEN reco_lock THEN           -- lockado
				RetFun := -3;
				return (RetFun);
	
			WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
				IF (to_number(cVDigit) = 2) THEN
					RetFun := -2;
				ELSE
					Pad := 0;
					Alt := 0;
				END IF;				
	
			WHEN OTHERS THEN              -- outros erros
				RetFun := -1;
				rollback;
				return (RetFun);
		END;
	
	ELSE		-- CONSULTA PARA ATENDER COMANDO MANUAL/AUTOMATICO
		BEGIN
			SELECT 
				TO_CHAR(c.DIGITAL_PAD), TO_CHAR(c.DIGITAL_ALT) 
			INTO
				cTempl_Tit, cTempl_Alt
				FROM CONTDIG_OUTROS c
				WHERE c.ICARD = cMatric and
					  c.BIO_TIPO = cBioTipo;
			cAchou := 1;

		EXCEPTION
			WHEN NO_DATA_FOUND THEN 
				Pad := 0;
				Alt := 0;
			WHEN OTHERS THEN 
				Pad := 0;
				Alt := 0;
		END;

	END IF;
	
	IF (cAchou = 1) THEN	  	
		TamPad := length (cTempl_Tit);	  	
		TamAlt := length (cTempl_Alt);	  	
		IF (TamPad > 0) THEN 
			Pad := 1;
		end if;
		IF (TamAlt > 0) THEN 
			Alt := 1;
		end if;
	END IF;
	
	
	
	-- PREPARA RESULTADO	
	if (Pad = 1) then
	    if (Alt = 1) then
			Retfun := 0;   -- tem padrao e tem alternativo
		else 
			Retfun := 1;   -- tem padrao e nao tem alternativo
    	end if;
	else
		if (Alt = 1) then
			Retfun := 2;   -- nao tem padrao e tem alternativo
		else 
			Retfun := 3;   -- nao tem padrao e nao tem alternativo
		end if;
	end if;
	
	-- VERIFICA SE NAO ACHOU NENHUMA BIOMETRIA E � COMANDO DE ENVIO DE DIGITAIS, DEVERA GUARDAR INFORMACAO EM DIGLOAD001	
	IF ((Retfun = 3) and (cTipoCons != '1' )) THEN
		INSERT INTO DIGLOAD001 (END_IP, ICARD, BIO_TIPO) 		-- insere em tabela DIGLOAD001
						VALUES (cEndIp, cMatric, cBioTipo);
		COMMIT;
	END IF;

	return (Retfun);
	
	
END sqlBusca_Outros_biomet;
/

