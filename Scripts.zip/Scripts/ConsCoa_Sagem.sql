CREATE OR REPLACE FUNCTION sqlcon_coacao_sagem (cMatric VARCHAR2,
cTempl_Coa1tot IN OUT VARCHAR2, cTempl_Coa2tot IN OUT VARCHAR2, 
cTempl_Coa3tot IN OUT VARCHAR2, cTempl_Coa4tot IN OUT VARCHAR2
) 
RETURN NUMBER IS
RetFun	NUMBER;
Coa 	NUMBER;
cTempl_Coa4Aux VARCHAR2(32);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);  -- erro quando registro lockado

BEGIN
	RetFun := 1;
	Coa := 1;
	BEGIN
		SELECT 
			Templ_Coa1, Templ_Coa2, Templ_Coa3, Templ_Coa4
		INTO 
			cTempl_Coa1tot, cTempl_Coa2tot, cTempl_Coa3tot, cTempl_Coa4Aux 
		FROM CONTDIG_SAGEM 
		WHERE Icard = cMatric;
		if ((cTempl_Coa1tot is Null) or (cTempl_Coa2tot is Null) or
			(cTempl_Coa3tot is Null) or (cTempl_Coa4Aux is Null) or
			(length(cTempl_Coa1tot) < 160) or (length(cTempl_Coa2tot) < 160) or
			(length(cTempl_Coa3tot) < 160) or (length(cTempl_Coa4Aux) < 32)) then 
			Coa := 0;
		end if;
		if (length(cTempl_Coa4Aux) = 32) then
			cTempl_Coa4tot := RPAD(cTempl_Coa4Aux, 160, '0');
		end if;
			
	EXCEPTION
		WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
			Coa := 0;
		WHEN OTHERS THEN              -- outros erros
			RetFun := -1;
			return (RetFun);
	END;
	IF (Coa = 0) THEN
		RetFun := 0;
	end if;
	Return (RetFun);
END sqlcon_coacao_sagem;
/
