CREATE OR REPLACE FUNCTION sqlproc_icardpis4 (cEndIp VARCHAR2, cNumRep VARCHAR2, nTotal NUMBER, cInicio VARCHAR2, cTipoCom CHAR, cTipoRep4000 CHAR, cLisMat VARCHAR2, cLisOKMat IN OUT VARCHAR2, cLisPis IN OUT VARCHAR2, cErrMat IN OUT VARCHAR2)   
RETURN NUMBER IS

Retfun NUMBER;
RetAux NUMBER;
nCont NUMBER;
nContOK NUMBER;
nPos NUMBER;
cFunc VARCHAR2(12);
cPis VARCHAR2(12);
cCpf VARCHAR2(11);
nInsLista NUMBER;

cAuxPis VARCHAR2(12);
cNome VARCHAR2(52);


BEGIN


	Retfun := 0;      -- assume que achou o icard
	RetAux := 0;      -- assume que nao ha erro em insercao na tab. de nomes
	cLisOkMat := '';		-- assume lista vazia de matriculas ok
	cLisPis := '';
	cErrMat := '';
	nCont := 0;
	nContOK := 0;
	
	IF (cInicio = '1') THEN 
		BEGIN
			DELETE REPAUXEMPR WHERE END_IP = cEndIp and TIPO = cTipoCom;
			
		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				RetAux := 0;
			WHEN OTHERS THEN
				RetAux := 0;
		END;
	END IF;

	WHILE (nCont < nTotal) LOOP
		nPos := (nCont * 12) + 1;
		cFunc := SUBSTR (cLisMat, nPos, 12);
		nInsLista := 1;

		BEGIN
			-- procura pelo nome e PIS contendo somente 12 digitos
			--SELECT PIS, NOME  
			SELECT PIS, NOME, CPF  
				INTO cPis, cNome, cCpf 
			FROM REPEMPR002 WHERE (IFUNC = cFunc) and 
								  (translate(PIS,'A0123456789', 'A') is null and length(PIS) = 12) and 
								  (translate(CPF,'A0123456789', 'A') is null and length(CPF) = 11);

			IF (cTipoRep4000 = '1') THEN
				IF (cCpf = '00000000000') THEN 
					INSERT INTO REPLOAD001 (END_IP, REP, IFUNC, DIA) 
						VALUES (cEndIp, cNumRep, cFunc, SYSDATE);
					nInsLista := 0;
					
				ELSE
					cPis := '0'|| cCpf;
				END IF;
			ELSE
				IF (cPis = '000000000000') THEN 
					INSERT INTO REPLOAD001 (END_IP, REP, IFUNC, DIA) 
						VALUES (cEndIp, cNumRep, cFunc, SYSDATE);
					nInsLista := 0;
				END IF;
			END IF;
			
			IF (nInsLista = 1) THEN 
				cLisOkMat := cLisOkMat || cFunc ;
				cLisPis := cLisPis || cPis ;
				nContOK := nContOK + 1;
			
				BEGIN
					SELECT PIS INTO cAuxPis
						--FROM REPAUXEMPR WHERE END_IP = cEndIp and TIPO = cTipoCom and PIS = cPis for update nowait;
						FROM REPAUXEMPR WHERE END_IP = cEndIp and TIPO = cTipoCom and PIS = cPis and IFUNC = cFunc for update nowait;

					UPDATE REPAUXEMPR SET NOME = cNome, ST = '0'  
						--WHERE END_IP = cEndIp and TIPO = cTipoCom and PIS = cPis;
						WHERE END_IP = cEndIp and TIPO = cTipoCom and PIS = cPis and IFUNC = cFunc;

				EXCEPTION
					WHEN NO_DATA_FOUND THEN 
						INSERT INTO REPAUXEMPR (END_IP, PIS, NOME, TIPO, IFUNC, ST) 
							VALUES (cEndIp, cPis, cNome, cTipoCom, cFunc, '0');		-- cTipoCom :'0' = carga via comando, 1 = automatico

					WHEN OTHERS THEN 
						Retfun := -1;
				END;
			
			END IF;

		EXCEPTION
			WHEN NO_DATA_FOUND THEN 
				BEGIN
					INSERT INTO REPLOAD001 (END_IP, REP, IFUNC, DIA) 
						VALUES (cEndIp, cNumRep, cFunc, SYSDATE);

				EXCEPTION
					WHEN OTHERS THEN 
						Retfun := -1;
				END;
				if (cErrMat is null) then 
					cErrMat := cFunc ;
				end if;					
				
				
			WHEN OTHERS THEN 
				BEGIN
					INSERT INTO REPLOAD001 (END_IP, REP, IFUNC, DIA) 
						VALUES (cEndIp, cNumRep, cFunc, SYSDATE);
				EXCEPTION
					WHEN OTHERS THEN 
						Retfun := -1;
				END;
				if (cErrMat = null) then 
					cErrMat := cFunc ;
				end if;
				
				Retfun := -1;
		END;
		nCont := nCont + 1;

	END LOOP;
	
	COMMIT;
	
	if (Retfun < 0 ) then 
		return (Retfun);
	else
		return (nContOK);
	end if;
	
END sqlproc_icardpis4;
/


