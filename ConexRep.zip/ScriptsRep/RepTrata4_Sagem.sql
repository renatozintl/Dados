CREATE OR REPLACE  PROCEDURE trata4_RepSagem IS
  
TYPE endipDigI_type IS TABLE OF RDIG002.END_IP%TYPE 
	INDEX BY binary_integer;
TYPE statusDigI_type IS TABLE OF RDIG002.STATUS%TYPE 
	INDEX BY binary_integer;
TYPE biotipoDigI_type IS TABLE OF RDIG002.BIO_TIPO%TYPE 
	INDEX BY binary_integer;


TYPE endipDigE_type IS TABLE OF RDIG102.END_IP%TYPE 
	INDEX BY binary_integer;
TYPE statusDigE_type IS TABLE OF RDIG102.STATUS%TYPE 
	INDEX BY binary_integer;
TYPE biotipoDigE_type IS TABLE OF RDIG102.BIO_TIPO%TYPE 
	INDEX BY binary_integer;

TYPE rowid_type IS TABLE OF ROWID  
	INDEX BY binary_integer;

	
l_endipDigInc endipDigI_type;
l_statusDigInc statusDigI_type;
l_biotipoDigInc biotipoDigI_type;

l_endipDigExc endipDigE_type;
l_statusDigExc statusDigE_type;
l_biotipoDigExc biotipoDigE_type;

l_rowid rowid_type;
p_recSag RDIG001%rowtype;
p_recExcSag RDIG101%rowtype;
p_recDigCom RDIG002%rowtype;
p_recDigExc RDIG102%rowtype;


RECO_LOCK EXCEPTION;
PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);

tem_deadlock EXCEPTION; 
PRAGMA EXCEPTION_INIT (tem_deadlock, -60); 

i number;
cMatAux CHAR(12);
cStAux CHAR(1);
cIpAux CHAR(15);


BEGIN
	-- ********************   ARRUMAR SITUA��ES PARA SAGEM    -  INCLUSAO
	-- ***********************  TRATA AS BIOMETRIAS SAGEM QUE FICARAM PENDENTES NA CARGA E QUE NAO SERAO REENVIADAS AUTOMATICAMENTE
	-- SITUACAO EM QUE CARGA FICOU PENDENTE PORQUE EQUIPAMENTO REJEITOU A CARGA (status '4')
	FOR r in (SELECT distinct IFUNC from RDIG001  WHERE STATUS = '4')
	LOOP
		FOR cur_troubleIns2 in 
			(SELECT rowid, IFUNC, END_IP  			-- GUARDA EM CURSOR TODAS AS LINHAS DESTA MATRICULA Q NAO TEM O bio sagem  CADASTRADO, Q ESTA COM STATUS = '4'
				FROM RDIG001 
				WHERE IFUNC = r.IFUNC and 
					  STATUS = '4'  )
		LOOP
			BEGIN		-- PARA CADA LINHA , RESERVA ('for update nowait') PARA ALTERAR O STATUS
				SELECT * into p_recSag FROM RDIG001 WHERE rowid = cur_troubleIns2.rowid for update nowait;
	
				--DELETE RDIG001 WHERE rowid = cur_troubleIns2.rowid ;
				UPDATE RDIG001 SET STATUS = '0' WHERE rowid = cur_troubleIns2.rowid ;

			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
					
			BEGIN
				SELECT END_IP into cIpAux FROM RDIG002 WHERE END_IP = p_recSag.END_IP and STATUS = '3' for update nowait;
				UPDATE RDIG002 set status = '1'
					WHERE (END_IP = p_recSag.END_IP and STATUS = '3' ) ;
						
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		end loop;
	END LOOP;
	COMMIT;



	-- ***********************  TRATA AS BIOMETRIAS SAGEM QUE FICARAM PENDENTES NA CARGA
	-- SITUACAO EM QUE CARGA FICOU PENDENTE PORQUE HOUVE DELETE DE REGISTROS DAS BIOS SAGEM (DA TAB.CONTDIG_SAGEM CADASTRO)
	-- delete registro de RDIG001 se nao houver cadastro de bio sagem desta matricula
	FOR r in 
		(SELECT distinct IFUNC from RDIG001 
			WHERE STATUS = '3')
	LOOP 
		BEGIN
			-- VERIFICA SE H� CADASTRO de bio sagem DA MATRICULA
			SELECT ICARD INTO cMatAux FROM CONTDIG_SAGEM WHERE ICARD = r.IFUNC;
			
		EXCEPTION
			when NO_DATA_FOUND then 		-- NAO HA bio sagem CADASTRADO
				FOR c_curdig in 
					(SELECT rowid, IFUNC, END_IP  			-- GUARDA EM CURSOR TODAS AS LINHAS DESTA MATRICULA Q NAO TEM O bio sagem  CADASTRADO, Q ESTA COM STATUS = '3'
						FROM RDIG001 
						WHERE IFUNC = r.IFUNC and 
							  STATUS = '3'  )
				LOOP
					BEGIN		-- PARA CADA LINHA , RESERVA ('for update nowait') PARA ALTERAR O STATUS
						SELECT * into p_recSag FROM RDIG001 WHERE rowid = c_curdig.rowid for update nowait;
						--UPDATE RDIG001 set status = '0' WHERE rowid = c_curdig.rowid ;
						DELETE RDIG001 WHERE rowid = c_curdig.rowid ;

					EXCEPTION
						when reco_lock then NULL ;
						when tem_deadlock then NULL ;
						when NO_DATA_FOUND then NULL;
						when OTHERS then NULL;
					END;
					
					BEGIN
						SELECT END_IP into cIpAux FROM RDIG002 WHERE END_IP = p_recSag.END_IP and STATUS = '3' for update nowait;
						UPDATE RDIG002 set status = '1'
							WHERE (END_IP = p_recSag.END_IP) ;
						
					EXCEPTION
						when reco_lock then NULL ;
						when tem_deadlock then NULL ;
						when NO_DATA_FOUND then NULL;
						when OTHERS then NULL;
					END;
					
				end loop;
			when OTHERS then NULL;
		END;
	END LOOP;
	COMMIT;
	-- FIM SITUACAO NOVA

	
	
	
	-- altera status de todos os codins para carga de digitais, se esses n�o estiverem com carga de digitais ou estiverem pendentes
	-- nao altera status se o equipamento responde 'NAO IMPLEMENTADO'
	FOR r in 
		(SELECT distinct END_IP, BIO_TIPO, STATUS from RDIG001 
			--where (STATUS != '0') and (STATUS != '2') and  (BIO_TIPO = '6' OR BIO_TIPO = '7')
			where (STATUS != '0') and (STATUS != '2') and (STATUS != '4') and  
					(BIO_TIPO = '6' OR BIO_TIPO = '7')
		) 
	LOOP
		BEGIN
			SELECT * into p_recDigCom FROM RDIG002
				WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3' or STATUS = '4') and		-- status '0':carregado, '3':pendente, '4':rep nao aceita carga digital
					   BIO_TIPO = r.BIO_TIPO) for update nowait;

			UPDATE RDIG002 set status = '1'
				WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3' or STATUS = '4') and		-- status '0':carregado, '3':pendente, '4':rep nao aceita carga digital
					   BIO_TIPO = r.BIO_TIPO);
		EXCEPTION
			when reco_lock then NULL ;
			when tem_deadlock then NULL ;
			when NO_DATA_FOUND then NULL;
			when OTHERS then NULL;
		END;
	END LOOP;
	
	COMMIT;	

	-- ********************   TRATA EQUIPAMENTOS SAGEM QUE FICARAM EM ESTADO CARREGANDO OU SOFRERAM CARGA DE APLICATIVO
	-- equipamentos SAGEM q ficaram em estado de carregando '2' por mais de 2 minutos OU
	-- equipamentos SAGEM que tiveram carga de aplicativo (perda de biometria) e devem ser recarregados com a biometria
	
	SELECT distinct END_IP, BIO_TIPO, STATUS, ROWID
		BULK COLLECT INTO l_endipDigInc, l_biotipoDigInc, l_statusDigInc, l_rowid	
			FROM RDIG002  
			WHERE ( (BIO_TIPO = '6' or BIO_TIPO = '7') 
				    AND 
				    (STATUS = '5' or STATUS = '6' OR (STATUS = '2' and (DATA_LOAD + ( 2 / 24 / 60 )  < sysdate)) ) 
				  );
	
	FOR i in 1 .. l_endipDigInc.count	
	LOOP
		IF (l_statusDigInc(i) = '2') THEN		-- estado CARREGANDO ('2') parado
			FOR c_curdig in 
				(SELECT rowid, IFUNC 
					FROM RDIG001 
					WHERE END_IP = l_endipDigInc(i) and 
						  STATUS = '2'  and 
						  BIO_TIPO = l_biotipoDigInc(i) )
			LOOP
				BEGIN
					SELECT * into p_recSag FROM RDIG001 WHERE rowid = c_curdig.rowid for update nowait;
					UPDATE RDIG001 set status = '1' WHERE rowid = c_curdig.rowid ;
				
				EXCEPTION
					when reco_lock then NULL ;
					when tem_deadlock then NULL ;
					when NO_DATA_FOUND then NULL;
					when OTHERS then NULL;
				END;
			end loop;
						   
			BEGIN
				SELECT * into p_recDigCom from RDIG002 WHERE END_IP = l_endipDigInc(i) and BIO_TIPO = l_biotipoDigInc(i) for update nowait;
				UPDATE RDIG002 set status = '1' where END_IP = l_endipDigInc(i) and BIO_TIPO = l_biotipoDigInc(i);		-- FAZ RECARGA DE BIOMETRIAS SAGEM
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		
		ELSIF ((l_statusDigInc(i) = '5') OR (l_statusDigInc(i) = '6')) THEN		-- estado de CARGA DE APLICATIVO
			BEGIN
				SELECT * into p_recDigCom from RDIG002 WHERE END_IP = l_endipDigInc(i) and BIO_TIPO = l_biotipoDigInc(i) for update nowait;
				UPDATE RDIG002 set status = '0' WHERE END_IP =  l_endipDigInc(i) and BIO_TIPO = l_biotipoDigInc(i);		-- VOLTA AO ESTADO DE REPOUSO
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		END IF;		
	END LOOP;
	
	COMMIT;	



	
	-- ***********************  TRATA AS BIOMETRIAS SAGEM QUE FICARAM EM ESTADO DE CARREGANDO E NAO SAI DESTA SITUA��O
	-- para BIOMETRIAS  SAGEM DE RDIG001 que ficaram em estado carregando '2' e o equipamento est� em estado de repouso	, forca o equipamento a carrega-los novamente

	SELECT END_IP, STATUS 
		BULK COLLECT INTO l_endipDigInc, l_statusDigInc
			FROM (SELECT  A.END_IP, A.status 
					FROM RDIG002 A INNER JOIN 
						 RDIG001 B
					ON A.END_IP = B.END_IP and 
					   A.status = '0' and 
					   B.STATUS = '2' and
					   (A.BIO_TIPO = '6') or (A.BIO_TIPO = '7')) ;

	FOR i IN 1 .. l_endipDigInc.count     
	LOOP			
		for c1 in (select rowid from RDIG001 
			WHERE END_IP = l_endipDigInc(i) AND (STATUS = '2') )
		loop
			BEGIN
				select * into p_recSag from RDIG001 where rowid = c1.rowid for update nowait;		
				UPDATE RDIG001 SET STATUS = '1' where rowid = c1.rowid;

			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		end loop;				
		
		BEGIN
			SELECT * into p_recDigCom FROM RDIG002 WHERE END_IP = l_endipDigInc(i) for update nowait;
			UPDATE RDIG002 SET STATUS = '1'	WHERE END_IP = l_endipDigInc(i);
			
		EXCEPTION
			when reco_lock then NULL ;
			when tem_deadlock then NULL ;
			when NO_DATA_FOUND then NULL;
			when OTHERS then NULL;
		END;
	end LOOP;

	COMMIT;
	

	-- ********************   ARRUMAR SITUA��ES PARA SAGEM    -  EXCLUSAO

	-- ***************  NOVO
	-- ***********************  TRATA AS BIOMETRIAS SAGEM QUE FICARAM PENDENTES NA CARGA E QUE NAO SERAO REENVIADAS AUTOMATICAMENTE
	-- SITUACAO EM QUE CARGA FICOU PENDENTE PORQUE EQUIPAMENTO REJEITOU A EXCLUSAO (status '4')
	FOR r in (SELECT distinct IFUNC from RDIG101  WHERE STATUS = '4')
	LOOP
		FOR cur_troubleExc2 in 
			(SELECT rowid, IFUNC, END_IP  			-- GUARDA EM CURSOR TODAS AS LINHAS DESTA MATRICULA Q NAO TEM O bio sagem  CADASTRADO, Q ESTA COM STATUS = '4'
				FROM RDIG101 
				WHERE IFUNC = r.IFUNC and 
					  STATUS = '4'  )
		LOOP
			BEGIN		-- PARA CADA LINHA , RESERVA ('for update nowait') PARA ALTERAR O STATUS
				SELECT * into p_recExcSag FROM RDIG101 WHERE rowid = cur_troubleExc2.rowid for update nowait;
	
				--DELETE RDIG001 WHERE rowid = cur_troubleExc2.rowid ;
				UPDATE RDIG101 SET STATUS = '0' WHERE rowid = cur_troubleExc2.rowid ;

			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
					
			BEGIN
				SELECT END_IP into cIpAux FROM RDIG102 WHERE END_IP = p_recExcSag.END_IP and STATUS = '3' for update nowait;
				UPDATE RDIG102 set status = '1'
					WHERE (END_IP = p_recExcSag.END_IP and STATUS = '3' ) ;
						
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		end loop;
	END LOOP;
	
	COMMIT;
	
	-- *************** FIM NOVO
	
	-- ***********************  TRATA AS BIOMETRIAS SAGEM QUE FICARAM PENDENTES NA EXCLUSAO
	-- altera status dos codins Sagem para exclusao de biometria, se esses n�o estiverem com exclusao de biometria ou estiverem pendentes

	FOR r in 
		(SELECT distinct END_IP, BIO_TIPO from RDIG101 
			where (STATUS != '0') and (STATUS != '2') and (STATUS != '4') and 
					(BIO_TIPO = '6' or BIO_TIPO = '7')
		) 
	LOOP
		BEGIN
			SELECT * into p_recDigExc FROM RDIG102
				WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3' or STATUS = '4') and
					   BIO_TIPO = r.BIO_TIPO) for update nowait;
	
			UPDATE RDIG102 set status = '1'
				WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3' or STATUS = '4') and
					   BIO_TIPO = r.BIO_TIPO);
		EXCEPTION
			when reco_lock then NULL ;
			when tem_deadlock then NULL ;
			when NO_DATA_FOUND then NULL;
			when OTHERS then NULL;
		END;
	END LOOP;
	
	COMMIT;	
	


	-- ********************   TRATA EQUIPAMENTOS SAGEM QUE FICARAM EM ESTADO EXCLUINDO OU SOFRERAM CARGA DE APLICATIVO
	-- equipamentos  q ficaram em estado de excluindo '2' por mais de 2 minutos ou
	-- equipamentos que sofreram exclusao/recarga de aplicativo 
	
	SELECT distinct END_IP, BIO_TIPO, STATUS, ROWID
		BULK COLLECT INTO l_endipDigExc, l_biotipoDigExc, l_statusDigExc, l_rowid	
			FROM RDIG102  
			WHERE ( (BIO_TIPO = '6' or BIO_TIPO = '7') 
				    AND 
				    (STATUS = '5' or STATUS = '6' OR (STATUS = '2' and (DATA_LOAD + ( 2 / 24 / 60 )  < sysdate)) ) 
				  );

	FOR i in 1 .. l_endipDigExc.count	
	LOOP
		IF (l_statusDigExc(i) = '2') THEN		-- estado CARREGANDO ('2') parado
			FOR c_curdig in 
				(SELECT rowid, IFUNC 
					FROM RDIG101 
					WHERE END_IP = l_endipDigExc(i) and 
						  STATUS = '2'  and 
						  BIO_TIPO = l_biotipoDigExc(i) )
			LOOP
				BEGIN
					SELECT * into p_recSag FROM RDIG101 WHERE rowid = c_curdig.rowid for update nowait;
					UPDATE RDIG101 set status = '1' WHERE rowid = c_curdig.rowid ;
				
				EXCEPTION
					when reco_lock then NULL ;
					when tem_deadlock then NULL ;
					when NO_DATA_FOUND then NULL;
					when OTHERS then NULL;
				END;
			end loop;
						   
			BEGIN
				SELECT * into p_recDigExc from RDIG102 WHERE END_IP = l_endipDigExc(i) and BIO_TIPO = l_biotipoDigExc(i) for update nowait;
				UPDATE RDIG102 set status = '1' WHERE END_IP = l_endipDigExc(i) and BIO_TIPO = l_biotipoDigExc(i);		-- FAZ RECARGA DE BIOMETRIAS SAGEM
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		
		ELSIF ((l_statusDigExc(i) = '5') OR (l_statusDigExc(i) = '6')) THEN		-- estado de CARGA DE APLICATIVO
			BEGIN
				SELECT * into p_recDigExc from RDIG102 WHERE END_IP = l_endipDigExc(i) and BIO_TIPO = l_biotipoDigExc(i) for update nowait;
				UPDATE RDIG102 set status = '0' WHERE END_IP = l_endipDigExc(i) and BIO_TIPO = l_biotipoDigExc(i);		-- VOLTA AO ESTADO DE REPOUSO
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		END IF;		
	END LOOP;
	
	COMMIT;	


	-- ***********************  TRATA AS BIOMETRIAS SAGEM QUE FICARAM EM ESTADO DE EXCLUINDO E NAO SAI DESTA SITUA��O
	-- para BIOMETRIAS  SAGEM DE RDIG101 que ficaram em estado excluindo '2' e o equipamento est� em estado de repouso	, forca o equipamento a exclui-los novamente

	SELECT END_IP, STATUS 
		BULK COLLECT INTO l_endipDigExc, l_statusDigExc
			FROM (SELECT  A.END_IP, A.status 
					FROM RDIG102 A INNER JOIN 
						 RDIG101 B
					ON A.END_IP = B.END_IP and 
					   A.status = '0' and 
					   B.STATUS = '2' and
					   (A.BIO_TIPO = '6') or (A.BIO_TIPO = '7')) ;

	FOR i IN 1 .. l_endipDigExc.count     
	LOOP			
		for c1 in (select rowid from RDIG101 
			WHERE END_IP = l_endipDigExc(i) AND (STATUS = '2') )
		loop
			BEGIN
				select * into p_recExcSag from RDIG101 where rowid = c1.rowid for update nowait;		
				UPDATE RDIG101 SET STATUS = '1' where rowid = c1.rowid;

			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		end loop;				
		
		BEGIN
			SELECT * into p_recDigExc FROM RDIG102 WHERE END_IP = l_endipDigExc(i) for update nowait;
			UPDATE RDIG102 SET STATUS = '1'	WHERE END_IP = l_endipDigExc(i);
			
		EXCEPTION
			when reco_lock then NULL ;
			when tem_deadlock then NULL ;
			when NO_DATA_FOUND then NULL;
			when OTHERS then NULL;
		END;
	end LOOP;

	COMMIT;
	
	

end trata4_RepSagem ;
/
