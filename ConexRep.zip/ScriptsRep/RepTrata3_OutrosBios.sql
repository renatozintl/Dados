CREATE OR REPLACE  PROCEDURE trata3_RepOutrosBios IS
  
TYPE endipDigI_type IS TABLE OF RDIG002.END_IP%TYPE 
	INDEX BY binary_integer;
TYPE statusDigI_type IS TABLE OF RDIG002.STATUS%TYPE 
	INDEX BY binary_integer;
TYPE biotipoDigI_type IS TABLE OF RDIG002.BIO_TIPO%TYPE 
	INDEX BY binary_integer;


TYPE endipDigE_type IS TABLE OF RDIG102.END_IP%TYPE 
	INDEX BY binary_integer;
TYPE statusDigE_type IS TABLE OF RDIG102.STATUS%TYPE 
	INDEX BY binary_integer;
TYPE biotipoDigE_type IS TABLE OF RDIG102.BIO_TIPO%TYPE 
	INDEX BY binary_integer;

TYPE rowid_type IS TABLE OF ROWID  
	INDEX BY binary_integer;

	
l_endipDigInc endipDigI_type;
l_statusDigInc statusDigI_type;
l_biotipoDigInc biotipoDigI_type;

l_endipDigExc endipDigE_type;
l_statusDigExc statusDigE_type;
l_biotipoDigExc biotipoDigE_type;

l_rowid rowid_type;
p_recVrd RDIG004%rowtype;
p_recExcVrd RDIG104%rowtype;
p_recDigCom RDIG002%rowtype;
p_recDigExc RDIG102%rowtype;


RECO_LOCK EXCEPTION;
PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);

tem_deadlock EXCEPTION; 
PRAGMA EXCEPTION_INIT (tem_deadlock, -60); 

i number;
nCont number;
cMatAux CHAR(12);
cStAux CHAR(1);
cIpAux CHAR(15);
total NUMBER;
cDigital VARCHAR2(1200);
nNumDig NUMBER;
nNaoExiste NUMBER;


BEGIN
	-- ********************   ARRUMAR SITUA��ES PARA VIRDI    -  INCLUSAO
	-- ***********************  TRATA AS BIOMETRIAS  QUE FICARAM PENDENTES NA CARGA E QUE NAO SERAO REENVIADAS AUTOMATICAMENTE
	-- SITUACAO EM QUE CARGA FICOU PENDENTE PORQUE EQUIPAMENTO REJEITOU A CARGA (status '4')
	FOR r in (SELECT distinct IFUNC from RDIG004 WHERE STATUS = '4')
	LOOP
		FOR cur_troubleIns2 in 
			(SELECT rowid, IFUNC, END_IP  			-- GUARDA EM CURSOR TODAS AS LINHAS DESTA MATRICULA Q NAO TEM O bio   CADASTRADO, Q ESTA COM STATUS = '4'
				FROM RDIG004 
				WHERE IFUNC = r.IFUNC and 
					  STATUS = '4'  )
		LOOP
			BEGIN		-- PARA CADA LINHA , RESERVA ('for update nowait') PARA ALTERAR O STATUS
				SELECT * into p_recVrd FROM RDIG004 WHERE rowid = cur_troubleIns2.rowid for update nowait;
	
				UPDATE RDIG004 SET STATUS = '0' WHERE rowid = cur_troubleIns2.rowid ;
				--DELETE RDIG004 WHERE rowid = cur_troubleIns2.rowid ;

			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
					
			BEGIN
				SELECT END_IP into cIpAux FROM RDIG002 WHERE END_IP = p_recVrd.END_IP and STATUS = '3' for update nowait;
				UPDATE RDIG002 set status = '1'
					WHERE (END_IP = p_recVrd.END_IP  and STATUS = '3') ;
						
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		end loop;
	END LOOP;

	COMMIT;




	-- ***********************  TRATA AS BIOMETRIAS VIRDI QUE FICARAM PENDENTES NA CARGA
	-- SITUACAO EM QUE CARGA FICOU PENDENTE PORQUE HOUVE DELETE DE REGISTROS DAS BIOS VIRDI (DA TAB.CONTDIG_OUTROS CADASTRO)
	-- delete registro de RDIG004 se nao houver cadastro de bio VIRDI desta matricula
	FOR r in 
		(SELECT distinct IFUNC, BIO_TIPO from RDIG004 
			WHERE STATUS = '3')
			
	LOOP 
		BEGIN
			-- VERIFICA SE H� CADASTRO dA bio  DA MATRICULA
			SELECT ICARD INTO cMatAux FROM CONTDIG_OUTROS 
				WHERE ICARD = r.IFUNC and
					BIO_TIPO = r.BIO_TIPO;
			
		EXCEPTION
			when NO_DATA_FOUND then 		-- NAO HA bio  CADASTRADO
				FOR c_curdig in 
					(SELECT rowid, IFUNC, END_IP, BIO_TIPO   			-- GUARDA EM CURSOR TODAS AS LINHAS DESTA MATRICULA Q NAO TEM O bio sagem  CADASTRADO, Q ESTA COM STATUS = '3'
						FROM RDIG004 
						WHERE IFUNC = r.IFUNC and 
							STATUS = '3' and 
							BIO_TIPO = r.BIO_TIPO    )
				LOOP
					BEGIN		-- PARA CADA LINHA , RESERVA ('for update nowait') PARA ALTERAR O STATUS
						SELECT * into p_recVrd FROM RDIG004 WHERE rowid = c_curdig.rowid for update nowait;
						DELETE RDIG004 WHERE rowid = c_curdig.rowid ;

					EXCEPTION
						when reco_lock then NULL ;
						when tem_deadlock then NULL ;
						when NO_DATA_FOUND then NULL;
						when OTHERS then NULL;
					END;
					
					BEGIN
						SELECT END_IP into cIpAux FROM RDIG002 WHERE END_IP = p_recVrd.END_IP and STATUS = '3' for update nowait;
						UPDATE RDIG002 set status = '1'
							WHERE (END_IP = p_recVrd.END_IP) ;
						
					EXCEPTION
						when reco_lock then NULL ;
						when tem_deadlock then NULL ;
						when NO_DATA_FOUND then NULL;
						when OTHERS then NULL;
					END;
					
				end loop;
			when OTHERS then NULL;
		END;
	END LOOP;
	COMMIT;
	-- FIM SITUACAO NOVA



	
	-- ******************** ALTERA STATUS DE TODOS OS REPS PARA CARGA DE DIGITAIS, SE ESSES N�O ESTIVEREM COM CARGA DE DIGITAIS OU ESTIVEREM PENDENTES
	-- nao altera status se o equipamento responde 'NAO IMPLEMENTADO'
	FOR r in 
		(SELECT distinct END_IP, BIO_TIPO, STATUS from RDIG004 
			where (STATUS != '0') and (STATUS != '2')
		) 
	LOOP
		IF (r.STATUS != '4') THEN		-- REP NAO ACEITA CARGA DIGITAL, POIS RESPONDEU COMO 'NAO IMPLEMENTADO'
			BEGIN
				SELECT * into p_recDigCom FROM RDIG002
					--WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3') and
					WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3' or STATUS = '4') and			-- status '0':carregado, '3':pendente, '4':rep nao aceita carga digital
						   BIO_TIPO = r.BIO_TIPO) for update nowait;

				UPDATE RDIG002 set status = '1'
					--WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3') and
					WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3' or STATUS = '4') and			-- status '0':carregado, '3':pendente, '4':rep nao aceita carga digital
						   BIO_TIPO = r.BIO_TIPO);
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		END IF;
	END LOOP;
	
	COMMIT;	

	-- ********************   TRATA EQUIPAMENTOS VIRDI QUE FICARAM EM ESTADO CARREGANDO OU SOFRERAM CARGA DE APLICATIVO
	-- equipamentos VIRDI q ficaram em estado de carregando '2' por mais de 2 minutos OU
	-- equipamentos VIRDI que tiveram carga de aplicativo (perda de biometria) e devem ficar em estado de 'repouso' (nao sera recarregada a biometria)
	
	SELECT distinct END_IP, BIO_TIPO, STATUS, ROWID
		BULK COLLECT INTO l_endipDigInc, l_biotipoDigInc, l_statusDigInc, l_rowid	
			FROM RDIG002  
			WHERE (((BIO_TIPO != '6') and (BIO_TIPO != '7') and (BIO_TIPO != '8')) and
				   (status = '5' or status = '6' OR (status = '2' and (data_load + ( 2 / 24 / 60 )  < sysdate)) ) 
				  );
	
	FOR i in 1 .. l_endipDigInc.count	
	LOOP
		IF (l_statusDigInc(i) = '2') THEN		-- estado CARREGANDO ('2') parado
			FOR c_curdig in 
				(SELECT rowid, IFUNC 
					FROM RDIG004 
					WHERE END_IP = l_endipDigInc(i) and 
						  STATUS = '2'  and 
						  BIO_TIPO = l_biotipoDigInc(i) )
			LOOP
				BEGIN
					SELECT * into p_recVrd FROM RDIG004 WHERE rowid = c_curdig.rowid for update nowait;
					UPDATE RDIG004 set status = '1' WHERE rowid = c_curdig.rowid ;
				
				EXCEPTION
					when reco_lock then NULL ;
					when tem_deadlock then NULL ;
					when NO_DATA_FOUND then NULL;
					when OTHERS then NULL;
				END;
			end loop;
						   
			BEGIN
				SELECT * into p_recDigCom from RDIG002 WHERE END_IP = l_endipDigInc(i) and BIO_TIPO = l_biotipoDigInc(i) for update nowait;
				UPDATE RDIG002 set status = '1' where END_IP = l_endipDigInc(i) and BIO_TIPO = l_biotipoDigInc(i);		-- FAZ RECARGA DE BIOMETRIAS VIRDI
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		
		ELSIF ((l_statusDigInc(i) = '5') or (l_statusDigInc(i) = '6')) THEN		-- estado de CARGA DE APLICATIVO
			BEGIN
				SELECT * into p_recDigCom from RDIG002 WHERE END_IP = l_endipDigInc(i) and BIO_TIPO = l_biotipoDigInc(i) for update nowait;
				UPDATE RDIG002 set status = '0' WHERE END_IP =  l_endipDigInc(i) and BIO_TIPO = l_biotipoDigInc(i);		-- VOLTA AO ESTADO DE REPOUSO
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
			
			
		END IF;		
	END LOOP;
	
	COMMIT;	



	
	-- ***********************  TRATA AS BIOMETRIAS VIRDI QUE FICARAM EM ESTADO DE CARREGANDO E NAO SAI DESTA SITUA��O
	-- para BIOMETRIAS  VIRDI DE RDIG004 que ficaram em estado carregando '2' e o equipamento est� em estado de repouso	, forca o equipamento a carrega-los novamente

	SELECT END_IP, STATUS, BIO_TIPO  
		BULK COLLECT INTO l_endipDigInc, l_statusDigInc, l_biotipoDigInc 
			FROM (SELECT  A.END_IP, A.status , A.BIO_TIPO  
					FROM RDIG002 A INNER JOIN 
						 RDIG004 B
					ON A.END_IP = B.END_IP and 
					   A.status = '0' and 
					   B.STATUS = '2' and
					   A.BIO_TIPO = B.BIO_TIPO) ;

	FOR i IN 1 .. l_endipDigInc.count     
	LOOP			
		for c1 in (select rowid from RDIG004 
			WHERE END_IP = l_endipDigInc(i) AND (STATUS = '2') AND (BIO_TIPO = l_biotipoDigInc(i)))
		loop
			BEGIN
				select * into p_recVrd from RDIG004 where rowid = c1.rowid for update nowait;		
				UPDATE RDIG004 SET STATUS = '1' where rowid = c1.rowid;

			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		end loop;				
		
		BEGIN
			SELECT * into p_recDigCom FROM RDIG002 WHERE END_IP = l_endipDigInc(i) for update nowait;
			UPDATE RDIG002 SET STATUS = '1'	WHERE END_IP = l_endipDigInc(i);
			
		EXCEPTION
			when reco_lock then NULL ;
			when tem_deadlock then NULL ;
			when NO_DATA_FOUND then NULL;
			when OTHERS then NULL;
		END;
	end LOOP;

	COMMIT;
	

	-- ********************   ARRUMAR SITUA��ES PARA VIRDI  -  EXCLUSAO
	-- ***********************  TRATA AS BIOMETRIAS  QUE FICARAM PENDENTES NA EXCLUSAO E QUE NAO SERAO REENVIADAS AUTOMATICAMENTE
	-- SITUACAO EM QUE CARGA FICOU PENDENTE PORQUE EQUIPAMENTO REJEITOU A EXCLUSAO (status '4')
	FOR r in (SELECT distinct IFUNC from RDIG104 WHERE STATUS = '4')
	LOOP
		FOR cur_troubleExc2 in 
			(SELECT rowid, IFUNC, END_IP  			-- GUARDA EM CURSOR TODAS AS LINHAS DESTA MATRICULA Q ESTA COM STATUS = '4'
				FROM RDIG104 
				WHERE IFUNC = r.IFUNC and 
					  STATUS = '4'  )
		LOOP
			BEGIN		-- PARA CADA LINHA , RESERVA ('for update nowait') PARA ALTERAR O STATUS
				SELECT * into p_recExcVrd FROM RDIG104 WHERE rowid = cur_troubleExc2.rowid for update nowait;
	
				UPDATE RDIG104 SET STATUS = '0' WHERE rowid = cur_troubleExc2.rowid ;
				--DELETE RDIG104 WHERE rowid = cur_troubleExc2.rowid ;

			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
					
			BEGIN
				SELECT END_IP into cIpAux FROM RDIG102 WHERE END_IP = p_recExcVrd.END_IP and STATUS = '3' for update nowait;
				UPDATE RDIG102 set status = '1'
					WHERE (END_IP = p_recExcVrd.END_IP  and STATUS = '3') ;
						
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		end loop;
	END LOOP;

	
	-- ***********************  TRATA AS BIOMETRIAS VIRDI QUE FICARAM PENDENTES NA EXCLUSAO
	-- altera status dos codins VIRDI para exclusao de biometria, se esses n�o estiverem com exclusao de biometria ou estiverem pendentes

	FOR r in 
		(SELECT distinct END_IP, BIO_TIPO from RDIG104 
			where (STATUS != '0') and (STATUS != '2') and (STATUS != '4')		-- statys 4 indica resposta do rep de nao implementado
		) 
	LOOP
		BEGIN
			SELECT * into p_recDigExc FROM RDIG102
				--WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3') and
				WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3' or STATUS = '4') and		-- statys 4 indica resposta do rep de nao implementado
					   BIO_TIPO = r.BIO_TIPO) for update nowait;
	
			UPDATE RDIG102 set status = '1'
				--WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3') and
				WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3' or STATUS = '4') and		-- statys 4 indica resposta do rep de nao implementado
					   BIO_TIPO = r.BIO_TIPO);
		EXCEPTION
			when reco_lock then NULL ;
			when tem_deadlock then NULL ;
			when NO_DATA_FOUND then NULL;
			when OTHERS then NULL;
		END;
	END LOOP;
	
	COMMIT;	
	


	-- ********************   TRATA EQUIPAMENTOS VIRDI QUE FICARAM EM ESTADO EXCLUINDO OU SOFRERAM CARGA DE APLICATIVO
	-- equipamentos  q ficaram em estado de excluindo '2' por mais de 2 minutos ou
	-- equipamentos que sofreram exclusao/recarga de aplicativo 
	
	SELECT distinct END_IP, BIO_TIPO, STATUS, ROWID
		BULK COLLECT INTO l_endipDigExc, l_biotipoDigExc, l_statusDigExc, l_rowid	
			FROM RDIG102  
			WHERE (((BIO_TIPO != '6') and (BIO_TIPO != '7') and (BIO_TIPO != '8')) and
				   (status = '5' or status = '6' OR (status = '2' and (data_load + ( 2 / 24 / 60 )  < sysdate)) ) 
				  );

	FOR i in 1 .. l_endipDigExc.count	
	LOOP
		IF (l_statusDigExc(i) = '2') THEN		-- estado CARREGANDO ('2') parado
			FOR c_curdig in 
				(SELECT rowid, IFUNC 
					FROM RDIG104 
					WHERE END_IP = l_endipDigExc(i) and 
						  STATUS = '2'  and 
						  BIO_TIPO = l_biotipoDigExc(i) )
			LOOP
				BEGIN
					SELECT * into p_recVrd FROM RDIG104 WHERE rowid = c_curdig.rowid for update nowait;
					UPDATE RDIG104 set status = '1' WHERE rowid = c_curdig.rowid ;
				
				EXCEPTION
					when reco_lock then NULL ;
					when tem_deadlock then NULL ;
					when NO_DATA_FOUND then NULL;
					when OTHERS then NULL;
				END;
			end loop;
						   
			BEGIN
				SELECT * into p_recDigExc from RDIG102 WHERE END_IP = l_endipDigExc(i) and BIO_TIPO = l_biotipoDigExc(i) for update nowait;
				UPDATE RDIG102 set status = '1' WHERE END_IP = l_endipDigExc(i) and BIO_TIPO = l_biotipoDigExc(i);		-- FAZ RECARGA DE BIOMETRIAS VIRDI
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		
		ELSIF ((l_statusDigExc(i) = '5') or (l_statusDigExc(i) = '6')) THEN		-- estado de CARGA DE APLICATIVO
			BEGIN
				SELECT * into p_recDigExc from RDIG102 WHERE END_IP = l_endipDigExc(i) and BIO_TIPO = l_biotipoDigExc(i) for update nowait;
				UPDATE RDIG102 set status = '0' WHERE END_IP = l_endipDigExc(i) and BIO_TIPO = l_biotipoDigExc(i);		-- VOLTA AO ESTADO DE REPOUSO
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		END IF;		
	END LOOP;
	
	COMMIT;	


	-- ***********************  TRATA AS BIOMETRIAS VIRDI QUE FICARAM EM ESTADO DE EXCLUINDO E NAO SAI DESTA SITUA��O
	-- para BIOMETRIAS  VIRDI DE RDIG104 que ficaram em estado EXCLUINDO '2' e o equipamento est� em estado de repouso	, forca o equipamento a exclui-los novamente

	SELECT END_IP, STATUS, BIO_TIPO  
		BULK COLLECT INTO l_endipDigExc, l_statusDigExc, l_biotipoDigExc
			FROM (SELECT  A.END_IP, A.status, A.BIO_TIPO   
					FROM RDIG102 A INNER JOIN 
						 RDIG104 B
					ON A.END_IP = B.END_IP and 
					   A.status = '0' and 
					   B.STATUS = '2' and
					   A.BIO_TIPO = B.BIO_TIPO) ;

	FOR i IN 1 .. l_endipDigExc.count     
	LOOP			
		for c1 in (select rowid from RDIG104 
			WHERE END_IP = l_endipDigExc(i) AND (STATUS = '2')  AND (BIO_TIPO = l_biotipoDigExc(i)))
		loop
			BEGIN
				select * into p_recExcVrd from RDIG104 where rowid = c1.rowid for update nowait;		
				UPDATE RDIG104 SET STATUS = '1' where rowid = c1.rowid;

			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		end loop;				
		
		BEGIN
			SELECT * into p_recDigExc FROM RDIG102 WHERE END_IP = l_endipDigExc(i) for update nowait;
			UPDATE RDIG102 SET STATUS = '1'	WHERE END_IP = l_endipDigExc(i);
			
		EXCEPTION
			when reco_lock then NULL ;
			when tem_deadlock then NULL ;
			when NO_DATA_FOUND then NULL;
			when OTHERS then NULL;
		END;
	end LOOP;

	COMMIT;
	

	

end trata3_RepOutrosBios ;
/
