-- INICIO3aTCPARL.SQL: compilacao de funcoes e procedures

SPOOL RESULT3A.LOG;

CONNECT CP_TELEMAT/TELEMAT;

-- cria procedures e funcoes
@@PRINCPRXAT;

-- criacao de role com permissao de execucao de funcoes e procedures 
@@GRTSQLTCP;
@@GRTSQLPRI;

-- criacao do job. O Agent do Oracle deve estar ativo
@@JOBSTCOLET;

SPOOL OFF;

-- Continuar com script Inicio5TcpArl.sql: criacao de usuarios
