CREATE OR REPLACE FUNCTION sqlconsG3G5_term_repp_tcpoff18 (cEndIp in varchar2, cBuffer in out varchar2, cTamG3G5 in out varchar2) 
   RETURN NUMBER IS

Ret    NUMBER;
--cPlanta CHAR(3);
cPlanta VARCHAR(9);
cTip_Term CHAR(1);
--cLaces CHAR(3);
cLaces VARCHAR2(9);
cBiotipo CHAR(1);
cRast CHAR(1);
cInih CHAR(1);
cFimh CHAR(1);
cVal CHAR(1);
cSMAx CHAR(1); 
cTleit CHAR(1); 
cPosVPlaca CHAR(1);
cPosMBloq CHAR(1);
cValDiasSuc CHAR(1);
nTamG NUMBER;
cAdBuf CHAR(2);
cRepP CHAR(1);


BEGIN
    Ret := 1;
	cTip_Term := '1';
	--cLaces := '00000';
	cBiotipo := '0';
	--cPlanta := '000';
	cRast := '0';
	cInih := '0';
	cFimh := '0';
	cVal := '0';
	cSMAx := '0'; 
	cTleit := '0'; 
    cPosVPlaca := '0';
	cPosMBloq := '0';
    cValDiasSuc := '0';
    
    cLaces := NULL;
    cPlanta := NULL;
	
	cRepP := '0';
	
	BEGIN
		select data_length INTO nTamG 
			from   user_tab_columns
			where  table_name = 'DAT07' and	column_name = 'LACES';
	EXCEPTION
		WHEN OTHERS THEN 
			nTamG := 3;		-- ASSUME TAMANHO DO CAMPO LACES COM 3 DIGITOS
	END;

    BEGIN
		SELECT Tip_Term, laces, bio_tipo, planta, rastreador, pos_inihalm, pos_fimhalm, valid_ret, VALID_SAIDAMAx, tip_leit, PosValPlaca, PosMensBloq, Valid_NDias   
			INTO cTip_Term,	cLaces,	cBiotipo, cPlanta, cRast, cInih, cFimh, cVal, cSMAx, cTleit, cPosVPlaca, cPosMBloq, cValDiasSuc    
		FROM DAT07
		WHERE End_Ip = cEndIp;

	EXCEPTION
		WHEN NO_DATA_FOUND then Ret := 0;
		WHEN OTHERS then Ret := -1;
	END;
	
	if (cTip_Term is Null) then
		cTip_Term := '1';
	end if;

	if (cLaces is Null) then
		if (nTamG = 3)	then
			cLaces := '000';
		else
			cLaces := '00000';
		end if;
	end if;

	if (cBiotipo is Null) then
		cBiotipo := '0';
	end if;

	if (cPlanta is Null) then
		if (nTamG = 3)	then
			cPlanta := '000';
		else
			cPlanta := '00000';
		end if;
		
	end if;

	if (cRast is Null) then
		cRast := '0';
	end if;

	if (cInih is Null) then
		cInih := '0';
	end if;

	if (cFimh is Null) then
		cFimh := '0';
	end if;

	if (cVal is Null) then
		cVal := '0';
	end if;

	if (cSMAx is Null) then
		cSMAx := '0';
	end if;

	if (cTleit is Null) then
		cTleit := '0';
	end if;

	if (cPosVPlaca is Null) then
		cPosVPlaca := '0';
	end if;

	if (cPosMBloq is Null) then
		cPosMBloq := '0';
	end if;

	if (cValDiasSuc is Null) then
		cValDiasSuc := '0';
	end if;

	IF (nTamG = 3) then
		cAdBuf := '  ';		-- 2 esp�os
	ELSE
		cAdBuf := NULL;
	END IF;

    -- VERIFICA SE REP_P
    BEGIN
		--SELECT REP_P
		--	INTO cRepP
		--	FROM DAT07REPP
		--	WHERE End_Ip = cEndIp;
		SELECT '1'
			INTO cRepP
			FROM DAT07REPP
			WHERE End_Ip = cEndIp and rownum = 1;
	
	EXCEPTION 
		WHEN NO_DATA_FOUND THEN
			cRepP := '0';
		WHEN OTHERS THEN
			cRepP := '0';
	END;

    cBuffer := cTip_Term || cLaces || cAdBuf ||
    		   cBiotipo || cPlanta || cAdBuf ||
    		   cRast || cInih || cFimh || cVal || cSMAx || '00' || '00' || cTleit || cPosVPlaca || cPosMBloq || cValDiasSuc ||
    		   cRepP;


    cTamG3G5 := TO_CHAR(nTamG);


    return (Ret);

END sqlconsG3G5_term_repp_tcpoff18;
/
