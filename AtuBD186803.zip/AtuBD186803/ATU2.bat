@echo off
if "%1" == "?" goto sintaxe
if "%1" == "/?" goto sintaxe
if "%1" == "-?" goto sintaxe
if "%1" == "" goto sintaxe

@echo off
if not "%1" == "" goto Server
goto sintaxe

:Server
cls

echo - Criando Stored Procedures 


OSQL /UTELESSVR /PSSVRTELE /S%1 /dACESSOTA /iC:\ACESSOSS\Scripts\S_G3G5_PREP4_TSI1.sql > C:\ACESSOSS\Scripts\ATU2.log
OSQL /UTELESSVR /PSSVRTELE /S%1 /dACESSOTA /iC:\ACESSOSS\Scripts\S_sqlAtuCont512_bdcc.sql >> C:\ACESSOSS\Scripts\ATU2.log

echo - Privilegios
OSQL /UTELESSVR /PSSVRTELE /S%1 /dACESSOTA /iC:\ACESSOSS\Scripts\Priv.sql >> C:\ACESSOSS\Scripts\ATU2.log
echo.

echo Fim de ATU.
echo Verifique C:\ACESSOSS\Scripts\ATU2.log
goto limpa

:sintaxe
@echo Sintaxe:
@echo ATU {server_name}
@echo.
goto fim

:limpa
echo.
doskey /reinstall
@echo off

:fim
