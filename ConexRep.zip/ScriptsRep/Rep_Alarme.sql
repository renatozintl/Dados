CREATE OR REPLACE FUNCTION sqlrep_alarme (cEndIp in varchar2, cNumRep in varchar2, nAlarme in NUMBER, cDados in VARCHAR2) 
   RETURN NUMBER IS

nRet NUMBER;
cData VARCHAR2(10);
cHora VARCHAR2(10);
cStatus VARCHAR2(10);
BEGIN
	
	nRet := 0;
	cData := substr (cDados, 1, 6);
	cHora := substr (cDados, 7, 6);
	cStatus := substr (cDados, 13, 5);
	
	BEGIN
		INSERT INTO REPALARME (END_IP, REP, ALARME, DATA, HORA, ESTADO) 
						VALUES (cEndIp, cNumRep, nAlarme, cData, cHora, cStatus);
		COMMIT;
	EXCEPTION
		WHEN OTHERS THEN 
			nRet := -1;
	END;

    return (nRet);
    
END sqlrep_alarme;
/
