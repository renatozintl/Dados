CREATE OR REPLACE FUNCTION sqlbloco_col_dam99_tcp (Registro in VARCHAR2, RegDoc in VARCHAR2)
   RETURN NUMBER IS
Ret NUMBER;
dado_veic CHAR(15);

BEGIN
	dado_veic := '               ';	-- 15 espacos
	INSERT INTO DAM99 (ICARD, DIAM, MESM, ANOM, HORAM,SEGUNDO, CODAC, POSIC, END_IP, CODFNC, ONOFF, VEICULO,
						NUMSERIAL, DOC_TIPO, DOCUMENTO, PLACA)
               VALUES (SUBSTR(Registro, 1, 12), SUBSTR(Registro, 13, 2),
                       	SUBSTR(Registro, 15, 2), SUBSTR(Registro, 17, 2),
						SUBSTR(Registro, 19, 4), SUBSTR(Registro, 23, 2),
	               		SUBSTR(Registro, 25, 2),
     	               	SUBSTR(Registro, 27, 1), SUBSTR(Registro, 28, 15),
		       			SUBSTR(Registro, 43, 2), SUBSTR(Registro, 45, 1),
		       			dado_veic,
		       			SUBSTR(RegDoc, 13, 10), SUBSTR(RegDoc, 23, 1),
		       			SUBSTR(RegDoc, 24, 14), SUBSTR(RegDoc, 38, 10)
		       			);

   Return (0);
END sqlbloco_col_dam99_tcp;
/


