CREATE OR REPLACE FUNCTION sqlGravaBD_BinaryBios (cMatric in VARCHAR2, cdados in BLOB, tam in number, nTipoPadAlt in number, cBioTipo in VARCHAR2)
   RETURN NUMBER IS
cAuxMat CHAR(12);
cBioAux char(1);
cStAux char(1);
cStRepAux char(1);
lob_pad BLOB;
lob_alt BLOB;
reco_lock EXCEPTION;
tam_erase NUMBER;
PRAGMA EXCEPTION_INIT (reco_lock,-54);  -- erro quando registro lockado 


BEGIN
	IF (nTipoPadAlt = 0) THEN			-- PADRAO
		begin
			SELECT DIGITALBIN_PAD INTO lob_pad FROM CONTDIG_OUTROS 
			WHERE Icard = cMatric AND 			-- matricula
				  BIO_TIPO = cBioTipo 			-- identificador  do biometrico 
				FOR UPDATE NOWAIT;

			tam_erase := DBMS_LOB.GETLENGTH (lob_pad);
			IF (tam_erase > tam) then
				DBMS_LOB.ERASE (lob_pad, tam_erase, 1);
			END IF;
			
			DBMS_LOB.WRITE(lob_pad, tam, 1, cdados);	
			UPDATE CONTDIG_OUTROS set STATUS = '1', STATUS_REP = '1' 
				WHERE ICARD = cMatric AND
					  BIO_TIPO = cBioTipo;

		exception
			when NO_DATA_FOUND then	
				INSERT INTO CONTDIG_OUTROS (icard, DIGITALBIN_PAD, DIGITALBIN_ALT, BIO_TIPO, STATUS, STATUS_REP)
					VALUES (cMatric, empty_BLOB(), empty_BLOB(), cBioTipo, '1', '1')
					RETURNING ICARD, DIGITALBIN_PAD, DIGITALBIN_ALT, BIO_TIPO, STATUS, STATUS_REP INTO cAuxMat, lob_pad, lob_alt, cBioAux,cStAux, cStRepAux;

				DBMS_LOB.WRITE(lob_pad, tam, 1, cdados);
	
			when OTHERS then 
				return (0);
		end;
	
	
	ELSE					-- ALTERNATIVO
		begin
			SELECT DIGITALBIN_ALT INTO lob_alt FROM CONTDIG_OUTROS 
				WHERE ICARD = cMatric AND
			   	  	  BIO_TIPO = cBioTipo  FOR UPDATE NOWAIT;

			tam_erase := DBMS_LOB.GETLENGTH (lob_alt);
			IF (tam_erase > tam) then
				DBMS_LOB.ERASE (lob_alt, tam_erase, 1);
			END IF;

			DBMS_LOB.WRITE(lob_alt, tam, 1, cdados);	
			UPDATE CONTDIG_OUTROS set STATUS = '1', STATUS_REP = '1' 
				WHERE ICARD = cMatric AND
					  BIO_TIPO = cBioTipo;

		exception
			when NO_DATA_FOUND then	
				INSERT INTO CONTDIG_OUTROS (icard, DIGITALBIN_PAD, DIGITALBIN_ALT, BIO_TIPO, STATUS, STATUS_REP)
					VALUES (cMatric, empty_BLOB(), empty_BLOB(), cBioTipo, '1', '1')
					RETURNING ICARD, DIGITALBIN_PAD, DIGITALBIN_ALT, BIO_TIPO, STATUS, STATUS_REP INTO cAuxMat, lob_pad, lob_alt, cBioAux,cStAux, cStRepAux;

				DBMS_LOB.WRITE(lob_alt, tam, 1, cdados);
	
			when OTHERS then 
				return (0);
		end;
	END IF;
	
	COMMIT;    
    return (1);

END sqlGravaBD_BinaryBios;
/
