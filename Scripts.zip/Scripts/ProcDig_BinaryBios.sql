
CREATE OR REPLACE FUNCTION sqlproc_digitBinaryBios (cMatric in VARCHAR2, cEndIp VARCHAR2, cBioTipo in VARCHAR2, cDados1 out blob, cDados2 out blob, len1 out number, len2 out number)
   RETURN NUMBER IS
   cAux   VARCHAR2(15);
   ret number;

BEGIN

	cDados1 := null;
	cDados2 := null;
	len1 := 0;
	len2 := 0;

	begin
		select icard, DIGITALBIN_PAD, dbms_lob.getlength(DIGITALBIN_PAD), DIGITALBIN_ALT, dbms_lob.getlength(DIGITALBIN_ALT)
			into cAux, cDados1, len1, cDados2, len2  
		from CONTDIG_OUTROS 
		WHERE ICARD = cMatric AND 
		  	  BIO_TIPO = cBioTipo;
		ret := 1;
			
		IF ( ((len1 is NULL) and (len2 is NULL)) OR
		     ((cDados1 is NULL) and (cDados2 is NULL)) ) then
			ret := 0;
		end if;
		
		IF (len1 is NULL) THEN 
			len1 := 0;
		end if;
		
		IF (len2 is NULL) THEN 
			len2 := 0;
		end if;
		
	exception
		when NO_DATA_FOUND then	
			ret := 0;
		when OTHERS then	
			ret := 0;			
	end;
	
	IF (ret = 0) then
		-- insere em tabela DIGLOAD001
		INSERT INTO DIGLOAD001 (END_IP, ICARD, BIO_TIPO) 
			VALUES (cEndIp, cMatric, cBioTipo);
		COMMIT;
	END IF;
	
    return (ret);

END sqlproc_digitBinaryBios;
/

