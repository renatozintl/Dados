CREATE OR REPLACE FUNCTION sqlrproc_tsi1_template2 (MATRIC VARCHAR2, cEndIp VARCHAR2, cNumRep VARCHAR2, T_TIT1 IN OUT VARCHAR2, T_TIT2 IN OUT VARCHAR2, 
T_TIT3 IN OUT VARCHAR2, T_TIT4 IN OUT VARCHAR2, T_ALT1 IN OUT VARCHAR2, T_ALT2 IN OUT VARCHAR2,
T_ALT3 IN OUT VARCHAR2, T_ALT4 IN OUT VARCHAR2, cNivel IN OUT VARCHAR2,
T_TIT5 IN OUT VARCHAR2, T_ALT5 IN OUT VARCHAR2)
   RETURN NUMBER IS
      Retfun NUMBER;
      RECO_LOCK EXCEPTION;
      PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);
      AUX VARCHAR2(15);
      T_TIT5Aux VARCHAR2(128);
      T_ALT5Aux VARCHAR2(128);
      Alt NUMBER;
      Pad NUMBER;

BEGIN
	
    Pad := 0;
    Alt := 0;
	Retfun := 3;      -- sem templ padrao e sem templ alternativo
	
	BEGIN
		SELECT TEMPL_TIT1, TEMPL_TIT2, TEMPL_TIT3, TEMPL_TIT4, TEMPL_TIT5,
		  TEMPL_ALT1, TEMPL_ALT2, TEMPL_ALT3, TEMPL_ALT4, TEMPL_ALT5,
		  NIVEL
		INTO 
		  T_TIT1, T_TIT2, T_TIT3, T_TIT4, T_TIT5Aux,
		  T_ALT1, T_ALT2, T_ALT3, T_ALT4, T_ALT5Aux,
		  cNivel 
		FROM CONTDIG_TSI1 WHERE ICARD = MATRIC;
		   
		Pad := 1;    -- assume que tem template padrao
		Alt := 1;    -- assume que tem template alternativo
		if ((T_tit1 is Null) or (T_tit2 is Null) or 
			(T_tit3 is Null) or (T_tit4 is Null) or 
			(T_tit5Aux is Null) or
			(length(T_tit1) < 160) or (length(T_tit2) < 160) or
			(length(T_tit3) < 160) or (length(T_tit4) < 160) or 
			(length(T_tit5Aux) < 128)) then
			Pad := 0;
		else
			T_TIT5 := RPAD(T_TIT5Aux, 160, '1');
		end if;

		if ((T_alt1 is Null) or (T_alt2 is Null) or
			(T_alt3 is Null) or (T_alt4 is Null) or 
			(T_alt5Aux is Null) or
			(length(T_alt1) < 160) or (length(T_alt2) < 160) or
			(length(T_alt3) < 160) or (length(T_alt4) < 160) or 
			(length(T_alt5Aux) < 128)) then
			Alt := 0;
		else
			T_ALT5 := RPAD(T_ALT5Aux, 160, '1');
		end if;

	EXCEPTION
		WHEN NO_DATA_FOUND THEN 
			Pad := 0;
			Alt := 0;
		WHEN OTHERS THEN 
			Pad := 0;
			Alt := 0;
	END;

	if (Pad = 1) then
	    if (Alt = 1) then
			Retfun := 0;   -- tem padrao e tem alternativo
		else 
			Retfun := 1;   -- tem padrao e nao tem alternativo
    	end if;
	end if;
	if (Pad = 0) then
	    if (Alt = 1) then
			Retfun := 2;   -- nao tem padrao e tem alternativo
		else 
			Retfun := 3;   -- nao tem padrao e nao tem alternativo
    	end if;
	end if;
	
	IF (Retfun = 3)	then 	-- digital nao cadastrado
		INSERT INTO REPDIGLOAD001 (END_IP, REP, IFUNC, BIO_TIPO) 
			VALUES (cEndIp, cNumRep, MATRIC, '8');
		COMMIT;
	END IF;
	
	
	return (Retfun);
END sqlrproc_tsi1_template2;
/


