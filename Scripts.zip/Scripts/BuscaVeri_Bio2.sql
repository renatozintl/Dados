CREATE OR REPLACE FUNCTION sqlBusca_Veri_biomet2 (cMatric VARCHAR2, cTipTerm VARCHAR2, cEndIp VARCHAR2, cTipoCons VARCHAR2,
cTempl_tit1tot IN OUT VARCHAR2, cTempl_tit2tot IN OUT VARCHAR2, 
cTempl_tit3tot IN OUT VARCHAR2, cTempl_tit4tot IN OUT VARCHAR2, 
cTempl_Alt1tot IN OUT VARCHAR2, cTempl_Alt2tot IN OUT VARCHAR2, 
cTempl_Alt3tot IN OUT VARCHAR2, cTempl_Alt4tot IN OUT VARCHAR2, 
cTempl_tit5tot IN OUT VARCHAR2, cTempl_Alt5tot IN OUT VARCHAR2, 
cNivel IN OUT VARCHAR2)
RETURN NUMBER IS

RetFun    NUMBER;
Alt NUMBER;
Pad NUMBER;
cAchou    NUMBER;	
cVDigit    VARCHAR2(1);	
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);  -- erro quando registro lockado

BEGIN
	RetFun := 0;
	cNivel := Null;
	Pad := 0;
	Alt := 0;
	cAchou := 0;
	cVDigit := '2';		-- 1

	IF (cTipoCons = '1') THEN		-- TIPO DE CONSULTA � ONLINE, E DEVER� SER CONSULTADO JUNTAMENTE COM A TAB.CONTROLE. NAO DEVER� SER GRAVADO EM DIGLOAD001
	
		BEGIN
			SELECT Ver_Digit INTO cVDigit FROM CONTROLE WHERE Icard = cMatric;
			
			BEGIN
				SELECT 
					c.Templ_Tit1, c.Templ_Tit2, c.Templ_Tit3, c.Templ_Tit4, 
					c.Templ_Alt1, c.Templ_Alt2, c.Templ_Alt3, c.Templ_Alt4,
					c.nivel, c.Templ_Tit5, c.Templ_Alt5
				INTO 
					cTempl_tit1tot, cTempl_tit2tot, cTempl_tit3tot, cTempl_tit4tot, 
					cTempl_alt1tot, cTempl_alt2tot, cTempl_alt3tot, cTempl_alt4tot,
					cNivel, cTempl_tit5tot, cTempl_alt5tot
				FROM CONTDIG_VERI c
				WHERE c.Icard = cMatric;

				cAchou := 1;

			EXCEPTION

				WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
					IF ((to_number(cVDigit) = 2) OR (to_number(cVDigit) = 3) ) THEN		-- 2 = BIO(1:N);  3 = BIO(1:1)
						RetFun := -2;
					ELSE
						Pad := 0;
						Alt := 0;
					END IF;				

				WHEN OTHERS THEN              -- outros erros
					RetFun := -1;
					return (RetFun);
			END;
			
		EXCEPTION
			WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
				cVDigit := '3';			  -- BIO (1:1) confere digital com necessidade de cartao 
			WHEN OTHERS THEN       -- reg. nao encontrado
				cVDigit := '3';			  -- BIO (1:1) confere digital com necessidade de cartao 
		END;
	
	
	ELSE
		BEGIN
			SELECT 
				c.Templ_Tit1, c.Templ_Tit2, c.Templ_Tit3, c.Templ_Tit4, 
				c.Templ_Alt1, c.Templ_Alt2, c.Templ_Alt3, c.Templ_Alt4,
				c.Templ_Tit5, c.Templ_Alt5
			INTO 
				cTempl_tit1tot, cTempl_tit2tot, cTempl_tit3tot, cTempl_tit4tot, 
				cTempl_alt1tot, cTempl_alt2tot, cTempl_alt3tot, cTempl_alt4tot,
				cTempl_tit5tot, cTempl_alt5tot 
			FROM CONTDIG_VERI c
			WHERE c.Icard = cMatric ;

			cAchou := 1;
			
		EXCEPTION
			WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
				Pad := 0;
				Alt := 0;
			WHEN OTHERS THEN              -- outros erros
				RetFun := -1;
				return (RetFun);
		END;
	END IF;

	IF (cAchou = 1) THEN
		Pad := 1;    -- assume que tem template padrao
		Alt := 1;    -- assume que tem template alternativo

		if ((cTempl_tit1tot is Null) or (cTempl_tit2tot is Null) or 
			(cTempl_tit3tot is Null) or (cTempl_tit4tot is Null) or
			(cTempl_tit5tot is Null) or
			(length(cTempl_tit1tot) < 160) or (length(cTempl_tit2tot) < 160) or
			(length(cTempl_tit3tot) < 160) or (length(cTempl_tit4tot) < 160) or
			(length(cTempl_tit5tot) < 56)) then
				Pad := 0;
		end if;
	
		if ((cTempl_alt1tot is Null) or (cTempl_alt2tot is Null) or
			(cTempl_alt3tot is Null) or (cTempl_alt4tot is Null) or
			(cTempl_ALt5tot is Null) or
			(length(cTempl_alt1tot) < 160) or (length(cTempl_alt2tot) < 160) or
			(length(cTempl_alt3tot) < 160) or (length(cTempl_alt4tot) < 160) or
			(length(cTempl_ALt5tot) < 56)) then 
				Alt := 0;
		end if;
	END IF;
	
	IF (Retfun != -2) then
		if (Pad = 1) then
			if (Alt = 1) then
				Retfun := 0;   -- tem padrao e tem alternativo
			else 
				Retfun := 1;   -- tem padrao e nao tem alternativo
			end if;
		end if;
		if (Pad = 0) then
			if (Alt = 1) then
				Retfun := 2;   -- nao tem padrao e tem alternativo
			else 
				Retfun := 3;   -- nao tem padrao e nao tem alternativo
			end if;
		end if;
	end if;
	
	-- VERIFICA SE NAO ACHOU NENHUMA BIOMETRIA E � COMANDO DE ENVIO DE DIGITAIS, DEVERA GUARDAR INFORMACAO EM DIGLOAD001	
	IF ((Retfun = 3) and (cTipoCons != '1' )) THEN
		INSERT INTO DIGLOAD001 (END_IP, ICARD, BIO_TIPO) 
						VALUES (cEndIp, cMatric, cTipTerm);
		COMMIT;
	END IF;
		
	Return (RetFun);
	
END sqlBusca_Veri_biomet2;
/
