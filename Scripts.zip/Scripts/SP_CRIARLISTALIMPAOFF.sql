CREATE OR REPLACE  PROCEDURE SP_CRIARLISTALIMPAOFF   is
       HoraMaquina  varchar(5);
       horaFechada varchar(5);
BEGIN
             select to_char(sysdate,'HH24:MI') as hora into HoraMaquina from dual;

    horaFechada := HoraMaquina;

--------------------------------------------------
-- I N I C I O   D A   V E R I F I C A � � O  
--------------------------------------------------
for x in ( select END_IP, HORA from pend_on002lpz ) LOOP
    if x.hora <> '99:99' then  
        if x.hora =  horaFechada then           
           update pend_on002LPZ set status_lpz = '1' where end_ip = x.end_ip;
           commit ;
        end if;   
    end if;

END LOOP;
end sp_criarlistalimpaoff ;
/
