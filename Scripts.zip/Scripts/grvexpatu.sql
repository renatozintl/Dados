CREATE OR REPLACE FUNCTION sqlins_expireatusmart (Registro in VARCHAR2)
   RETURN NUMBER IS
      Ret NUMBER;

BEGIN
    INSERT INTO EXPIREATU (IDENTIF, NUMSERIAL, DATA_EXP, END_IP, BLUEB, CODTT) 
	--VALUES (SUBSTR(Registro, 1, 14), 
	VALUES (to_identif(SUBSTR(Registro, 1, 14)), 
		SUBSTR(Registro, 15, 10),
                SUBSTR(Registro, 25, 10),
                SUBSTR(Registro, 35, 15),
                SUBSTR(Registro, 50, 2),
                SUBSTR(Registro, 52, 2));
    COMMIT;
    Return (0);

END sqlins_expireatusmart;
/


