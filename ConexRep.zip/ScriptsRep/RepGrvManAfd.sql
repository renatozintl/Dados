CREATE OR REPLACE PROCEDURE sqlgrava_repManEsp (NumRep in VARCHAR2, Registro in VARCHAR2, cEndIp in VARCHAR2, cInterj in NUMBER) IS
	
Nsr CHAR(9);
TipoReg CHAR(1);

cAuxPis VARCHAR2(12);
cAuxDta VARCHAR2(12);

BEGIN
	
	Nsr := SUBSTR (Registro, 1, 9);	
	TipoReg := SUBSTR (Registro, 10, 1);	
	
	if TipoReg not IN ('1', '2', '3', '4', '5', '6', '9') then
		INSERT INTO REPAFD104 
			(END_IP, REP, NSR, TIPO_REG, STATUS, INFORM) VALUES
			(cEndIp, NumRep, Nsr, TipoReg, '0', Registro);
	else
		BEGIN
			INSERT INTO REPAFD101 
				(END_IP, REP, NSR, TIPO_REG, STATUS, INFORM) VALUES
				(cEndIp, NumRep, Nsr, TipoReg, '0', Registro);
		EXCEPTION
			WHEN PROGRAM_ERROR THEN
				INSERT INTO REPAFD104 
					(END_IP, REP, NSR, TIPO_REG, STATUS, INFORM) VALUES
					(cEndIp, NumRep, Nsr, TipoReg, '0', Registro);
			WHEN OTHERS THEN
				INSERT INTO REPAFD104 
					(END_IP, REP, NSR, TIPO_REG, STATUS, INFORM) VALUES
					(cEndIp, NumRep, Nsr, TipoReg, '0', Registro);
		END;			

	end if;
	
	
END sqlgrava_repManEsp;
/
