CREATE or REPLACE FUNCTION sqller_autoLoadPalmV
(
cEndSensoBox in VARCHAR2,
nQtdCiclos in NUMBER,
cListaMat in out VARCHAR2
) 
RETURN NUMBER IS

xCont NUMBER;
nTotal NUMBER;
cStatus VARCHAR2(1);
cAux VARCHAR2(12);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

cursor lpalmv_cur is 
	SELECT ICARD, STATUS FROM PALMV014 
		WHERE END_CTRLPALMV = cEndSensoBox AND STATUS != '0' AND STATUS != '2' 
		order by ICARD for update of STATUS;

begin
    xCont := 0;
    nTotal := nQtdCiclos * 20;
    if (nTotal > 100) then
		nTotal := 100;
	end if;


	BEGIN
		SELECT STATUS into cStatus 
			FROM PALMV004 
			WHERE END_CTRLPALMV = cEndSensoBox for update nowait;

		IF (cStatus = '1') THEN 
			FOR r in lpalmv_cur LOOP
				cListaMat := cListaMat || r.Icard;
				update PALMV014 set STATUS = '2' where current of lpalmv_cur ;
				xCont := xCont+1;
				--IF (xCont >= 20) THEN 
				IF (xCont >= nTotal) THEN 
					Exit;
				END IF;
			END LOOP;

			IF (xCont = 0) THEN
				UPDATE PALMV004 SET STATUS = '0' WHERE END_CTRLPALMV = cEndSensoBox;
			ELSE
				cListaMat := cListaMat || ';';
				UPDATE PALMV004 SET STATUS = '2', DATA_LOAD = SYSDATE WHERE END_CTRLPALMV = cEndSensoBox;
			END IF;

		ELSE
			COMMIT;
			return (0);
		END IF;					

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			xCont := 0;
		WHEN reco_lock THEN
			xCont := 0;
		WHEN OTHERS THEN
			xCont := 0;
	END;
	
	COMMIT;
	return (xCont);
		
END sqller_autoLoadPalmV;
/

