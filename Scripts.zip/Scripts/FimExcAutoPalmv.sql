CREATE or REPLACE FUNCTION sqlfim_ExcAutoPalmv (cEndIp in VARCHAR2, cStat in VARCHAR2) 
RETURN NUMBER IS

xCont NUMBER;
ret NUMBER;
cAux VARCHAR2(1);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

cursor lexcf015_cur is 
	SELECT ICARD, STATUS FROM PALMV015 
		WHERE END_CTRLPALMV = cEndIp AND STATUS = '2' 
		order by ICARD for update of STATUS;

begin
    xCont := 0;
    ret := 0;

	-- atualiza o status somente dos ICARDS q estavam sendo excluidos (sofrendo o comando de exlucsao no conex)
	for r in lexcf015_cur LOOP
		update PALMV015 set STATUS = cStat where current of lexcf015_cur ;
		xCont := xCont+1;
	END LOOP;


	BEGIN
		SELECT STATUS into cAux   
			FROM PALMV005 
			WHERE END_CTRLPALMV = cEndIp for update nowait;
			
		UPDATE PALMV005 SET STATUS = cStat WHERE END_CTRLPALMV = cEndIp;
			

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			ret := 0;
		WHEN reco_lock THEN
			ret := (0);
		WHEN OTHERS THEN
			ret := -1;
	END;
    
	
	COMMIT;
	return (ret);
		
END sqlfim_ExcAutoPalmv;
/

