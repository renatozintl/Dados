CREATE OR REPLACE FUNCTION sqlhora_gerbio (cEndIp varchar2) 
   RETURN NUMBER IS

Ret    NUMBER;
cHoraIni CHAR(8);	-- 'hh:mi:ss'
cHoraFim CHAR(8);	-- 'hh:mi:ss'
cHoraCor CHAR(8);		-- 'hh:mi:ss'
   
BEGIN
	
    Ret := 0;
    
    BEGIN
    	SELECT INICIO_GER, FINAL_GER INTO cHoraIni, cHoraFim
			FROM ACEAUTOBIO
			WHERE End_Ip = cEndIp;

    EXCEPTION
		WHEN NO_DATA_FOUND then Ret := -1;
		WHEN OTHERS then Ret := -1;
    END;
    

    IF (Ret >= 0) THEN
    	SELECT TO_CHAR (sysdate, 'HH24:MI:SS')
			into cHoraCor from dual; 
		
		IF (cHoraIni < cHoraFim) THEN 
			IF ((cHoraCor >= cHoraIni) AND (cHoraCor <= cHoraFim)) THEN
				Ret := 1;
			END IF;
		
		ELSE 
			IF (cHoraCor >= cHoraIni) THEN
				Ret := 1;
			ELSE
				IF (cHoraCor <= cHoraFim) THEN
					Ret := 1;
				END IF;
			END IF;
		END IF;
    END IF;

    return (Ret);

END sqlhora_gerbio;
/

