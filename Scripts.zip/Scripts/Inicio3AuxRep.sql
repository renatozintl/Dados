-- INICIO3AuxRep.SQL: compilacao de funcoes e procedures

SPOOL RESULT3A.LOG;

CONNECT CP_TELEMAT/TELEMAT;

--compilacao ConexRep
@@RepGrvAfd3B.sql;
@@RepGrvAfd4B.sql;


SPOOL OFF;

-- Continuar com script Inicio4.sql: criacao de usuarios
