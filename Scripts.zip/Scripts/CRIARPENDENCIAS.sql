CREATE OR REPLACE TRIGGER CRIARPENDENCIAS AFTER 
INSERT ON ATUALI FOR EACH ROW call sp_criarpendencias( :new.identif, :new.numserial, :new.icard, :new.numcpo, :new.inform )
/
