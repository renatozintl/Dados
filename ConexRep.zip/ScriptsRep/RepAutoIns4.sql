CREATE or REPLACE FUNCTION sqlrep_autoIns4
(
cEndIp in VARCHAR2,
cListaMat in out VARCHAR2,
nTotal in NUMBER,
cTipoRep in VARCHAR2
) 
RETURN NUMBER IS

xCont NUMBER;
cStatus VARCHAR2(1);
cAux VARCHAR2(12);
nOK NUMBER;
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

cursor linsf001_cur is 
	SELECT IFUNC, STATUS, DOC_TIPO FROM REPAUTO011 
		--WHERE END_IP = cEndIp AND STATUS != '0' AND STATUS != '2' 
		WHERE END_IP = cEndIp AND STATUS != '0'
		order by IFUNC for update of STATUS;

begin
    xCont := 0;

	BEGIN
		SELECT STATUS into cStatus  
		FROM REPAUTO001 
		WHERE END_IP = cEndIp for update nowait;

		IF (cStatus = '1') then
			UPDATE REPAUTO001 SET STATUS = '2', DATA_LOAD = SYSDATE 
				WHERE END_IP = cEndIp;

		
			-- coloca em lista de Inclusao somente os <nTotal> primeiros funcionarios para carga de lista
			for r in linsf001_cur LOOP 
				nOK := 0;
				if ((cTipoRep = '1') and ((r.DOC_TIPO = '1') or (r.DOC_TIPO = '0')) ) then 		-- rep aceita PIS e a nova carga esta ocorrendo porque houve atltera��o no PIS ou NOME
					nOK := 1;
				else
					if ((cTipoRep = '2') and ((r.DOC_TIPO = '2') or (r.DOC_TIPO = '0')) ) then 		-- rep aceita CPF e a nova carga esta ocorrendo porque houve atltera��o no CPF ou NOME
						nOK := 1;
					end if;
				end if;
			
				IF (nOK = 1) THEN
					cListaMat := cListaMat || r.IFUNC;
					xCont := xCont+1;
				END IF;
				
				update REPAUTO011 set STATUS = '2' where current of linsf001_cur ;
				
				if (xCont >= nTotal) then
					Exit;
				end if;
			END LOOP;

			IF (xCont = 0) THEN
				UPDATE REPAUTO001 SET STATUS = '0' WHERE END_IP = cEndIp;
			ELSE
				cListaMat := cListaMat || ';';
				UPDATE REPAUTO001 SET 
					STATUS = '2', 
					DATA_LOAD = SYSDATE 
					WHERE END_IP = cEndIp;
			END IF;
			
		ELSE
			COMMIT;
			return (0);
		END IF;					

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			return (0);
		WHEN reco_lock THEN
			return (0);
		WHEN OTHERS THEN
			return (0);
	END;
    
	
	COMMIT;
	return (xCont);
		
END sqlrep_autoIns4;
/

