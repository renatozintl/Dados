CREATE OR REPLACE FUNCTION sqlver_lista_b_tcp (cEnd_Ip in VARCHAR2, cLista IN OUT VARCHAR2, cIndLis IN OUT VARCHAR2) 
RETURN NUMBER IS
	nLaces  NUMBER;
      
BEGIN
	nLaces := 1;
	BEGIN
		SELECT LBenef, Ind_Lis into cLista, cIndLis FROM TermBenef
		WHERE End_Ip = cEnd_Ip;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN   -- linha procurada nao foi encontrado em TERMBENEF
			nLaces := 0;
		WHEN OTHERS THEN
			nLaces := 0;
	END;
	
	return (nLaces);
END sqlver_lista_b_tcp;
/
