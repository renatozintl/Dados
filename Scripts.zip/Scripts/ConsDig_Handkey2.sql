CREATE OR REPLACE FUNCTION sqlcon_handkey_tcp2 (cMatric VARCHAR2, cTipTerm VARCHAR2, cTempl_tit1tot IN OUT VARCHAR2) 
RETURN NUMBER IS

RetFun    NUMBER;
VarAux    VARCHAR2(12);
cVDigit    VARCHAR2(1);	
Alt NUMBER;
Pad NUMBER;

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);  -- erro quando registro lockado

BEGIN
	RetFun := 0;
	Pad := 0;
	Alt := 0;
	cVDigit := '2';		-- 1

	BEGIN
		SELECT 
			c.Templ_Tit1 INTO cTempl_tit1tot
		FROM CONTDIG c
		WHERE c.Icard = cMatric;
		
		Pad := 1;    -- assume que tem template padrao
		if ((cTempl_tit1tot is Null) or (length(cTempl_tit1tot) < 18) ) then
			Pad := 0;
		end if;
			
	EXCEPTION
		WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
			--RetFun := 3;
			IF (to_number(cVDigit) = 2) THEN
				RetFun := -2;
				--mensagem := 'Digital nao encontrado !! ';
			ELSE
				Pad := 0;
			END IF;				
		--	return (RetFun);
		WHEN OTHERS THEN              -- outros erros
			RetFun := -1;
			--mensagem := 'Outros erros encontrados!! Retorno = '|| TO_CHAR(RetFun);
			return (RetFun);
	END;
		
	if (Pad = 1) then
		Retfun := 0;   -- tem padrao 
	else
		Retfun := 3;   -- nao tem padrao
	end if;
	
	
	Return (RetFun);

END sqlcon_handkey_tcp2;
/
