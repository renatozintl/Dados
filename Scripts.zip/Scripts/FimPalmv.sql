CREATE or REPLACE FUNCTION sqlfim_LdigPalmv (cEndIp in VARCHAR2, cStatus in VARCHAR2) 
RETURN NUMBER IS

Ret NUMBER;
cAuxIp VARCHAR2(15);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

BEGIN

	Ret := 0;
	BEGIN
		SELECT END_CTRLPALMV into cAuxIp from PALMV004 
			WHERE END_CTRLPALMV = cEndIp FOR UPDATE NOWAIT;

		UPDATE PALMV004 set STATUS = cStatus
			WHERE END_CTRLPALMV = cEndIp;
			
		COMMIT;
			
	EXCEPTION
		WHEN NO_DATA_FOUND then 
			Ret := 0;
		WHEN reco_lock then
			Ret := -1;
		WHEN OTHERS then 
			Ret := -2;
				
	END;
	
	return (Ret);
END sqlfim_LdigPalmv;
/
