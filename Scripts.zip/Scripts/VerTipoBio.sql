CREATE OR REPLACE FUNCTION sqlver_tipobio (cEndIp IN VARCHAR2, cTipoBio IN OUT varchar2) 
   RETURN NUMBER IS
      RetFun NUMBER;
      reco_lock EXCEPTION;
      PRAGMA EXCEPTION_INIT (reco_lock, -54);  -- erro quando registro lockado 

BEGIN
	RetFun := 0;       -- assume matricula encontrada
	cTipoBio := '0';
	
	BEGIN
		SELECT BIO_TIPO into cTipoBio FROM DAT07
			WHERE END_IP = cEndIp and BLUEB = '00' and CODIN = '00';

		IF (cTipoBio is NULL) THEN
			cTipoBio := '0';     	
		END IF;
		
		RetFun := 1;       -- assume matricula encontrada
		
	EXCEPTION
		WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
			cTipoBio := '0';     	
			RetFun := 0;
		WHEN OTHERS THEN              -- outros erros
			cTipoBio := '0';     	
			RetFun := -1;
   END;
   return (RetFun);
END sqlver_tipobio;
/

