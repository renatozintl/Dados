-- ****************************************************************************
-- to_identif
-- ****************************************************************************

create or replace function to_identif 
  ( fn_identif in char ) return varchar2 deterministic is 

begin

  return (substr(fn_identif,5,2) || substr(fn_identif,3,2) || substr(fn_identif,1,2) || substr(fn_identif,7,8));

end to_identif ;
/
-- ****************************************************************************