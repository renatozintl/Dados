-- ****************************************************************************
--
-- Copyright (c) 2005, Telem�tica Sistemas Inteligentes.
--  
--    NAME
--      to_identif - Convert YYMMDDHH24MISSID  para DDMMYYHH24MISSID
--
--    VERSION <<< ORACLE >>>
--      1.0 - RN 
--
--    AUTHOR
--      Alex Siqueira (TSI)
--   
--    DESCRIPTION
--  
-- ****************************************************************************

create or replace function ret_identif 
  ( fn_identif in char ) return varchar2 deterministic is 

begin

  return (substr(fn_identif,5,2) || substr(fn_identif,3,2) || substr(fn_identif,1,2) || substr(fn_identif,7,8));

end ret_identif ;
/
-- ****************************************************************************