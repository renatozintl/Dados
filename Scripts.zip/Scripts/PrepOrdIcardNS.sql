CREATE OR REPLACE FUNCTION sqlprep_ordIcardNS (nTotal NUMBER, cLisMat CHAR, cEndIP VARCHAR2, cInicio VARCHAR2)   
RETURN NUMBER IS

Retfun NUMBER;
nCont NUMBER;
nContOK NUMBER;
nPos NUMBER;
cIcard CHAR(12);
cNumSerial CHAR(10);
cAuxIcardNS CHAR(22);
cTitular CHAR(12);
RetAux NUMBER;

BEGIN

	Retfun := 0;      -- assume que achou o icard
	RetAux := 0;      -- assume que nao ha erro em insercao na tab. de nomes
	
	--cLisIcardNS := '';		-- assume lista vazia de matriculas e numserial
	nCont := 0;
	nContOK := 0;
	
	IF (cInicio = '1') THEN 
		BEGIN
			DELETE ICARDNSAUX WHERE END_IP = cEndIp;
			
		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				RetAux := 0;
			WHEN OTHERS THEN
				RetAux := 0;
		END;
	END IF;

	
	WHILE ((nCont < nTotal) and (Retfun = 0)) LOOP
		nPos := (nCont * 12) + 1;
		cIcard := SUBSTR (cLisMat, nPos, 12);
		cNumSerial := '0000000000';

		BEGIN
			-- procura pelo ICARD 
			SELECT NUMSERIAL, TITULAR 
				INTO cNumSerial , cTitular 
			FROM CONTROLE WHERE (ICARD = cIcard);
		
			-- ACHOU O ICARD
			if (cNumSerial is Null) or (cNumSerial = '          ') then
				cNumSerial := '0000000000';
			end if;
			
			-- VERIFICA SE NUMERO SERIAL N�O DEFINIDO
			IF (cNumSerial = '0000000000') THEN
				-- SITUACAO SURICATO: VARIOS CARTOES SM COM MESMO ICARD, E NA CONTROLE ESTAO OS VALORES DE NUM.SERIAL NA COLUNA ICARD, TODOS COM O MESMO VALOR DO TITULAR
				-- A BUSCA PRIMEIRO SERA FEITA ICARD E ENVIAR SEU NUM.SERIAL. MAS SE O NUM.SERIAL FOR ZERADO, DEVE-SE CONSIDERAR O TITULAR COMO ICARD, E O ICARD COMO NUM.SERIAL
				if (cTitular is Null) or (cTitular =  '            ') then
					cTitular := '000000000000';
				end if;
				
				-- VERIFICA VALOR DO TITULAR
				IF (cTitular != '000000000000') THEN
					cNumSerial := substr(cIcard, 3, 10);		-- AS 10 ULTIMAS POSICOES DO ICARD SAO AGORA O NUMERO SERIAL
					cIcard := cTitular;							-- O TITULAR AGORA � O ICARD
				END IF;
			end if;				

			--cLisIcardNS := cLisIcardNS || cIcard || cNumSerial;
			nContOK := nContOK + 1;
			
			BEGIN
				SELECT ICARDNS into cAuxIcardNS
					FROM ICARDNSAUX WHERE END_IP = cEndIp and ICARDNS = (cIcard || cNumSerial);
					
			EXCEPTION
				WHEN NO_DATA_FOUND THEN 
					INSERT INTO ICARDNSAUX (END_IP, ICARDNS) VALUES 
						(cEndIp, cIcard||cNumSerial);		
					
				WHEN OTHERS THEN 
					Retfun := -1;
			END;
			

		EXCEPTION
			-- NAO ACHOU O ICARD 
			WHEN NO_DATA_FOUND THEN 
				--cErrMat := cIcard ;
				cNumSerial := '9999999999';
				
				BEGIN
					SELECT ICARDNS into cAuxIcardNS
						FROM ICARDNSAUX WHERE END_IP = cEndIp and ICARDNS = (cIcard || cNumSerial);
									
				EXCEPTION
					WHEN NO_DATA_FOUND THEN 
						INSERT INTO ICARDNSAUX (END_IP, ICARDNS) VALUES 
						(cEndIp, cIcard||cNumSerial);		
									
					WHEN OTHERS THEN 
						Retfun := -1;
				END;
			
				
				--cLisIcardNS := cLisIcardNS || cIcard || cNumSerial;
				nContOK := nContOK + 1;
				
			WHEN OTHERS THEN 
				--cErrMat := cIcard ;
				Retfun := -1;
		END;
		nCont := nCont + 1;

	END LOOP;

	COMMIT;
	
	if (Retfun < 0 ) then 
		return (Retfun);
	else
		return (nContOK);
	end if;
	
END sqlprep_ordIcardNS;
/


