CREATE OR REPLACE FUNCTION sqlbloco_backup_smart_tcp2 (Registro in VARCHAR2)
   RETURN NUMBER IS
      Ret NUMBER;

BEGIN
   INSERT INTO DAM01 (ICARD, DIAM, MESM, ANOM, HORAM, SEGUNDO, CODAC, POSIC, END_IP, CODFNC, 
		      NIVEL, FX_REF, CRED_FX, SITUA, QTD_MENS, VEICULO) 
	       VALUES (SUBSTR(Registro,  1, 12),
		       SUBSTR(Registro, 13,  2),
		       SUBSTR(Registro, 15,  2),
		       SUBSTR(Registro, 17,  2),
		       SUBSTR(Registro, 19,  4),
		       SUBSTR(Registro, 23,  2),
		       SUBSTR(Registro, 25,  2),
		       SUBSTR(Registro, 27,  1),
		       SUBSTR(Registro, 28,  15),
		       SUBSTR(Registro, 43,  2),
		       SUBSTR(Registro, 45,  2),
		       SUBSTR(Registro, 47,  2),
		       SUBSTR(Registro, 49,  2),
		       SUBSTR(Registro, 51,  2),
		       SUBSTR(Registro, 53,  2),
		       SUBSTR(Registro, 55,  15));
   Return (0);
END sqlbloco_backup_smart_tcp2;
/


