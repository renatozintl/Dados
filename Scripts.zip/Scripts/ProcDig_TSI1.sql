CREATE OR REPLACE FUNCTION sqlproc_digitTSI1 (cMatric VARCHAR2, cTipTerm VARCHAR2, cEndIp VARCHAR2, 
cTempl_tit1tot IN OUT VARCHAR2, cTempl_tit2tot IN OUT VARCHAR2, 
cTempl_tit3tot IN OUT VARCHAR2, cTempl_tit4tot IN OUT VARCHAR2, 
cTempl_Alt1tot IN OUT VARCHAR2, cTempl_Alt2tot IN OUT VARCHAR2, 
cTempl_Alt3tot IN OUT VARCHAR2, cTempl_Alt4tot IN OUT VARCHAR2, 
cTempl_tit5tot IN OUT VARCHAR2, cTempl_Alt5tot IN OUT VARCHAR2, 
cTempl_tit6tot IN OUT VARCHAR2, cTempl_Alt6tot IN OUT VARCHAR2) 
RETURN NUMBER IS

RetFun    NUMBER;
Alt NUMBER;
Pad NUMBER;
cTempl_tit5Aux VARCHAR2(128);
cTempl_alt5Aux VARCHAR2(128);

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);  -- erro quando registro lockado

BEGIN
	RetFun := 0;
	Pad := 0;
	Alt := 0;
	
	BEGIN
		SELECT 
			c.Templ_Tit1, c.Templ_Tit2, c.Templ_Tit3, c.Templ_Tit4, c.Templ_Tit5, 
			c.Templ_Alt1, c.Templ_Alt2, c.Templ_Alt3, c.Templ_Alt4, c.Templ_Alt5
		INTO 
			cTempl_tit1tot, cTempl_tit2tot, cTempl_tit3tot, cTempl_tit4tot, cTempl_tit5Aux, 
			cTempl_alt1tot, cTempl_alt2tot, cTempl_alt3tot, cTempl_alt4tot, cTempl_alt5Aux
		FROM CONTDIG_TSI1 c 
		WHERE c.Icard = cMatric;
			
		Pad := 1;    -- assume que tem template padrao
		Alt := 1;    -- assume que tem template alternativo
		if ((cTempl_tit1tot is Null) or (cTempl_tit2tot is Null) or 
			(cTempl_tit3tot is Null) or (cTempl_tit4tot is Null) or 
			(cTempl_tit5Aux is Null) OR
			(length(cTempl_tit1tot) < 160) or (length(cTempl_tit2tot) < 160) or
			(length(cTempl_tit3tot) < 160) or (length(cTempl_tit4tot) < 160) or 
			(length(cTempl_tit5Aux) < 128)) then
			Pad := 0;
		end if;

		if (length(cTempl_tit5Aux) = 128) then
			cTempl_tit5tot := RPAD(cTempl_tit5Aux, 160, '0');
			cTempl_tit6tot := RPAD('0', 26, '0');
		end if;

		if ((cTempl_alt1tot is Null) or (cTempl_alt2tot is Null) or
			(cTempl_alt3tot is Null) or (cTempl_alt4tot is Null) or 
			(cTempl_alt5Aux is Null) or
			(length(cTempl_alt1tot) < 160) or (length(cTempl_alt2tot) < 160) or
			(length(cTempl_alt3tot) < 160) or (length(cTempl_alt4tot) < 160) or 
			(length(cTempl_alt5Aux) < 128)) then 
			Alt := 0;
		end if;

		if (length(cTempl_alt5Aux) = 128) then
			cTempl_alt5tot := RPAD(cTempl_alt5Aux, 160, '0');
			cTempl_alt6tot := RPAD('0', 26, '0');
		end if;
			
	EXCEPTION
		WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
			Pad := 0;
			Alt := 0;
		WHEN OTHERS THEN              -- outros erros
			RetFun := -1;
			return (RetFun);
	END;
		
	if (Pad = 1) then
	    if (Alt = 1) then
			Retfun := 0;   -- tem padrao e tem alternativo
		else 
			Retfun := 1;   -- tem padrao e nao tem alternativo
    	end if;
	end if;

	if (Pad = 0) then
	    if (Alt = 1) then
			Retfun := 2;   -- nao tem padrao e tem alternativo
		else 
			Retfun := 3;   -- nao tem padrao e nao tem alternativo
    	end if;
	end if;

	IF (Retfun = 3) then
		-- insere em tabela DIGLOAD001
		INSERT INTO DIGLOAD001 (END_IP, ICARD, BIO_TIPO) 
			VALUES (cEndIp, cMatric, cTipTerm);
		COMMIT;
	END IF;

	Return (RetFun);

END sqlproc_digitTSI1;
/
