grant execute on G3G5_PREP4_TSI1 to ACE_USU
grant execute on sqlAtuCont512_bdcc to ACE_USU
