

DROP SYNONYM SITENTRADA;
CREATE SYNONYM SITENTRADA FOR cp_telemat.SITENTRADA;

DROP SYNONYM SITCOLETOR;
CREATE SYNONYM SITCOLETOR FOR cp_telemat.SITCOLETOR;

drop synonym CP_NB;
CREATE SYNONYM CP_NB FOR cp_telemat.CP_NB;

drop synonym CONTDIG_OMOK;
CREATE SYNONYM CONTDIG_OMOK FOR cp_telemat.CONTDIG_OMOK;

DROP SYNONYM PEND_ON002ON;
CREATE SYNONYM PEND_ON002ON FOR cp_telemat.PEND_ON002ON;

DROP SYNONYM PEND_ON002OFF;
CREATE SYNONYM PEND_ON002OFF FOR cp_telemat.PEND_ON002OFF;

DROP SYNONYM PEND_ON002LPZ;
CREATE SYNONYM PEND_ON002LPZ FOR cp_telemat.PEND_ON002LPZ;

drop synonym DIG002;
CREATE SYNONYM DIG002 FOR cp_telemat.DIG002;

drop synonym DIG102;
CREATE SYNONYM DIG102 FOR cp_telemat.DIG102;

drop synonym PALMV004;
create synonym PALMV004 for cp_telemat.PALMV004;

drop synonym PALMV005;
create synonym PALMV005 for cp_telemat.PALMV005;

drop synonym DAT07;
create synonym DAT07 for cp_telemat.DAT07;


--
drop synonym sqlget_sodata;
CREATE SYNONYM sqlget_sodata FOR cp_telemat.sqlget_sodata;

drop synonym sqlentrada_codin;
create synonym sqlentrada_codin for cp_telemat.sqlentrada_codin;

drop synonym sqlget_dh;
create synonym sqlget_dh for cp_telemat.sqlget_dh;

drop synonym sqlsit_coletor;
create synonym sqlsit_coletor for cp_telemat.sqlsit_coletor;

drop synonym sqlident_conex;
create synonym sqlident_conex for cp_telemat.sqlident_conex;

--
DROP SYNONYM G3G5_PREP4_SAGEM;
CREATE SYNONYM G3G5_PREP4_SAGEM FOR cp_telemat.G3G5_PREP4_SAGEM;

DROP SYNONYM G3G5_PREP4_TSI1;
CREATE SYNONYM G3G5_PREP4_TSI1 FOR cp_telemat.G3G5_PREP4_TSI1;

DROP SYNONYM G3G5_Prep3_Palmv;
CREATE SYNONYM G3G5_Prep3_Palmv FOR cp_telemat.G3G5_Prep3_Palmv;

DROP SYNONYM PREP3_OUTROSBIOS;
CREATE SYNONYM PREP3_OUTROSBIOS FOR cp_telemat.PREP3_OUTROSBIOS;

drop synonym trata4_sagem;
create synonym trata4_sagem  for cp_telemat.trata4_sagem;

drop synonym trata4_tsi1;
create synonym trata4_tsi1 for cp_telemat.trata4_tsi1;

DROP SYNONYM trata3_palmv;
CREATE SYNONYM trata3_palmv FOR cp_telemat.trata3_palmv;

drop synonym trata_OutrosBios;
create synonym trata_OutrosBios for cp_telemat.trata_OutrosBios;

DROP SYNONYM G3G5_P_GERDIGITAL6;
CREATE SYNONYM G3G5_P_GERDIGITAL6 FOR cp_telemat.G3G5_P_GERDIGITAL6;

drop synonym sqlhora_gerbio;
CREATE SYNONYM SQLHORA_GERBIO  FOR cp_telemat.SQLHORA_GERBIO;

DROP SYNONYM sqlget_dhNowFut;
CREATE SYNONYM sqlget_dhNowFut FOR cp_telemat.sqlget_dhNowFut;

DROP SYNONYM sqlexiste_tabela;
CREATE SYNONYM sqlexiste_tabela FOR cp_telemat.sqlexiste_tabela;

DROP SYNONYM sqlgrava_apoc;
CREATE SYNONYM sqlgrava_apoc FOR cp_telemat.sqlgrava_apoc;

DROP SYNONYM sqlle_apoc2;
CREATE SYNONYM sqlle_apoc2 FOR cp_telemat.sqlle_apoc2;






