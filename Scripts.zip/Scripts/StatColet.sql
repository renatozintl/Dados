CREATE OR REPLACE PROCEDURE sqlat_StatColetor as

Begin
	Update SITCOLETOR set Status = '0' 
	    where (((sysdate-dt_atuali)*24*60*60 ) >= 90) and
	    		(status = '1');

	Update SITCOLETOR set Status = '1' 
	    where (((sysdate-dt_atuali)*24*60*60 ) < 90) and
	    		(status = '0');

	commit;
END sqlat_StatColetor;
/