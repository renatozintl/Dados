-- ESTA AUXILIAR DA TRIGGER (INSERT/UPDATE/DELETE) DA TAB. REPEMPR002
-- INSERIR� NA TAB.REPNAUTO000, A MATRICULA COM OS GRUPOS AOS QUAIS PERTENCEM, COM STATUS DE INCLUS�O('3') OU EXCLUS�O('8')

CREATE OR REPLACE PROCEDURE Auxtrg_repFunc2 (cFunc in CHAR, cNovoStatus in CHAR, cDocTipo in CHAR) IS

Aux CHAR(1);
cVelhoStat CHAR(1);
cAuxDocTipo CHAR(1);

CURSOR cur_auto000 IS select GRUPO from REPGRPF WHERE IFUNC = cFunc;

BEGIN

	IF (cNovoStatus = '3') THEN 		-- FUNCION�RIO FOI INSERIDO OU ATUALIZADO NA TAB.REPEMPR002
		cVelhoStat := '8';
	
	ELSE								-- FUNCION�RIO FOI EXCLUIDO DA TAB.REPEMPR002
		cVelhoStat := '3';
	END IF;	

	for r in cur_auto000 
	LOOP
		BEGIN
			SELECT STATUS, DOC_TIPO into Aux, cAuxDocTipo FROM REPNAUTO000 
				WHERE REPNAUTO000.IFUNC = cFunc and 
					to_number(REPNAUTO000.GRUPO) = to_number(r.Grupo);
			
			-- verifica se est� na tabela para ainda ser processado para INCLUSAO OU EXCLUSAO OU SE J� SOFREU O PROCESSAMENTO
			IF (Aux = cVelhoStat OR Aux = '0') then 
				-- como ainda est� para ser incluido (OU excluido), altera para status de exclusao (OU inclusao), atualizando a data
				UPDATE REPNAUTO000 SET STATUS = cNovoStatus , DATA_INS = SYSDATE , DOC_TIPO = cDocTipo 
					WHERE REPNAUTO000.IFUNC = cFunc and 
						to_number(REPNAUTO000.GRUPO) = to_number(r.Grupo);
						
			ELSE
				IF (cNovoStatus = '3') THEN			-- HOUVE ALTERACAO EM CARGA FUNCIONARIO
					IF (cAuxDocTipo <> cDocTipo) THEN		-- VERIFICA SE O EXISTENTE � DIFERENTE DO QUE EST� CHEGANDO, EX: TINHA ALTERA��O DE PIS, CHEGOU ALTERACAO DE CPF OU TUDO
						UPDATE REPNAUTO000 SET STATUS = cNovoStatus , DATA_INS = SYSDATE , DOC_TIPO = cDocTipo 
							WHERE REPNAUTO000.IFUNC = cFunc and 
							to_number(REPNAUTO000.GRUPO) = to_number(r.Grupo);
					END IF;		-- CASO JA EXISTA O MESMO TIPO DE ALTERA��O, NADA FAZ
				END IF;
			END IF;
			
		EXCEPTION
			WHEN NO_DATA_FOUND then
				-- como nao existe, inserir� na tab.REPNAUTO000, a matricula com o grupo ao qual pertence, com status de inclusao ou exclus�o (cNovoStatus)
				INSERT INTO REPNAUTO000 (IFUNC, STATUS, GRUPO, DOC_TIPO) 
								VALUES  (cFunc, cNovoStatus, r.Grupo, cDocTipo);

			WHEN OTHERS then NULL;
		END;
	END LOOP;

END Auxtrg_repFunc2;	
/


