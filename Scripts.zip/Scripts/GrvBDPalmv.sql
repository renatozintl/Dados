
CREATE OR REPLACE FUNCTION sqlGravaBD_PalmVein (mat in CHAR, cdados in BLOB, tam in number, nTipo in number)
   RETURN NUMBER IS

cAuxMat CHAR(12);
lob_palmvp BLOB;
lob_palmva BLOB;
reco_lock EXCEPTION;
tam_erase NUMBER;
PRAGMA EXCEPTION_INIT (reco_lock,-54);  -- erro quando registro lockado 


BEGIN
	IF (nTipo = 0) THEN			-- PADRAO
		begin
			SELECT TEMPL_PAD INTO lob_palmvp FROM PALMV001 
				WHERE ICARD = mat FOR UPDATE NOWAIT;

			tam_erase := DBMS_LOB.GETLENGTH (lob_palmvp);
			if (tam_erase > tam) then
				DBMS_LOB.ERASE (lob_palmvp, tam_erase, 1);
			end if;
				
			DBMS_LOB.WRITE(lob_palmvp, tam, 1, cdados);	
			update palmv001 set st = '1' WHERE ICARD = mat;

		exception
			when NO_DATA_FOUND then	
				INSERT INTO PALMV001 (icard, TEMPL_PAD, TEMPL_ALT)
					VALUES (mat, empty_BLOB(), empty_BLOB())
					RETURNING ICARD, TEMPL_PAD, TEMPL_ALT INTO cAuxMat, lob_palmvp, lob_palmva;

				DBMS_LOB.WRITE(lob_palmvp, tam, 1, cdados);
				update palmv001 set st = '1' WHERE ICARD = mat;

	
			when OTHERS then 
				return (0);
		end;
	ELSE					-- ALTERNATIVO
		begin
			SELECT TEMPL_ALT INTO lob_palmva FROM PALMV001 
				WHERE ICARD = mat FOR UPDATE NOWAIT;

			tam_erase := DBMS_LOB.GETLENGTH (lob_palmva);
			IF (tam_erase > tam) then
				DBMS_LOB.ERASE (lob_palmva, tam_erase, 1);
			END IF;

			DBMS_LOB.WRITE(lob_palmva, tam, 1, cdados);	
			update palmv001 set st = '1' WHERE ICARD = mat;

		exception
			when NO_DATA_FOUND then	
				INSERT INTO PALMV001 (icard, TEMPL_PAD, TEMPL_ALT)
					VALUES (mat, empty_BLOB(), empty_BLOB())
					RETURNING ICARD, TEMPL_PAD, TEMPL_ALT INTO cAuxMat, lob_palmvp, lob_palmva;

				DBMS_LOB.WRITE(lob_palmva, tam, 1, cdados);
				update palmv001 set st = '1' WHERE ICARD = mat;
	
			when OTHERS then 
				return (0);
		end;
	END IF;
	
	COMMIT;    
    return (1);

END sqlGravaBD_PalmVein;
/
