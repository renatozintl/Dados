CREATE OR REPLACE PROCEDURE sqlgrava_rep3interj (NumRep in VARCHAR2, Registro in VARCHAR2, cEndIp in VARCHAR2, cInterj in NUMBER) IS
	
Nsr CHAR(9);
TipoReg CHAR(1);

cAuxPis VARCHAR2(12);
cAuxDta VARCHAR2(12);

BEGIN
	
	Nsr := SUBSTR (Registro, 1, 9);	
	TipoReg := SUBSTR (Registro, 10, 1);	
	
	if TipoReg not IN ('1', '2', '3', '4', '5', '9') then
		INSERT INTO REPAFD004 
			(END_IP, REP, NSR, TIPO_REG, STATUS, INFORM) VALUES
			(cEndIp, NumRep, Nsr, TipoReg, '0', Registro);
	else
		BEGIN
			INSERT INTO REPAFD001 
				(END_IP, REP, NSR, TIPO_REG, STATUS, INFORM) VALUES
				(cEndIp, NumRep, Nsr, TipoReg, '0', Registro);
		EXCEPTION
			WHEN PROGRAM_ERROR THEN
				INSERT INTO REPAFD004 
					(END_IP, REP, NSR, TIPO_REG, STATUS, INFORM) VALUES
					(cEndIp, NumRep, Nsr, TipoReg, '0', Registro);
			WHEN OTHERS THEN
				INSERT INTO REPAFD004 
					(END_IP, REP, NSR, TIPO_REG, STATUS, INFORM) VALUES
					(cEndIp, NumRep, Nsr, TipoReg, '0', Registro);
		END;			

		IF (TipoReg = '3') then
			INSERT INTO REPAFD003 
				(END_IP, REP, NSR, TIPO_REG, STATUS, INFORM) VALUES
				(cEndIp, NumRep, Nsr, TipoReg, '0', Registro);
	
			-- para Controle de Acesso Interjornada
			IF (cInterj = 1) or (cInterj = 2) THEN 
				cAuxPis := SUBSTR (Registro, 23, 12);		-- pis
				cAuxDta := SUBSTR (Registro, 11, 12);		-- ddmmyyyyhhmi
				 sqlrepPto_interj (cAuxPis, cAuxDta);
			END IF;

		END IF;	
	end if;
	
	
END sqlgrava_rep3interj;
/
