if object_id('sqlbloco_col_dam00_new4', 'p') is null
    exec ('create procedure sqlbloco_col_dam00_new4 as select 1')
go

ALTER PROCEDURE sqlbloco_col_dam00_new4 @Registro CHAR(110), @cTipo char(1), @cTipoRepP INT, @nTipoNR36 INT, @cTitular CHAR(12)
AS
DECLARE @ret int,
@C1 char(12), @C2 char(2), @C3 char(2), 
@C4 char(2), @C5 char(4), @C6 char(2), 
@C7 char(2), @C8 char(1), @C9 char(15), 
@C10 char(2), @C11 char(1), @C12 char(15), 
@C13 char(2),
@C14 char(10), @C15 char(10) ,
@C16 CHAR (6), @C17 char(7), @C18 char(7), @C19 char(2), @C20 CHAR(1),
@dDatOcor DATETIME	;

set ansi_warnings on
set ansi_padding on
set ansi_nulls on
set concat_null_yields_null on

	set DATEFORMAT ymd

	SET @ret = 0
	SET @C1 = SUBSTRING(@Registro, 1, 12)  -- ICARD
	SET @C2 = SUBSTRING(@Registro, 13, 2)	--diam
	SET @C3 = SUBSTRING(@Registro, 15, 2)	--mesm
	SET @C4 = SUBSTRING(@Registro, 17, 2)	--anom
	SET @C5 = SUBSTRING(@Registro, 19, 4)	--horam
	SET @C6 = SUBSTRING(@Registro, 23, 2)	--segundo
	SET @C7 = SUBSTRING(@Registro, 25, 2)	--codac
	SET @C8 = SUBSTRING(@Registro, 27, 1)	--posic
	SET @C9 = SUBSTRING(@Registro, 28, 15)	--end_ip
	SET @C10 = SUBSTRING(@Registro, 43, 2) 	--codfnc
	SET @C11 = SUBSTRING(@Registro, 45, 1) 	--onoff
	SET @C12 = SUBSTRING(@Registro, 46, 15)	--veiculo
	SET @C13 = SUBSTRING(@Registro, 61, 2)	--tipodoc
	SET @C14 = SUBSTRING(@Registro, 63, 10)	--ns_icard
	SET @C15 = SUBSTRING(@Registro, 73, 10)	--ns_veic
	SET @C16 = SUBSTRING(@Registro, 83, 6)	--peso
	SET @C17 = SUBSTRING(@Registro, 89, 7)	--valkilo
	SET @C18 = SUBSTRING(@Registro, 96, 7)	--valor
	SET @C19 = SUBSTRING(@Registro, 103, 2)	--qtde
	SET @C20 = SUBSTRING(@Registro, 105, 1)	--BIO1N 

	INSERT INTO DAM00 (ICARD, DIAM, MESM, ANOM, HORAM, SEGUNDO,CODAC, POSIC, END_IP, CODFNC, 
						ONOFF, VEICULO, TIPODOC, ICARD_NS, VEICULO_NS, BIO1N)
			VALUES (@C1, @C2, @C3, @C4, @C5, @C6, @C7, @C8, @C9, @C10, 
					@C11, @C12, @C13, @C14, @C15, @C20)
					
	IF ((@cTipoRepP = 1) and (@C7 = '01')) 
		INSERT INTO DAM00REPP (ICARD, DIAM, MESM, ANOM, HORAM, SEGUNDO,CODAC, POSIC, END_IP, CODFNC, ONOFF) 
					values (@C1, @C2, @C3, @C4, @C5, @C6, @C7, @C8, @C9, @C10, @C11);
				
				
	IF ((@nTipoNR36 = 1) and (@C7 = '01')) 
	BEGIN
		
		--SET @dDatOcor = CAST((@C2+'-'+@C3+'-'+@C4+' '+						-- formato dmy, pode dar problema no suricato em versoes anteriores, entao optou-se para format ymd
		SET @dDatOcor = CAST((@C4+'-'+@C3+'-'+@C2+' '+							-- formato ymd
		   				      substring(@C5,1,2)+':'+ substring(@C5,3,2)+':'+@C6) 
		   				      AS datetime);
   	
		INSERT INTO DAM00NR36 (ICARD, DATA_OCORR, POSIC, END_IP, ONOFF) 
					values (@cTitular, @dDatOcor, @C8, @C9, @C11);
	END
				
   
	SELECT @ret
	GO





