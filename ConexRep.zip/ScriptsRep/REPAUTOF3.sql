CREATE OR REPLACE  FUNCTION  SQL_REPAUTOF3 
RETURN NUMBER IS

ret number ;
cAuxSt char(1);
nInfo NUMBER;
nParado NUMBER;

BEGIN

	ret := 0;
	nInfo := 0;

	
    BEGIN
		select 1 INTO nInfo from REPNAUTO000 WHERE STATUS <> '0' AND ROWNUM = 1;
		ret := 0;
		
	
	EXCEPTION
		
		WHEN NO_DATA_FOUND THEN
		
			-- ********************   ARRUMAR SITUA��ES PARA   INCLUSAO
			-- ********************************
			-- VERIFICA SE HA FUNCIONARIOS A SEREM CARREGADOS EM REPAUTO011 MAS O EQUIPAMENTO N�O EST� SINALIZADO EM REPAUTO001
			-- ***********************  			
			for r in 
			(
				select distinct END_IP from REPAUTO011 A 
					where (status != '0' and status != '2' and status != '4') and					-- '4' = para resposta de nao implementado
						  (A.END_IP  NOT IN (SELECT END_IP FROM REPAUTO001 WHERE STATUS = '1') )
			) 
			LOOP		
				BEGIN
					SELECT status into cAuxSt FROM REPAUTO001 WHERE END_IP = r.end_ip FOR UPDATE NOWAIT;

					UPDATE REPAUTO001 set status = '1'
						WHERE (end_ip = r.end_ip and (status = '0' or status = '3' or status = '4'));		-- '4' = para resposta de nao implementado

				EXCEPTION
					WHEN NO_DATA_FOUND THEN
						insert into REPAUTO001 (END_IP, STATUS) VALUES (r.end_ip, '1');
					WHEN OTHERS THEN NULL;
				END;
			END LOOP;

			COMMIT;


			-- ********************************
			-- VERIFICA SE H� EQUIPAMENTOS DE REPAUTO001 COM STATUS '2' PARADOS
			-- ***********************  			
			for r in 
			(	
				select distinct END_IP from REPAUTO001 where status = '2' and data_load + ( 4 / 24 / 60 )  < sysdate			-- 4 MINUTOS
			) 
			LOOP
				BEGIN
					SELECT status into cAuxSt FROM REPAUTO011 WHERE (end_ip = r.end_ip and status = '2') FOR UPDATE NOWAIT;
					UPDATE REPAUTO011 set status = '1'
						WHERE (end_ip = r.end_ip and status = '2');

				EXCEPTION
					WHEN NO_DATA_FOUND THEN NULL;
					WHEN OTHERS THEN NULL;

				END;
				
				BEGIN
					SELECT status into cAuxSt FROM REPAUTO001
						where end_ip = r.end_ip and status = '2' and data_load + ( 4 / 24 / 60 )  < sysdate FOR UPDATE NOWAIT; 		-- 4 MINUTOS
						
					UPDATE REPAUTO001 set status = '1' 
						where end_ip = r.end_ip and status = '2' and data_load + ( 4 / 24 / 60 )  < sysdate; 		-- 4 MINUTOS

				EXCEPTION
					WHEN NO_DATA_FOUND THEN NULL;
					WHEN OTHERS THEN NULL;

				END;
			END LOOP;
			
			COMMIT;


			-- **********************  NOVO
			-- TRATA AS MATRICULAS QUE FICARAM EM ESTADO DE CARREGANDO E NAO SAI DESTA SITUA��O pois o equipamento est� em estado de repouso
			-- ***********************  
			for r in 
			(	
				select A.IFUNC, A.END_IP 
					from REPAUTO011 A INNER JOIN 
						 REPAUTO001 B
					ON A.END_IP = B.END_IP and 
					   A.STATUS = '2' and 
					   B.STATUS = '0' and
					   (B.DATA_LOAD + ( 4 / 24 / 60 )  < sysdate )
			) 
			LOOP

				BEGIN				
					SELECT status into cAuxSt from REPAUTO011 where IFUNC = r.ifunc and END_IP = r.end_ip and STATUS = '2'  FOR UPDATE NOWAIT;
					
					-- a carga foi finalizada, mas nao foi atualizado o status
					UPDATE REPAUTO011 set STATUS = '1'					-- com novo REPAUTO011.STATUS = '1', REENVIAR� A CARGA
						WHERE (IFUNC = r.ifunc and END_IP = r.end_ip and STATUS = '2');
				
				EXCEPTION
					WHEN NO_DATA_FOUND THEN null;
					WHEN OTHERS THEN null;
				END;						
				
			END loop;
			
			COMMIT;

			-- **********************  NOVO
			-- TRATA AS MATRICULAS QUE FICARAM EM ESTADO DE FOI ENVIADO, MAS FOI REJEITADO (STATUS '4') POR NAO IMPLEMENTADO E NAOP SERAO REENVIADAS AUTOMATICAMENTE
			-- ***********************  
			for r in 
			(	
				select IFUNC, END_IP 
					FROM  REPAUTO011 
					WHERE STATUS = '4'  
			) 
			LOOP

				BEGIN				
					SELECT status into cAuxSt from REPAUTO011 WHERE IFUNC = r.ifunc and END_IP = r.end_ip and STATUS = '4'  FOR UPDATE NOWAIT;
					
					-- a carga foi REJEITADA COMO NAO IMPELEMNTADO, ENTAO P�RA O REENVIO
					UPDATE REPAUTO011 set STATUS = '0'					-- com novo REPAUTO011.STATUS = '0', NAO REENVIAR� A CARGA
						WHERE (IFUNC = r.ifunc and END_IP = r.end_ip and STATUS = '4');
				
				EXCEPTION
					WHEN NO_DATA_FOUND THEN null;
					WHEN OTHERS THEN null;
				END;						
				
			END loop;

			COMMIT;





			-- ********************   ARRUMAR SITUA��ES PARA   EXCLUSAO
			-- ********************************
			-- VERIFICA SE HA FUNCIONARIOS A SEREM EXCLUIDOS EM REPAUTO012 MAS O EQUIPAMENTO N�O EST� SINALIZADO EM REPAUTO002
			-- ********************************						
			
			-- VERIFICA SE HA FUNCIONARIOS A SEREM EXCLUIDOS
			for r in 
			(
				select distinct END_IP from REPAUTO012 A 
					where (status != '0' and status != '2' and status != '4' ) and
						  (A.END_IP  NOT IN (SELECT END_IP FROM REPAUTO002 WHERE STATUS = '1') )
			)
			LOOP
				BEGIN
					SELECT status into cAuxSt FROM REPAUTO002 WHERE END_IP = r.end_ip;

					UPDATE REPAUTO002 set status = '1'
						WHERE (end_ip = r.end_ip and (status = '0' or status = '3' or status = '4'));		-- '4' = para resposta de nao implementado

				EXCEPTION
					WHEN NO_DATA_FOUND THEN
						insert into REPAUTO002 (END_IP, STATUS) VALUES (r.end_ip, '1');
					WHEN OTHERS THEN 
						NULL;
				END;
			END LOOP;

			COMMIT;


			-- ********************************
			-- VERIFICA SE H� EQUIPAMENTOS DE REPAUTO002 COM STATUS '2' PARADOS
			-- ***********************  			
			for r in 
			(
				select distinct END_IP from REPAUTO002 where status = '2' and data_load + ( 4 / 24 / 60 )  < sysdate
			) 
			LOOP
				BEGIN
					SELECT status into cAuxSt FROM REPAUTO012 WHERE (end_ip = r.end_ip and status = '2') FOR UPDATE NOWAIT;		
			
					UPDATE REPAUTO012 set status = '1'
						WHERE (END_IP = r.end_ip and STATUS = '2');

				EXCEPTION
					WHEN NO_DATA_FOUND THEN NULL;
					WHEN OTHERS THEN NULL;
				END;

				
				BEGIN
					SELECT status into cAuxSt FROM REPAUTO002
						where end_ip = r.end_ip and status = '2' and data_load + ( 4 / 24 / 60 )  < sysdate FOR UPDATE NOWAIT; 		-- 4 MINUTOS

					UPDATE REPAUTO002 set status = '1' 
						where end_ip = r.end_ip and status = '2' and data_load + ( 4 / 24 / 60 )  < sysdate; 

				EXCEPTION
					WHEN NO_DATA_FOUND THEN NULL;
					WHEN OTHERS THEN NULL;

				END;
			END LOOP;
			
			COMMIT;


			-- **********************  NOVO
			-- TRATA AS MATRICULAS QUE FICARAM EM ESTADO DE EXCLUINDO E NAO SAI DESTA SITUA��O pois o equipamento est� em estado de repouso
			-- ***********************  
			for r in 
			(	
				select A.IFUNC, A.END_IP 
					from REPAUTO012 A INNER JOIN 
						 REPAUTO002 B
					ON A.END_IP = B.END_IP and 
					   A.STATUS = '2' and 
					   B.STATUS = '0' and
					   (B.DATA_LOAD + ( 4 / 24 / 60 )  < sysdate )
			) 
			LOOP
				BEGIN				
					SELECT status into cAuxSt from REPAUTO012 where IFUNC = r.ifunc and END_IP = r.end_ip and STATUS = '2'  FOR UPDATE NOWAIT;
					
					-- a carga foi finalizada, mas nao foi atualizado o status
					UPDATE REPAUTO012 set STATUS = '1'					-- com novo REPAUTO012.STATUS = '1', REENVIAR� A EXCLUSAO
						WHERE (IFUNC = r.ifunc and END_IP = r.end_ip and STATUS = '2');
				
				EXCEPTION
					WHEN NO_DATA_FOUND THEN null;
					WHEN OTHERS THEN null;
				END;						
				
			END LOOP;

			COMMIT;


			
			-- **********************  NOVO
			-- TRATA AS MATRICULAS QUE FICARAM EM ESTADO DE FOI ENVIADO A EXCLUSAO, MAS FOI REJEITADO (STATUS '4') POR NAO IMPLEMENTADO E NAOP SERAO REENVIADAS A EXCLUSAO AUTOMATICAMENTE
			-- ***********************  
			for r in 
			(	
				select IFUNC, END_IP 
					FROM  REPAUTO012 
					WHERE STATUS = '4'  
			) 
			LOOP

				BEGIN				
					SELECT status into cAuxSt from REPAUTO012 WHERE IFUNC = r.ifunc and END_IP = r.end_ip and STATUS = '4'  FOR UPDATE NOWAIT;
					
					-- a carga foi REJEITADA COMO NAO IMPELEMNTADO, ENTAO P�RA O REENVIO
					UPDATE REPAUTO012 set STATUS = '0'					-- com novo REPAUTO012.STATUS = '0', NAO REENVIAR� A EXCLUSAO
						WHERE (IFUNC = r.ifunc and END_IP = r.end_ip and STATUS = '4');
				
				EXCEPTION
					WHEN NO_DATA_FOUND THEN null;
					WHEN OTHERS THEN null;
				END;						
				
			END loop;

			COMMIT;

			ret := 1;
		
	WHEN OTHERS THEN
		ret := 0; 
		
	END;
	
	return (ret);

end SQL_REPAUTOF3 ;
/
