CREATE OR REPLACE FUNCTION sqlle_IcardNSOrd (cEndIp VARCHAR2, nTotal NUMBER, cUltIcardNS VARCHAR2, cLisIcardNS IN OUT VARCHAR2)   
RETURN NUMBER IS

nCont NUMBER;
XIcNs CHAR(22);

cursor CURSOR_ICARDNS is
select ICARDNS 
  from
( select *
    from ICARDNSAUX WHERE END_IP = cEndIp  AND ICARDNS > cUltIcardNS 
   order by ICARDNS )
 where ROWNUM <= nTotal;   



BEGIN

	cLisIcardNS := '';		-- assume lista vazia de matriculas e numserial
	nCont := 0;
	OPEN CURSOR_ICARDNS;
	LOOP
		FETCH CURSOR_ICARDNS  INTO XIcNs;
		EXIT WHEN CURSOR_ICARDNS%NOTFOUND;
	
		cLisIcardNS := cLisIcardNS || XIcNs;
		nCont := nCont+1;
	END LOOP;
    close CURSOR_ICARDNS;	
	

	
	return (nCont);
	
END sqlle_IcardNSOrd;
/


