CREATE or REPLACE FUNCTION sqlatu_geral4(cEndIp in VARCHAR2, pt_aviso in VARCHAR2, cTipo in VARCHAR2, cData in VARCHAR2)
RETURN NUMBER IS

cStatus VARCHAR2(1);
cAviso VARCHAR2(2);
cMens  VARCHAR2(30);
cAux   VARCHAR2(1);
dData  DATE;

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);
nRet1 number;
nRet2 number;
nRet3 number;
nRet4 number;
nRet5 number;
nRet6 number;
nRet7 number;
begin


	nRet1 := 0;

	-- ATUALIZA CP_BN
	nRet2 := 0;
	cAviso := SUBSTR(pt_aviso, 16,2);
	cStatus:= SUBSTR(pt_aviso, 18,1);
	cMens  := SUBSTR(pt_aviso, 19,30);

	BEGIN
		select ST into cAux 
			from CP_BN 
			where AVISO = cAviso and
              	  END_IP = cEndIp
			for update nowait; 

	EXCEPTION
		WHEN reco_lock then nRet2 := -1;
      	WHEN NO_DATA_FOUND then nRet2 := 1;
      	WHEN OTHERS then nRet2 := -1;
	END;

	if (nRet2 = 0) then            -- aviso existe, substitui aviso 
		update 	CP_BN set ST = cStatus, 
				EPN3 = cMens 
		where AVISO = cAviso AND
              END_IP = cEndIp;

	elsif (nRet2 = 1) then       
		-- aviso nao existe, sera' inserido novo comando
		insert into CP_BN (END_IP, AVISO, ST, EPN3) 
			values (cEndIp, cAviso, cStatus, cMens);          
	end if;


	COMMIT;

	if (nRet2 = -1) then
		return (-1);
	else
		return (0);
	end if;

END sqlatu_geral4;
/
