CREATE OR REPLACE FUNCTION sqlConsCont512_bdcc (cMatric VARCHAR2, nMaxMes NUMBER, nMaxAno NUMBER, cDataOcor VARCHAR2, nBloqMes OUT NUMBER, nBloqAno OUT NUMBER) 
RETURN NUMBER IS
Ret  NUMBER;
nContMes NUMBER;
nContAno NUMBER;
cMesAno VARCHAR(4);
cAno VARCHAR(2);
cMesAnoOcorr VARCHAR(4);
cAnoOcorr VARCHAR(2);

BEGIN
	
    Ret := 0;
    nContMes := 0;
    nContAno := 0;
    nBloqMes := 0;
    nBloqAno := 0;
    
    cMesAnoOcorr := substr (cDataOcor,3,4);		-- mmyy
    cAnoOcorr := substr (cDataOcor,5,2);		-- yy
    

	BEGIN
		-- PROCURA PELO CONTADOR DE ENTRADAS PARA CARTAO NAO BDCC EM EQUIPAMENTO BDCC
		SELECT 	CONT_MES, substr (to_char(DATA_MES, 'ddmmyyyy'), 3, 2)|| substr (to_char(DATA_MES, 'ddmmyyyy'), 7, 2), 			-- coleta mmyy
				CONT_ANO, substr (to_char(DATA_ANO, 'ddmmyyyy'), 7, 2) 															-- coleta yy
			INTO nContMes, cMesAno, nContAno, cAno
			FROM CONT512_AUX 
				WHERE ICARD = cMatric;
			
		-- VERIFICA SE ATINGIU	QTD MAXIMA DE ENTRADAS NO MES
		IF (cMesAno = cMesAnoOcorr) THEN
			IF (nContMes >= nMaxMes) THEN
				nBloqMes := 1;
			END IF;
		END IF;

		-- VERIFICA SE ATINGIU	QTD MAXIMA DE ENTRADAS NO ANO
		IF (cAno = cAnoOcorr) THEN
			IF (nContAno >= nMaxAno) THEN
				nBloqAno := 1;
			END IF;		
		END IF;

	EXCEPTION
		WHEN NO_DATA_FOUND then Ret := 0;
		WHEN others then 
			Ret := -1;
	END;

	return Ret;
	
END sqlConsCont512_bdcc;
/


