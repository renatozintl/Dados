CREATE OR REPLACE  PROCEDURE trata3_palmv IS
  
TYPE endipPalmI_type IS TABLE OF PALMV004.END_CTRLPALMV%TYPE 
	INDEX BY binary_integer;
TYPE statusPalmI_type IS TABLE OF PALMV004.STATUS%TYPE 
	INDEX BY binary_integer;


TYPE endipPalmE_type IS TABLE OF PALMV005.END_CTRLPALMV%TYPE 
	INDEX BY binary_integer;
TYPE statusPalmE_type IS TABLE OF PALMV005.STATUS%TYPE 
	INDEX BY binary_integer;

TYPE rowid_type IS TABLE OF ROWID  
	INDEX BY binary_integer;

	
l_endipPalmInc endipPalmI_type;
l_statusPalmInc statusPalmI_type;

l_endipPalmExc endipPalmE_type;
l_statusPalmExc statusPalmE_type;

l_rowid rowid_type;
p_recPalmv PALMV014%rowtype;
p_recComI PALMV004%rowtype;
p_recPalmvE PALMV015%rowtype;
p_recComE PALMV005%rowtype;


RECO_LOCK EXCEPTION;
PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);

tem_deadlock EXCEPTION; 
PRAGMA EXCEPTION_INIT (tem_deadlock, -60); 

cMatAux CHAR(12);
cStAux CHAR(1);
cIpAux CHAR(15);

BEGIN

	-- ********************   ARRUMAR SITUA��ES PARA PALMVEIN    -  INCLUSAO
	-- ***********************  TRATA AS BIOMETRIAS PALMVEIN QUE FICARAM PENDENTES NA CARGA E QUE NAO SERAO REENVIADAS AUTOMATICAMENTE
	-- SITUACAO EM QUE CARGA FICOU PENDENTE PORQUE EQUIPAMENTO REJEITOU A CARGA (status '4')
	FOR r in (SELECT distinct ICARD from PALMV014 WHERE STATUS = '4')
	LOOP
		FOR cur_troubleIns3 in 
			(SELECT rowid, ICARD, END_CTRLPALMV  			-- GUARDA EM CURSOR TODAS AS LINHAS DESTA MATRICULA Q NAO TEM O bio PALMVEIN  CADASTRADO, Q ESTA COM STATUS = '4'
				FROM PALMV014 
				WHERE ICARD = r.ICARD and 
					  STATUS = '4'  )
		LOOP
			BEGIN		-- PARA CADA LINHA , RESERVA ('for update nowait') PARA ALTERAR O STATUS
				SELECT * into p_recPalmv FROM PALMV014 WHERE rowid = cur_troubleIns3.rowid for update nowait;
	
				--DELETE PALMV014 WHERE rowid = cur_troubleIns3.rowid ;
				UPDATE PALMV014 SET STATUS = '0' WHERE rowid = cur_troubleIns3.rowid ;

			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
					
			BEGIN
				SELECT END_CTRLPALMV into cIpAux FROM PALMV004 WHERE END_CTRLPALMV = p_recPalmv.END_CTRLPALMV and STATUS = '3' for update nowait;
				UPDATE PALMV004 set status = '1'
					WHERE (END_CTRLPALMV = p_recPalmv.END_CTRLPALMV  and STATUS = '3') ;
						
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		end loop;
	END LOOP;



	-- ***********************  TRATA AS BIOMETRIAS SAGEM QUE FICARAM PENDENTES NA CARGA
	-- SITUACAO EM QUE CARGA FICOU PENDENTE PORQUE HOUVE DELETE DE REGISTROS DOS PALMVEINS (DA TAB.PALMV001 CADASTRO)
	-- delete registro de PALMV014 se nao houver cadastro de palmvein desta matricula
	FOR r in 
		(SELECT distinct ICARD from PALMV014 
			WHERE STATUS = '3')
	LOOP 
		BEGIN
			-- VERIFICA SE H� CADASTRO DO PALMVEIN DA MATRICULA
			SELECT ICARD INTO cMatAux FROM PALMV001 WHERE ICARD = r.ICARD;
			
		EXCEPTION
			when NO_DATA_FOUND then 		-- NAO HA PALMVEIN CADASTRADO
				FOR c_curdig in 
					(SELECT rowid, ICARD, END_CTRLPALMV  			-- GUARDA EM CURSOR TODAS AS LINHAS DESTA MATRICULA Q NAO TEM O PALM CADASTRADO, Q ESTA COM STATUS = '3'
						FROM PALMV014 
						WHERE ICARD = r.ICARD and 
							  STATUS = '3'  )
				LOOP
					BEGIN		-- PARA CADA LINHA , RESERVA ('for update nowait') PARA ALTERAR O STATUS
						SELECT * into p_recPalmv FROM PALMV014 WHERE rowid = c_curdig.rowid for update nowait;
						--UPDATE PALMV014 set status = '0' WHERE rowid = c_curdig.rowid ;
						DELETE PALMV014 WHERE rowid = c_curdig.rowid ;

					EXCEPTION
						when reco_lock then NULL ;
						when tem_deadlock then NULL ;
						when NO_DATA_FOUND then NULL;
						when OTHERS then NULL;
					END;
					
					BEGIN
						SELECT END_CTRLPALMV into cIpAux FROM PALMV004 WHERE END_CTRLPALMV = p_recPalmv.END_CTRLPALMV and STATUS = '3' for update nowait;
						UPDATE PALMV004 set status = '1'
							WHERE (END_CTRLPALMV = p_recPalmv.END_CTRLPALMV) ;
						
					EXCEPTION
						when reco_lock then NULL ;
						when tem_deadlock then NULL ;
						when NO_DATA_FOUND then NULL;
						when OTHERS then NULL;
					END;
					
				end loop;
			when OTHERS then NULL;
		END;
	END LOOP;
	COMMIT;
	-- FIM SITUACAO NOVA

	
	
	-- altera status de todos os codins para carga de Palmveins, se esses n�o estiverem com carga ou estiverem pendentes
	FOR r in 
		(SELECT distinct END_CTRLPALMV from PALMV014 
			where (STATUS != '0') and (STATUS != '2')
		) 
	LOOP
		BEGIN
			SELECT * into p_recComI FROM PALMV004
				WHERE (END_CTRLPALMV = r.END_CTRLPALMV and (STATUS = '0' or STATUS = '3')) for update nowait;
	
			UPDATE PALMV004 set status = '1'
				WHERE (END_CTRLPALMV = r.END_CTRLPALMV and (STATUS = '0' or STATUS = '3')) ;

		EXCEPTION
			when reco_lock then NULL ;
			when tem_deadlock then NULL ;
			when NO_DATA_FOUND then NULL;
			when OTHERS then NULL;
		END;
	END LOOP;
	
	COMMIT;	

	-- ********************   TRATA EQUIPAMENTOS PALMVEIN QUE FICARAM EM ESTADO CARREGANDO OU SOFRERAM CARGA DE APLICATIVO
	-- equipamentos PALMVEIN q ficaram em estado de carregando '2' por mais de 2 minutos OU
	-- equipamentos PALMVEIN que tiveram carga de aplicativo 
	
	SELECT distinct END_CTRLPALMV, STATUS, ROWID
		BULK COLLECT INTO l_endipPalmInc, l_statusPalmInc, l_rowid	
			FROM PALMV004  
			WHERE (status = '5' or (status = '2' and (data_load + ( 2 / 24 / 60 )  < sysdate)) );
	
	FOR i in 1 .. l_endipPalmInc.count	
	LOOP
		IF (l_statusPalmInc(i) = '2') THEN		-- estado CARREGANDO ('2') parado
			FOR c_curdig in 
				(SELECT rowid, ICARD 
					FROM PALMV014 
					WHERE END_CTRLPALMV = l_endipPalmInc(i) and 
						  STATUS = '2'  )
			LOOP
				BEGIN
					SELECT * into p_recPalmv FROM PALMV014 WHERE rowid = c_curdig.rowid for update nowait;
					UPDATE PALMV014 set status = '1' WHERE rowid = c_curdig.rowid ;
				
				EXCEPTION
					when reco_lock then NULL ;
					when tem_deadlock then NULL ;
					when NO_DATA_FOUND then NULL;
					when OTHERS then NULL;
				END;
			end loop;
						   
			BEGIN
				SELECT * into p_recComI from PALMV004 WHERE END_CTRLPALMV = l_endipPalmInc(i) for update nowait;
				UPDATE PALMV004 set status = '1' where END_CTRLPALMV = l_endipPalmInc(i) ;		-- FAZ RECARGA DE PALMVEIN
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		
		ELSIF (l_statusPalmInc(i) = '5') THEN		-- estado de CARGA DE APLICATIVO
			BEGIN
				SELECT * into p_recComI from PALMV004 WHERE END_CTRLPALMV = l_endipPalmInc(i) for update nowait;
				UPDATE PALMV004 set status = '0' WHERE END_CTRLPALMV =  l_endipPalmInc(i);		-- VOLTA AO ESTADO DE REPOUSO
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		END IF;		
	END LOOP;
	
	COMMIT;	



	
	-- ***********************  TRATA AS PALMVEIN QUE FICARAM EM ESTADO DE CARREGANDO E NAO SAEM DESTA SITUA��O
	-- para PALMV   DE PALMV014 que ficaram em estado carregando '2' e o equipamento est� em estado de repouso	, forca o equipamento a carrega-los novamente

	SELECT END_CTRLPALMV, STATUS 
		BULK COLLECT INTO l_endipPalmInc, l_statusPalmInc
			FROM (SELECT  A.END_CTRLPALMV, A.status 
					FROM PALMV004 A INNER JOIN 
						 PALMV014 B
					ON A.END_CTRLPALMV = B.END_CTRLPALMV and 
					   A.status = '0' and 
					   B.STATUS = '2' ) ;

	FOR i IN 1 .. l_endipPalmInc.count     
	LOOP			
		for c1 in (select rowid from PALMV014 
			WHERE END_CTRLPALMV = l_endipPalmInc(i) AND STATUS = '2' )
		loop
			BEGIN
				select * into p_recPalmv from PALMV014 where rowid = c1.rowid for update nowait;		
				UPDATE PALMV014 SET STATUS = '1' where rowid = c1.rowid;

			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		end loop;				
		
		BEGIN
			SELECT * into p_recComI FROM PALMV004 WHERE END_CTRLPALMV = l_endipPalmInc(i) for update nowait;
			UPDATE PALMV004 SET STATUS = '1'	WHERE END_CTRLPALMV = l_endipPalmInc(i);
			
		EXCEPTION
			when reco_lock then NULL ;
			when tem_deadlock then NULL ;
			when NO_DATA_FOUND then NULL;
			when OTHERS then NULL;
		END;
	end LOOP;

	COMMIT;
	

	-- ********************   ARRUMAR SITUA��ES PARA PALMVEIN    -  EXCLUSAO
	
	-- ***********************  TRATA AS PALMVEIN QUE FICARAM PENDENTES NA EXCLUSAO
	-- altera status dos codins PALMVEIN para exclusao de biometria, se esses n�o estiverem com exclusao de PALMVEIN ou estiverem pendentes

	FOR r in 
		(SELECT distinct END_CTRLPALMV from PALMV015 
			where (STATUS != '0') and (STATUS != '2') and (STATUS != '4') 
		) 
	LOOP
		BEGIN
			SELECT * into p_recComE FROM PALMV005
				WHERE (END_CTRLPALMV = r.END_CTRLPALMV and (STATUS = '0' or STATUS = '3')) for update nowait;
	
			UPDATE PALMV005 set status = '1'
				WHERE (END_CTRLPALMV = r.END_CTRLPALMV and (STATUS = '0' or STATUS = '3'));
		EXCEPTION
			when reco_lock then NULL ;
			when tem_deadlock then NULL ;
			when NO_DATA_FOUND then NULL;
			when OTHERS then NULL;
		END;
	END LOOP;
	
	COMMIT;	
	


	-- ********************   TRATA EQUIPAMENTOS PALMVEIN QUE FICARAM EM ESTADO EXCLUINDO OU SOFRERAM CARGA DE APLICATIVO
	-- equipamentos  q ficaram em estado de excluindo '2' por mais de 2 minutos ou
	-- equipamentos que sofreram exclusao/recarga de aplicativo 
	
	SELECT distinct END_CTRLPALMV, STATUS, ROWID
		BULK COLLECT INTO l_endipPalmExc, l_statusPalmExc, l_rowid	
			FROM PALMV005  
			WHERE (status = '5' or (status = '2' and (data_load + ( 2 / 24 / 60 )  < sysdate)));

	FOR i in 1 .. l_endipPalmExc.count	
	LOOP
		IF (l_statusPalmExc(i) = '2') THEN		-- estado CARREGANDO ('2') parado
			FOR c_curdig in 
				(SELECT rowid, ICARD 
					FROM PALMV015 
					WHERE END_CTRLPALMV = l_endipPalmExc(i) and 
						  STATUS = '2' )
			LOOP
				BEGIN
					SELECT * into p_recPalmv FROM PALMV015 WHERE rowid = c_curdig.rowid for update nowait;
					UPDATE PALMV015 set status = '1' WHERE rowid = c_curdig.rowid ;
				
				EXCEPTION
					when reco_lock then NULL ;
					when tem_deadlock then NULL ;
					when NO_DATA_FOUND then NULL;
					when OTHERS then NULL;
				END;
			end loop;
						   
			BEGIN
				SELECT * into p_recComE from PALMV005 WHERE END_CTRLPALMV = l_endipPalmExc(i) for update nowait;
				UPDATE PALMV005 set status = '1' WHERE END_CTRLPALMV = l_endipPalmExc(i) ;		-- FAZ RECARGA DE PALMVEIN
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		
		ELSIF (l_statusPalmExc(i) = '5') THEN		-- estado de CARGA DE APLICATIVO
			BEGIN
				SELECT * into p_recComE from PALMV005 WHERE END_CTRLPALMV = l_endipPalmExc(i) for update nowait;
				UPDATE PALMV005 set status = '0' WHERE END_CTRLPALMV = l_endipPalmExc(i) ;		-- VOLTA AO ESTADO DE REPOUSO
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		END IF;		
	END LOOP;
	
	COMMIT;	


	-- ***********************  TRATA AS BIOMETRIAS PALMVEIN QUE FICARAM EM ESTADO DE EXCLUINDO E NAO SAI DESTA SITUA��O
	-- para BIOMETRIAS  PALMVEIN DE PALMV015 que ficaram em estado excluindo '2' e o equipamento est� em estado de repouso	, forca o equipamento a exclui-los novamente

	SELECT END_CTRLPALMV, STATUS 
		BULK COLLECT INTO l_endipPalmExc, l_statusPalmExc
			FROM (SELECT  A.END_CTRLPALMV, A.status 
					FROM PALMV005 A INNER JOIN 
						 PALMV015 B
					ON A.END_CTRLPALMV = B.END_CTRLPALMV and 
					   A.status = '0' and 
					   B.STATUS = '2' ) ;

	FOR i IN 1 .. l_endipPalmExc.count     
	LOOP			
		for c1 in (select rowid from PALMV015 
			WHERE END_CTRLPALMV = l_endipPalmExc(i) AND STATUS = '2' )
		loop
			BEGIN
				select * into p_recPalmvE from PALMV015 where rowid = c1.rowid for update nowait;		
				UPDATE PALMV015 SET STATUS = '1' where rowid = c1.rowid;

			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		end loop;				
		
		BEGIN
			SELECT * into p_recComE FROM PALMV005 WHERE END_CTRLPALMV = l_endipPalmExc(i) for update nowait;
			UPDATE PALMV005 SET STATUS = '1'	WHERE END_CTRLPALMV = l_endipPalmExc(i);
			
		EXCEPTION
			when reco_lock then NULL ;
			when tem_deadlock then NULL ;
			when NO_DATA_FOUND then NULL;
			when OTHERS then NULL;
		END;
	end LOOP;

	COMMIT;

	

end trata3_palmv ;
/
