CREATE or REPLACE FUNCTION sqlInfo_ErroListaDig (cMatric in VARCHAR2, cEndIp in VARCHAR2, cBioTipo in VARCHAR2, cErro in VARCHAR2) 
RETURN NUMBER IS

Ret NUMBER;
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

BEGIN

	Ret := 0;
	
	INSERT INTO DIGLOAD001 (END_IP, ICARD, BIO_TIPO, NERRO) VALUES (cEndIp, cMatric, cBioTipo, cErro);
	
	COMMIT;

	RETURN (Ret);
	
END sqlInfo_ErroListaDig;
/
