CREATE OR REPLACE FUNCTION sqlproc_empregador2 (IdentEmpr VARCHAR2, EndIp VARCHAR2, TipoInfo in OUT VARCHAR2, Cei in OUT VARCHAR2, 
RSocial in OUT VARCHAR2, LocalServ in OUT VARCHAR2, Caepf in OUT VARCHAR2)   RETURN NUMBER IS

Retfun NUMBER;
Ret NUMBER;
RetAux NUMBER;
AuxLocalServ VARCHAR2(100);

BEGIN
	Ret := 0;
	RetAux := 0;
	Cei := '000000000000';
	Caepf := '00000000000000';

	-- procura o Local de Servico pelo IP
	BEGIN
		SELECT LOCAL_SERV 
			INTO AuxLocalServ  
		FROM REPBLOQ001 WHERE END_IP = EndIp;
		Ret := 1;

	EXCEPTION
		WHEN NO_DATA_FOUND THEN Ret := 0;
		WHEN OTHERS THEN Ret := 0;
	END;


	-- procura o CNOCAEPF pelo IP
	BEGIN
		SELECT CNOCAEPF 
			INTO Caepf  
		FROM DAT07 WHERE END_IP = EndIp;
		RetAux := 1;

	EXCEPTION
		WHEN NO_DATA_FOUND THEN RetAux := 0;
		WHEN OTHERS THEN RetAux := 0;
	END;
	

	Retfun := 1;      -- assume que achou o identificador
	BEGIN
		SELECT TIPO_ID, CEI, RSOCIAL, LOCAL_SERV 
			INTO TipoInfo, Cei, RSocial, LocalServ 
		FROM REPEMPR001 
		--WHERE (IDENT = IdentEmpr) and (regexp_like (CEI, '^[[:digit:]]+$'));  -- UTILIZADO EM 10G E SUP
		--WHERE (IDENT = IdentEmpr) and (translate(CEI,'A0123456789', 'A') is null and length(CEI) = 12);
		WHERE (IDENT = IdentEmpr);

	EXCEPTION
		WHEN NO_DATA_FOUND THEN Retfun := 0;
		WHEN OTHERS THEN Retfun := -1;
	END;
	
	if ((Ret = 1) and (Retfun = 1)) then
		LocalServ := AuxLocalServ;
		if (Cei is null) then 
			Cei := '000000000000';
		end if;
	end if;

	if (Caepf is null) then 
		Caepf := '00000000000000';
	end if;


	
	return (Retfun);
END sqlproc_empregador2;
/


