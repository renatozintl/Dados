CREATE OR REPLACE TRIGGER trgmatgrp
    AFTER INSERT OR DELETE OR UPDATE OF GRUPO ON MATGRUPO
    FOR EACH ROW

declare 
qtd number;
auxSt char(1);

BEGIN

    IF (inserting) THEN
    	/*
		update COUNT_BY_GRUPO set cnt = cnt+1 where icard = :new.icard;

		IF (sql%rowcount = 0) THEN
			insert into count_by_grupo(icard,cnt) values (:new.icard,1);
		END IF;
		*/	
		-- OBS: O STATUS SER� 3 (ALTERADO GRUPO) E NAO 1 (INCLUSAO DE DIGITAL EM TABELA DIGITAL)
		UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
		UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
		UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :NEW.ICARD;
		UPDATE CONTDIG_OUTROS  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
		
    END IF;

    IF (deleting) THEN
    	/*
    	select cnt into qtd from COUNT_BY_GRUPO where icard = :old.icard;
		IF (qtd = 0) THEN			-- contador esta com valor zero
		 	NULL;
		ELSE
			update COUNT_BY_GRUPO set cnt = cnt-1 
				where  ICARD = :old.icard;					
		END IF;
		*/
		-- OBS: O STATUS SER� 3 (ALTERADO GRUPO) E NAO 8 (EXCLUSAO DE FUNCIONARIO DA CONTROLE)
		UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :OLD.ICARD;
		UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :OLD.ICARD;
		UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :OLD.ICARD;
		UPDATE CONTDIG_OUTROS  	SET STATUS = '3' WHERE ICARD = :OLD.ICARD;
				
	-- (updating)
    ELSE
		-- alterando grupo
		IF (:OLD.GRUPO != :NEW.GRUPO) THEN
			UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
			UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
			UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :NEW.ICARD;
			UPDATE CONTDIG_OUTROS  	SET STATUS = '3' WHERE ICARD = :NEW.ICARD;
		END IF;
	END IF;
    
    
END;
/
