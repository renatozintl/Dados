CREATE OR REPLACE FUNCTION sqlbloco_col_dam01_new2 (Registro in VARCHAR2, Tipo in NUMBER)
   RETURN NUMBER IS
      Ret NUMBER;

C1 char(12); C2 char(2); C3 char(2);
C4 char(2); C5 char(4); C6 char(2); 
C7 char(2); C8 char(1); C9 char(15); 
C10 char(2); C11 char(1); C12 char(15);
C13 char(2);
C14 char(10); C15 char(10) ;
C16 CHAR (6); C17 char(7); C18 char(7); C19 char(2);

BEGIN
	
	C1 := SUBSTR(Registro, 1, 12);
	C2 := SUBSTR(Registro, 13, 2);
	C3 := SUBSTR(Registro, 15, 2);
	C4 := SUBSTR(Registro, 17, 2);
	C5 := SUBSTR(Registro, 19, 4);
	C6 := SUBSTR(Registro, 23, 2);
	C7 := SUBSTR(Registro, 25, 2);
	C8 := SUBSTR(Registro, 27, 1);
	C9 := SUBSTR(Registro, 28, 15);
	C10 := SUBSTR(Registro, 43, 2);
	C11 := SUBSTR(Registro, 45, 1);
	C12 := SUBSTR(Registro, 46, 15);	-- VEICULO
	C13 := SUBSTR(Registro, 61, 2);
	C14 := SUBSTR(Registro, 63, 10);
	C15 := SUBSTR(Registro, 73, 10);
	C16 := SUBSTR(Registro, 83, 6);
	C17 := SUBSTR(Registro, 89, 7);
	C18 := SUBSTR(Registro, 96, 7);
	C19 := SUBSTR(Registro, 103, 2);
	
	
	IF (Tipo = 3) THEN 
		INSERT INTO DAM01 (ICARD, DIAM, MESM, ANOM, HORAM, SEGUNDO,CODAC, POSIC, END_IP, CODFNC, 
							--ONOFF, 
							VEICULO, TIPODOC, ICARD_NS, VEICULO_NS, 
							PESO, VALKILO, VALOR, QTDE)
			values (C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, 
					--C11, 
					C12, C13, C14, C15,
					TO_NUMBER(C16, '99.999'), TO_NUMBER(C17, '9999.99'), TO_NUMBER(C18, '9999.99'), C19)  ;
	ELSE
		INSERT INTO DAM01 (ICARD, DIAM, MESM, ANOM, HORAM, SEGUNDO,CODAC, POSIC, END_IP, CODFNC, 
						 -- ONOFF, 
						   VEICULO, TIPODOC, ICARD_NS, VEICULO_NS)
			values (C1, C2, C3, C4, C5, C6, C7, C8, C9, C10, 
					--C11, 
					C12, C13, C14, C15)  ;
	END IF;
	
						   
	Return (0);
	
END sqlbloco_col_dam01_new2;
/


