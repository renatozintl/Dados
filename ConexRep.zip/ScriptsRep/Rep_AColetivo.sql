CREATE OR REPLACE FUNCTION sqlrproc_AColetivo (EndIp VARCHAR2, AColetivo OUT VARCHAR2)  RETURN NUMBER IS

Retfun NUMBER;
Ret NUMBER;
AuxLocalServ VARCHAR2(100);

BEGIN
	Ret := 0;
	AColetivo := '99999999999999999';

	-- procura o Acordo Coletivo pelo IP
	BEGIN
		SELECT ACOLETIVO 
			INTO AColetivo  
		FROM DAT07 WHERE END_IP = EndIp;
		Ret := 1;

	EXCEPTION
		WHEN NO_DATA_FOUND THEN Ret := 0;
		WHEN OTHERS THEN Ret := 0;
	END;

	return (Ret);
	
END sqlrproc_AColetivo;
/


