USE [suricato]
GO

/****** Object:  StoredProcedure [TELESSVR].[G3G5_PREP4_TSI1]    Script Date: 27/08/2026 10:44:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO


ALTER PROCEDURE [TELESSVR].[G3G5_PREP4_TSI1] AS

DECLARE @c_status CHAR(1)
DECLARE @c_icard CHAR(12)

DECLARE @xc_status CHAR(1)
DECLARE @xc_icard CHAR(12)
DECLARE @xc_endip CHAR(15)
DECLARE @xc_tipobio CHAR(1)
DECLARE @ret CHAR(1)

DECLARE @z_endip CHAR(15)
DECLARE @nCont SMALLINT
DECLARE @nAchouGrupo SMALLINT
DECLARE @aux_icard CHAR(12)          


SET DATEFORMAT YMD


	set @ret = 0

	-- cursor para matriculas cujas digitais foram alteradas
	DECLARE cur_stdigital CURSOR FOR (select ICARD, STATUS from CONTDIG_TSI1 WHERE STATUS = '1' or STATUS = '3' or STATUS = '8')

	OPEN cur_stdigital
	FETCH NEXT FROM cur_stdigital INTO @c_icard, @c_status
	while @@fetch_status != -1
	begin
	
		SET @nAchouGrupo = 0		-- presupoe q nao tem icard x grupo correspondente em tab 
	
		-- *************************************************************************
		-- prepara os ids excluidos (controle.situa = invalido) ou grupos da controle alterados, retirando as digitais de todos os equipamentos 
		IF (@c_status = '3') or (@c_status = '8') BEGIN			-- alterados grupos (3) ou situa invalidos  (8)

			-- MONTA temporaria matricula x equipamentos cadastrados
			INSERT INTO TMP_DIG103 (ICARD, END_IP, STATUS, BIO_TIPO) 		
				SELECT distinct @c_icard, DAT07.END_IP, '0', DAT07.BIO_TIPO 
				FROM DAT07 
				WHERE BIO_TIPO = '8';

	
			-- *****************************************************************
			-- COMO ESTA EXCLUINDO O FUNCIONARIO DA EMPRESA (CONTROLE.SITUA = '1' INVALIDO), TIRA DA LISTA DE INCLUSAO DE TODOS OS equipamentos PALMVEIN
			-- COMO ALTEROU O GRUPO, TIRA DA LISTA DE INCLUSAO DE TODOS OS equipamentos PALMVEIN

			--DELETE FROM DIG003 WHERE ICARD = @c_icard AND (STATUS = '0' OR STATUS = '1')
			
			-- VAI DELETAR A MATRICULA DE QUALQUER STATUS PORQUE PODE CAIR NA SITUACAO EM QUE HA INCLUSAO DA MATRICULA, MAS NAO VAI PORQUE O EQUIPAMENTO 'ESTA OCUPADO' (nova resposta do microdimarms).
			-- SE HOUVER POSTERIORMENTE EXCLUSAO DESSA MESMA MATRICULA, DEVE=-SE EXCLUIR A INCLUSAO DESSA MATRICULA DA TABELA
			DELETE FROM DIG003 WHERE ICARD = @c_icard 
		
		END	

		IF (@c_status = '1') or (@c_status = '3')  BEGIN				-- alteracao na digital ou em grupo

			-- ******************************************************************
			-- para todos icards q alteraram digital, distribui nos equipamentos de acordo com o grupo cadastrado em 
			-- CONTROLE, DAT07,DAT08 
			-- MONTA temporaria matricula com codins com permissao acesso
					
			insert into TMP_DIG003 (ICARD, END_IP, STATUS, BIO_TIPO)
			SELECT distinct A.icard,  A.end_ip, A.st, A.bio_tipo
				FROM 
					-- seleciona os equipamentos que fazem parte dos grupos do usuário
					(SELECT distinct @c_icard as 'icard',  dat07.end_ip, '0' as 'st', dat07.bio_tipo
						from dat07, dat08 
						where 
							dat07.end_ip <> '000.000.000.000' and
							CONVERT(int,dat08.grupo) in (
								select CONVERT(int,grupo) from CONTROLE where ICARD = @c_icard AND (SITUA <> '1') AND (VER_DIGIT = '2')  		-- antes era ((SITUA = '1') or (SITUA = '7'))
								  union
								select CONVERT(int,grupo1) from CONTROLE where ICARD = @c_icard AND (SITUA <> '1') AND (VER_DIGIT = '2')
								  union	
								select CONVERT(int,grupo2) from CONTROLE where ICARD = @c_icard AND (SITUA <> '1') AND (VER_DIGIT = '2')
								  union
								select CONVERT(int,grupo3) from CONTROLE where ICARD = @c_icard AND (SITUA <> '1') AND (VER_DIGIT = '2')
								  union
								select CONVERT(int,grupo_sab) from CONTROLE where ICARD = @c_icard AND (SITUA <> '1') AND (VER_DIGIT = '2')
								  union
								select CONVERT(int,grupo_dom) from CONTROLE where ICARD = @c_icard AND (SITUA <> '1') AND (VER_DIGIT = '2')
								  union
								select CONVERT(int,grupo_fer) from CONTROLE where ICARD = @c_icard AND (SITUA <> '1') AND (VER_DIGIT = '2')
								  union
								select CONVERT(int,A.grupo) from MATNGRUPOS A, CONTROLE B where A.ICARD = @c_icard  AND B.ICARD = @c_icard AND (B.SITUA <> '1') and (B.VER_DIGIT = '2')
								  union
								select CONVERT(int,A.grupo) from MATGRUPO A, CONTROLE B where A.ICARD = @c_icard  AND B.ICARD = @c_icard AND (B.SITUA <> '1') and (B.VER_DIGIT = '2')
								) and
						  CONVERT(int,dat07.laces) = CONVERT(int,dat08.laces) and
						  CONVERT(int,dat07.planta) = CONVERT(int,dat08.planta) and
						  dat07.bio_tipo = '8'  
				UNION
					SELECT distinct @c_icard as 'icard',  dat07.end_ip, '0' as 'st', dat07.bio_tipo
						from dat07, MATCODIN 
						where 
							matcodin.icard = @c_icard and
							matcodin.end_ip <> '000.000.000.000' and 
							matcodin.end_ip = dat07.end_ip and 
							dat07.bio_tipo = '8') as A
							
			-- para quem incluiu/alterou digital (status 1) ou mudou de grupo (status 3)				
			-- IF (@c_status = '3') BEGIN
			IF (@c_status = '1') OR (@c_status = '3') BEGIN
				-- ******************************************************************
				-- deve-se excluir da tabela de exclusao temporaria os equipamentos que fazem parte do novo grupo

				DELETE FROM TMP_DIG103
					WHERE EXISTS
						(SELECT TMP_DIG003.icard 
							FROM 
								TMP_DIG003
							WHERE 
								TMP_DIG003.icard = TMP_DIG103.icard and
								TMP_DIG003.END_IP = TMP_DIG103.END_IP and
							  	TMP_DIG003.icard = @c_icard
						);

				-- ******************************************************************
				-- deve-se excluir da tabela de exclusao final os equipamentos do ID em questão, para REFAZER a tabela
				
				--DELETE from DIG103 where ICARD = @c_icard AND (STATUS = '0' OR STATUS = '1')
				-- VAI DELETAR A MATRICULA DE QUALQUER STATUS PORQUE PODE CAIR NA SITUACAO EM QUE HA EXCLUSAO DA MATRICULA, MAS NAO VAI PORQUE O EQUIPAMENTO ESTA OCUPADO.
				-- SE HOUVER POSTERIORMENTE INCLUSAO DESSA MESMA MATRICULA, DEVE=-SE EXCLUIR A EXCLUSAO DESSA MATRICULA DA TABELA
				DELETE from DIG103 where ICARD = @c_icard 
				
			END
							
		END

		-- ******************************************************************
		-- PREPARA TABELA TEMPORARIA DE INCLUSAO COM OS ENDEREÇOS IP 
		SET @nCont = (SELECT COUNT(*) FROM TMP_DIG003)

		-- verifica se a matricula esta cadastrada em controle e se pertence a alguma codin. 
		-- Caso negativo, seu status ainda continua setado até que seja cadastrada e pertença a algum local de acesso
		IF (@nCont != 0) BEGIN

			-- insere icard-codin em tab. DIG003, se não existir em tab.
			DECLARE cur_tmpdigital CURSOR FOR (select ICARD, END_IP, STATUS, BIO_TIPO from TMP_DIG003)
			OPEN cur_tmpdigital
			FETCH NEXT FROM cur_tmpdigital into @xc_icard, @xc_endip, @xc_status, @xc_tipobio

			while @@fetch_status != -1
			begin
				UPDATE DIG003 SET STATUS = '1' 
					WHERE  ICARD = @xc_icard AND
						   END_IP = @xc_endip
				if @@rowcount = 0
				begin		
					INSERT INTO DIG003 (ICARD, END_IP, STATUS, BIO_TIPO) 
						values (@xc_icard, @xc_endip, '1', @xc_tipobio);
				end

				FETCH NEXT FROM cur_tmpdigital into @xc_icard, @xc_endip, @xc_status, @xc_tipobio
			end
			
			SET @nAchouGrupo = 1;
			
			-- coloca o codin na tab. DIG002 (CARGA LISTA) o codin não existir
			insert into DIG002 (END_IP, DATA_LOAD, STATUS, BIO_TIPO)
				select distinct end_ip, getdate(), '0', bio_tipo  
				from
					DIG003
				where
					end_ip not in ( select end_ip from DIG002 );
			
			CLOSE cur_tmpdigital
			DEALLOCATE cur_tmpdigital
		END

		-- ******************************************************************
		-- PREPARA TABELA TEMPORARIA DE EXCLUSAO COM OS ENDEREÇOS IP DOS EQUIPAMENTOS
		SET @nCont = (SELECT COUNT(*) FROM TMP_DIG103)
		IF (@nCont != 0) BEGIN

			-- insere na tabela final DIG103  os ID COM STATUS de carga (0 / 1= a excluir)
			DECLARE cur_tmpdigital CURSOR FOR (select ICARD, END_IP, STATUS, BIO_TIPO from TMP_DIG103)
			OPEN cur_tmpdigital
			FETCH NEXT FROM cur_tmpdigital into @xc_icard, @xc_endip, @xc_status, @xc_tipobio

			WHILE @@fetch_status != -1 BEGIN
				UPDATE DIG103 SET STATUS = '1' 
					WHERE  ICARD = @xc_icard AND
						   END_IP = @xc_endip
				if @@rowcount = 0
				begin		
					INSERT INTO DIG103 (ICARD, END_IP, STATUS, BIO_TIPO) 
						values (@xc_icard, @xc_endip, '1', @xc_tipobio);
				end

				FETCH NEXT FROM cur_tmpdigital into @xc_icard, @xc_endip, @xc_status, @xc_tipobio
			end
			
			SET @nAchouGrupo = 1;

			-- coloca o equipamento na tab. DIG102 (CARGA LISTA) o equipamento q não existir
			insert into DIG102 (END_IP, DATA_LOAD, STATUS, BIO_TIPO)
				select distinct END_IP, GETDATE(), '0', BIO_TIPO
				from
					DIG103
				where
					END_IP not in ( select END_IP from DIG102 );
							
			CLOSE cur_tmpdigital
			DEALLOCATE cur_tmpdigital
		END	


		-- atualiza status da matricula, como tratado
		IF (@nAchouGrupo = 1) 	
			update CONTDIG_TSI1 SET STATUS = '0' 
				where ICARD = @c_icard;
			
		DELETE TMP_DIG003
		DELETE TMP_DIG103

		FETCH NEXT FROM cur_stdigital INTO @c_icard, @c_status
	end
	CLOSE cur_stdigital
	deallocate cur_stdigital


GO


