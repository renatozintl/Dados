CREATE OR REPLACE  PROCEDURE Prep_RepDigit5 (nQtd NUMBER) IS
TYPE ifunc_type IS TABLE OF REPNDIGAUTO000.IFUNC%TYPE 
	INDEX BY binary_integer;
TYPE status_type IS TABLE OF REPNDIGAUTO000.STATUS%TYPE 
	INDEX BY binary_integer;
TYPE grupo_type IS TABLE OF REPNDIGAUTO000.GRUPO%TYPE  
	INDEX BY binary_integer;
TYPE biotipo_type IS TABLE OF REPNDIGAUTO000.BIO_TIPO%TYPE  
	INDEX BY binary_integer;
		
l_ifunc ifunc_type;
l_status status_type;
l_grupo grupo_type;
l_biotipo biotipo_type;

RECO_LOCK EXCEPTION;
PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);

tem_deadlock EXCEPTION; 
PRAGMA EXCEPTION_INIT (tem_deadlock, -60); 

total number;
nCont NUMBER;
nTemLocal NUMBER;

xc_status CHAR(1);
xc_ifunc CHAR(12);
xc_endip CHAR(15);
xc_biotipo CHAR(1);
ret CHAR(1);

cAux CHAR(1);
cAux1 CHAR(1);
cTipo CHAR(1);


CURSOR cur_tmpautoSAG001 IS SELECT IFUNC, END_IP, STATUS from TMP_REPSAG001 where STATUS = '3' or STATUS = '1';

CURSOR cur_tmpautoSAG002 IS SELECT IFUNC, END_IP, STATUS from TMP_REPSAG002 where STATUS = '8';

CURSOR cur_tmpautoSUP001 IS SELECT IFUNC, END_IP, STATUS from TMP_REPSUP001 where STATUS = '3' or STATUS = '1';

CURSOR cur_tmpautoSUP002 IS SELECT IFUNC, END_IP, STATUS from TMP_REPSUP002 where STATUS = '8';

CURSOR cur_tmpautoVRD001 IS SELECT IFUNC, END_IP, STATUS, BIO_TIPO from TMP_REPVRD001 where STATUS = '3' or STATUS = '1';

CURSOR cur_tmpautoVRD002 IS SELECT IFUNC, END_IP, STATUS, BIO_TIPO from TMP_REPVRD002 where STATUS = '8';


BEGIN

	ret := 0;

	BEGIN
		-- **************** seleciona os ifuncs alterados da tabela REPNDIGAUTO000  ****************
		-- para preparar a tabela TMP_NREP000, e atualizar status de REPNDIGAUTO000 para TRATADO ('0')
		select IFUNC, STATUS, GRUPO, BIO_TIPO 
			BULK COLLECT INTO l_ifunc, l_status, l_grupo, l_biotipo   
		from ( 
			select IFUNC, STATUS, GRUPO, BIO_TIPO 
				FROM REPNDIGAUTO000 
			where 
				STATUS = '3' or STATUS = '8' 		-- '3'(insert/upd), '8'(excluido)
			ORDER BY DATA_INS, IFUNC)	
		--WHERE ROWNUM < 5;
		WHERE ROWNUM < nQtd;
		
		total := l_ifunc.count;
		
	
		FOR indx IN 1 .. total     
		LOOP
			nTemLocal := 0;
			DELETE FROM TMP_NREPDIGGRP;
			
			-- VERIFICA SE VALOR DE REPNDIGAUTO000.BIO_TIPO tem valor '0'.
			-- SE VALOR '0', indica que a preparacao das tabelas � para todos tipo de biometria
			-- SE VALOR � espec�fico para TIPO DE LEITOR BIO, s� vai ENTRAR EM tab. TMP_NREPDIGGRP os equipamentos dessa biometria
			
			IF (l_biotipo(indx) = '0') THEN
				-- inclui em TMP_NREPDIGGRP TODOS OS REPS Q FAZEM PARTE DO GRUPO EM QUESTAO (NOVO OU VELHO) DO FUNCIONARIO 
				INSERT into TMP_NREPDIGGRP (IFUNC, GRUPO,  END_IP, STATUS, BIO_TIPO)		
					select l_ifunc(indx), l_grupo(indx), VIEWGRPREP.end_ip, l_status(indx), VIEWGRPREP.BIO_TIPO
						from VIEWGRPREP
						where
							to_number(VIEWGRPREP.grupo) = to_number(l_grupo(indx)) and
							((VIEWGRPREP.bio_tipo != '0') and (VIEWGRPREP.bio_tipo != 'A'));
							--(VIEWGRPREP.bio_tipo = '6' or VIEWGRPREP.bio_tipo = '7'  or VIEWGRPREP.bio_tipo = '8' or VIEWGRPREP.bio_tipo = '9');
			ELSE
				-- inclui em TMP_NREPDIGGRP TODOS OS REPS Q FAZEM PARTE DO GRUPO EM QUESTAO (NOVO OU VELHO) DO FUNCIONARIO 
				INSERT into TMP_NREPDIGGRP (IFUNC, GRUPO,  END_IP, STATUS, BIO_TIPO)		
					select l_ifunc(indx), l_grupo(indx), VIEWGRPREP.end_ip, l_status(indx), l_biotipo(indx)
						from VIEWGRPREP
						where
							to_number(VIEWGRPREP.grupo) = to_number(l_grupo(indx)) and
							VIEWGRPREP.bio_tipo = l_biotipo(indx);
			END IF;


			IF (sql%rowcount != 0) THEN		-- ACHOU equipamento RELACIONADO ao GRUPO EM QUESTAO (NOVO OU VELHO)
				nTemLocal := 1;
			END IF;

		
			IF (nTemLocal = 1) THEN
				-- Insere em tabela OS REGISTROS de TMP_NREP000GRP
				IF (l_status(indx) = '3') then
					-- INCLUSAO
					cTipo := '3';
								
					FOR r in (SELECT END_IP, BIO_TIPO from TMP_NREPDIGGRP  
								WHERE IFUNC = l_ifunc(indx) and  
									  STATUS = cTipo and 
									  to_number(GRUPO) = to_number(l_grupo(indx)))
					LOOP
						-- trata equipamento SAGEM
						IF (r.BIO_TIPO = '6' or r.BIO_TIPO = '7') then
							BEGIN
								SELECT STATUS into cAux from TMP_REPSAG001 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
								IF (cAux = '0') then
										UPDATE TMP_REPSAG001 set STATUS = cTipo where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
								END IF;

							EXCEPTION
								WHEN NO_DATA_FOUND then 
									INSERT into TMP_REPSAG001 (IFUNC, END_IP, STATUS)	VALUES  (l_ifunc(indx), r.END_IP, cTipo );
								WHEN OTHERS then NULL;
							END;

						-- trata equipamento SUPREMA
						ELSIF (r.BIO_TIPO = '8') then
							BEGIN
								SELECT STATUS into cAux from TMP_REPSUP001 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
								IF (cAux = '0') then
									UPDATE TMP_REPSUP001 set STATUS = cTipo where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
								END IF;

							EXCEPTION
								WHEN NO_DATA_FOUND then 
									INSERT into TMP_REPSUP001 (IFUNC, END_IP, STATUS)	VALUES  (l_ifunc(indx), r.END_IP, cTipo );
								WHEN OTHERS then NULL;
							END;

						-- trata equipamento VIRDI / e outros
						ELSIF (r.BIO_TIPO != 'A') then
							-- NOVO PARA BIOMETRIAS QUE ESTAO CADASTRADAS EM CONTDIG_OUTROS
							BEGIN
								SELECT STATUS into cAux from TMP_REPVRD001 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP and BIO_TIPO = r.BIO_TIPO;
								IF (cAux = '0') then
									UPDATE TMP_REPVRD001 set STATUS = cTipo where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
								END IF;

							EXCEPTION
								WHEN NO_DATA_FOUND then 
									INSERT into TMP_REPVRD001 (IFUNC, END_IP, BIO_TIPO, STATUS)	VALUES  (l_ifunc(indx), r.END_IP, r.BIO_TIPO, cTipo );
								WHEN OTHERS then NULL;
							END;
						END IF;
						
						
						-- verifica se funcionario x ip ja est� em tabela de exclusao, para excluir
						-- SAGEM
						IF (r.BIO_TIPO = '6' or r.BIO_TIPO = '7') then
							BEGIN
								SELECT STATUS into cAux from TMP_REPSAG002 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
								IF (cAux = '8') then
									DELETE FROM TMP_REPSAG002 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
								END IF;

							EXCEPTION
								WHEN NO_DATA_FOUND then NULL;
								WHEN OTHERS then NULL;
							END;

						-- SUPREMA
						ELSIF (r.BIO_TIPO = '8') then
							BEGIN
								SELECT STATUS into cAux from TMP_REPSUP002 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
								IF (cAux = '8') then
									DELETE FROM TMP_REPSUP002 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
								END IF;
									
							EXCEPTION
								WHEN NO_DATA_FOUND then NULL;
								WHEN OTHERS then NULL;
							END;
									
						-- OUTRAS BIOMETRIAS
						ELSIF (r.BIO_TIPO != 'A') then
							BEGIN
								SELECT STATUS into cAux from TMP_REPVRD002 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP and BIO_TIPO = r.BIO_TIPO;
								IF (cAux = '8') then
									DELETE FROM TMP_REPVRD002 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP  and BIO_TIPO = r.BIO_TIPO;
								END IF;
									
							EXCEPTION
								WHEN NO_DATA_FOUND then NULL;
								WHEN OTHERS then NULL;
							END;
															
						END IF;
									
						-- **********************************************************************
						-- NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  						
						-- VERIFICA SE FUNCIONARIO X IP JA EST� EM TABELA DE EXCLUSAO E ESTA PENDENTE
						-- SAGEM
						IF (r.BIO_TIPO = '6' or r.BIO_TIPO = '7') then
							BEGIN
								SELECT STATUS INTO cAux FROM RDIG101
									WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP AND (STATUS = '3' OR STATUS = '2');
				
								IF (cAux = '3') then		-- SITUA��O PENDENTE 
									BEGIN
										SELECT STATUS INTO cAux1 FROM RDIG101
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;
									
										UPDATE RDIG101 SET STATUS = '4' 							-- A EXCLUSAO QUE EST� PENDENTE FICARA COM ESTADO DE IGNORADA E NAO SER� MAIS EXECUTADA
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
									
									EXCEPTION
										WHEN RECO_LOCK THEN 
											null;
										WHEN NO_DATA_FOUND THEN 
											null;
										WHEN OTHERS THEN 
											null;
									END;			
									
								ELSE	 -- STATUS = '2' : PODE ESTAR NA SITUA��O DEXECUTANDO E NAO OBTEVE RESPOSTA
									-- PROCURA EM RDIG102 SE O EQUIPAMENTO EST� MAIS DE 30 SEGUNDOS ESPERANDO RESPOSTA, ENTAO PODE TIRAR.
									BEGIN
										SELECT STATUS into cAux1 from RDIG102 
											where END_IP = r.END_IP and 
												STATUS = '2' and 
											    (DATA_LOAD + ( 30 / 24 / 3600 )  < sysdate) and 
												((BIO_TIPO = '6') OR (BIO_TIPO = '7')) ;		-- O COMANDO FOI FEITO HA MAIS DE 30 SEGUNDOS
										BEGIN
											SELECT STATUS INTO cAux1 FROM RDIG101
												WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;
									
											UPDATE RDIG101 SET STATUS = '4' 						-- sinaliza que REP NAO RESPONDEU AO COMANDO DE EXCLUSAO E FICAR� COM ESTADO DE IGNORADA E NAO SER� MAIS EXECUTADA
												WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
									
										EXCEPTION
											WHEN RECO_LOCK THEN 
												null;
											WHEN NO_DATA_FOUND THEN 
												null;
											WHEN OTHERS THEN 
												null;
										END;			
									EXCEPTION
										WHEN RECO_LOCK THEN 
											null;
										WHEN NO_DATA_FOUND THEN 
											null;
										WHEN OTHERS THEN 
											null;
									END;			
								END IF;							
							
							EXCEPTION
								WHEN NO_DATA_FOUND THEN 
									null;
								WHEN OTHERS THEN 
									null;
							END;			
									
						-- SUPREMA
						ELSIF (r.BIO_TIPO = '8') then
							BEGIN
								SELECT STATUS INTO cAux FROM RDIG103
									WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP AND (STATUS = '3' OR STATUS = '2');
									
								IF (cAux = '3') then		-- SITUA��O PENDENTE 
									BEGIN
										SELECT STATUS INTO cAux1 FROM RDIG103
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;
									
										UPDATE RDIG103 SET STATUS = '4' 							-- A EXCLUSAO QUE EST� PENDENTE FICARA COM ESTADO DE IGNORADA E NAO SER� MAIS EXECUTADA
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
									
									EXCEPTION
										WHEN RECO_LOCK THEN 
											null;
										WHEN NO_DATA_FOUND THEN 
											null;
										WHEN OTHERS THEN 
											null;
									END;			
									
								ELSE	 -- STATUS = '2' : PODE ESTAR NA SITUA��O DEXECUTANDO E NAO OBTEVE RESPOSTA
									-- PROCURA EM RDIG102 SE O EQUIPAMENTO EST� MAIS DE 30 SEGUNDOS ESPERANDO RESPOSTA, ENTAO PODE TIRAR.
									BEGIN
										SELECT STATUS into cAux1 from RDIG102 
											where END_IP = r.END_IP and 
												  STATUS = '2' and 
												  (DATA_LOAD + ( 30 / 24 / 3600 )  < sysdate) and 
												  (BIO_TIPO = '8') ;		-- O COMANDO FOI FEITO HA MAIS DE 30 SEGUNDOS
										BEGIN
											SELECT STATUS INTO cAux1 FROM RDIG103
												WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;
							
											UPDATE RDIG103 SET STATUS = '4' 						-- sinaliza que REP NAO RESPONDEU AO COMANDO DE EXCLUSAO E FICAR� COM ESTADO DE IGNORADA E NAO SER� MAIS EXECUTADA
												WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
									
										EXCEPTION
											WHEN RECO_LOCK THEN 
												null;
											WHEN NO_DATA_FOUND THEN 
												null;
											WHEN OTHERS THEN 
												null;
										END;			
									EXCEPTION
										WHEN RECO_LOCK THEN 
											null;
										WHEN NO_DATA_FOUND THEN 
											null;
										WHEN OTHERS THEN 
											null;
									END;			
								END IF;							
									
							EXCEPTION
								WHEN NO_DATA_FOUND THEN 
									null;
								WHEN OTHERS THEN 
									null;
							END;			
									
						-- OUTRAS BIOMETRIAS
						ELSIF (r.BIO_TIPO != 'A') then
							BEGIN
								SELECT STATUS INTO cAux FROM RDIG104
									WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP AND (STATUS = '3' OR STATUS = '2');
								
								IF (cAux = '3') then		-- SITUA��O PENDENTE 
									BEGIN
										SELECT STATUS INTO cAux1 FROM RDIG104
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;
									
										UPDATE RDIG104 SET STATUS = '4' 							-- A EXCLUSAO QUE EST� PENDENTE FICARA COM ESTADO DE IGNORADA E NAO SER� MAIS EXECUTADA
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
									
									EXCEPTION
										WHEN RECO_LOCK THEN 
											null;
										WHEN NO_DATA_FOUND THEN 
											null;
										WHEN OTHERS THEN 
											null;
									END;			
									
								ELSE	 -- STATUS = '2' : PODE ESTAR NA SITUA��O DEXECUTANDO E NAO OBTEVE RESPOSTA
									-- PROCURA EM RDIG102 SE O EQUIPAMENTO EST� MAIS DE 30 SEGUNDOS ESPERANDO RESPOSTA, ENTAO PODE TIRAR.
									BEGIN
										SELECT STATUS into cAux1 from RDIG102 
											where END_IP = r.END_IP and 
												  STATUS = '2' and 
												  (DATA_LOAD + ( 30 / 24 / 3600 )  < sysdate) and 
												  ((BIO_TIPO != '6') and (BIO_TIPO != '7') and (BIO_TIPO != '8') and (BIO_TIPO != 'A')) ;		-- O COMANDO FOI FEITO HA MAIS DE 30 SEGUNDOS
										BEGIN
											SELECT STATUS INTO cAux1 FROM RDIG104
												WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;
									
											UPDATE RDIG104 SET STATUS = '4' 						-- sinaliza que REP NAO RESPONDEU AO COMANDO DE EXCLUSAO E FICAR� COM ESTADO DE IGNORADA E NAO SER� MAIS EXECUTADA
												WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
									
										EXCEPTION
											WHEN RECO_LOCK THEN 
												null;
											WHEN NO_DATA_FOUND THEN 
												null;
											WHEN OTHERS THEN 
												null;
										END;			
									EXCEPTION
										WHEN RECO_LOCK THEN 
											null;
										WHEN NO_DATA_FOUND THEN 
											null;
										WHEN OTHERS THEN 
											null;
									END;			
								END IF;							
									
							EXCEPTION
								WHEN NO_DATA_FOUND THEN 
									null;
								WHEN OTHERS THEN 
									null;
							END;			
								
						END IF;
						-- FIM NOVO    FIM NOVO    FIM NOVO    FIM NOVO    FIM NOVO    
						-- **********************************************************************
						
					END LOOP;
				
				ELSIF (l_status(indx) = '8') then
					-- EXCLUSAO
					cTipo := '8';
					DELETE FROM TMP_NREPDIGOUTROS;
					
					IF (l_biotipo(indx) = '0') THEN
						-- inclui em TMP_NREPDIGOUTROS TODOS OS REPS Q FAZEM PARTE De outros GRUPOs DO FUNCIONARIO
						INSERT into TMP_NREPDIGOUTROS (IFUNC, GRUPO, END_IP, BIO_TIPO, STATUS)		-- inclui em TMP_NREPDIGOUTROS TODOS OS REPS Q FAZEM PARTE DOs outros GRUPOs DO FUNCIONARIO
							select distinct l_ifunc(indx), VIEWGRPREP.Grupo,  VIEWGRPREP.end_ip, VIEWGRPREP.bio_tipo , l_status(indx)
								from VIEWGRPREP , REPGRPF
									where (to_number(VIEWGRPREP.grupo) = to_number(repgrpf.grupo) ) and
										  (REPGRPF.IFUNC = l_ifunc(indx)) AND
										  (to_number(VIEWGRPREP.grupo) != to_number(l_grupo(indx)) ) and
										  (to_number(VIEWGRPREP.grupo) not in (SELECT to_number(GRUPO) FROM TMP_NREPDIGATV  WHERE IFUNC =l_ifunc(indx)) ) and 
										  (VIEWGRPREP.bio_tipo != '0' AND VIEWGRPREP.bio_tipo != 'A');
					ELSE
						-- inclui em TMP_NREPDIGOUTROS TODOS OS REPS Q FAZEM PARTE De outros GRUPOs DO FUNCIONARIO COM O MESMO BIO_TIPO
						INSERT into TMP_NREPDIGOUTROS (IFUNC, GRUPO, END_IP, BIO_TIPO, STATUS)		-- inclui em TMP_NREPDIGOUTROS TODOS OS REPS Q FAZEM PARTE DOs outros GRUPOs DO FUNCIONARIO
							select distinct l_ifunc(indx), VIEWGRPREP.Grupo,  VIEWGRPREP.end_ip, l_biotipo(indx), l_status(indx)
								from VIEWGRPREP , REPGRPF
									where (to_number(VIEWGRPREP.grupo) = to_number(repgrpf.grupo) ) and
										  (REPGRPF.IFUNC = l_ifunc(indx)) AND
										  (to_number(VIEWGRPREP.grupo) != to_number(l_grupo(indx)) ) and
										  (to_number(VIEWGRPREP.grupo) not in (SELECT to_number(GRUPO) FROM TMP_NREPDIGATV  WHERE IFUNC =l_ifunc(indx)) ) and 
										  (VIEWGRPREP.bio_tipo = l_biotipo(indx) );
					END IF;
									
					nCont := sql%rowcount;							

					FOR r in (SELECT END_IP, BIO_TIPO from TMP_NREPDIGGRP  WHERE IFUNC = l_ifunc(indx) and  STATUS = cTipo and to_number(GRUPO) = to_number(l_grupo(indx)))
					LOOP 
						--cAux := '2';
						nCont := 0;
						--SELECT STATUS into cAux from TMP_NREPDIGOUTROS WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
						SELECT COUNT(*) INTO nCont from TMP_NREPDIGOUTROS WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
						
						IF (nCont = 0) THEN
							-- trata equipamento SAGEM
							IF (r.BIO_TIPO = '6' or r.BIO_TIPO = '7') then
								BEGIN
									SELECT STATUS into cAux from TMP_REPSAG002 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
									IF (cAux = '0') then
										UPDATE TMP_REPSAG002 set STATUS = cTipo where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
									END IF;

								EXCEPTION
									WHEN NO_DATA_FOUND then 
										INSERT into TMP_REPSAG002 (IFUNC, END_IP, STATUS)	VALUES  (l_ifunc(indx), r.END_IP, cTipo );
									WHEN OTHERS then NULL;
								END;

							-- trata equipamento SUPREMA
							ELSIF (r.BIO_TIPO = '8') then
								BEGIN
									SELECT STATUS into cAux from TMP_REPSUP002 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
									IF (cAux = '0') then
										UPDATE TMP_REPSUP002 set STATUS = cTipo where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
									END IF;

								EXCEPTION
									WHEN NO_DATA_FOUND then 
										INSERT into TMP_REPSUP002 (IFUNC, END_IP, STATUS)	VALUES  (l_ifunc(indx), r.END_IP, cTipo );
									WHEN OTHERS then NULL;
								END;
							
							-- trata EQUIPAMENTOS DE OUTRAS BIOMETRIAS
							ELSIF (r.BIO_TIPO != 'A') then
								BEGIN
									SELECT STATUS into cAux from TMP_REPVRD002 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP and BIO_TIPO = r.BIO_TIPO;
									IF (cAux = '0') then
										UPDATE TMP_REPVRD002 set STATUS = cTipo where IFUNC = l_ifunc(indx) and END_IP = r.END_IP and BIO_TIPO = r.BIO_TIPO;
									END IF;

								EXCEPTION
									WHEN NO_DATA_FOUND then 
										INSERT into TMP_REPVRD002 (IFUNC, END_IP, BIO_TIPO, STATUS)	VALUES  (l_ifunc(indx), r.END_IP, r.BIO_TIPO, cTipo );
									WHEN OTHERS then NULL;
								END;
							END IF;
						END IF;									
									
							
					
						-- verifica se funcionario x ip ja est� em tabela de inclusao, para incluir
						-- SAGEM
						IF (r.BIO_TIPO = '6' or r.BIO_TIPO = '7') then
							BEGIN
								SELECT STATUS into cAux from TMP_REPSAG001 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
								IF (cAux = '3') then
									DELETE FROM TMP_REPSAG001 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
								END IF;

							EXCEPTION
								WHEN NO_DATA_FOUND then NULL;
								WHEN OTHERS then NULL;
							END;
						
						--SUPREMA
						ELSIF (r.BIO_TIPO = '8') then							
							BEGIN
								SELECT STATUS into cAux from TMP_REPSUP001 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
								IF (cAux = '3') then
									DELETE FROM TMP_REPSUP001 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
								END IF;

							EXCEPTION
								WHEN NO_DATA_FOUND then NULL;
								WHEN OTHERS then NULL;
							END;

						--OUTRAS BIOMETRIAS
						ELSIF (r.BIO_TIPO != 'A') then							
							BEGIN
								SELECT STATUS into cAux from TMP_REPVRD001 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP and BIO_TIPO = r.BIO_TIPO;
								IF (cAux = '3') then
									DELETE FROM TMP_REPVRD001 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP and BIO_TIPO = r.BIO_TIPO;
								END IF;

							EXCEPTION
								WHEN NO_DATA_FOUND then NULL;
								WHEN OTHERS then NULL;
							END;
						
						END IF;

						-- **********************************************************************
						-- NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  						
						-- VERIFICA SE FUNCIONARIO X IP JA EST� EM TABELA DE INCLUSAO E ESTA PENDENTE

						-- SAGEM
						IF (r.BIO_TIPO = '6' or r.BIO_TIPO = '7') then
							BEGIN
								SELECT STATUS INTO cAux FROM RDIG001
									WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP AND (STATUS = '3' OR STATUS = '2');

								IF (cAux = '3') then		-- SITUA��O PENDENTE 
									BEGIN
										SELECT STATUS INTO cAux1 FROM RDIG001
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;

										UPDATE RDIG001 SET STATUS = '4' 
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;

									EXCEPTION
										WHEN RECO_LOCK THEN 
											null;
										WHEN NO_DATA_FOUND THEN 
											null;
										WHEN OTHERS THEN 
											null;
									END;			

								ELSE	 -- STATUS = '2' : PODE ESTAR NA SITUA��O DEXECUTANDO E NAO OBTEVE RESPOSTA
									-- PROCURA EM RDIG002 SE O EQUIPAMENTO EST� MAIS DE 30 SEGUNDOS ESPERANDO RESPOSTA, ENTAO PODE TIRAR.
									BEGIN
										SELECT STATUS into cAux1 from RDIG002 
											where END_IP = r.END_IP and 
												  STATUS = '2' and 
												  (DATA_LOAD + ( 30 / 24 / 3600 )  < sysdate) and 
												  ((BIO_TIPO = '6') OR (BIO_TIPO = '7')) ;		-- O COMANDO FOI FEITO HA MAIS DE 30 SEGUNDOS
											
										BEGIN
											SELECT STATUS INTO cAux1 FROM RDIG001
												WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;

											UPDATE RDIG001 SET STATUS = '4' 
												WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;

										EXCEPTION
											WHEN RECO_LOCK THEN 
												null;
											WHEN NO_DATA_FOUND THEN 
												null;
											WHEN OTHERS THEN 
												null;
										END;			
									EXCEPTION
										WHEN RECO_LOCK THEN 
											null;
										WHEN NO_DATA_FOUND THEN 
											null;
										WHEN OTHERS THEN 
											null;
									END;			
								END IF;							

							EXCEPTION
								WHEN NO_DATA_FOUND THEN 
									null;
								WHEN OTHERS THEN 
									null;
							END;			

						-- SUPREMA
						ELSIF (r.BIO_TIPO = '8') then
							BEGIN
								SELECT STATUS INTO cAux FROM RDIG003
									WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP AND (STATUS = '3' OR STATUS = '2');

								IF (cAux = '3') then		-- SITUA��O PENDENTE 
									BEGIN
										SELECT STATUS INTO cAux1 FROM RDIG003
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;

										UPDATE RDIG003 SET STATUS = '4' 
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;

									EXCEPTION
										WHEN RECO_LOCK THEN 
											null;
										WHEN NO_DATA_FOUND THEN 
											null;
										WHEN OTHERS THEN 
											null;
									END;			

								ELSE	 -- STATUS = '2' : PODE ESTAR NA SITUA��O DEXECUTANDO E NAO OBTEVE RESPOSTA
									-- PROCURA EM RDIG002 SE O EQUIPAMENTO EST� MAIS DE 30 SEGUNDOS ESPERANDO RESPOSTA, ENTAO PODE TIRAR.
									BEGIN
										SELECT STATUS into cAux1 from RDIG002 
											where END_IP = r.END_IP and 
												  STATUS = '2' and 
												  (DATA_LOAD + ( 30 / 24 / 3600 )  < sysdate) and 
												  (BIO_TIPO = '8') ;		-- O COMANDO FOI FEITO HA MAIS DE 30 SEGUNDOS
											
										BEGIN
											SELECT STATUS INTO cAux1 FROM RDIG003
												WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;

											UPDATE RDIG003 SET STATUS = '4' 
												WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;

										EXCEPTION
											WHEN RECO_LOCK THEN 
												null;
											WHEN NO_DATA_FOUND THEN 
												null;
											WHEN OTHERS THEN 
												null;
										END;			
									EXCEPTION
										WHEN RECO_LOCK THEN 
											null;
										WHEN NO_DATA_FOUND THEN 
											null;
										WHEN OTHERS THEN 
											null;
									END;			
								END IF;							

							EXCEPTION
								WHEN NO_DATA_FOUND THEN 
									null;
								WHEN OTHERS THEN 
									null;
							END;			

						-- OUTRAS BIOMETRIAS
						ELSIF (r.BIO_TIPO != 'A') then
							BEGIN
								SELECT STATUS INTO cAux FROM RDIG004
									WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP AND (STATUS = '3' OR STATUS = '2');

								IF (cAux = '3') then		-- SITUA��O PENDENTE 
									BEGIN
										SELECT STATUS INTO cAux1 FROM RDIG004
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;

										UPDATE RDIG004 SET STATUS = '4' 
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;

									EXCEPTION
										WHEN RECO_LOCK THEN 
											null;
										WHEN NO_DATA_FOUND THEN 
											null;
										WHEN OTHERS THEN 
											null;
									END;			

								ELSE	 -- STATUS = '2' : PODE ESTAR NA SITUA��O DEXECUTANDO E NAO OBTEVE RESPOSTA
									-- PROCURA EM RDIG002 SE O EQUIPAMENTO EST� MAIS DE 30 SEGUNDOS ESPERANDO RESPOSTA, ENTAO PODE TIRAR.
									BEGIN
										SELECT STATUS into cAux1 from RDIG002 
											where END_IP = r.END_IP and 
												  STATUS = '2' and 
												  (DATA_LOAD + ( 30 / 24 / 3600 )  < sysdate) and 
												  ((BIO_TIPO != '6') and (BIO_TIPO != '7') and (BIO_TIPO != '8') and (BIO_TIPO != 'A')) ;		-- O COMANDO FOI FEITO HA MAIS DE 30 SEGUNDOS
											
										BEGIN
											SELECT STATUS INTO cAux1 FROM RDIG004
												WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;

											UPDATE RDIG004 SET STATUS = '4' 
												WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;

										EXCEPTION
											WHEN RECO_LOCK THEN 
												null;
											WHEN NO_DATA_FOUND THEN 
												null;
											WHEN OTHERS THEN 
												null;
										END;			
									EXCEPTION
										WHEN RECO_LOCK THEN 
											null;
										WHEN NO_DATA_FOUND THEN 
											null;
										WHEN OTHERS THEN 
											null;
									END;			
								END IF;							

							EXCEPTION
								WHEN NO_DATA_FOUND THEN 
									null;
								WHEN OTHERS THEN 
									null;
							END;			

						END IF;
						
						-- FIM NOVO    FIM NOVO    FIM NOVO    FIM NOVO    FIM NOVO    
						-- **********************************************************************

					END LOOP;
					
					INSERT INTO TMP_NREPDIGATV (IFUNC, GRUPO, BIO_TIPO) VALUES (l_ifunc(indx), l_grupo(indx), l_biotipo(indx));
			
				END IF;		
			END IF;
			
			-- atualiza estado para tratado em REPNDIGAUTO000, SE N�O encontrou equipamento pertencente ao grupo e cai fora para tratar proximo funcionario
			UPDATE REPNDIGAUTO000 SET STATUS = '0' 			
				WHERE IFUNC = l_ifunc(indx) and 
					BIO_TIPO = l_biotipo(indx) and 
					to_number(GRUPO) = to_number(l_grupo(indx));

			
		END LOOP;
	END;



	-- trata SAGEM
	-- **************** trata os novos ifuncs X Eqptos  (resultantes da tabela TMP_REPSAG001 - INCLUSAO)

	SELECT count(*) into nCont from TMP_REPSAG001 where STATUS = '3';	
	IF (nCont != 0) then
		-- coloca o codin na tab. RDIG002 (CARGA LISTA) o codin n�o existir
		INSERT into RDIG002 (END_IP, STATUS, BIO_TIPO)
			select distinct end_ip, '0', '6'
			from TMP_REPSAG001
			where TMP_REPSAG001.end_ip not in ( select end_ip from RDIG002 ) and 
					TMP_REPSAG001.STATUS = '3';
		
		-- insere ifunc-rep em tab. RDIG001, se n�o existir em tab.
		OPEN cur_tmpautoSAG001;
		LOOP
			FETCH cur_tmpautoSAG001 into xc_ifunc, xc_endip, xc_status;
			EXIT when cur_tmpautoSAG001%NOTFOUND;

			BEGIN
				SELECT STATUS INTO cAux FROM RDIG001 
					WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip FOR UPDATE NOWAIT;
				

				UPDATE RDIG001 SET STATUS = '1' 
					WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN 
					INSERT INTO RDIG001 (IFUNC, END_IP, STATUS, BIO_TIPO) 
								 VALUES (xc_ifunc, xc_endip, '1', '6');
								 
				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;			
								 
			-- deleta o ifunc da tabela de exclusao para o rep especifico do grupo
			BEGIN
				SELECT STATUS INTO cAux  FROM RDIG101 
					WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1') FOR UPDATE NOWAIT;	

				DELETE FROM RDIG101 WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1');	-- DELETA DA TABELA DE EXCLUSAO
				
			EXCEPTION
				WHEN NO_DATA_FOUND THEN null;
				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;			
				
		END LOOP;
		CLOSE cur_tmpautoSAG001;
	END IF;

	
	-- **************** trata os novos ifuncs X Eqptos  (resultantes da tabela TMP_REPSAG002 - EXCLUSAO)

	SELECT count(*) into nCont from TMP_REPSAG002 where STATUS = '8';	
	IF (nCont != 0) then
		-- coloca o codin na tab. RDIG102 (EXCLUSAO) o codin n�o existir
		INSERT INTO RDIG102 (END_IP, STATUS, BIO_TIPO) 
			select distinct end_ip, '0', '6'
			from TMP_REPSAG002
			where TMP_REPSAG002.end_ip not in ( select end_ip from RDIG102 ) and 
					TMP_REPSAG002.STATUS = '8';
	
		-- insere ifunc-rep em tab. REPAUTO012, se n�o existir em tab.
		OPEN cur_tmpautoSAG002;
		LOOP
			FETCH cur_tmpautoSAG002 into xc_ifunc, xc_endip, xc_status;
			EXIT when cur_tmpautoSAG002%NOTFOUND;

			BEGIN
				SELECT STATUS INTO cAux FROM RDIG101 
					WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip FOR UPDATE NOWAIT;
				
				UPDATE RDIG101 SET STATUS = '1' 
					WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN 
					INSERT INTO RDIG101 (IFUNC, END_IP, STATUS, BIO_TIPO) 
								 VALUES (xc_ifunc, xc_endip, '1', '6');
								 
				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;			

		
			-- deleta o ifunc da tabela de INclusao para o rep especifico do grupo
			BEGIN
				SELECT STATUS INTO cAux  FROM RDIG001 
					WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1') FOR UPDATE NOWAIT;	

				DELETE FROM RDIG001 WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1');	-- DELETA DA TABELA DE INCLUSAO
				
			EXCEPTION
				WHEN NO_DATA_FOUND THEN null;
				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;			
			
		END LOOP;
		CLOSE cur_tmpautoSAG002;
	END IF;


	-- trata SUPREMA
	-- **************** trata os novos ifuncs X Eqptos  (resultantes da tabela TMP_REPSUP001 - INCLUSAO)
	SELECT count(*) into nCont from TMP_REPSUP001 where STATUS = '3';	
	IF (nCont != 0) then
		-- coloca o codin na tab. RDIG002 (CARGA LISTA) o codin n�o existir
		INSERT into RDIG002 (END_IP, STATUS, BIO_TIPO)
			select distinct end_ip, '0', '8'
			from TMP_REPSUP001
			where TMP_REPSUP001.end_ip not in ( select end_ip from RDIG002 ) and 
					TMP_REPSUP001.STATUS = '3';
		
		-- insere ifunc-rep em tab. RDIG003, se n�o existir em tab.
		OPEN cur_tmpautoSUP001;
		LOOP
			FETCH cur_tmpautoSUP001 into xc_ifunc, xc_endip, xc_status;
			EXIT when cur_tmpautoSUP001%NOTFOUND;

			BEGIN
				SELECT STATUS INTO cAux FROM RDIG003 
					WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip FOR UPDATE NOWAIT;
				

				UPDATE RDIG003 SET STATUS = '1' 
					WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN 
					INSERT INTO RDIG003 (IFUNC, END_IP, STATUS, BIO_TIPO) 
								 values (xc_ifunc, xc_endip, '1', '8');
								 
				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;			

			-- deleta o ifunc da tabela de exclusao para o rep especifico do grupo
			BEGIN
				SELECT STATUS INTO cAux  FROM RDIG103 
					WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1') FOR UPDATE NOWAIT;	

				DELETE FROM RDIG103 WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1');	-- DELETA DA TABELA DE EXCLUSAO
				
			EXCEPTION
				WHEN NO_DATA_FOUND THEN null;
				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;			
			
		END LOOP;
		CLOSE cur_tmpautoSUP001;
	END IF;

	
	-- **************** trata os novos ifuncs X Eqptos  (resultantes da tabela TMP_REPSUP002 - EXCLUSAO)

	SELECT count(*) into nCont from TMP_REPSUP002 where STATUS = '8';	
	IF (nCont != 0) then
		-- coloca o codin na tab. RDIG102 (EXCLUSAO) o codin n�o existir
		INSERT INTO RDIG102 (END_IP, STATUS, BIO_TIPO) 
			select distinct end_ip, '0', '8'
			from TMP_REPSUP002
			where TMP_REPSUP002.end_ip not in ( select end_ip from RDIG102 ) and 
					TMP_REPSUP002.STATUS = '8';
	
		-- insere ifunc-rep em tab. RDIG103, se n�o existir em tab.
		OPEN cur_tmpautoSUP002;
		LOOP
			FETCH cur_tmpautoSUP002 into xc_ifunc, xc_endip, xc_status;
			EXIT when cur_tmpautoSUP002%NOTFOUND;

			BEGIN
				SELECT STATUS INTO cAux FROM RDIG103 
					WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip FOR UPDATE NOWAIT;
				
				UPDATE RDIG103 SET STATUS = '1' 
					WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN 
					INSERT INTO RDIG103 (IFUNC, END_IP, STATUS, BIO_TIPO) 
								 VALUES (xc_ifunc, xc_endip, '1', '8');
								 
				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;			

			
			-- deleta o ifunc da tabela de INclusao para o rep especifico do grupo
			BEGIN
				SELECT STATUS INTO cAux  FROM RDIG003 
					WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1') FOR UPDATE NOWAIT;	

				DELETE FROM RDIG003 WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1');	-- DELETA DA TABELA DE INCLUSAO
				
			EXCEPTION
				WHEN NO_DATA_FOUND THEN null;
				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;			
			
		END LOOP;
		CLOSE cur_tmpautoSUP002;
	END IF;


	-- trata VIRDI/ outras biometrias
	-- **************** trata os novos ifuncs X Eqptos  (resultantes da tabela TMP_REPVRD001 - INCLUSAO)
	SELECT count(*) into nCont from TMP_REPVRD001 where STATUS = '3';	
	IF (nCont != 0) then
		-- coloca o codin na tab. RDIG002 (CARGA LISTA) o codin n�o existir
		INSERT into RDIG002 (END_IP, STATUS, BIO_TIPO)
			--select distinct end_ip, '0', '9'
			select distinct end_ip, '0', bio_tipo  
			from TMP_REPVRD001
			where TMP_REPVRD001.end_ip not in ( select end_ip from RDIG002 ) and 
					TMP_REPVRD001.STATUS = '3';
		
		-- insere ifunc-rep em tab. RDIG004, se n�o existir em tab.
		OPEN cur_tmpautoVRD001;
		LOOP
			FETCH cur_tmpautoVRD001 into xc_ifunc, xc_endip, xc_status, xc_biotipo;
			EXIT when cur_tmpautoVRD001%NOTFOUND;

			BEGIN
				SELECT STATUS INTO cAux FROM RDIG004 
					WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip FOR UPDATE NOWAIT;
				

				UPDATE RDIG004 SET STATUS = '1' 
					WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN 
					INSERT INTO RDIG004 (IFUNC, END_IP, STATUS, BIO_TIPO) 
								 values (xc_ifunc, xc_endip, '1', xc_biotipo);
								 
				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;			

			-- deleta o ifunc da tabela de exclusao para o rep especifico do grupo
			BEGIN
				SELECT STATUS INTO cAux  FROM RDIG104 
					WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1') FOR UPDATE NOWAIT;	

				DELETE FROM RDIG104 WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1');	-- DELETA DA TABELA DE EXCLUSAO
				
			EXCEPTION
				WHEN NO_DATA_FOUND THEN null;
				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;			
			
		END LOOP;
		CLOSE cur_tmpautoVRD001;
	END IF;

	
	-- **************** trata os novos ifuncs X Eqptos  (resultantes da tabela TMP_REPVRD002 - EXCLUSAO)

	SELECT count(*) into nCont from TMP_REPVRD002 where STATUS = '8';	
	IF (nCont != 0) then
		-- coloca o codin na tab. RDIG102 (EXCLUSAO) o codin n�o existir
		INSERT INTO RDIG102 (END_IP, STATUS, BIO_TIPO) 
			--select distinct end_ip, '0', '9'
			select distinct end_ip, '0', bio_tipo 
			from TMP_REPVRD002
			where TMP_REPVRD002.end_ip not in ( select end_ip from RDIG102 ) and 
					TMP_REPVRD002.STATUS = '8';
	
		-- insere ifunc-rep em tab. RDIG104, se n�o existir em tab.
		OPEN cur_tmpautoVRD002;
		LOOP
			FETCH cur_tmpautoVRD002 into xc_ifunc, xc_endip, xc_status, xc_biotipo;
			EXIT when cur_tmpautoVRD002%NOTFOUND;

			BEGIN
				SELECT STATUS INTO cAux FROM RDIG104 
					WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip FOR UPDATE NOWAIT;
				
				UPDATE RDIG104 SET STATUS = '1' 
					WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN 
					INSERT INTO RDIG104 (IFUNC, END_IP, STATUS, BIO_TIPO) 
								 VALUES (xc_ifunc, xc_endip, '1', xc_biotipo);
								 
				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;			

			
			-- deleta o ifunc da tabela de INclusao para o rep especifico do grupo
			BEGIN
				SELECT STATUS INTO cAux  FROM RDIG004 
					WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1') FOR UPDATE NOWAIT;	

				DELETE FROM RDIG004 WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1');	-- DELETA DA TABELA DE INCLUSAO
				
			EXCEPTION
				WHEN NO_DATA_FOUND THEN null;
				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;			
			
		END LOOP;
		CLOSE cur_tmpautoVRD002;
	END IF;



	COMMIT;

END Prep_RepDigit5;
/

