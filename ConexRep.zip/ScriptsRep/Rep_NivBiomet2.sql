CREATE OR REPLACE FUNCTION sqlrnivel_biomet2 (cEndIp in varchar2, cBlueb in varchar2, cCodin in varchar2, cBioTipo out char) 
   RETURN NUMBER IS
   Ret    NUMBER;
   cNivel CHAR(2);
BEGIN
    Ret := 2;
    BEGIN
    	select BIO_TIPO into cBioTipo
			from DAT07
			where END_IP = cEndIp and BLUEB = cBlueb and CODIN = cCodin;
		
    EXCEPTION
		WHEN NO_DATA_FOUND then 
			cBioTipo := '0';
		WHEN OTHERS then 
			cBioTipo := '0';
    END;

		
	if (cBioTipo = '4') or (cBiotipo = '5') then
		BEGIN
			select NIVEL into cNivel
				from GEOMOK001
				where  END_IP = cEndIp and BLUEB = cBlueb and CODIN = cCodin;
			Ret := to_number(cNivel);
		EXCEPTION
			WHEN NO_DATA_FOUND then Ret := 4;
		END;
	elsif (cBioTipo = '6') or (cBiotipo = '7')  or (cBiotipo = '9') then			-- sagem(6,7), virdi(9)
		BEGIN
			select NIVELSAG into cNivel
				from GEOMOK001
				where  END_IP = cEndIp and BLUEB = cBlueb and CODIN = cCodin;
			Ret := to_number(cNivel);
		EXCEPTION
			WHEN NO_DATA_FOUND then Ret := 5;
		END;
	elsif (cBioTipo = '8') OR (cBioTipo = 'C') then 		-- suprema (8), suprema iso viavarejo(C)
		BEGIN
			select NIVEL into cNivel
				from GEOMOK001
				where  END_IP = cEndIp and BLUEB = cBlueb and CODIN = cCodin;
			Ret := to_number(cNivel);
		EXCEPTION
			WHEN NO_DATA_FOUND then Ret := 3;
		END;
		
	else
		Ret := 0;
	end if;

    return (Ret);

END sqlrnivel_biomet2;
/

