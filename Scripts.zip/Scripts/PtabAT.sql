drop synonym Controle;
create synonym Controle for telemat.controle;

drop synonym cp_bn;
create synonym cp_bn for telemat.cp_bn;

drop synonym cp_nb;
create synonym cp_nb for telemat.cp_nb;

drop synonym Dat07;
create synonym Dat07 for telemat.Dat07;

drop synonym Dat08;
create synonym Dat08 for telemat.Dat08;

drop synonym DAT09;
create synonym DAT09 for telemat.DAT09;

drop synonym Dam00;
create synonym Dam00 for telemat.Dam00;

drop synonym DAM01;
create synonym DAM01 for telemat.DAM01;

drop synonym DAM02;
create synonym DAM02 for telemat.DAM02;

drop synonym FXHORARIA;
CREATE SYNONYM FXHORARIA for telemat.fxhoraria;

DROP SYNONYM FERIADO;
CREATE SYNONYM FERIADO for telemat.feriado;

drop synonym teleseq;
create synonym teleseq for telemat.teleseq;

--drop synonym seqsemaf;
--create synonym seqsemaf for telemat.seqsemaf;

drop synonym TERMBENEF;
CREATE SYNONYM TERMBENEF for telemat.TERMBENEF;

DROP SYNONYM TABGRPSETFX;
CREATE SYNONYM TABGRPSETFX FOR telemat.TABGRPSETFX;

DROP SYNONYM TABALARME;
CREATE SYNONYM TABALARME FOR telemat.TABALARME;

DROP SYNONYM SITENTRADA;
CREATE SYNONYM SITENTRADA FOR telemat.SITENTRADA;


drop synonym BENEFICIO;
CREATE SYNONYM BENEFICIO for telemat.BENEFICIO;

drop synonym LBENEF00;
CREATE SYNONYM LBENEF00 for telemat.LBENEF00;

drop synonym LBENEF01;
CREATE SYNONYM LBENEF01 for telemat.LBENEF01;

drop synonym LBENEF02;
CREATE SYNONYM LBENEF02 for telemat.LBENEF02;

drop synonym LBENEF03;
CREATE SYNONYM LBENEF03 for telemat.LBENEF03;

drop synonym LBENEF04;
CREATE SYNONYM LBENEF04 for telemat.LBENEF04;

drop synonym LBENEF05;
CREATE SYNONYM LBENEF05 for telemat.LBENEF05;

drop synonym LBENEF06;
CREATE SYNONYM LBENEF06 for telemat.LBENEF06;

drop synonym LBENEF07;
CREATE SYNONYM LBENEF07 for telemat.LBENEF07;

drop synonym LBENEF08;
CREATE SYNONYM LBENEF08 for telemat.LBENEF08;

drop synonym LBENEF09;
CREATE SYNONYM LBENEF09 for telemat.LBENEF09;

drop synonym LBENEF10;
CREATE SYNONYM LBENEF10 for telemat.LBENEF10;

drop synonym LBENEF11;
CREATE SYNONYM LBENEF11 for telemat.LBENEF11;

drop synonym LBENEF12;
CREATE SYNONYM LBENEF12 for telemat.LBENEF12;

drop synonym LBENEF13;
CREATE SYNONYM LBENEF13 for telemat.LBENEF13;

drop synonym LBENEF14;
CREATE SYNONYM LBENEF14 for telemat.LBENEF14;

drop synonym LBENEF15;
CREATE SYNONYM LBENEF15 for telemat.LBENEF15;

drop synonym LBENEF16;
CREATE SYNONYM LBENEF16 for telemat.LBENEF16;

drop synonym LBENEF17;
CREATE SYNONYM LBENEF17 for telemat.LBENEF17;

drop synonym LBENEF18;
CREATE SYNONYM LBENEF18 for telemat.LBENEF18;

drop synonym LBENEF19;
CREATE SYNONYM LBENEF19 for telemat.LBENEF19;

drop synonym LBENEF20;
CREATE SYNONYM LBENEF20 for telemat.LBENEF20;

drop synonym LBENEF21;
CREATE SYNONYM LBENEF21 for telemat.LBENEF21;

drop synonym LBENEF22;
CREATE SYNONYM LBENEF22 for telemat.LBENEF22;

drop synonym LBENEF23;
CREATE SYNONYM LBENEF23 for telemat.LBENEF23;

drop synonym TABDEV;
CREATE SYNONYM TABDEV for telemat.TABDEV;

drop synonym INFOMAT;
CREATE SYNONYM INFOMAT for telemat.INFOMAT;

drop synonym BLOQSAD;
CREATE SYNONYM BLOQSAD for telemat.BLOQSAD;

drop synonym BLOQTIPO;
CREATE SYNONYM BLOQTIPO for telemat.BLOQTIPO;

drop synonym EXCESAD;
CREATE SYNONYM EXCESAD for telemat.EXCESAD;

drop synonym EXCETIPO;
CREATE SYNONYM EXCETIPO for telemat.EXCETIPO;

drop synonym CONTFUNC;
CREATE SYNONYM CONTFUNC for telemat.CONTFUNC;

drop synonym ATUALI;
CREATE SYNONYM ATUALI for telemat.ATUALI;

drop synonym LIMPATU;
CREATE SYNONYM LIMPATU for telemat.LIMPATU;

drop synonym CONTVEI;
CREATE SYNONYM CONTVEI for telemat.CONTVEI;

drop synonym PENDSMART;
CREATE SYNONYM PENDSMART for telemat.PENDSMART;

drop synonym EXPIREATU;
CREATE SYNONYM EXPIREATU for telemat.EXPIREATU;

drop synonym CREDLOG;
CREATE SYNONYM CREDLOG for telemat.CREDLOG;

drop synonym VEICULO;
CREATE SYNONYM VEICULO for telemat.VEICULO;

drop synonym SITCOLETOR;
create synonym SITCOLETOR for telemat.SITCOLETOR;

drop synonym PEND_ON001;
create synonym PEND_ON001 for telemat.PEND_ON001;

drop synonym PEND_ON002ON;
create synonym PEND_ON002ON for telemat.PEND_ON002ON;

drop synonym PEND_ON002OFF;
create synonym PEND_ON002OFF for telemat.PEND_ON002OFF;

drop synonym PEND_ON002LPZ;
create synonym PEND_ON002LPZ for telemat.PEND_ON002LPZ;

drop synonym PEND_ON003;
create synonym PEND_ON003 for telemat.PEND_ON003;

drop synonym LOGPEND;
create synonym LOGPEND for telemat.LOGPEND;

drop synonym tmp_listapendencia;
create synonym tmp_listapendencia for telemat.tmp_listapendencia;

drop synonym tmp_codins;
create synonym tmp_codins for telemat.tmp_codins;

