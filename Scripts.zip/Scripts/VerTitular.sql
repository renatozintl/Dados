CREATE OR REPLACE FUNCTION sqlver_TitMat (cMatric VARCHAR2, cTitular IN OUT VARCHAR2)
RETURN NUMBER IS

Retfun NUMBER;
RECO_LOCK EXCEPTION;
PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);


BEGIN

	Retfun := 1;      -- assume que achou matricula
	BEGIN
		SELECT TITULAR INTO  cTitular 
			FROM CONTROLE WHERE ICARD = cMatric;
		if (cTitular is Null) then
			cTitular := '            ';		-- 12 espacos
		end if;	

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			cTitular := '            ';		-- 12 espacos
			Retfun := 0;

		WHEN OTHERS THEN
			cTitular := '            ';		-- 12 espacos
			Retfun := -1;
	END;
	return (Retfun);
	
END sqlver_TitMat;
/


