CREATE OR REPLACE  PROCEDURE ANTEPREP3_RSAGEM (nQtd NUMBER) 
IS

TYPE icard_type IS TABLE OF CONTDIG_SAGEM.icard%TYPE 
	INDEX BY binary_integer;
TYPE statusrep_type IS TABLE OF CONTDIG_SAGEM.status_rep%TYPE 
	INDEX BY binary_integer;
	
l_icard icard_type;
l_statusrep statusrep_type;

total number;

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock,-54);  -- erro quando registro lockado 
tem_deadlock EXCEPTION; 
PRAGMA EXCEPTION_INIT (tem_deadlock, -60); 
	
BEGIN

	SELECT ICARD, STATUS_REP 
		BULK COLLECT INTO l_icard, l_statusrep  
	from 
		CONTDIG_SAGEM 
	where 
		STATUS_REP = '1' or STATUS_REP = '3' or STATUS_REP = '8';
		
	total := l_icard.count;
	
	-- NOVO
	--IF (total > 5) then
	--	total := 5;
	IF (total > nQtd) then
		total := nQtd;
	END IF;
	
	-- ******************************************************************
	-- PARA TODOS AS BIOMETRIAS  CADASTRADOS/INSERIDOS/DELETADOS
	FOR indx IN 1 .. total     
	LOOP
		Auxtrg_repDig2 (l_icard(indx), l_statusrep(indx), '6');
		
		UPDATE CONTDIG_SAGEM SET STATUS_REP = '0' 
				where ICARD = l_icard(indx);
	
	END LOOP;
	
	COMMIT;
	
end ANTEPREP3_RSAGEM;
/
