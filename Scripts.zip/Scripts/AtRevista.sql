CREATE OR REPLACE FUNCTION sqlat_bloq_revista (cMatric in VARCHAR2, Posic in VARCHAR2) 
   RETURN NUMBER IS
      VarAux VARCHAR2(12);
      reco_lock EXCEPTION;
      PRAGMA EXCEPTION_INIT (reco_lock, -54);  
      Retorno NUMBER;
BEGIN
      Retorno := 0;      

   BEGIN
      SELECT Icard into VarAux from Controle 
		WHERE rowid = chartorowid (Posic) for update nowait;
		 
      UPDATE CONTROLE 
	 	SET BloqRev = '1'
	 		WHERE rowid = chartorowid (Posic);

      COMMIT;

   EXCEPTION
      WHEN reco_lock THEN           -- reg. ja'lockado
	 Retorno := -3;
      WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
	 Retorno := 0;
      WHEN OTHERS THEN
	 Retorno := -1;
   END;
   return (Retorno);
END sqlat_bloq_revista;
/


