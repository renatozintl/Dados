CREATE OR REPLACE  PROCEDURE G3G5_Prep3_Palmv
IS

TYPE icard_type IS TABLE OF PALMV001.icard%TYPE 
	INDEX BY binary_integer;
TYPE status_type IS TABLE OF PALMV001.st%TYPE 
	INDEX BY binary_integer;
	
l_icard icard_type;
l_status status_type;
p_rec PALMV014%rowtype;

total number;
aux_icard char(12) := '000000000000';
nCont number;
nAchouGrupo number;

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock,-54);  -- erro quando registro lockado 
tem_deadlock EXCEPTION; 
PRAGMA EXCEPTION_INIT (tem_deadlock, -60); 



BEGIN

	-- *************************************************************************
	-- seleciona os ids alterados/inseridos(st = '1')  e excluidos (status = '8') da tabela PALMV001  
	SELECT ICARD, ST 
		BULK COLLECT INTO l_icard, l_status  
	from 
		PALMV001 
	where 
		ST = '1' or ST = '3'  or  ST = '8';		-- 1 = inclusao/alteracao,  3 = alteracao em grupo,   8 = controle.situa = '1' 
		
	total := l_icard.count;


-- OBS:
--PALMV014 - ID X IP PALMV (INCLUSAO DE ID)   
--PALMV015 - ID X IP PALMV (EXCLUSAO DE ID)	

--PALMV004 - IP PALMV (SINALIZACAO DE INCLUSAO DE ID) 
--PALMV005 - IP PALMV (SINALIZACAO DE EXCLUSAO DE ID) 


	-- ******************************************************************
	-- PARA TODOS OS IFUNCS ALTERADOS/INSERIDOS/DELETADOS
	FOR indx IN 1 .. total     
	LOOP
		nAchouGrupo := 0;		-- presupoe q nao tem ICARDfunc x grupo correspondente em tab DAT08 X DAT07
		
		-- *************************************************************************
		-- prepara os ids excluidos (controle.situa = invalido) ou grupos da controle alterados, retirando os PALMVs de todos os equipamentos control PALMVs
		IF (l_status(indx) = '3' or l_status(indx) = '8' ) THEN		-- alterados grupos (3) ou situa invalidos  (8)
		
			-- MONTA temporaria matricula x equipamentos palmvein
			INSERT INTO TMP2_PALMV015 (ICARD, END_CTRLPALMV) 		
				SELECT distinct l_icard(indx), DAT07.end_ip
				FROM DAT07
				WHERE BIO_TIPO = 'A';

			-- ******************************************************************
			-- COMO ESTA EXCLUINDO O FUNCIONARIO DA EMPRESA (CONTROLE.SITUA = '1' INVALIDO), TIRA DA LISTA DE INCLUSAO DE TODOS OS equipamentos PALMVEIN
			-- COMO ALTEROU O GRUPO, TIRA DA LISTA DE INCLUSAO DE TODOS OS equipamentos PALMVEIN

			-- ALTERACAO ABAIXO
			-- VAI DELETAR A MATRICULA DE QUALQUER STATUS PORQUE PODE CAIR NA SITUACAO EM QUE HA INCLUSAO DA MATRICULA, MAS NAO VAI PORQUE O EQUIPAMENTO 'ESTA OCUPADO' (nova resposta do microdimarms).
			-- SE HOUVER POSTERIORMENTE EXCLUSAO DESSA MESMA MATRICULA, DEVE=-SE EXCLUIR A INCLUSAO DESSA MATRICULA DA TABELA

			for c1 in (select rowid from PALMV014 
				--WHERE ICARD = l_icard(indx) AND (STATUS = '0' OR STATUS = '1') )
				WHERE ICARD = l_icard(indx) )
			loop
				BEGIN
					select * into p_rec from PALMV014 where rowid = c1.rowid for update nowait;		
					delete from PALMV014 where rowid = c1.rowid;

				EXCEPTION
					when reco_lock then NULL ;
					when tem_deadlock then NULL ;
					when NO_DATA_FOUND then NULL;
					when OTHERS then NULL;
				END;
			end loop;					

			-- ******************************************************************
			-- obs : nao excluo das temporarias de exclusao porque elas estao vazias

		END IF;
		
		
		IF (l_status(indx) = '1' or l_status(indx) = '3' ) THEN		-- incluido/alterado PALMV (1)   ou   alterados grupos (3) 
					
			-- ******************************************************************
			-- para todos icards q alteraram PALMV, distribui nos control PALMVs de acordo com o grupo cadastrado em 
			-- CONTROLE, DAT07,DAT08, MATCODIN

			INSERT into TMP2_PALMV014 (ICARD, END_CTRLPALMV)
				SELECT distinct l_icard(indx),  end_iP
				FROM 
					(
					-- seleciona os equipamentos que fazem parte dos grupos do usu�rio
					SELECT distinct l_icard(indx),  dat07.end_iP
					from
						dat07, dat08
					where
						dat07.end_ip <> '000.000.000.000' and
					  	TO_NUMBER(dat08.grupo) in (
							select TO_NUMBER(grupo) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1')		-- era (SITUA = '0' OR SITUA = '7'), trocou para validar tbem se situa = '8'
							  union
							select TO_NUMBER(grupo1) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1')
							  union	
							select TO_NUMBER(grupo2) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1')
							  union
							select TO_NUMBER(grupo3) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1')
							  union
							select TO_NUMBER(grupo_sab) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1')
							  union
							select TO_NUMBER(grupo_dom) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1')
							  union
							select TO_NUMBER(grupo_fer) from CONTROLE where ICARD = l_icard(indx) AND (SITUA <> '1')
							  union
							select TO_NUMBER(A.grupo) from MATNGRUPOS A, CONTROLE B where A.ICARD = l_icard(indx) AND B.ICARD = l_icard(indx) AND (B.SITUA <> '1')
							  union
							select TO_NUMBER(A.grupo) from MATGRUPO A, CONTROLE B where A.ICARD = l_icard(indx) AND B.ICARD = l_icard(indx) AND (B.SITUA <> '1') AND (B.VER_DIGIT <> '1')
							) and 
						
							
					  	TO_NUMBER(dat07.laces) = TO_NUMBER(dat08.laces) and
					  	TO_NUMBER(dat07.planta) = TO_NUMBER(dat08.planta) and
					  	dat07.bio_tipo = 'A'
					
					UNION
					 
					-- seleciona os equipamentos que est�o em tab.MATCODIN pertencete ao usu�rio
					SELECT distinct l_icard(indx),  dat07.end_ip
					from 
						dat07, matcodin
					where 
						matcodin.icard = l_icard(indx) 	and
						matcodin.end_ip <> '000.000.000.000' and 
						matcodin.end_ip = dat07.end_ip and 
				   		dat07.bio_tipo = 'A'
					);

					  
			-- para quem incluiu/alterou digital (status 1) ou mudou de grupo (status 3)				
			--IF (l_status(indx) = '3') THEN  
			IF (l_status(indx) = '1' OR l_status(indx) = '3') THEN  
				-- ******************************************************************
				-- deve-se excluir da tabela de exclusao temporaria os control PALMV que fazem parte do novo grupo
			
				DELETE FROM TMP2_PALMV015
				WHERE EXISTS
					(SELECT TMP2_PALMV014.icard 
						FROM TMP2_PALMV014
						WHERE TMP2_PALMV014.icard = TMP2_PALMV015.icard and
								TMP2_PALMV014.END_CTRLPALMV = TMP2_PALMV015.END_CTRLPALMV  and
								TMP2_PALMV014.icard = l_icard(indx)
					);

				-- ******************************************************************
					-- deve-se excluir da tabela de exclusao final os control PALMV que fazem parte do novo grupo

				-- ALTERACAO ABAIXO				
				-- VAI DELETAR A MATRICULA DE QUALQUER STATUS PORQUE PODE CAIR NA SITUACAO EM QUE HA EXCLUSAO DA MATRICULA, MAS NAO VAI PORQUE O EQUIPAMENTO ESTA OCUPADO.
				-- SE HOUVER POSTERIORMENTE INCLUSAO DESSA MESMA MATRICULA, DEVE=-SE EXCLUIR A EXCLUSAO DESSA MATRICULA DA TABELA
				for c1 in (select rowid from PALMV015 
					--WHERE ICARD = l_icard(indx) AND (STATUS = '0' OR STATUS = '1') )
					WHERE ICARD = l_icard(indx) )
				loop
					BEGIN
						select * into p_rec from PALMV015 where rowid = c1.rowid for update nowait;		
						delete from PALMV015 where rowid = c1.rowid;

					EXCEPTION
						when reco_lock then NULL ;
						when tem_deadlock then NULL ;
						when NO_DATA_FOUND then NULL;
						when OTHERS then NULL;
					END;
				end loop;					
								
			END IF;
		END IF;
				
		-- ****************************************************	
		-- PREPARA TABELA DE INCLUSAO DE PALMVEIN
		SELECT count(*) into nCont from TMP2_PALMV014;					
		IF (nCont != 0) then
			-- insere na tabela final PALMV014  os ID x CONTROLPALMV e STATUS de carga (0 / 1= a carregar)
			FOR x in (select ICARD, END_CTRLPALMV from TMP2_PALMV014) loop
				BEGIN
					select icard into aux_icard from PALMV014 
						WHERE ICARD = x.icard AND
							END_CTRLPALMV = x.end_ctrlPALMV for update nowait;

					UPDATE PALMV014 SET STATUS = '1' 
						WHERE  ICARD = x.icard AND
							   END_CTRLPALMV = x.end_ctrlPALMV;
				EXCEPTION
					WHEN NO_DATA_FOUND THEN
						INSERT INTO PALMV014 (ICARD, END_CTRLPALMV, STATUS) 
						values (x.icard, x.end_ctrlPALMV, '1');
				END;
			END LOOP;
				
			nAchouGrupo := 1;

			-- coloca o CONTROLPALMV na tab. PALMV004 (CARGA LISTA) o ControlPALMV q n�o existir
			insert into PALMV004 (END_CTRLPALMV, DATA_LOAD, STATUS)
				select distinct END_CTRLPALMV, sysdate(), '0'
				from
					PALMV014
				where
					END_CTRLPALMV not in ( select END_CTRLPALMV from PALMV004 );


			-- atualiza status da matricula, como tratado
			update PALMV001 SET ST = '0' 
				where ICARD = l_icard(indx);

		END IF;

		-- ****************************************************
		-- PREPARA TABELA DE EXCLUSAO DE PALMVEIN
		SELECT count(*) into nCont from TMP2_PALMV015;					
		IF (nCont != 0) then
			-- insere na tabela final PALMV015  os ID x CONTROLPALMV e STATUS de carga (0 / 1= a carregar)
			FOR x in (select ICARD, END_CTRLPALMV from TMP2_PALMV015) loop
				BEGIN
					select icard into aux_icard from PALMV015 
						WHERE ICARD = x.icard AND
							END_CTRLPALMV = x.end_ctrlPALMV for update nowait;

					UPDATE PALMV015 SET STATUS = '1' 
						WHERE  ICARD = x.icard AND
							   END_CTRLPALMV = x.end_ctrlPALMV;
				EXCEPTION
					WHEN NO_DATA_FOUND THEN
						INSERT INTO PALMV015 (ICARD, END_CTRLPALMV, STATUS) 
						values (x.icard, x.end_ctrlPALMV, '1');
				END;
			END LOOP;

			nAchouGrupo := 1;
				
			-- coloca o CONTROLPALMV na tab. PALMV005 (CARGA LISTA) o ControlPALMV q n�o existir
			insert into PALMV005 (END_CTRLPALMV, DATA_LOAD, STATUS)
				select distinct END_CTRLPALMV, sysdate(), '0'
				from
					PALMV015
				where
					END_CTRLPALMV not in ( select END_CTRLPALMV from PALMV005 );
		END IF;

		-- atualiza status da matricula, como tratado
		IF (nAchouGrupo = 1) THEN 
			update PALMV001 SET ST = '0' 
				where ICARD = l_icard(indx);
		END IF;
		
		COMMIT;	

	END LOOP;
	
end G3G5_Prep3_Palmv;
/
