CREATE OR REPLACE FUNCTION sqlident_VERI_niv_template_tcp (MATRIC VARCHAR2,  cNivel IN OUT VARCHAR2)
   RETURN NUMBER IS
      Retfun NUMBER;
      RECO_LOCK EXCEPTION;
      PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);
      AUX VARCHAR2(15);
      Alt NUMBER;
      Pad NUMBER;

BEGIN

   Retfun := 1;      -- assume que achou matricula
   BEGIN
       SELECT NIVEL
       INTO   cNivel 
       FROM CONTDIG_VERI WHERE ICARD = MATRIC;


   EXCEPTION
	WHEN NO_DATA_FOUND THEN
		Retfun := 0;
	WHEN OTHERS THEN
		Retfun := -1;
   END;
   return (Retfun);
END sqlident_VERI_niv_template_tcp;
/


