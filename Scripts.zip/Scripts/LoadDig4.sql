CREATE or REPLACE FUNCTION sqlload_listadig4 (cMatric in VARCHAR2, cEndIp in VARCHAR2, cStatus in VARCHAR2, cErro in VARCHAR2) 
RETURN NUMBER IS

Ret NUMBER;
cAux VARCHAR2(12);
cAuxIp VARCHAR2(15);
cBioTipo VARCHAR2(5);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

BEGIN

	Ret := 0;
	cBioTipo := '0';
	
	BEGIN
		SELECT BIO_TIPO into cBioTipo FROM DIG002
			WHERE END_IP = cEndIp FOR update nowait;
	
		UPDATE DIG002 SET DATA_LOAD = sysdate 
			WHERE END_IP = cEndIp;
			
	
	EXCEPTION
		WHEN NO_DATA_FOUND then 
			Ret := 0;
		WHEN reco_lock then
			Ret := -1;
		WHEN OTHERS then
			Ret := -1;
	END;
	
				  
	IF (cBioTipo = '6' or cBioTipo = '7') then		-- (SAGEM)
		BEGIN
			SELECT Icard into cAux FROM DIG001 
				where ICARD = cMatric and
					  END_IP = cEndIp FOR update nowait;

			UPDATE DIG001 SET STATUS = cStatus 
				where ICARD = cMatric and
					  END_IP = cEndIp;


			EXCEPTION
				WHEN NO_DATA_FOUND then 
					Ret := 0;
				WHEN reco_lock then
					Ret := -1;
				WHEN OTHERS then
					Ret := -1;
			END;

	ELSE 
		IF (cBioTipo = '8') then		-- BIOTIPO = '8' (TSI1)
			BEGIN
				SELECT Icard into cAux FROM DIG003 
					where ICARD = cMatric and
						  END_IP = cEndIp FOR update nowait;

				UPDATE DIG003 SET STATUS = cStatus 
					where ICARD = cMatric and
						  END_IP = cEndIp;

			EXCEPTION
				WHEN NO_DATA_FOUND then 
					Ret := 0;
				WHEN reco_lock then
					Ret := -1;
				WHEN OTHERS then
					Ret := -1;
			END;

		ELSIF (cBioTipo != '0')   then		-- BIOTIPO PARA OUTRAS BIOMETRIAS. VIRDI BIOTIPO = '9'
			BEGIN
				SELECT Icard into cAux FROM DIG004 
					where ICARD = cMatric and
						  END_IP = cEndIp FOR update nowait;

				UPDATE DIG004 SET STATUS = cStatus 
					where ICARD = cMatric and
						  END_IP = cEndIp;

			EXCEPTION
				WHEN NO_DATA_FOUND then 
					Ret := 0;
				WHEN reco_lock then
					Ret := -1;
				WHEN OTHERS then
					Ret := -1;
			END;
		END IF;		
	END IF;

	-- NOVO
	IF (cStatus = '0') THEN
		INSERT INTO HISTDIG (IFUNC, END_IP, BIO_TIPO, INSEXC, MODO) VALUES (cMatric, cEndIp, cBioTipo, 'I', 'A');		-- TIPO:'I'= INCLUSAO, 'E'=EXCLUSAO; MODO:'A'=AUTOMATICO, 'M'=MANUAL
	ELSE
		--IF (cStatus = '4') THEN 	-- ERRO DE CARGA (devido a memoria cheiia, minucia errada: que nao adianta enviar a digital novamente ao equipamento ), ou nao implementado
			INSERT INTO DIGLOAD001 (END_IP, ICARD, BIO_TIPO, NERRO) VALUES (cEndIp, cMatric, cBioTipo, cErro);
		--END IF;
	END IF;
	-- FIM NOVO
	
	COMMIT;
	
		
	RETURN (Ret);
END sqlload_listadig4;
/
