CREATE or REPLACE FUNCTION sqller_RautoExclDigit4 (cEndIp in VARCHAR2, cListaMat in out VARCHAR2, nTotal in NUMBER) 
RETURN NUMBER IS

xCont NUMBER;
cStatus VARCHAR2(1);
cBio_Tipo VARCHAR2(1);
cAux VARCHAR2(12);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

cursor ldigit_cur1 is 					-- RDIGITAIS SUPREMA A SEREM EXCLUIDAS
	SELECT IFUNC, STATUS FROM RDIG101 
		--WHERE END_IP = cEndIp AND STATUS != '0' AND STATUS != '2' 
		WHERE END_IP = cEndIp AND STATUS != '0' 
		order by IFUNC for update of STATUS;

cursor ldigit_cur2 is 					-- DIGITAIS TSI1 A SEREM EXCLUIDAS
	SELECT IFUNC, STATUS FROM RDIG103 
		--WHERE END_IP = cEndIp AND STATUS != '0' AND STATUS != '2' 
		WHERE END_IP = cEndIp AND STATUS != '0' 
		order by IFUNC for update of STATUS;

cursor ldigit_cur3 is 					-- DIGITAIS VIRDI/OUTROS A SEREM EXCLUIDAS
	SELECT IFUNC, STATUS FROM RDIG104 
		--WHERE END_IP = cEndIp AND STATUS != '0' AND STATUS != '2' 
		WHERE END_IP = cEndIp AND STATUS != '0' 
		order by IFUNC for update of STATUS;


begin
    xCont := 0;

	BEGIN
		SELECT STATUS, BIO_TIPO into cStatus, cBio_Tipo 
			FROM RDIG102 
			WHERE END_IP = cEndIp for update nowait;

		IF (cStatus = '1') THEN 
			IF (cBio_Tipo =  '6') or (cBio_Tipo =  '7') THEN		-- SAGEM
				FOR r in ldigit_cur1 LOOP
					cListaMat := cListaMat || r.IFUNC;
					update RDIG101 set STATUS = '2' where current of ldigit_cur1 ;
					xCont := xCont+1;
					--IF (xCont >= 90) THEN 
					--IF (xCont >= 200) THEN 
					IF (xCont >= nTotal) THEN 
						Exit;
					END IF;
				END LOOP;
			ELSIF (cBio_Tipo =  '8') THEN		-- TSI1
				FOR r in ldigit_cur2 LOOP
					cListaMat := cListaMat || r.IFUNC;
					update RDIG103 set STATUS = '2' where current of ldigit_cur2 ;
					xCont := xCont+1;
					--IF (xCont >= 90) THEN 
					--IF (xCont >= 200) THEN 
					IF (xCont >= nTotal) THEN 
						Exit;
					END IF;
				END LOOP;
			--ELSIF (cBio_Tipo =  '9') THEN
			ELSIF (cBio_Tipo !=  '0') THEN		-- VIRDI / OUTROS
				FOR r in ldigit_cur3 LOOP
					cListaMat := cListaMat || r.IFUNC;
					update RDIG104 set STATUS = '2' where current of ldigit_cur3 ;
					xCont := xCont+1;
					--IF (xCont >= 90) THEN 
					--IF (xCont >= 200) THEN 
					IF (xCont >= nTotal) THEN 
						Exit;
					END IF;
				END LOOP;
			END IF;
			
			IF (xCont = 0) THEN
				UPDATE RDIG102 SET STATUS = '0' WHERE END_IP = cEndIp;
			ELSE
				cListaMat := cListaMat || ';';
				UPDATE RDIG102 SET STATUS = '2', DATA_LOAD = SYSDATE WHERE END_IP = cEndIp;
			END IF;

		ELSE
			COMMIT;
			return (0);
		END IF;					

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			xCont := 0;
		WHEN reco_lock THEN
			xCont := 0;
		WHEN OTHERS THEN
			xCont := 0;
	END;
	
	COMMIT;
	return (xCont);
		
END sqller_RautoExclDigit4;
/

