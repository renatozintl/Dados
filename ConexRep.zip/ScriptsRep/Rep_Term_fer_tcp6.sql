CREATE OR REPLACE FUNCTION sqlrcons_term_fer_tcp6 (cEndIp in varchar2, cData in varchar2, cBuffer in out varchar2) 
   RETURN NUMBER IS
   Ret    NUMBER;
   X NUMBER;
   cDescr VARCHAR(30);
   cPlanta char(3);
   nPlanta NUMBER;

BEGIN
    Ret := 0;
    cDescr := ' ';
    cBuffer := '0';
    BEGIN
	--	SELECT Tip_Term|| laces|| bio_tipo|| planta|| rastreador || pos_inihalm || pos_fimhalm || valid_ret || 
	--			valid_saidaMax || toler_antes || toler_apos || tip_leit, planta

	--	SELECT Tip_Term|| laces|| bio_tipo|| planta|| '0' || '0' || '0' || '0' || 
	--			'0' || '00' || '00' || '0', planta

		SELECT bio_tipo,  TO_NUMBER(PLANTA) 
		INTO cBuffer, nPlanta
			FROM DAT07
			WHERE End_Ip = cEndIp;
		Ret := 1;
	
		IF (cData != '000000') THEN
		-- verifica se data e�de Feriado
    	    BEGIN
		    	SELECT desc_fer INTO cDescr
				    FROM FERIADO
			    WHERE (
			    		((to_char(data_fer, 'ddmmrr') = cData) and
				        ((to_number(planta_fer) = nPlanta) or (planta_fer is null) or (to_number(planta_fer) = 0)) ));
		    	Ret := 2;
		    EXCEPTION
				WHEN NO_DATA_FOUND THEN X := 0;
				WHEN OTHERS then Ret := -1;
		    END;
		END IF;	
	EXCEPTION
		WHEN NO_DATA_FOUND then Ret := 0;
		WHEN OTHERS then Ret := -1;
    END;

    return (Ret);
    
END sqlrcons_term_fer_tcp6;
/

