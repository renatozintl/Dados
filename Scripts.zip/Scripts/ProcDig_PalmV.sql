
CREATE OR REPLACE FUNCTION sqlproc_digitPALMV (cMatric in VARCHAR2, cEndIp VARCHAR2, cDados1 out blob, cDados2 out blob, len1 out number, len2 out number)
   RETURN NUMBER IS
   cAux   VARCHAR2(15);
   ret number;

BEGIN

	cDados1 := null;
	cDados2 := null;
	len1 := 0;
	len2 := 0;

	begin
		select icard, templ_pad, dbms_lob.getlength(templ_pad),
			templ_alt, dbms_lob.getlength(templ_alt)
		into cAux, cDados1, len1, cDados2, len2  from PALMV001 where icard = cMatric;
		ret := 1;
			
		IF ( ((len1 is NULL) and (len2 is NULL)) OR
		     ((cDados1 is NULL) and (cDados2 is NULL)) ) then
			ret := 0;
		end if;
		
		IF (len1 is NULL) THEN 
			len1 := 0;
		end if;
		
		IF (len2 is NULL) THEN 
			len2 := 0;
		end if;
		
	exception
		when NO_DATA_FOUND then	
			ret := 0;
		when OTHERS then	
			ret := 0;			
	end;
	
	IF (ret = 0) then
		-- insere em tabela DIGLOAD001
		INSERT INTO DIGLOAD001 (END_IP, ICARD, BIO_TIPO) 
			VALUES (cEndIp, cMatric, 'A');
		COMMIT;
	END IF;
	
    return (ret);

END sqlproc_digitPALMV;
/

