CREATE OR REPLACE FUNCTION sqlat_tab_refplanta (cRegistro1 VARCHAR2)
RETURN NUMBER IS

cMatric char(12); cPlanta char(5); cFaixa char(8); cCred char(2); cDatHorRef char(10); cAux char(12);
Retorno number;

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);  -- erro quando registro lockado


BEGIN

	cMatric  := substr(cRegistro1,  1, 12);
	cPlanta  := substr(cRegistro1, 13,  5);
	cFaixa   := substr(cRegistro1, 18,  8);
	cCred    := substr(cRegistro1, 26,  2);
	cDatHorRef := substr(cRegistro1, 28,  10);
	Retorno := 0;


	-- atualiza tabela MATNREFEIT, na faixa especifica

	BEGIN
		SELECT ICARD INTO cAux FROM MATNREFEIT 
			WHERE ICARD =  cMatric and 
				  to_number(PLANTA) = to_number(cPlanta) and
				  FX_REF = cFaixa 
				for update nowait;	 

		UPDATE MATNREFEIT set CRED_FXREF = cCred
			WHERE ICARD =  cMatric and 
				  to_number(PLANTA) = to_number(cPlanta) and
				  FX_REF = cFaixa ;

	EXCEPTION
		WHEN reco_lock then
			Retorno := -1;
		WHEN NO_DATA_FOUND then
			null;
		WHEN OTHERS then
			Retorno := -1;
	END;


	-- continua atualiza��o se n�o houve problema no processo anterior
	if (Retorno = 0) then
		-- insere ou atualiza tabela AUXMATNREFEIT, a data/faixa da �ltima passagem no refeitorio de acordo com a planta
		BEGIN
			SELECT ICARD INTO cAux FROM AUXMATNREFEIT 
				WHERE ICARD =  cMatric and 
					  PLANTA = cPlanta 				
				for update nowait;	 

			UPDATE AUXMATNREFEIT set ULTPAS_REF = cDatHorRef 
				WHERE ICARD =  cMatric and 
					  PLANTA = cPlanta ;

		EXCEPTION
			WHEN reco_lock then
				Retorno := -1;
			WHEN NO_DATA_FOUND then
				INSERT INTO AUXMATNREFEIT (ICARD, PLANTA, ULTPAS_REF) 
								   VALUES (cMatric, cPlanta, cDatHorRef);
			WHEN OTHERS then
				Retorno := -1;

		END;
	end if;
	
	COMMIT;

	Return (Retorno);		
	
END sqlat_tab_refplanta;
/



