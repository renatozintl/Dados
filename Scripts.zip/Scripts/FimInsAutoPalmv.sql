CREATE or REPLACE FUNCTION sqlfim_InsAutoPalmv (cEndIp in VARCHAR2, cStat in VARCHAR2) 
RETURN NUMBER IS

nErr NUMBER;
xCont NUMBER;
cAux VARCHAR2(20);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

cursor lfim014_cur is 
	SELECT ICARD, STATUS FROM PALMV014 
		WHERE END_CTRLPALMV = cEndIp AND STATUS = '2' 
		order by ICARD for update of STATUS;

begin
    xCont := 0;
    nErr := 0;

	BEGIN
		-- atualiza o status somente dos funcionarios do rep q estavam sendo incluidos (sofrendo o comando de inclusao no conex)
		for r in lfim014_cur LOOP
			update PALMV014 set STATUS = cStat where current of lfim014_cur ;
			xCont := xCont+1;
		END LOOP;

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			nErr := 0;
		WHEN reco_lock THEN
			nErr := 1;
		WHEN OTHERS THEN
			nErr := 1;
	END;
    
	
	BEGIN
		SELECT END_CTRLPALMV into cAux FROM PALMV004 
			where END_CTRLPALMV = cEndIp for update nowait;
		UPDATE PALMV004 SET STATUS = cStat WHERE END_CTRLPALMV = cEndIp;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			nErr := 0;
		WHEN reco_lock THEN
			nErr := 1;
		WHEN OTHERS THEN
			nErr := 1;
	END;
	
	COMMIT;
	return (xCont);
		
END sqlfim_InsAutoPalmv;
/

