CREATE OR REPLACE FUNCTION sqlver_mensagem (cMatric VARCHAR2, cMens OUT VARCHAR2)
   RETURN NUMBER IS
      Ret NUMBER;
      reco_lock EXCEPTION;
      PRAGMA EXCEPTION_INIT (reco_lock, -54);  -- erro quando registro lockado 
BEGIN
   Ret := 1;
   BEGIN
   SELECT Mensagem INTO cMens
      FROM CONTROLE
      WHERE ICard = cMatric;

   EXCEPTION
      WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
         Ret := 0;
      WHEN OTHERS THEN              -- outros erros
         Ret := -1;
   END;

   return (Ret);
END sqlver_mensagem;
/

