CREATE OR REPLACE FUNCTION sqlrfuso_timestamp (cEndIp varchar2, cData IN out varchar2, cTimeZone IN out varchar2) 
   RETURN NUMBER IS

Ret    NUMBER;
cFuso varchar2(8);
cDia varchar2(1);

Minutos NUMBER;
nFator NUMBER;
newHora NUMBER;
newMinutos NUMBER;
MinutosTimeStamp NUMBER;

BEGIN
	
    Ret := 1;
    cFuso := '0000';
    cData := '01/01/2001 00:00:0001';
    
    cTimeZone := '-0300';
    Minutos := 0;
    nFator := 1;
    
    -- coleta valor de fuso horario do equipamento em rela��o ao local da Base de Dados
    BEGIN
    	SELECT Fuso INTO cFuso
		FROM DAT07
		WHERE End_Ip = cEndIp;
    EXCEPTION
		WHEN NO_DATA_FOUND then Ret := 0;
		WHEN OTHERS then Ret := -1;
    END;

    IF (Ret >= 0) THEN
    	BEGIN
			Minutos := to_number(cFuso);
		EXCEPTION
			WHEN OTHERS then Minutos := 0;
		END;
	ELSE
		Minutos := 0;
	END IF;
	
	
	-- verifica o hor�rio do banco e calcula horario do equipamento considerando o fuso horario . Verifica o dia da semana deste horario calculado
   	select case to_char (sysdate+(Minutos/1440), 'FmDay', 'nls_date_language=english')
	          when 'Monday' then 2
	          when 'Tuesday' then 3
	          when 'Wednesday' then 4
	          when 'Thursday' then 5
	          when 'Friday' then 6
	          when 'Saturday' then 7
	          when 'Sunday' then 1
	       end 
		INTO cDia FROM dual;
       	    
	SELECT TO_CHAR (sysdate+(Minutos/1440), 'DD/MM/YYYY HH24:MI:SS') || '0' || cDia , 
		   TO_CHAR (SYSTIMESTAMP, 'TZHTZM')
		into cData , cTimeZone from dual; 


    if (substr (cTimeZone,1,1) = '-') then
		nFator := -1;
	end if;

	-- calcula o tempo em minutos do timezone, com valor negativo ou positivo
    MinutosTimeStamp := ( (to_number(substr (cTimeZone,2,2)) * 60) + (to_number(substr(cTimeZone, 4, 2)))) * nFator;

	-- recalcula o tempo em minutos do timezone considerando o fuso horario do equipamento em relacao � BD    
    MinutosTimeStamp := MinutosTimeStamp + Minutos;

    cTimeZone := '+';
    if (MinutosTimeStamp < 0) then
    	cTimeZone := '-';
    	-- transforma em valor positivo, pois o sinal j� ser� considerado na variavel que ir� receber
    	MinutosTimeStamp := MinutosTimeStamp * (-1);
    end if;

    
    -- transforma a parte de horas no formato hh
    newHora := trunc(MinutosTimeStamp / 60);
    -- transforma a parte de miutos no formato mm
    newMinutos := ((MinutosTimeStamp / 60) - trunc(MinutosTimeStamp / 60)) * 60;
    
    
    cTimeZone := trim(cTimeZone) || trim(to_char(newHora, '00')) || trim(to_char(newMinutos, '00'));
    
    
    return (Ret);
END sqlrfuso_timestamp;
/


