CREATE or REPLACE FUNCTION sqlrdig_rejeit2 (cDigRejeit in VARCHAR2, cNumRep in VARCHAR2) 
RETURN NUMBER IS

ret NUMBER;
cEndIP CHAR(15);
cMat CHAR(12);
dDataHora DATE;
cBioTipo char(1);
cErro char(2);

BEGIN

	ret := 0;
	cEndIP 		:= SUBSTR (cDigRejeit, 1, 15);
	cMat 		:= SUBSTR (cDigRejeit, 16, 12);
	dDataHora 	:= TO_DATE (SUBSTR (cDigRejeit, 28, 12), 'DDMMYYHH24MISS');
	cBioTipo 	:= SUBSTR (cDigRejeit, 40, 1);
	cErro 		:= SUBSTR (cDigRejeit, 41, 2);
	
	INSERT INTO REPDIGLOAD002 (END_IP, REP, IFUNC, BIO_TIPO, DATA_INS, NERRO) 
					VALUES (cEndIP , cNumRep, cMat, cBioTipo, dDataHora, cErro);
	COMMIT;

	return (ret);
		
END sqlrdig_rejeit2;
/


