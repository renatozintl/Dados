CREATE or REPLACE FUNCTION sqlfim_ExcAutoDigit3 (cEndIp in VARCHAR2, cStat in VARCHAR2, cBioTipo in VARCHAR2) 
RETURN NUMBER IS

xCont NUMBER;
ret NUMBER;
cAux VARCHAR2(1);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

cursor lexcdig_cur1 is 
	SELECT ICARD, STATUS FROM DIG101 
		WHERE END_IP = cEndIp AND STATUS = '2' 
		order by ICARD for update of STATUS;

cursor lexcdig_cur3 is 
	SELECT ICARD, STATUS FROM DIG103 
		WHERE END_IP = cEndIp AND STATUS = '2' 
		order by ICARD for update of STATUS;

cursor lexcdig_cur4 is 
	SELECT ICARD, STATUS FROM DIG104 
		WHERE END_IP = cEndIp AND 
			  STATUS = '2'  AND 
			  BIO_TIPO = cBioTipo 
		order by ICARD for update of STATUS;


begin
    xCont := 0;
    ret := 0;

	IF (cBioTipo = '6') or (cBioTipo = '7') THEN
		-- atualiza o status somente dos ICARDS q estavam sendo excluidos (sofrendo o comando de exlucsao no conex - BIOMETRIA SAGEM)
		for r in lexcdig_cur1 LOOP
			update DIG101 set STATUS = cStat where current of lexcdig_cur1 ;
			xCont := xCont+1;
		END LOOP;

	ELSIF (cBioTipo = '8') THEN
		-- atualiza o status somente dos ICARDS q estavam sendo excluidos (sofrendo o comando de exlucsao no conex - BIOMETRIA TSI1)
		for r in lexcdig_cur3 LOOP
			update DIG103 set STATUS = cStat where current of lexcdig_cur3 ;
			xCont := xCont+1;
		END LOOP;
		
	ELSIF (cBioTipo != '0') THEN
		-- atualiza o status somente dos ICARDS q estavam sendo excluidos (sofrendo o comando de exlucsao no conex - BIOMETRIA VIRDI)
		for r in lexcdig_cur4 LOOP
			update DIG104 set STATUS = cStat where current of lexcdig_cur4 ;
			xCont := xCont+1;
		END LOOP;
	END IF;
	
	BEGIN
		SELECT STATUS into cAux   
			FROM DIG102 
			WHERE END_IP = cEndIp for update nowait;

		UPDATE DIG102 SET STATUS = cStat WHERE END_IP = cEndIp;


	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			ret := 0;
		WHEN reco_lock THEN
			ret := (0);
		WHEN OTHERS THEN
			ret := -1;
	END;
    
	
	COMMIT;
	return (ret);
		
END sqlfim_ExcAutoDigit3;
/

