CREATE OR REPLACE  PROCEDURE trata_OutrosBios IS
  
TYPE endipDigI_type IS TABLE OF DIG002.END_IP%TYPE 
	INDEX BY binary_integer;
TYPE statusDigI_type IS TABLE OF DIG002.STATUS%TYPE 
	INDEX BY binary_integer;
TYPE biotipoDigI_type IS TABLE OF DIG002.BIO_TIPO%TYPE 
	INDEX BY binary_integer;


TYPE endipDigE_type IS TABLE OF DIG102.END_IP%TYPE 
	INDEX BY binary_integer;
TYPE statusDigE_type IS TABLE OF DIG102.STATUS%TYPE 
	INDEX BY binary_integer;
TYPE biotipoDigE_type IS TABLE OF DIG102.BIO_TIPO%TYPE 
	INDEX BY binary_integer;

TYPE rowid_type IS TABLE OF ROWID  
	INDEX BY binary_integer;

	
l_endipDigInc endipDigI_type;
l_statusDigInc statusDigI_type;
l_biotipoDigInc biotipoDigI_type;

l_endipDigExc endipDigE_type;
l_statusDigExc statusDigE_type;
l_biotipoDigExc biotipoDigE_type;

l_rowid rowid_type;
p_recBios DIG004%rowtype;
p_recExcBios DIG104%rowtype;
p_recDigCom DIG002%rowtype;
p_recDigExc DIG102%rowtype;


RECO_LOCK EXCEPTION;
PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);

tem_deadlock EXCEPTION; 
PRAGMA EXCEPTION_INIT (tem_deadlock, -60); 

i number;
cMatAux CHAR(12);
cStAux CHAR(1);
cIpAux CHAR(15);

BEGIN
	-- ********************   ARRUMAR SITUA��ES PARA outras bios    -  INCLUSAO
	-- ***********************  TRATA AS BIOMETRIAS  QUE FICARAM PENDENTES NA CARGA E QUE NAO SERAO REENVIADAS AUTOMATICAMENTE
	-- SITUACAO EM QUE CARGA FICOU PENDENTE PORQUE EQUIPAMENTO REJEITOU A CARGA (status '4')
	FOR r in (SELECT distinct ICARD from DIG004 WHERE STATUS = '4')
	LOOP
		FOR cur_troubleIns2 in 
			(SELECT rowid, ICARD, END_IP  			-- GUARDA EM CURSOR TODAS AS LINHAS DESTA MATRICULA Q NAO TEM O bio   CADASTRADO, Q ESTA COM STATUS = '4'
				FROM DIG004 
				WHERE ICARD = r.ICARD and 
					  STATUS = '4'  )
		LOOP
			BEGIN		-- PARA CADA LINHA , RESERVA ('for update nowait') PARA ALTERAR O STATUS
				SELECT * into p_recBios FROM DIG004 WHERE rowid = cur_troubleIns2.rowid for update nowait;
	
				DELETE DIG004 WHERE rowid = cur_troubleIns2.rowid ;

			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
					
			BEGIN
				SELECT END_IP into cIpAux FROM DIG002 WHERE END_IP = p_recBios.END_IP and STATUS = '3' for update nowait;
				UPDATE DIG002 set status = '1'
					WHERE (END_IP = p_recBios.END_IP  and STATUS = '3') ;
						
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		end loop;
	END LOOP;


	

	-- ***********************  TRATA AS BIOMETRIAS  QUE FICARAM PENDENTES NA CARGA
	-- SITUACAO EM QUE CARGA FICOU PENDENTE PORQUE HOUVE DELETE DE REGISTROS DAS BIOS  (DA TAB.CONTDIG_OUTROS CADASTRO)
	-- delete registro de DIG004 se nao houver cadastro de bio  desta matricula
	FOR r in 
		(SELECT distinct ICARD, BIO_TIPO from DIG004 
			WHERE STATUS = '3')
	LOOP 
		BEGIN
			-- VERIFICA SE H� CADASTRO de bio  DA MATRICULA
			SELECT ICARD INTO cMatAux FROM CONTDIG_OUTROS 
				WHERE ICARD = r.ICARD AND BIO_TIPO = r.BIO_TIPO;
			
		EXCEPTION
			-- NAO HA bio  CADASTRADO
			when NO_DATA_FOUND then 		
			begin
				-- GUARDA EM CURSOR TODAS AS LINHAS DESTA MATRICULA Q NAO TEM O bio  CADASTRADO, Q ESTA COM STATUS = '3'
				FOR c_curdig in (SELECT rowid, ICARD, BIO_TIPO, END_IP  			
									FROM DIG004 
								WHERE ICARD = r.ICARD and 
							  		STATUS = '3'  and
							  		BIO_TIPO = r.BIO_TIPO)
				LOOP
					BEGIN		-- PARA CADA LINHA , RESERVA ('for update nowait') PARA ALTERAR O STATUS
						SELECT * into p_recBios FROM DIG004 WHERE rowid = c_curdig.rowid for update nowait;
						DELETE DIG004 WHERE rowid = c_curdig.rowid ;

					EXCEPTION
						when reco_lock then NULL ;
						when tem_deadlock then NULL ;
						when NO_DATA_FOUND then NULL;
						when OTHERS then NULL;
					END;
					
					BEGIN
						SELECT END_IP into cIpAux FROM DIG002 WHERE END_IP = p_recBios.END_IP and STATUS = '3' for update nowait;
						UPDATE DIG002 set status = '1'
							WHERE (END_IP = p_recBios.END_IP) ;
						
					EXCEPTION
						when reco_lock then NULL ;
						when tem_deadlock then NULL ;
						when NO_DATA_FOUND then NULL;
						when OTHERS then NULL;
					END;
					
				end loop;
			end;				
			when OTHERS then NULL;
		END;
	END LOOP;
	COMMIT;
	-- FIM SITUACAO NOVA

	
	
	
	
	
	-- altera status de todos os codins para carga de digitais, se esses n�o estiverem com carga de digitais ou estiverem pendentes
	
	FOR r in 
		(SELECT distinct END_IP, BIO_TIPO, STATUS from DIG004 
			where (STATUS != '0') and (STATUS != '2')
		) 
	LOOP
		IF (r.STATUS != '4') THEN		-- REP NAO ACEITA CARGA DIGITAL, POIS RESPONDEU COMO 'NAO IMPLEMENTADO'
			BEGIN
				SELECT * into p_recDigCom FROM DIG002
					WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3' or STATUS = '4') and		-- status '0':carregado, '3':pendente, '4': nao aceita carga digital
						   BIO_TIPO = r.BIO_TIPO) for update nowait;

				UPDATE DIG002 set status = '1'
					WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3' or STATUS = '4') and		-- status '0':carregado, '3':pendente, '4': nao aceita carga digital
						   BIO_TIPO = r.BIO_TIPO);
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		END IF;
	END LOOP;
	
	COMMIT;	

	-- ********************   TRATA EQUIPAMENTOS bios QUE FICARAM EM ESTADO CARREGANDO OU SOFRERAM CARGA DE APLICATIVO
	-- equipamentos q ficou em estado de carregando '2' por mais de 2 minutos OU
	
	
	SELECT distinct END_IP, BIO_TIPO, STATUS, ROWID
		BULK COLLECT INTO l_endipDigInc, l_biotipoDigInc, l_statusDigInc, l_rowid	
			FROM DIG002  
			WHERE (((BIO_TIPO != '8') and (BIO_TIPO != '6') and (BIO_TIPO != '7')) AND 		-- nao trata das outras bios conhecidas, pois ja tem seus processos
					(status = '5' or status = '6' or (status = '2' and (data_load + ( 2 / 24 / 60 )  < sysdate)) ) 
				  );
	
	FOR i in 1 .. l_endipDigInc.count	
	LOOP
		IF (l_statusDigInc(i) = '2') THEN		-- estado CARREGANDO ('2') parado
			FOR c_curdig in 
				(SELECT rowid, ICARD 
					FROM DIG004 
					WHERE END_IP = l_endipDigInc(i) and 
						  STATUS = '2'  and 
						  BIO_TIPO = l_biotipoDigInc(i) )
			LOOP
				BEGIN
					SELECT * into p_recBios FROM DIG004 WHERE rowid = c_curdig.rowid for update nowait;
					UPDATE DIG004 set status = '1' WHERE rowid = c_curdig.rowid ;
				
				EXCEPTION
					when reco_lock then NULL ;
					when tem_deadlock then NULL ;
					when NO_DATA_FOUND then NULL;
					when OTHERS then NULL;
				END;
			end loop;
						   
			BEGIN
				SELECT * into p_recDigCom from DIG002 WHERE END_IP = l_endipDigInc(i) and BIO_TIPO = l_biotipoDigInc(i) for update nowait;
				UPDATE DIG002 set status = '1' where END_IP = l_endipDigInc(i) and BIO_TIPO = l_biotipoDigInc(i);		-- FAZ RECARGA DE BIOMETRIAS 
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		
		ELSIF ((l_statusDigInc(i) = '5') or (l_statusDigInc(i) = '6')) THEN		-- estado de CARGA DE APLICATIVO
			BEGIN
				SELECT * into p_recDigCom from DIG002 WHERE END_IP = l_endipDigInc(i) and BIO_TIPO = l_biotipoDigInc(i) for update nowait;
				UPDATE DIG002 set status = '0' WHERE END_IP =  l_endipDigInc(i) and BIO_TIPO = l_biotipoDigInc(i);		-- VOLTA AO ESTADO DE REPOUSO
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		END IF;		
	END LOOP;
	
	COMMIT;	



	
	-- ***********************  TRATA AS BIOMETRIAS  QUE FICARAM EM ESTADO DE CARREGANDO E NAO SAI DESTA SITUA��O
	-- para BIOMETRIAS   DE DIG004 que ficaram em estado carregando '2' e o equipamento est� em estado de repouso	, forca o equipamento a carrega-los novamente

	SELECT END_IP, STATUS 
		BULK COLLECT INTO l_endipDigInc, l_statusDigInc
			FROM (SELECT  A.END_IP, A.status 
					FROM DIG002 A INNER JOIN 
						 DIG004 B
					ON A.END_IP = B.END_IP and 
					   A.status = '0' and 
					   B.STATUS = '2' and
					   A.BIO_TIPO = B.BIO_TIPO) ;

	FOR i IN 1 .. l_endipDigInc.count     
	LOOP			
		for c1 in (select rowid from DIG004 
			WHERE END_IP = l_endipDigInc(i) AND (STATUS = '2') )
		loop
			BEGIN
				select * into p_recBios from DIG004 where rowid = c1.rowid for update nowait;		
				UPDATE DIG004 SET STATUS = '1' where rowid = c1.rowid;

			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		end loop;				
		
		BEGIN
			SELECT * into p_recDigCom FROM DIG002 WHERE END_IP = l_endipDigInc(i) for update nowait;
			UPDATE DIG002 SET STATUS = '1'	WHERE END_IP = l_endipDigInc(i);
			
		EXCEPTION
			when reco_lock then NULL ;
			when tem_deadlock then NULL ;
			when NO_DATA_FOUND then NULL;
			when OTHERS then NULL;
		END;
	end LOOP;

	COMMIT;
	

	-- ********************   ARRUMAR SITUA��ES PARA biometrias    -  EXCLUSAO
	
	-- ***********************  TRATA AS BIOMETRIAS QUE FICARAM PENDENTES NA EXCLUSAO
	-- altera status dos codins para exclusao de biometria, se esses n�o estiverem com exclusao de biometria ou estiverem pendentes

	FOR r in 
		(SELECT distinct END_IP, BIO_TIPO from DIG104 
			where (STATUS != '0') and (STATUS != '2') and (STATUS != '4')		-- statys 4 indica resposta do EQUIPAM de nao implementado
		) 
	LOOP
		BEGIN
			SELECT * into p_recDigExc FROM DIG102
				--WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3') and
				WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3' or STATUS = '4') and		-- statys 4 indica resposta do rep de nao implementado
					   BIO_TIPO = r.BIO_TIPO) for update nowait;
	
			UPDATE DIG102 set status = '1'
				--WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3') and 
				WHERE (END_IP = r.END_IP and (STATUS = '0' or STATUS = '3' or STATUS = '4') and		-- statys 4 indica resposta do rep de nao implementado
					   BIO_TIPO = r.BIO_TIPO);
		EXCEPTION
			when reco_lock then NULL ;
			when tem_deadlock then NULL ;
			when NO_DATA_FOUND then NULL;
			when OTHERS then NULL;
		END;
	END LOOP;
	
	COMMIT;	
	


	-- ********************   TRATA EQUIPAMENTOS  QUE FICARAM EM ESTADO EXCLUINDO OU SOFRERAM CARGA DE APLICATIVO
	-- equipamentos  q ficaram em estado de excluindo '2' por mais de 2 minutos ou
	-- equipamentos que sofreram exclusao/recarga de aplicativo 
	
	SELECT distinct END_IP, BIO_TIPO, STATUS, ROWID
		BULK COLLECT INTO l_endipDigExc, l_biotipoDigExc, l_statusDigExc, l_rowid	
			FROM DIG102  
			WHERE (((BIO_TIPO != '6') and (BIO_TIPO != '7') and (BIO_TIPO != '8')) and
					(status = '5' or status = '6' or (status = '2' and (data_load + ( 2 / 24 / 60 )  < sysdate)))
				  );

	FOR i in 1 .. l_endipDigExc.count	
	LOOP
		IF (l_statusDigExc(i) = '2') THEN		-- estado CARREGANDO ('2') parado
			FOR c_curdig in 
				(SELECT rowid, ICARD 
					FROM DIG104 
					WHERE END_IP = l_endipDigExc(i) and 
						  STATUS = '2'  and 
						  BIO_TIPO = l_biotipoDigExc(i) )
			LOOP
				BEGIN
					SELECT * into p_recBios FROM DIG104 WHERE rowid = c_curdig.rowid for update nowait;
					UPDATE DIG104 set status = '1' WHERE rowid = c_curdig.rowid ;
				
				EXCEPTION
					when reco_lock then NULL ;
					when tem_deadlock then NULL ;
					when NO_DATA_FOUND then NULL;
					when OTHERS then NULL;
				END;
			end loop;
						   
			BEGIN
				SELECT * into p_recDigExc from DIG102 WHERE END_IP = l_endipDigExc(i) and BIO_TIPO = l_biotipoDigExc(i) for update nowait;
				UPDATE DIG102 set status = '1' WHERE END_IP = l_endipDigExc(i) and BIO_TIPO = l_biotipoDigExc(i);		-- FAZ RECARGA DE BIOMETRIAS TSI1
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		
		ELSIF ((l_statusDigExc(i) = '5')  or (l_statusDigExc(i) = '6')) THEN		-- estado de CARGA DE APLICATIVO
			BEGIN
				SELECT * into p_recDigExc from DIG102 WHERE END_IP = l_endipDigExc(i) and BIO_TIPO = l_biotipoDigExc(i) for update nowait;
				UPDATE DIG102 set status = '0' WHERE END_IP = l_endipDigExc(i) and BIO_TIPO = l_biotipoDigExc(i);		-- VOLTA AO ESTADO DE REPOUSO
				
			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		END IF;		
	END LOOP;
	
	COMMIT;	

	
	-- ***********************  TRATA AS BIOMETRIAS  QUE FICARAM EM ESTADO DE EXCLUINDO E NAO SAEM DESTA SITUA��O
	-- para BIOMETRIAS  VIRDI DE DIG104 que ficaram em estado EXCLUINDO '2' e o equipamento est� em estado de repouso	, forca o equipamento a exclui-los novamente

	SELECT END_IP, STATUS, BIO_TIPO  
		BULK COLLECT INTO l_endipDigExc, l_statusDigExc, l_biotipoDigExc
			FROM (SELECT  A.END_IP, A.status, A.BIO_TIPO   
					FROM DIG102 A INNER JOIN 
						 DIG104 B
					ON A.END_IP = B.END_IP and 
					   A.status = '0' and 
					   B.STATUS = '2' and
					   A.BIO_TIPO = B.BIO_TIPO) ;

	FOR i IN 1 .. l_endipDigExc.count     
	LOOP			
		for c1 in (select rowid from DIG104 
			WHERE END_IP = l_endipDigExc(i) AND (STATUS = '2')  AND (BIO_TIPO = l_biotipoDigExc(i)))
		loop
			BEGIN
				select * into p_recExcBios from DIG104 where rowid = c1.rowid for update nowait;		
				UPDATE DIG104 SET STATUS = '1' where rowid = c1.rowid;

			EXCEPTION
				when reco_lock then NULL ;
				when tem_deadlock then NULL ;
				when NO_DATA_FOUND then NULL;
				when OTHERS then NULL;
			END;
		end loop;				
		
		BEGIN
			SELECT * into p_recDigExc FROM DIG102 WHERE END_IP = l_endipDigExc(i) for update nowait;
			UPDATE DIG102 SET STATUS = '1'	WHERE END_IP = l_endipDigExc(i);
			
		EXCEPTION
			when reco_lock then NULL ;
			when tem_deadlock then NULL ;
			when NO_DATA_FOUND then NULL;
			when OTHERS then NULL;
		END;
	end LOOP;

	COMMIT;
	

end trata_OutrosBios ;
/
