--DROP SYNONYM CP_NB;
CREATE SYNONYM CP_NB FOR cp_telemat.CP_NB;

DROP SYNONYM REPBLOQ001;
CREATE SYNONYM REPBLOQ001 FOR cp_telemat.REPBLOQ001;

DROP SYNONYM REPSINALIDP;
CREATE SYNONYM REPSINALIDP FOR cp_telemat.REPSINALIDP;

drop synonym REPAUTO001;
create synonym REPAUTO001  for cp_telemat.REPAUTO001;

drop synonym REPAUTO002;
create synonym REPAUTO002  for cp_telemat.REPAUTO002;

drop synonym GERAUTO;
create synonym GERAUTO  for cp_telemat.GERAUTO;

drop synonym RDIG002;
create synonym RDIG002 for cp_telemat.RDIG002;

drop synonym RDIG102;
create synonym RDIG102  for cp_telemat.RDIG102;

drop synonym DAT07REPP;
create synonym DAT07REPP  for cp_telemat.DAT07REPP;


DROP SYNONYM sqlrget_sodata;
CREATE SYNONYM sqlrget_sodata FOR cp_telemat.sqlrget_sodata;


DROP SYNONYM sqlrident_conex;
CREATE SYNONYM sqlrident_conex FOR cp_telemat.sqlrident_conex;


DROP SYNONYM sqlrsit_coletor;
CREATE SYNONYM sqlrsit_coletor FOR cp_telemat.sqlrsit_coletor;

DROP SYNONYM sqlrget_dh;
CREATE SYNONYM sqlrget_dh FOR cp_telemat.sqlrget_dh;

DROP SYNONYM sqlrentrada_codin;
CREATE SYNONYM sqlrentrada_codin FOR cp_telemat.sqlrentrada_codin;

DROP SYNONYM Prep_RepAuto8;
CREATE SYNONYM Prep_RepAuto8 FOR cp_telemat.Prep_RepAuto8;

drop synonym SQL_REPAUTOF3;
create synonym SQL_REPAUTOF3 for cp_telemat.SQL_REPAUTOF3;

drop synonym ANTEPREP3_RSAGEM;
create synonym ANTEPREP3_RSAGEM for cp_telemat.ANTEPREP3_RSAGEM;

drop synonym AntePrep3_RTsi1;
create synonym AntePrep3_RTsi1 for cp_telemat.AntePrep3_RTsi1;

DROP SYNONYM AntePrep2_ROutrosBios;
CREATE SYNONYM AntePrep2_ROutrosBios FOR cp_telemat.AntePrep2_ROutrosBios;


drop synonym Prep_RepDigit5;
create synonym Prep_RepDigit5 for cp_telemat.Prep_RepDigit5;

drop synonym trata4_RepSagem;
create synonym trata4_RepSagem for cp_telemat.trata4_RepSagem;

drop synonym trata4_Reptsi1;
create synonym trata4_Reptsi1 for cp_telemat.trata4_Reptsi1;

DROP SYNONYM trata3_RepOutrosBios;
CREATE SYNONYM trata3_RepOutrosBios FOR cp_telemat.trata3_RepOutrosBios;

drop synonym P_RepGerDigital5;
CREATE SYNONYM P_RepGerDigital5 FOR cp_telemat.P_RepGerDigital5;

DROP SYNONYM sqlrhora_gerbiof3;
CREATE SYNONYM sqlrhora_gerbiof3 FOR cp_telemat.sqlrhora_gerbiof3;
