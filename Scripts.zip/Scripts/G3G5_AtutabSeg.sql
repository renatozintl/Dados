CREATE OR REPLACE FUNCTION sqlatG3G5_tab_acessoSeg (cRegistro in VARCHAR2, Posic in VARCHAR2) 
   RETURN NUMBER IS
      NumMat VARCHAR2(12);
      VarAux VARCHAR2(12);
      reco_lock EXCEPTION;
      PRAGMA EXCEPTION_INIT (reco_lock, -54);  
      Retorno NUMBER;
      nTamG NUMBER;
      cSubnv VARCHAR2(9);


BEGIN
      Retorno := 0;      
      NumMat := substr(cRegistro, 1, 12);
      
	BEGIN
		select data_length INTO nTamG 
			from   user_tab_columns
			where  table_name = 'CONTROLE' and	column_name = 'GRUPO';
	EXCEPTION
		WHEN OTHERS THEN 
			nTamG := 3;		-- ASSUME TAMANHO DO CAMPO LACES COM 3 DIGITOS
	END;
      
	IF (nTamG = 5) then							
		cSubnv :=  substr(cRegistro, 14, 7);
	ELSE
		cSubnv := SUBSTR (substr(cRegistro, 14, 7), 1, 5);
	END IF;
      

   BEGIN
      SELECT Icard into VarAux from Controle 
		 WHERE rowid = chartorowid (Posic) for update nowait;

      UPDATE controle 
	 SET Situa = substr(cRegistro, 13, 1),
	     --Subnv = substr(cRegistro, 14, 5),
	     Subnv = cSubnv,
	     Ultrs = substr(cRegistro, 21, 25),
	     Fx_Dta = substr(cRegistro, 46, 11),
	     Qtd_Mens = substr(cRegistro, 57, 2),
	     Cred_Fx1 = substr(cRegistro, 59, 2),
	     Cred_Fx2 = substr(cRegistro, 61, 2),
	     Cred_Fx3 = substr(cRegistro, 63, 2),
	     Cred_Fx4 = substr(cRegistro, 65, 2),
	     Cred_Fx5 = substr(cRegistro, 67, 2),
	     Cred_Fx6 = substr(cRegistro, 69, 2),
	     UltPas_Ref = substr(cRegistro, 71, 10),
         Planta = substr(cRegistro, 81, 3),
		 ULTRSEG = substr(cRegistro, 84, 2)

	 WHERE rowid = chartorowid (Posic);

      COMMIT;

   EXCEPTION
      WHEN reco_lock THEN           -- reg. ja'lockado
	 Retorno := -3;
      WHEN NO_DATA_FOUND THEN       -- reg. nao encontrado
	 Retorno := -1;
      WHEN OTHERS THEN
	 Retorno := -1;
   END;
   return (Retorno);
END sqlatG3G5_tab_acessoSeg;
/


