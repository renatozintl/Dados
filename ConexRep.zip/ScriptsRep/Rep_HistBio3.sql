CREATE or REPLACE FUNCTION sqlhist_Rbio3 (cListaMat in VARCHAR2, cEndIp in VARCHAR2, cInsDel in VARCHAR2, cModo in VARCHAR2, cBioTipo in VARCHAR2) 
RETURN NUMBER IS

Tam NUMBER;
Pos NUMBER;
ret NUMBER;
cAcao VARCHAR2(1);
cAuxIp VARCHAR2(15);
cBio CHAR(1);

RECO_LOCK EXCEPTION;
PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);
BEGIN


	cBio := ' ';
	BEGIN
		SELECT BIO_TIPO INTO cBio FROM DAT07 WHERE END_IP = cEndIp;
		
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			cBio := ' ';
		WHEN OTHERS THEN
			cBio := ' ';
	END;
	
	ret := 0;
	IF (cInsDel = '3') THEN
		cAcao := 'I';
	ELSE
		cAcao := 'E';
	END IF;
		
	Tam := LENGTH (cListaMat) ;

	IF (Tam > 0) THEN
		Pos := 1;
		WHILE (Pos < Tam) LOOP
			INSERT INTO HISTREPDIG (IFUNC, END_IP, BIO_TIPO, INSEXC, MODO) 
			--				VALUES (SUBSTR (cListaMat, Pos, 12) , cEndIp, cBioTipo, cAcao, cModo);
				VALUES (SUBSTR (cListaMat, Pos, 12) , cEndIp, cBio, cAcao, cModo);
			Pos := Pos + 12;
		END LOOP;

		BEGIN
			SELECT END_IP INTO cAuxIp FROM REPLASTCOM WHERE END_IP = cEndIp for update nowait;
			UPDATE REPLASTCOM SET DATA_INS = SYSDATE WHERE END_IP = cEndIp;
		EXCEPTION
			WHEN NO_DATA_FOUND THEN 
				INSERT INTO REPLASTCOM (END_IP, DATA_INS) VALUES (cEndIp, SYSDATE);
			WHEN RECO_LOCK THEN 
				NULL;
			WHEN OTHERS THEN 
				NULL;
		END;

		COMMIT;
	END IF;

	return (ret);
		
END sqlhist_Rbio3;
/


