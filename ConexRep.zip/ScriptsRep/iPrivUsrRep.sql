GRANT SELECT ON REPNAUTO000 TO EXECFUNTCP;
GRANT SELECT ON REPNDIGAUTO000 TO EXECFUNTCP;

GRANT EXECUTE ON sqlrident_conex TO EXECFUNTCP;                                  
GRANT EXECUTE ON sqlravisa_cpbb_novell_tcp TO EXECFUNTCP;
GRANT EXECUTE ON sqlrget_dh TO EXECFUNTCP;
GRANT EXECUTE ON sqlrentrada_codin TO EXECFUNTCP;

--GRANT EXECUTE ON sqlrfuso_horario_tcp2 TO EXECFUNTCP;
GRANT EXECUTE ON sqlrfuso_timestamp TO EXECFUNTCP;
GRANT EXECUTE ON sqlrsit_coletor TO EXECFUNTCP;
GRANT EXECUTE ON sqlrcons_term_fer_tcp6 TO EXECFUNTCP;

GRANT EXECUTE ON sqlrcon_coacao_sagem TO EXECFUNTCP;
GRANT EXECUTE ON sqlrcon_coacao_tsi1 TO EXECFUNTCP;
GRANT EXECUTE ON sqlrproc_sagem_template2 TO EXECFUNTCP;
GRANT EXECUTE ON sqlrproc_tsi1_template2 TO EXECFUNTCP;
GRANT EXECUTE ON sqlratualiza_sagem_digital2 TO EXECFUNTCP;
GRANT EXECUTE ON sqlratualiza_tsi1_digital2 TO EXECFUNTCP;

GRANT EXECUTE ON sqlrgrava_cp_novell_APPL TO EXECFUNTCP;
GRANT EXECUTE ON sqlrolha_overwrite_appl TO EXECFUNTCP;
--GRANT EXECUTE ON sqlrolha_alarme_appl TO EXECFUNTCP;

GRANT EXECUTE ON SQLPROC_EMPREGADOR2 TO EXECFUNTCP;
GRANT EXECUTE ON sqlrepPto_interj3 TO EXECFUNTCP;
GRANT EXECUTE ON sqlgrava_rep6interj TO EXECFUNTCP;				
GRANT EXECUTE ON sqlproc_dadosfunc3 TO EXECFUNTCP;
GRANT EXECUTE ON sqlrepara_comando_appl TO EXECFUNTCP;

GRANT EXECUTE ON sqlins_idpis TO EXECFUNTCP;
GRANT EXECUTE ON sqllimpa_idpis TO EXECFUNTCP;
GRANT EXECUTE ON sqlsinal_statidpis TO EXECFUNTCP;
GRANT EXECUTE ON sqllog_loadfunc TO EXECFUNTCP;

-- 10 digs tsi1
GRANT EXECUTE ON sqlcons_10dig TO EXECFUNTCP;
GRANT EXECUTE ON sqlatu_10tsi1_clob TO EXECFUNTCP;

-- carga automatica
grant execute on sqlrep_autoIns4 to EXECFUNTCP;
grant execute on sqlrep_autoExc5 to EXECFUNTCP;
grant execute on sqlrep_fimInsAuto3 to EXECFUNTCP;
grant execute on sqlrep_fimExcAuto4 to EXECFUNTCP;

-- INMETRO
grant execute on SQLOLHA_INME_ALARME_APPL to EXECFUNTCP;
grant execute on sqlinform_rep to EXECFUNTCP;
grant execute on sqlgrv_logerros to EXECFUNTCP;
grant execute on sqlrep_alarme to EXECFUNTCP;

grant execute on sqlrnivel_biomet2 to EXECFUNTCP;
--grant execute on sqlrproc_outrosbios to EXECFUNTCP;
--grant execute on sqlratu_outrosbios  to EXECFUNTCP;

grant execute on sqlrproc_binarybios to EXECFUNTCP;
grant execute on sqlratu_binarybios  to EXECFUNTCP;

grant execute on sqlrinfo_comcpf to EXECFUNTCP;
grant execute on sqlproc_PisNome2 to EXECFUNTCP;
grant execute on sqlproc_icardpis4 to EXECFUNTCP;
GRANT EXECUTE ON sqlrproc_AColetivo TO EXECFUNTCP;
GRANT EXECUTE ON sqlprephist_RStF TO EXECFUNTCP;
GRANT EXECUTE ON sqlfinal_histRStF TO EXECFUNTCP;
GRANT EXECUTE ON sqlhist_RfuncInme TO EXECFUNTCP;
GRANT EXECUTE ON sqlrperm_novocomando TO EXECFUNTCP;

GRANT EXECUTE ON sqlrdig_rejeit2 TO EXECFUNTCP;

-- carga dig
grant execute on sqlfim_rExcAutoDigit3 to EXECFUNTCP;
grant execute on sqlfim_rLdig to EXECFUNTCP;
grant execute on sqller_RautoLoadDigit5 to EXECFUNTCP;
grant execute on sqller_RautoExclDigit4 to EXECFUNTCP;
grant execute on sqlload_Rlistadig4 to EXECFUNTCP;

grant execute on sqlhist_Rfunc2 to EXECFUNTCP;
grant execute on sqlhist_Rbio3 to EXECFUNTCP;

grant execute on sqlgrava_repManEsp to EXECFUNTCP;
GRANT EXECUTE ON sqlrhora_gerbiof3 TO EXECFUNTCP;

-- viav
grant execute on sqlrperm_ConxViaV to EXECFUNTCP;

GRANT EXECUTE ON sqlrep_ExistLisTab TO EXECFUNTCP;
GRANT EXECUTE ON sqlrep_LeFuncTab TO EXECFUNTCP;

GRANT EXECUTE ON sqlgrava_RepListaMat to EXECFUNTCP;
