CREATE OR REPLACE FUNCTION sqllimpa_idpis (cEndIp in varchar2, cNumRep in varchar2, Status in VARCHAR2) 
   RETURN NUMBER IS
	nRet NUMBER;
	cAux VARCHAR2(30);
	reco_unique EXCEPTION;
	PRAGMA EXCEPTION_INIT (reco_unique, -1);  -- erro quando registro DUPLICADO 
	
    reco_lock EXCEPTION;
    PRAGMA EXCEPTION_INIT (reco_lock, -54);  
	

BEGIN
	nRet := 0;
	BEGIN
		INSERT INTO REPIDPIS002 (END_IP, REP, ST, DIA) VALUES (	cEndIp, cNumRep, Status, SYSDATE);
	
	EXCEPTION
		WHEN reco_unique THEN 
			BEGIN
				SELECT REP into cAux FROM REPIDPIS002 
					WHERE END_IP = cEndIp and REP = cNumRep for update nowait;
					
				update REPIDPIS002 set ST = Status, DIA = SYSDATE 
					WHERE END_IP = cEndIp and REP = cNumRep;
			EXCEPTION
				WHEN reco_lock THEN 
					nRet := -1;
				WHEN OTHERS THEN 
					nRet := -1;
			END;
		WHEN OTHERS THEN 
			nRet := -1;
	END;
	

    BEGIN
    	DELETE REPIDPIS001 
    		WHERE END_IP = cEndIp AND
    			  REP = cNumRep;
    	
    EXCEPTION
    	WHEN NO_DATA_FOUND THEN nRet := 0;
    	WHEN OTHERS THEN nRet := 0;
    END;

	COMMIT;
    return (nRet);
    
END sqllimpa_idpis;
/
