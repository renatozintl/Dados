CREATE or REPLACE FUNCTION sqlrep_autoExc5
(
cEndIp in VARCHAR2,
cListaMat in out VARCHAR2,
nTotal in NUMBER,
nAutoGerDig NUMBER, 
nAutoComDig NUMBER 
) 
RETURN NUMBER IS

xCont NUMBER;
cStatus VARCHAR2(1);
cAux VARCHAR2(12);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);
cBio CHAR(1);
nQtdPendDig NUMBER;

cursor linsf002_cur is 
	SELECT IFUNC, STATUS FROM REPAUTO012 
		--WHERE END_IP = cEndIp AND STATUS != '0' AND STATUS != '2' 
		WHERE END_IP = cEndIp AND STATUS != '0' 
		order by IFUNC for update of STATUS;

begin
    xCont := 0;
    cBio := '0';
    nQtdPendDig := 1;

	BEGIN
		SELECT STATUS into cStatus  
		FROM REPAUTO002 
		WHERE END_IP = cEndIp for update nowait;

		IF (cStatus = '1') then
		
			-- NOVO
			-- ANTES DE ENVIAR EXCLUSAO DE FUNCIONARIOS, DEVE-SE VERIFICAR SE H� EXCLUSAO DE DIGITAIS AINDA A SER FEITA EM RDIG10X
			BEGIN
				SELECT BIO_TIPO into cBio FROM DAT07 WHERE END_IP = cEndIp;
				
				IF ((cBio = '6') or (cBio = '7')) THEN
					BEGIN
						SELECT 1 into nQtdPendDig FROM RDIG101 WHERE END_IP = cEndIp AND STATUS <> '0' ;
					EXCEPTION
						WHEN NO_DATA_FOUND THEN 
							nQtdPendDig := 0;
						WHEN OTHERS THEN
							NULL;
					END;
				ELSIF ((cBio = '8') ) THEN
					BEGIN
						SELECT 1 into nQtdPendDig FROM RDIG103 WHERE END_IP = cEndIp AND STATUS <> '0' ;
					EXCEPTION
						WHEN NO_DATA_FOUND THEN 
							nQtdPendDig := 0;
						WHEN OTHERS THEN
							NULL;
					END;
				ELSIF ((cBio <> '0') ) THEN
					BEGIN
						SELECT 1 into nQtdPendDig FROM RDIG104 WHERE END_IP = cEndIp AND STATUS <> '0' ;
					EXCEPTION
						WHEN NO_DATA_FOUND THEN 
							nQtdPendDig := 0;
						WHEN OTHERS THEN
							NULL;
					END;
				ELSE
					nQtdPendDig := 0;
				END IF;
				
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					nQtdPendDig := 0;
				WHEN OTHERS THEN
					nQtdPendDig := 0;
			END;
			
			--IF (nQtdPendDig = 0)  THEN   	-- NAO HA EXCLUSAO DE DIGITAIS A FAZER, PODE EXCLUIR FUNCIONARIOS
			IF (nQtdPendDig = 0) OR 		-- NAO HA EXCLUSAO DE DIGITAIS A FAZER  OU  
			   (nQtdPendDig <> 0 AND nAutoGerDig = 0) OR    	--H� EXCLUSAO DE DIGITAIS MAS NAO H� GERENCIAMENTO AUTOMATICO DE DIGITAIS
			   (nQtdPendDig <> 0 AND nAutoComDig = 0) THEN    	--H� EXCLUSAO DE DIGITAIS MAS NAO H� ENVIO DE CARGA/EXCLUSAO DE DIGITAIS AO EQUIPAMENTO
			
		
				UPDATE REPAUTO002 SET STATUS = '2', DATA_LOAD = SYSDATE WHERE END_IP = cEndIp;

				-- coloca em lista de exclusao somente os primeiros <nTotal> funcionarios
				for r in linsf002_cur LOOP
					cListaMat := cListaMat || r.IFUNC;
					update REPAUTO012 set STATUS = '2' where current of linsf002_cur ;
					xCont := xCont+1;
					if (xCont >= nTotal) then
						Exit;
					end if;
				END LOOP;

				IF (xCont = 0) THEN
					UPDATE REPAUTO002 SET STATUS = '0' WHERE END_IP = cEndIp;
				ELSE
					cListaMat := cListaMat || ';';
					UPDATE REPAUTO002 SET STATUS = '2', DATA_LOAD = SYSDATE WHERE END_IP = cEndIp;
				END IF;

			ELSE
				UPDATE REPAUTO002 SET STATUS = '0' WHERE END_IP = cEndIp;
				COMMIT;
				return (0);
			END IF;			
			
		ELSE
			UPDATE REPAUTO002 SET STATUS = '0' WHERE END_IP = cEndIp;
			COMMIT;
			return (0);
		END IF;					


	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			return (0);
		WHEN reco_lock THEN
			return (0);
		WHEN OTHERS THEN
			return (0);
	END;
    
	
	COMMIT;
	return (xCont);
		
END sqlrep_autoExc5;
/

