CREATE OR REPLACE FUNCTION sqlproc_handkey_template_tcp (MATRIC VARCHAR2, T_TIT1 IN OUT VARCHAR2)
RETURN NUMBER IS

Retfun NUMBER;

BEGIN

	Retfun := 3;      -- sem templ padrao
	BEGIN
		SELECT TEMPL_TIT1 INTO T_TIT1 FROM CONTDIG WHERE ICARD = MATRIC;
		if ((T_tit1 is Null) or (length(T_tit1) < 18)) then
			Retfun := 0;
		end if;

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			Retfun := 3;
		WHEN OTHERS THEN
			Retfun := 3;
	END;
	
	return (Retfun);
END sqlproc_handkey_template_tcp;
/


