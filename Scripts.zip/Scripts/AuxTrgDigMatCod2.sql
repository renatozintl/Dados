CREATE OR REPLACE PROCEDURE Auxtrg_digmatcod2 (cMatric in VARCHAR2, cEndIP in VARCHAR2) IS
cBio VARCHAR2(1);
cSt varchar2(1);
cStNovo varchar2(1);
cSitua varchar2(1);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);  -- erro quando registro lockado


BEGIN

	
	cStNovo := '3';
	BEGIN
		-- verifica CONTROLE.SITUA da matricula
		SELECT SITUA INTO cSitua FROM CONTROLE
			WHERE ICARD = cMatric;
		IF (cSitua = '1') THEN
			cStNovo := '8';
		END IF;
		
	EXCEPTION 
		WHEN NO_DATA_FOUND THEN 
			cStNovo := '8';
		WHEN OTHERS THEN 
			cStNovo := '8';
	END;
		
	BEGIN
		-- verifica o tipo de biometria do equipamento codin
		SELECT BIO_TIPO INTO cBio FROM DAT07
			WHERE END_IP = cEndIP;

		IF (cBio = '6') or (cBio = '7') THEN 	-- biometria sagem
			BEGIN
				SELECT STATUS into cSt from CONTDIG_SAGEM WHERE 
					ICARD = cMatric FOR UPDATE NOWAIT;
				IF (cSt = '0') THEN
					--UPDATE CONTDIG_SAGEM set STATUS = '3'  
					UPDATE CONTDIG_SAGEM set STATUS = cStNovo  
						WHERE ICARD = cMatric ;
					COMMIT;
				END IF;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN NULL;
				WHEN reco_lock THEN NULL;
				WHEN OTHERS THEN NULL;	
			END;

		ELSIF (cBio = '8') THEN				-- biometria tsi1
			BEGIN
				SELECT STATUS into cSt from CONTDIG_TSI1 WHERE 
					ICARD = cMatric FOR UPDATE NOWAIT;
				IF (cSt = '0') THEN
					--UPDATE CONTDIG_TSI1 set STATUS = '3'  
					UPDATE CONTDIG_TSI1 set STATUS = cStNovo   
						WHERE ICARD = cMatric ;
					COMMIT;
				END IF;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN NULL;
				WHEN reco_lock THEN NULL;
				WHEN OTHERS THEN NULL;	
			END;

		ELSIF (cBio = 'A') THEN				-- PALMVEIN
			BEGIN
				SELECT ST into cSt from PALMV001 WHERE 
					ICARD = cMatric FOR UPDATE NOWAIT;
				IF (cSt = '0') THEN
					--UPDATE PALMV001 set ST = '3'  
					UPDATE PALMV001 set ST = cStNovo   
						WHERE ICARD = cMatric ;
					COMMIT;
				END IF;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN NULL;
				WHEN reco_lock THEN NULL;
				WHEN OTHERS THEN NULL;	
			END;

		ELSIF (cBio != '0') THEN				-- VIRDI E OUTRAS BIOS
			BEGIN
				SELECT STATUS into cSt from CONTDIG_OUTROS
					WHERE  ICARD = cMatric  AND  
							BIO_TIPO = cBio FOR UPDATE NOWAIT;
				IF (cSt = '0') THEN
					--UPDATE CONTDIG_OUTROS set STATUS = '3'  
					UPDATE CONTDIG_OUTROS set STATUS = cStNovo  
						WHERE ICARD = cMatric AND 
								BIO_TIPO = cBio;
					COMMIT;
				END IF;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN NULL;
				WHEN reco_lock THEN NULL;
				WHEN OTHERS THEN NULL;	
			END;
		END IF;

	EXCEPTION 
		WHEN NO_DATA_FOUND THEN NULL;
		WHEN OTHERS THEN NULL;
	END;


END Auxtrg_digmatcod2;	
/


