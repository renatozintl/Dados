CREATE or REPLACE FUNCTION sqlrep_fimExcAuto4 (cEndIp in VARCHAR2, cStat in VARCHAR2) 
RETURN NUMBER IS

xCont NUMBER;
ret NUMBER;
cAux VARCHAR2(1);
cAuxIp VARCHAR2(15);
cStInc VARCHAR2(1);
cNovoStat VARCHAR2(1);

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

cursor lexcf002_cur is 
	SELECT IFUNC, STATUS FROM REPAUTO012 
		WHERE END_IP = cEndIp AND STATUS = '2' 
		order by IFUNC for update of STATUS;

begin
    xCont := 0;
    ret := 0;
	cNovoStat := cStat;
	
	-- atualiza o status somente dos funcionarios do rep q estavam sendo excluidos (sofrendo o comando de exlucsao no conex)
	for r in lexcf002_cur LOOP
		if (cStat = '0') then
			--INSERT INTO HISTREPFUN (IFUNC, END_IP, INSEXC, MODO)	VALUES (r.IFUNC, cEndIp, 'E', 'A');	-- TIPO:'I'= INCLUSAO, 'E'=EXCLUSAO; MODO:'A'=AUTOMATICO, 'M'=MANUAL
			delete REPAUTO012 where current of lexcf002_cur ;
		else
			--NOVO
			-- SE ESTIVER PENDENTE, DEVE VERIFICAR SE H� ALGUM COMANDO DE EXCLUSAO DESSE FUNCION�RIO PARA O EQUIPAMENTO A SER EXECUTADO.
			-- SE HOUVER, DEVE-SE IGNORAR ESTA PENDENCIA DE INCLUSAO E TORNA-LA STATUS '4', PARA QUE O GERENCIADOR DE CARGA AUTOM�TICA ANULE ESTA PENDENCIA
			if (cStat = '3') then
				BEGIN 
					SELECT STATUS INTO cStInc FROM REPAUTO011 
						WHERE IFUNC = r.IFUNC and END_IP = cEndIp AND STATUS <> '0' ;

					-- ENCONTROU COMANDO MAIS RECENTE DE INCLUSAO, ENT�O NOVO VALOR DE 	REPAUTO012.STATUS SER� '4' PARA QUE ESTA CARGA SER DESCARTADA, E N�O SER� TRATADA COMO PENDENCIA.					
					cNovoStat := '4';
						
				EXCEPTION
					WHEN NO_DATA_FOUND then 
						null;
					WHEN OTHERS then 
						null;
				END;
			end if;
			--FIM NOVO
		
			--update REPAUTO012 set STATUS = cStat where current of lexcf002_cur ;
			update REPAUTO012 set STATUS = cNovoStat where current of lexcf002_cur ;

			
		end if;
		xCont := xCont+1;
	END LOOP;


	BEGIN
		SELECT STATUS into cAux   
			FROM REPAUTO002 
			WHERE END_IP = cEndIp for update nowait;
			
		UPDATE REPAUTO002 SET STATUS = cStat WHERE END_IP = cEndIp;
			

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			ret := 0;
		WHEN reco_lock THEN
			ret := (0);
		WHEN OTHERS THEN
			ret := -1;
	END;
    
	BEGIN
		SELECT END_IP INTO cAuxIp FROM REPLASTCOM WHERE END_IP = cEndIp for update nowait;
		UPDATE REPLASTCOM SET DATA_INS = SYSDATE WHERE END_IP = cEndIp;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN 
			INSERT INTO REPLASTCOM (END_IP, DATA_INS) VALUES (cEndIp, SYSDATE);
		WHEN reco_lock THEN
			NULL;
		WHEN OTHERS THEN 
			NULL;
	END;
	
	
	COMMIT;
	return (ret);
		
END sqlrep_fimExcAuto4;
/

