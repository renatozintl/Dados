CREATE OR REPLACE FUNCTION sqlproc_matmens (MATRIC VARCHAR2,  cMens OUT VARCHAR2)
   RETURN NUMBER IS
      Retfun NUMBER;
      RECO_LOCK EXCEPTION;
      PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);
      AUX VARCHAR2(15);
      Alt NUMBER;
      Pad NUMBER;

BEGIN

   Retfun := 1;      -- assume que achou matricula
   BEGIN
       SELECT Mensagem
       INTO   cMens 
       FROM CONTROLE WHERE ICARD = MATRIC;


   EXCEPTION
	WHEN NO_DATA_FOUND THEN
		Retfun := 0;
	WHEN OTHERS THEN
		Retfun := -1;
   END;
   return (Retfun);
END sqlproc_matmens;
/


