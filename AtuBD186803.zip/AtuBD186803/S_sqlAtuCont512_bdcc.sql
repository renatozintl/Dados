USE [suricato]
GO

/****** Object:  StoredProcedure [TELESSVR].[sqlAtuCont512_bdcc]    Script Date: 19/08/2026 15:09:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO


ALTER PROCEDURE [TELESSVR].[sqlAtuCont512_bdcc] @cMatric char(12), @cDataOcor CHAR(6) 
AS

DECLARE @cDataOcorTotal CHAR(10) 
DECLARE @Ret INT, @nContMes INT, @nContAno INT
DECLARE @cMesAno CHAR(4), @cAno CHAR(2), @cMesAnoOcorr CHAR(4), @cAnoOcorr CHAR(2)
DECLARE @cDataData_Mes char(10)
DECLARE @cDataData_Ano char(10)
DECLARE @DiaMesAnoTabela char(10)
DECLARE @DiaMesAno VARCHAR(6)


	SET @Ret = 0;
	SET @nContMes = 0;
	SET @nContAno = 0;
	SET @cDataOcorTotal = substring(@cDataOcor,1,2) + '/' + substring(@cDataOcor,3,2) + '/' + '20' + substring(@cDataOcor,5,2);		--DD/MM/YYYY

    SET @cMesAnoOcorr = substring (@cDataOcor,3,4);		-- mmyy
    SET @cAnoOcorr 	  = substring (@cDataOcor,5,2);		-- yy
	
	-- PROCURA PELO CONTADOR DE ENTRADAS PARA CARTAO NAO BDCC EM EQUIPAMENTO BDCC
	SELECT @nContMes = CONT_MES, 
			@cDataData_Mes = CONVERT(CHAR(12),DATA_MES,103) ,		-- dd/mm/yyyy
			@nContAno = CONT_ANO, 
			@cDataData_Ano = CONVERT(CHAR(12),DATA_ANO,103)	,		-- dd/mm/yyyy
			@DiaMesAnoTabela = CONVERT(CHAR(12),DATA_MES,103)			-- dd/mm/yyyy
		FROM CONT512_AUX 
		WHERE ICARD = @cMatric;
		
	IF (@@ROWCOUNT <> 0) begin 		
		SET @cMesAno = substring (@cDataData_Mes, 4,2) + substring (@cDataData_Mes, 9,2)  		-- mmyy
		SET @cAno = substring (@cDataData_Ano, 9,2)  		-- yy
		SET @DiaMesAno = substring (@DiaMesAnoTabela, 1,2) + substring (@DiaMesAnoTabela, 4,2) + substring (@DiaMesAnoTabela, 9,2)		-- ddmmyy
	
		IF (@cDataOcor <> @DiaMesAno) begin
			-- VERIFICA SE ATINGIU	QTD MAXIMA DE ENTRADAS NO MES
			IF (@cMesAno = @cMesAnoOcorr) BEGIN
				UPDATE CONT512_AUX SET 
					CONT_MES = @nContMes + 1,
					CONT_ANO = @nContAno + 1,
					DATA_MES = CONVERT(DATE, @cDataOcorTotal, 103),		-- 103 TEM O FORMAT DD/MM/YYYY
					DATA_ANO = CONVERT(DATE, @cDataOcorTotal, 103) 
				WHERE ICARD = @cMatric;				
			END
			ELSE
				IF (@cAno = @cAnoOcorr) BEGIN
					UPDATE CONT512_AUX SET 
						CONT_MES = 1,
						CONT_ANO = @nContAno + 1,
						DATA_MES = CONVERT(DATE, @cDataOcorTotal, 103),		-- 103 TEM O FORMAT DD/MM/YYYY
						DATA_ANO = CONVERT(DATE, @cDataOcorTotal, 103)		-- 103 TEM O FORMAT DD/MM/YYYY
					WHERE ICARD = @cMatric;					
				END
				ELSE BEGIN
					UPDATE CONT512_AUX SET 
						CONT_MES = 1,
						CONT_ANO = 1,
						DATA_MES = CONVERT(DATE, @cDataOcorTotal, 103),		-- 103 TEM O FORMAT DD/MM/YYYY
						DATA_ANO = CONVERT(DATE, @cDataOcorTotal, 103)		-- 103 TEM O FORMAT DD/MM/YYYY
					WHERE ICARD = @cMatric;
				END
		END
	END
	ELSE BEGIN
		INSERT INTO CONT512_AUX (ICARD, CONT_MES, DATA_MES, CONT_ANO, DATA_ANO) 
					VALUES (@cMatric, 1, CONVERT(DATE, @cDataOcorTotal, 103), 1, CONVERT(DATE, @cDataOcorTotal, 103));
	END
	
	SELECT @Ret
			

GO


