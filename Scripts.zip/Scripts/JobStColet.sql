declare n0 number;
begin
dbms_job.submit (n0, 'sqlat_StatColetor;', sysdate, '(sysdate)+1/(60*24)');
commit;
end;
/
