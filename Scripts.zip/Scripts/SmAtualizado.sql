-- insere em LOGPEND as atualiza��es realizadas no codin via atualizacao forcada ou em lista
-- atualiza em PEND_ON002 a qtde.livre resultante no codin

CREATE or REPLACE FUNCTION sqlsm_atualizado (
	Registro in VARCHAR2,
	nLivre in NUMBER
) RETURN NUMBER IS

cIdentif char(14);
cIcard char(12);
cNumcpo char(2);
cInform char(56);
cDataAtu char(10);
cEndIp char(15);
cNSerial char(10);
reco_locK EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);
nRet number;
nAux number;
	
BEGIN
	nRet := 0;
	cIdentif := SUBSTR(Registro, 1, 14);
	cNSerial := SUBSTR(Registro, 15, 10);
	cDataAtu := SUBSTR(Registro, 25, 10);
	cEndIp   := SUBSTR(Registro, 35, 15);
	cIcard := '            ';		-- 12 espacos
	cNumCpo := '  ';				-- 2 espacos
	cInform := ' ';					-- 1 espaco
			
	-- insere em PEND_ON007 
	INSERT into PEND_ON007 (IDENTIF, EVENTO,NUMSERIAL, ICARD, NUMCPO, INFORM, END_IP, INCLUSAO, TIPO_ATU)
		values  (to_identif(cIdentif), '16', cNSerial, cIcard, cNumcpo, cInform, cEndIP, SYSDATE, '0');
	
	COMMIT;
	return (nRet);
	
END sqlsm_atualizado;
/
