@@AuxTrgRepDig.sql;
@@AuxTrgRepFunc.SQL;
@@TrgRepFunc2_D.sql;
@@TrgRepFunc2_IU.sql;
@@TrgRepGrp2.sql;

