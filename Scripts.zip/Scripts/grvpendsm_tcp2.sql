CREATE OR REPLACE FUNCTION sqlbloco_pend_smart_tcp2 (cRegistro in VARCHAR2, Tipo in NUMBER, cEndIp in VARCHAR2)
   RETURN NUMBER IS
      Ret NUMBER;
      cIp CHAR(15);

BEGIN
	IF (Tipo = 0) THEN
		INSERT INTO PENDSMART (END_IP, NUMSERIAL, IDENTIF, NUMCPO, INFORM) 
			VALUES (cEndIp,
					SUBSTR(cRegistro,  1, 10),
					--SUBSTR(cRegistro, 11, 14),
					to_identif(SUBSTR(cRegistro, 11, 14)),
					SUBSTR(cRegistro, 25,  2),
					SUBSTR(cRegistro, 27, 56));
	ELSE
		INSERT INTO PENDSMART (END_IP, NUMSERIAL, IDENTIF) 
			VALUES (cEndIp,
					SUBSTR(cRegistro,  1, 10),
					--SUBSTR(cRegistro, 11, 14));
					to_identif(SUBSTR(cRegistro, 11, 14)));
	END IF;
	Return (0);
END sqlbloco_pend_smart_tcp2;
/


