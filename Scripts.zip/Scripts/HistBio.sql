CREATE or REPLACE FUNCTION sqlhist_bio (cListaMat in VARCHAR2, cEndIp in VARCHAR2, cInsDel in VARCHAR2, cModo in VARCHAR2, cBioTipo in VARCHAR2) 
RETURN NUMBER IS

Tam NUMBER;
Pos NUMBER;
ret NUMBER;
cAcao VARCHAR2(1);

cBio CHAR(1);

BEGIN


	cBio := ' ';
	BEGIN
		SELECT BIO_TIPO INTO cBio FROM DAT07 WHERE END_IP = cEndIp;
		
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			cBio := ' ';
		WHEN OTHERS THEN
			cBio := ' ';
	END;
	
	ret := 0;
	IF (cInsDel = '3') THEN
		cAcao := 'I';
	ELSE
		cAcao := 'E';
	END IF;
		
	Tam := LENGTH (cListaMat) ;

	IF (Tam > 0) THEN
		Pos := 1;
		WHILE (Pos < Tam) LOOP
			INSERT INTO HISTDIG (IFUNC, END_IP, BIO_TIPO, INSEXC, MODO) 
			--				VALUES (SUBSTR (cListaMat, Pos, 12) , cEndIp, cBioTipo, cAcao, cModo);
				VALUES (SUBSTR (cListaMat, Pos, 12) , cEndIp, cBio, cAcao, cModo);
			Pos := Pos + 12;
		END LOOP;

		COMMIT;
	END IF;

	return (ret);
		
END sqlhist_bio;
/


