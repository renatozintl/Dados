CREATE OR REPLACE FUNCTION sqlAtuCont512_bdcc (cMatric VARCHAR2, cDataOcor VARCHAR2) 
RETURN NUMBER IS
Ret  NUMBER;
nContMes NUMBER;
nContAno NUMBER;
cMesAno VARCHAR(4);
cAno VARCHAR(2);
cMesAnoOcorr VARCHAR(4);
cAnoOcorr VARCHAR(2);

BEGIN
	
    Ret := 0;
    nContMes := 0;
    nContAno := 0;
    
    cMesAnoOcorr := substr (cDataOcor,3,4);		-- mmyy
    cAnoOcorr := substr (cDataOcor,5,2);		-- yy
    

	BEGIN
		-- PROCURA PELO CONTADOR DE ENTRADAS PARA CARTAO NAO BDCC EM EQUIPAMENTO BDCC
		SELECT 	CONT_MES, substr (to_char(DATA_MES, 'ddmmyyyy'), 3, 2)|| substr (to_char(DATA_MES, 'ddmmyyyy'), 7, 2), 			-- coleta mmyy
				CONT_ANO, substr (to_char(DATA_ANO, 'ddmmyyyy'), 7, 2) 															-- coleta yy
			INTO nContMes, cMesAno, nContAno, cAno
			FROM CONT512_AUX 
				WHERE ICARD = cMatric FOR UPDATE NOWAIT;
			
		-- VERIFICA SE ATINGIU	QTD MAXIMA DE ENTRADAS NO MES
		IF (cMesAno = cMesAnoOcorr) THEN
			UPDATE CONT512_AUX SET 
				CONT_MES = nContMes + 1,
				CONT_ANO = nContAno + 1,
				DATA_MES = to_date (cDataOcor, 'ddmmrrrr'),
				DATA_ANO = to_date (cDataOcor, 'ddmmrrrr') 
			WHERE ICARD = cMatric;				
		ELSE
			IF (cAno = cAnoOcorr) THEN
				UPDATE CONT512_AUX SET 
					CONT_MES = 1,
					CONT_ANO = nContAno + 1,
					DATA_MES = to_date (cDataOcor, 'ddmmrrrr'),
					DATA_ANO = to_date (cDataOcor, 'ddmmrrrr') 
				WHERE ICARD = cMatric;					
			ELSE
				UPDATE CONT512_AUX SET 
					CONT_MES = 1,
					CONT_ANO = 1,
					DATA_MES = to_date (cDataOcor, 'ddmmrrrr'),
					DATA_ANO = to_date (cDataOcor, 'ddmmrrrr') 
				WHERE ICARD = cMatric;
			END IF;
		END IF;

	EXCEPTION
		WHEN NO_DATA_FOUND then 
			INSERT INTO CONT512_AUX (ICARD, CONT_MES, DATA_MES, CONT_ANO, DATA_ANO) 
							VALUES (cMatric, 1, to_date (cDataOcor, 'ddmmrrrr'), 1, to_date (cDataOcor, 'ddmmrrrr'));
		
		WHEN others then 
			Ret := -1;
	END;
		
	COMMIT;
	return Ret;
	
END sqlAtuCont512_bdcc;
/


