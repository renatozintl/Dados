CREATE OR REPLACE FUNCTION sqlrhora_gerbiof3 (cEndIp varchar2, nTipo NUMBER) 
   RETURN NUMBER IS

Ret    NUMBER;
cHoraIni CHAR(8);	-- 'hh:mi:ss'
cHoraFim CHAR(8);	-- 'hh:mi:ss'
cHoraCor CHAR(8);		-- 'hh:mi:ss'
nQtd 	NUMBER;
   
BEGIN
	
    Ret := 1;
    --nQtd := 5;
    nQtd := 1000;
    
    IF (nTipo = 2) THEN		-- PROCURA POR FAIXA DE EXECU��O DE GERENCIAMENTO DE BIOMETRIA
		BEGIN
			SELECT INICIO_GERBIO, FINAL_GERBIO, QTD_FUNC INTO cHoraIni, cHoraFim, nQtd 
				FROM REPAUTOBIOF
				WHERE End_Ip = cEndIp;

		EXCEPTION
			-- CASO NAO ENCONTRE, INDICA QUE O GERENCIADOR SEMPRE SER� EXECUTADO
			WHEN NO_DATA_FOUND then Ret := 0;
			WHEN OTHERS then Ret := -1;
		END;
    
    ELSE					-- PROCURA POR FAIXA DE EXECU��O DE GERENCIAMENTO DE FUNCIONARIOS
		BEGIN
			SELECT INICIO_GERFUN, FINAL_GERFUN, QTD_FUNC INTO cHoraIni, cHoraFim, nQtd 	
				FROM REPAUTOBIOF
				WHERE End_Ip = cEndIp;

		EXCEPTION
			-- CASO NAO ENCONTRE, INDICA QUE O GERENCIADOR SEMPRE SER� EXECUTADO
			WHEN NO_DATA_FOUND then Ret := 0;
			WHEN OTHERS then Ret := -1;
		END;
    END IF;
    
    
    IF (Ret = 0) then		-- NAO ENCONTROU NA TABELA, INDICA QUE O GERENCIADOR SEMPRE SER� EXECUTADO
    	--return (1);
    	return (nQtd);		-- retorna o default de quantidade
    END IF;

    IF (Ret > 0) THEN		-- ENCONTROU NA TABELA, VAI VERIFICAR A FAIXA HORARIA DE PERMISSAO DE EXECU��O DO GERENCIADOR
    	Ret := 0;			-- assume que horario � nao permitido
    	SELECT TO_CHAR (sysdate, 'HH24:MI:SS')
			into cHoraCor from dual; 
		
		-- VERIFICA SE HORA INICIAL � MENOR QUE A HORA FINAL. EXEMPLO:  DE  08:00:00 AS 16:00:00
		IF (cHoraIni < cHoraFim) THEN 
			IF ((cHoraCor >= cHoraIni) AND (cHoraCor <= cHoraFim)) THEN
				Ret := 1;
			END IF;
		
		-- SE HORA INICIAL � MAIOR QUE A HORA FINAL.EXEMPLO:  DE  18:00:00 AS 06:00:00
		ELSE 
			IF (cHoraCor >= cHoraIni) THEN
				Ret := 1;
			ELSE
				IF (cHoraCor <= cHoraFim) THEN
					Ret := 1;
				END IF;
			END IF;
		END IF;
    END IF;

    --return (Ret);
    
	IF (Ret > 0) then
		if ((nQtd < 0) OR nQtd IS NULL) then
			nQtd := 0;
		end if;
		
		return (nQtd);

	ELSE
		return (0);
	END IF;

END sqlrhora_gerbiof3;
/

