CREATE OR REPLACE FUNCTION sqlatu_vrdclob_cnx (cMatric in VARCHAR2, nChave in NUMBER, templ1 in VARCHAR2, templ2 in VARCHAR2, 
templ3 in VARCHAR2, templ4 in VARCHAR2, templ5 in VARCHAR2,  templ6 in VARCHAR2, nTipoTempl in NUMBER, nQtdBytes in NUMBER, cBioTipo in VARCHAR2)
   RETURN NUMBER IS
   cAuxMat VARCHAR2(15);
   matric VARCHAR2(15);
   nRetorno NUMBER;
   reco_lock EXCEPTION;
   PRAGMA EXCEPTION_INIT (reco_lock,-54);  -- erro quando registro lockado 

BEGIN

	nRetorno := 1;
	
	matric := cMatric;

	IF (nChave = 1)	 then 	-- pesquisa por Numero Serial, para coletar valor de Icard
	    
		BEGIN
			SELECT ICARD 
				into matric
			FROM Controle A
			WHERE A.NumSerial = substr(cMatric, 3, 10);
		EXCEPTION
			WHEN NO_DATA_FOUND THEN matric := cMatric;
			WHEN OTHERS THEN matric := cMatric;
		END;
	ELSIF (nChave = 2)	 then 	-- pesquisa por CPF, para coletar valor de Icard
		BEGIN
			SELECT ICARD 
				into matric
			FROM ContCPF A 
			WHERE  A.CPF = substr(cMatric, 2, 11); 
		EXCEPTION
			WHEN NO_DATA_FOUND THEN matric := cMatric;
			WHEN OTHERS THEN matric := cMatric;
		END;
	END IF;		

	

	BEGIN
		SELECT Icard INTO cAuxMat FROM CONTDIG_BIOMET
			WHERE Icard = matric AND 				-- matricula
				  BIO_TIPO = cBioTipo AND			-- identificador  do biometrico 
				  TPDIG = nTipoTempl						-- identificador do dedo (0 = padro, 1=alternativo, 2 = coacao)
		FOR UPDATE NOWAIT;
		
		UPDATE CONTDIG_BIOMET
			SET DIGITAL = to_clob(templ1 || templ2 || templ3 || templ4 || templ5 || substr (templ6,1,48)) ,
				Status = '1', Status_rep = '1'
		WHERE Icard = matric AND 				-- matricula
			  BIO_TIPO = cBioTipo AND			-- identificador  do biometrico 
			  TPDIG = nTipoTempl;						-- identificador do template (0 = padrao, 1=alternativo, 2 = coacao)
		
	EXCEPTION
		WHEN reco_lock THEN nRetorno:= -1;
		WHEN NO_DATA_FOUND THEN nRetorno := 0;
		WHEN OTHERS THEN nRetorno := -1;
	END;

	
	
	IF (nRetorno = 0) THEN          -- matricula NAO existe, INSERE a digital
		INSERT INTO CONTDIG_BIOMET (ICARD, BIO_TIPO, TPDIG, STATUS, STATUS_REP, DIGITAL)  
			VALUES (matric, cBioTipo, nTipoTempl, '1', '1', to_clob(templ1 || templ2 || templ3 || templ4 || templ5 || substr (templ6,1,48)) );
		
		nRetorno := 1;
	END IF;
	
	COMMIT;    
	
	
    return (nRetorno);

END sqlatu_vrdclob_cnx;
/

