CREATE OR REPLACE FUNCTION sqlle_apoc2 (templ1 in VARCHAR2, nCorrige IN NUMBER, templ2 out VARCHAR2) 
   RETURN NUMBER IS

Ret    NUMBER;
nTotal    NUMBER;
cAux VARCHAR2(50);	

reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);  

   
BEGIN
	
    Ret := 0;
    nTotal := 0;
    templ2 := 0;
    
    BEGIN
		SELECT count(*) into nTotal 
			FROM DAT12 ;
	EXCEPTION 
		WHEN NO_DATA_FOUND then 
			return (-2);
		WHEN OTHERS then 
			return (-2);
	END ;

    
    IF (nTotal = 1) then 
    	IF (nCorrige = 1) then
    		UPDATE DAT12 SET XDSC = templ1;
    		templ2 := templ1;
    	ELSE
    		SELECT XDSC into templ2 FROM DAT12 ;
    	END IF;
    	Ret := 1;
		return (Ret);	
	END IF;
	
    IF (nTotal = 0) then 
    	INSERT INTO DAT12 (XDSC) VALUES (templ1);
    	Ret := 0;
	END IF;
	
    IF (nTotal > 1) then 
    	DELETE FROM DAT12;
    	INSERT INTO DAT12 (XDSC) VALUES (templ1);
    	Ret := -1;
	END IF;
	COMMIT;
	
	return (Ret);
	
END sqlle_apoc2;
/

