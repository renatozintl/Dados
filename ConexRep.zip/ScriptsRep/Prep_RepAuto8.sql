CREATE OR REPLACE PROCEDURE Prep_RepAuto8 (nQtd NUMBER) IS

TYPE ifunc_type IS TABLE OF REPNAUTO000.IFUNC%TYPE
	INDEX BY binary_integer;
TYPE status_type IS TABLE OF REPNAUTO000.STATUS%TYPE
	INDEX BY binary_integer;
TYPE grupo_type IS TABLE OF REPNAUTO000.GRUPO%TYPE
	INDEX BY binary_integer;
TYPE doc_type IS TABLE OF REPNAUTO000.DOC_TIPO%TYPE
	INDEX BY binary_integer;

l_ifunc ifunc_type;
l_status status_type;
l_grupo grupo_type;
l_doctipo doc_type;

RECO_LOCK EXCEPTION;
PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);

tem_deadlock EXCEPTION;
PRAGMA EXCEPTION_INIT (tem_deadlock, -60);

total number;
nCont NUMBER;
nTemLocal NUMBER;
--nQtd NUMBER;

xc_status CHAR(1);
xc_ifunc CHAR(12);
xc_endip CHAR(15);
xc_doctipo CHAR(1);
ret CHAR(1);

cAux CHAR(1);
cAux1 CHAR(1);
cTipo CHAR(1);
cDocTipoAux CHAR(1);
cStatusAux CHAR(1);

CURSOR cur_tmpauto000 IS SELECT IFUNC, END_IP, STATUS, DOC_TIPO from TMP_NREP001 where STATUS = '3';

CURSOR cur_tmpauto001 IS SELECT IFUNC, END_IP, STATUS from TMP_NREP002 where STATUS = '8';

BEGIN

	ret := 0;
	--nQtd := 5 * nTempo;
	BEGIN
		-- **************** seleciona os ifuncs alterados da tabela REPAUTO000 (resultante da trigger) ****************
		-- para preparar a tabela TMP_NREP000, e atualizar status de REPNAUTO000 para TRATADO ('0')

		select IFUNC, STATUS, GRUPO, DOC_TIPO 
			BULK COLLECT INTO l_ifunc, l_status, l_grupo, l_doctipo
		from (
			SELECT IFUNC, STATUS, GRUPO, DOC_TIPO 
			FROM
				REPNAUTO000
			WHERE
				STATUS = '3' or STATUS = '8' 		-- '3'(insert/upd), '8'(excluido)
			ORDER BY DATA_INS, IFUNC
		)
		WHERE ROWNUM <= nQTD ;
    


		total := l_ifunc.count;

		FOR indx IN 1 .. total
		LOOP
			nTemLocal := 0;
			DELETE FROM TMP_NREP000GRP;
			-- inclui em TMP_NREP000GRP TODOS OS REPS Q FAZEM PARTE DO GRUPO EM QUESTAO (NOVO OU VELHO) DO FUNCIONARIO
			INSERT into TMP_NREP000GRP (IFUNC, GRUPO,  END_IP, STATUS, DOC_TIPO)
				select l_ifunc(indx), l_grupo(indx), VIEWGRPREP.end_ip, l_status(indx), l_doctipo(indx) 
					from VIEWGRPREP
					where
						to_number(VIEWGRPREP.grupo) = to_number(l_grupo(indx));

			IF (sql%rowcount != 0) THEN		-- ACHOU equipamento RELACIONADO ao GRUPO EM QUESTAO (NOVO OU VELHO)
				nTemLocal := 1;
			END IF;


			IF (nTemLocal = 1) THEN
			
				-- ********** TRATAMENTO PARA INSERCAO DE FUNCIONARIO  *****************

				-- Insere em tabela OS REGISTROS de TMP_NREP000GRP
				IF (l_status(indx) = '3') then
					cTipo := '3';
					FOR r in (SELECT END_IP from TMP_NREP000GRP
								WHERE IFUNC = l_ifunc(indx) and 
								      STATUS = cTipo and
									  to_number(GRUPO) = to_number(l_grupo(indx)) and 
									  DOC_TIPO = l_doctipo(indx)
							 )
					LOOP
						BEGIN
							SELECT STATUS, DOC_TIPO into cAux, cDocTipoAux from TMP_NREP001 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
							
							-- VERIFICA SE O QUE ESTA 'CADASTRADO' � O MESMO TIPO DE ALTERA��O DE INFORMA��O. SE O MESMO TIPO DE INFORMA��O ALTERADO, NADA FAZ
							-- CASO SEJAM INFORMA��ES ALTERADAS DIFERENTES: ATUALIZA PARA DOC_TIPO = '0', PARA ALTERAR TUDO(CPF E PIS) NO REP 
							IF ((cDocTipoAux = '0') OR (cDocTipoAux = l_doctipo(indx)) ) THEN 
								null;
							ELSE
								UPDATE TMP_NREP001 SET DOC_TIPO = '0' 
									where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;

							END IF;


						EXCEPTION
							WHEN NO_DATA_FOUND then
								INSERT into TMP_NREP001 (IFUNC, END_IP, STATUS, DOC_TIPO)	VALUES  (l_ifunc(indx), r.END_IP, cTipo, l_doctipo(indx) );
							WHEN OTHERS then NULL;
						END;


						-- VERIFICA SE FUNCIONARIO X IP JA EST� EM TABELA DE EXCLUSAO, PARA EXCLUIR
						BEGIN
							SELECT STATUS into cAux from TMP_NREP002 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
							IF (cAux = '8') then
								DELETE FROM TMP_NREP002 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
							END IF;

						EXCEPTION
							WHEN NO_DATA_FOUND then NULL;
							WHEN OTHERS then NULL;
						END;

						-- **********************************************************************
						-- NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO
						-- VERIFICA SE FUNCIONARIO X IP JA EST� EM TABELA DE EXCLUSAO E ESTA PENDENTE
						BEGIN

							SELECT STATUS INTO cAux FROM REPAUTO012
								WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP AND (STATUS = '3' OR STATUS = '2');

							IF (cAux = '3') then		-- SITUA��O PENDENTE
								BEGIN
									SELECT STATUS INTO cAux1 FROM REPAUTO012
										WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;

									UPDATE REPAUTO012 SET STATUS = '4' 							-- A EXCLUSAO QUE EST� PENDENTE FICARA COM ESTADO DE IGNORADA E NAO SER� MAIS EXECUTADA
										WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;

								EXCEPTION
									WHEN RECO_LOCK THEN
										null;
									WHEN NO_DATA_FOUND THEN
										null;
									WHEN OTHERS THEN
										null;
								END;

							ELSE	 -- STATUS = '2' : PODE ESTAR NA SITUA��O DEXECUTANDO E NAO OBTEVE RESPOSTA
								-- PROCURA EM REPAUTO002 SE O EQUIPAMENTO EST� MAIS DE 30 SEGUNDOS ESPERANDO RESPOSTA, ENTAO PODE TIRAR.
								BEGIN
									SELECT STATUS into cAux1 from REPAUTO002
										where END_IP = r.END_IP AND STATUS = '2' and (DATA_LOAD + ( 30 / 24 / 3600 )  < sysdate) ;		-- O COMANDO FOI FEITO HA MAIS DE 30 SEGUNDOS
									BEGIN
										SELECT STATUS INTO cAux1 FROM REPAUTO012
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;

										UPDATE REPAUTO012 SET STATUS = '4' 						-- sinaliza que REP NAO RESPONDEU AO COMANDO DE EXCLUSAO E FICAR� COM ESTADO DE IGNORADA E NAO SER� MAIS EXECUTADA
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;

									EXCEPTION
										WHEN RECO_LOCK THEN
											null;
										WHEN NO_DATA_FOUND THEN
											null;
										WHEN OTHERS THEN
											null;
									END;
								EXCEPTION
									WHEN RECO_LOCK THEN
										null;
									WHEN NO_DATA_FOUND THEN
										null;
									WHEN OTHERS THEN
										null;
								END;
							END IF;

						EXCEPTION
							WHEN NO_DATA_FOUND THEN
								null;
							WHEN OTHERS THEN
								null;
						END;


						-- FIM NOVO    FIM NOVO    FIM NOVO    FIM NOVO    FIM NOVO
						-- **********************************************************************

					END LOOP;

				ELSIF (l_status(indx) = '8') then
					cTipo := '8';

					DELETE FROM TMP_NREP000OUTROS;

					-- inclui em TMP_NREP000OUTROS TODOS OS REPS Q FAZEM PARTE De outros GRUPOs DO FUNCIONARIO
					INSERT into TMP_NREP000OUTROS (IFUNC, GRUPO, END_IP, STATUS)		-- inclui em TMP_NREP000OUTROS TODOS OS REPS Q FAZEM PARTE DOs outros GRUPOs DO FUNCIONARIO
                  		/*
						select distinct l_ifunc(indx), VIEWGRPREP.Grupo,  VIEWGRPREP.end_ip, l_status(indx)
							from VIEWGRPREP , REPGRPF
								where (to_number(VIEWGRPREP.grupo) != to_number(l_grupo(indx)) ) and
									  (to_number(VIEWGRPREP.grupo)  in (SELECT to_number(GRUPO) FROM REPGRPF WHERE IFUNC =l_ifunc(indx) ) ) and
									  (to_number(VIEWGRPREP.grupo) not in (SELECT to_number(GRUPO) FROM TMP_NREPGRPATV WHERE IFUNC =l_ifunc(indx)) ) ;
                        */
                        
                        select l_ifunc(indx), VIEWGRPREP.Grupo,  VIEWGRPREP.end_ip, l_status(indx)
							from VIEWGRPREP , REPGRPF
								where (to_number(VIEWGRPREP.grupo) = to_number(repgrpf.grupo) ) and
                        			  (REPGRPF.IFUNC = l_ifunc(indx)) AND
                        			  (to_number(VIEWGRPREP.grupo) != to_number(l_grupo(indx)) ) and
							  	  	  (to_number(VIEWGRPREP.grupo) not in (SELECT to_number(GRUPO) FROM TMP_NREPGRPATV WHERE IFUNC =l_ifunc(indx)) ) ;
					
					nCont := sql%rowcount;


					FOR r in (SELECT END_IP from TMP_NREP000GRP
								WHERE IFUNC = l_ifunc(indx) and
									  STATUS = cTipo and
									  to_number(GRUPO) = to_number(l_grupo(indx)) and
									  DOC_TIPO = l_doctipo(indx)
							 )
					LOOP
						nCont := 0;
						SELECT count(*) into nCont from TMP_NREP000OUTROS WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
						IF (nCont = 0) then
							BEGIN
								SELECT STATUS into cAux from TMP_NREP002 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;

							EXCEPTION
								WHEN NO_DATA_FOUND then
									INSERT into TMP_NREP002 (IFUNC, END_IP, STATUS)	VALUES  (l_ifunc(indx), r.END_IP, cTipo );
								WHEN OTHERS then NULL;
							END;

							-- VERIFICA SE FUNCIONARIO X IP JA EST� EM TABELA DE INCLUSAO, PARA INCLUIR
							BEGIN
								SELECT STATUS into cAux from TMP_NREP001 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;
								DELETE FROM TMP_NREP001 where IFUNC = l_ifunc(indx) and END_IP = r.END_IP;

							EXCEPTION
								WHEN NO_DATA_FOUND then NULL;
								WHEN OTHERS then NULL;
							END;


							-- **********************************************************************
							-- NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO  NOVO
							-- VERIFICA SE FUNCIONARIO X IP JA EST� EM TABELA DE INCLUSAO E ESTA PENDENTE
							BEGIN

								SELECT STATUS INTO cAux FROM REPAUTO011
									WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP AND (STATUS = '3' OR STATUS = '2');

								IF (cAux = '3') then		-- SITUA��O PENDENTE
									BEGIN
										SELECT STATUS INTO cAux1 FROM REPAUTO011
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;

										UPDATE REPAUTO011 SET STATUS = '4'
											WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;

									EXCEPTION
										WHEN RECO_LOCK THEN
											null;
										WHEN NO_DATA_FOUND THEN
											null;
										WHEN OTHERS THEN
											null;
									END;

								ELSE	 -- STATUS = '2' : PODE ESTAR NA SITUA��O DEXECUTANDO E NAO OBTEVE RESPOSTA
									-- PROCURA EM REPAUTO001 SE O EQUIPAMENTO EST� MAIS DE 30 SEGUNDOS ESPERANDO RESPOSTA, ENTAO PODE TIRAR.
									BEGIN
										SELECT STATUS into cAux1 from REPAUTO001
											where END_IP = r.END_IP AND STATUS = '2' and (DATA_LOAD + ( 30 / 24 / 3600 )  < sysdate) ;		-- O COMANDO FOI FEITO HA MAIS DE 30 SEGUNDOS
										BEGIN
											SELECT STATUS INTO cAux1 FROM REPAUTO011
												WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP  FOR UPDATE NOWAIT;

											UPDATE REPAUTO011 SET STATUS = '4'
												WHERE IFUNC = l_ifunc(indx) and END_IP = r.END_IP;

										EXCEPTION
											WHEN RECO_LOCK THEN
												null;
											WHEN NO_DATA_FOUND THEN
												null;
											WHEN OTHERS THEN
												null;
										END;
									EXCEPTION
										WHEN RECO_LOCK THEN
											null;
										WHEN NO_DATA_FOUND THEN
											null;
										WHEN OTHERS THEN
											null;
									END;
								END IF;

							EXCEPTION
								WHEN NO_DATA_FOUND THEN
									null;
								WHEN OTHERS THEN
									null;
							END;


							-- FIM NOVO    FIM NOVO    FIM NOVO    FIM NOVO    FIM NOVO
							-- **********************************************************************




						END IF;

					END LOOP;

					INSERT INTO TMP_NREPGRPATV (IFUNC, GRUPO) VALUES (l_ifunc(indx), l_grupo(indx));

				END IF;


			END IF;

			-- atualiza estado para tratado em REPNAUTO000, SE N�O encontrou equipamento pertencente ao grupo e cai fora para tratar proximo funcionario
			UPDATE REPNAUTO000 SET STATUS = '0'
				WHERE IFUNC = l_ifunc(indx) and 								
					  to_number(GRUPO) = to_number(l_grupo(indx)) and 
					  DOC_TIPO = l_doctipo(indx);

			--INSERT INTO TMP_NREPGRPATV (IFUNC, GRUPO) VALUES (l_ifunc(indx), l_grupo(indx));

		END LOOP;
	END;

	-- **************** trata os novos ifuncs X Eqptos  (resultantes da tabela TMP_NREP001 - INCLUSAO)

	SELECT count(*) into nCont from TMP_NREP001 where STATUS = '3';
	IF (nCont != 0) then



/* ******************** FAZER ESTA PARTE DE BAIXO * **************************/




		-- ESTE BLOCO ABAIXO EU TIREI PORQUE O REPAUTOF() FARA ESTA PARTE DE INSERIR EM REPAUTO001 OS QUE NAO EXISTEM
		/*
		-- coloca o codin na tab. REPAUTO001 (CARGA LISTA) o codin n�o existir
		INSERT into REPAUTO001 (END_IP, STATUS)
			select distinct end_ip, '0'
			from TMP_NREP001
			where TMP_NREP001.end_ip not in ( select end_ip from REPAUTO001 ) and
					TMP_NREP001.STATUS = '3';
		*/
		-- insere ifunc-rep em tab. REPAUTO011, se n�o existir em tab.
		OPEN cur_tmpauto000;
		LOOP
			FETCH cur_tmpauto000 into xc_ifunc, xc_endip, xc_status, xc_doctipo;
			EXIT when cur_tmpauto000%NOTFOUND;

			BEGIN
				SELECT STATUS, DOC_TIPO INTO cStatusAux, cDocTipoAux FROM REPAUTO011
					WHERE IFUNC = xc_ifunc AND END_IP = xc_endip  for update nowait;
					
				-- VERIFICA SE O QUE ESTA 'CADASTRADO' � O MESMO TIPO DE ALTERA��O DE INFORMA��O. SE O MESMO TIPO DE INFORMA��O ALTERADO, NADA FAZ
				-- CASO SEJAM INFORMA��ES ALTERADAS DIFERENTES: ATUALIZA PARA DOC_TIPO = '0', PARA ALTERAR TUDO(CPF E PIS) NO REP 
				
				IF (cStatusAux = '0') THEN		-- VERIFICA SE A CARGA QUE ESTA CADASTRADA JA FOI REALIZADA
					UPDATE REPAUTO011 SET STATUS = '1', DOC_TIPO = cDocTipoAux 
						WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip;
						
				ELSE				-- A CARGA QUE ESTA CADASTRADA AINDA NAO FOI FEITA, DEVE-SE VERIFICAR SE � O MESMO TIPO DE DOCUMENTACAO Q FOI ALTERADO
					IF (cDocTipoAux <> xc_doctipo)  THEN 
						UPDATE REPAUTO011 SET STATUS = '1', DOC_TIPO = '0'
							WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip;
					
					-- ESTE BLOCO ELSE ABAIXO NAO SER� NECESSARIO, POIS SE ESTIVER 1, FICAR� COM 1. SE ESTIVER COM 3(PENDENTE), SER� DELETADO POSTERIORMENTE					
					--ELSE
					--	UPDATE REPAUTO011 SET STATUS = '1'
					--	WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip;
					END IF;				
				END IF;
				

			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					INSERT INTO REPAUTO011 (IFUNC, END_IP, STATUS, DOC_TIPO) VALUES (xc_ifunc, xc_endip, '1', xc_doctipo);

				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;


			-- deleta o ifunc da tabela de exclusao para o rep especifico do grupo
			--DELETE FROM REPAUTO012 WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1');	-- DELETA DA TABELA DE EXCLUSAO

			BEGIN
				SELECT STATUS INTO cAux FROM REPAUTO012
					WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1' OR STATUS = '4') FOR UPDATE NOWAIT;

				DELETE FROM REPAUTO012 WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1' OR STATUS = '4');	-- DELETA DA TABELA DE EXCLUSAO

			EXCEPTION
				WHEN NO_DATA_FOUND THEN null;
				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;

		END LOOP;
		CLOSE cur_tmpauto000;
	END IF;


	-- **************** trata os novos ifuncs X Eqptos  (resultantes da tabela TMP_NREP002 - EXCLUSAO)

	SELECT count(*) into nCont from TMP_NREP002 where STATUS = '8';
	IF (nCont != 0) then

		-- ESTE BLOCO ABAIXO EU TIREI PORQUE O REPAUTOF() FARA ESTA PARTE DE INSERIR EM REPAUTO001 OS QUE NAO EXISTEM
		/*
		-- coloca o codin na tab. REPAUTO002 (EXCLUSAO) o codin n�o existir
		INSERT INTO REPAUTO002 (END_IP, STATUS)
			select distinct end_ip, '0'
			from TMP_NREP002
			where TMP_NREP002.end_ip not in ( select end_ip from REPAUTO002 ) and
					TMP_NREP002.STATUS = '8';
		*/

		-- insere ifunc-rep em tab. REPAUTO012, se n�o existir em tab.
		OPEN cur_tmpauto001;
		LOOP
			FETCH cur_tmpauto001 into xc_ifunc, xc_endip, xc_status;
			EXIT when cur_tmpauto001%NOTFOUND;

			BEGIN
				SELECT STATUS INTO cAux FROM REPAUTO012
					WHERE IFUNC = xc_ifunc AND END_IP = xc_endip for update nowait;

				UPDATE REPAUTO012 SET STATUS = '1'
					WHERE  IFUNC = xc_ifunc AND END_IP = xc_endip;

			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					INSERT INTO REPAUTO012 (IFUNC, END_IP, STATUS) VALUES (xc_ifunc, xc_endip, '1');

				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;


			-- deleta o ifunc da tabela de INclusao para o rep especifico do grupo
			BEGIN
				SELECT STATUS INTO cAux FROM REPAUTO011
					WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1' OR STATUS = '4') FOR UPDATE NOWAIT;

				DELETE FROM REPAUTO011 WHERE IFUNC = xc_ifunc AND END_IP = xc_endip AND (STATUS = '0' OR STATUS = '1' OR STATUS = '4');	-- DELETA DA TABELA DE INCLUSAO

			EXCEPTION
				WHEN NO_DATA_FOUND THEN null;
				WHEN RECO_LOCK THEN null;
				WHEN OTHERS THEN null;
			END;

		END LOOP;
		CLOSE cur_tmpauto001;
	END IF;
	COMMIT;

END Prep_RepAuto8;
/
