CREATE or REPLACE FUNCTION sqller_autoLoadDigit3
(
cEndIp in VARCHAR2,
cListaMat in out VARCHAR2
) 
RETURN NUMBER IS

xCont NUMBER;
cStatus VARCHAR2(1);
cBio_Tipo VARCHAR2(1);
cAux VARCHAR2(12);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

begin
    xCont := 0;

  BEGIN
    SELECT STATUS, BIO_TIPO into cStatus, cBio_Tipo
      FROM DIG002 
      WHERE END_IP = cEndIp for update nowait;

    DECLARE
      cursor ldigit_cur1 is 
        SELECT ICARD, STATUS FROM DIG001 
        WHERE END_IP = cEndIp AND STATUS != '0' AND STATUS != '2' 
        order by ICARD for update of STATUS;

      cursor ldigit_cur3 is 
        SELECT ICARD, STATUS FROM DIG003 
        WHERE END_IP = cEndIp AND STATUS != '0' AND STATUS != '2' 
        order by ICARD for update of STATUS;

      cursor ldigit_cur4 is 
        SELECT ICARD, STATUS FROM DIG004 
        WHERE END_IP = cEndIp AND STATUS != '0' AND STATUS != '2' and BIO_TIPO = cBio_Tipo
        order by ICARD for update of STATUS;
          
    BEGIN
		IF (cStatus = '1') THEN 
		  IF (cBio_Tipo = '6') OR (cBio_Tipo = '7') THEN
			FOR r in ldigit_cur1 LOOP
			  cListaMat := cListaMat || r.Icard;
			  update DIG001 set STATUS = '2' where current of ldigit_cur1 ;
			  xCont := xCont+1;
			  IF (xCont >= 20) THEN 
				Exit;
			  END IF;
			END LOOP;
		  ELSIF (cBio_Tipo = '8') THEN
			FOR r in ldigit_cur3 LOOP
			  cListaMat := cListaMat || r.Icard;
			  update DIG003 set STATUS = '2' where current of ldigit_cur3 ;
			  xCont := xCont+1;
			  IF (xCont >= 20) THEN 
				Exit;
			  END IF;
			END LOOP;
		  ELSIF (cBio_Tipo != '0') THEN    -- PARA OUTRAS BIOMETRIAS, EX. VIRDI BIO_TIPO = '9'
			FOR r in ldigit_cur4 LOOP
			  cListaMat := cListaMat || r.Icard;
			  update DIG004 set STATUS = '2' where current of ldigit_cur4 ;
			  xCont := xCont+1;
			  IF (xCont >= 20) THEN 
				Exit;
			  END IF;
			END LOOP;
		  END IF;

		  IF (xCont = 0) THEN
			UPDATE DIG002 SET STATUS = '0' WHERE END_IP = cEndIp;
		  ELSE
			cListaMat := cListaMat || ';';
			UPDATE DIG002 SET STATUS = '2', DATA_LOAD = SYSDATE WHERE END_IP = cEndIp;
		  END IF;

		ELSE
		  COMMIT;
		  return (0);
		END IF;          
	END;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      xCont := 0;
    WHEN reco_lock THEN
      xCont := 0;
    WHEN OTHERS THEN
      xCont := 0;
  END;
  
  COMMIT;
  return (xCont);
    
END sqller_autoLoadDigit3;
/

