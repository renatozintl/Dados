
@@TO_IDENTIF.SQL;
@@RET_IDENTIF.SQL;

@@REQUEST.SQL;
@@RELEASE.SQL;

-- ******************  FUNCOES COMUNS  ****************** 

@@G3G5_AtutabSeg.sql;
@@G3G5_AtutabGeral.sql;
--@@G3G5_ConsAceUsu9.sql;
@@G3G5_ConsAceUsu10.sql;
@@ProcIcardNS.sql;
@@GETDH.SQL;
@@LSTNEGRA.SQL;
@@MATSEMTB.SQL;
@@G3G5_VerFeri.SQL;
@@VGRPTERMAT;
@@ATUBENEF2.SQL;
@@CONBENEF2.SQL;
@@LEINFBLQ.SQL;
@@SADBLOQ.SQL;
@@SADEXCEC.SQL;
@@TIPOBLOQ.SQL;
@@TIPEXCEC.SQL;
@@ENTALARM.SQL;
@@FUNCMAT.SQL;
@@IDCONEX.SQL;
@@LOCLOCK.SQL;
@@MATVEIC2.SQL;
@@EXISTTAB.SQL;
@@CREDLOG.SQL;
@@TEMPOCRED2.SQL;
@@SITCOLETOR.SQL;
@@STATCOLET.SQL;
@@G3G5_ContPlanta.SQL;
@@CONSMENS.SQL;
@@AtDathor2.sql;
@@G3G5_AtDadosSm.sql;
@@BloqNumS.sql;
@@ProcMens.SQL;
@@VERTITULAR.SQL;
@@G3G5_VerTamG.sql;

@@AVCPBBX_TCP.SQL;
@@GRPCPNOV_APP.SQL;
@@GRPSETFX_TCP.SQL;
@@grvbloc0_N5.sql;
@@grvbloc1_N2.sql;
@@grvbloc2_N2.sql;
@@grvbloc3_N1.sql;
@@GRVDEV_TCP.SQL;
@@OLHA_ALARME_APP.SQL;
@@Olha_Overwrite_app.sql;

@@ALMCODIN_TCP.SQL;
@@LBENEF_TCP.SQL;
@@ATMAPBIO.SQL;
@@IDENTNIV.SQL;
@@FUSOHORARIO_TCP2ITP.SQL;
@@GRVPENDSM_TCP2.SQL;
@@GRVBACKSM_TCP2.SQL;
@@G3G5_MatCodin_tcp.sql;
@@GRVBLOC99_TCP.SQL;
@@MATPLACA.SQL;
@@MABMENS.SQL;
@@ATREVISTA.SQL;
@@ATUGERAL4.SQL;

@@VerMatNGrupos.sql;

@@VerTipoBio.SQL;
--@@VerMatNRefeit2.sql;
@@VerMatNRefeit3.sql;
@@AtuRefPlanta.sql;

@@HistBio.sql;
@@DigRejeit.sql;

@@GETDHFUT.sql;
@@GrvHoraApoc.sql;
@@LeHoraApoc2.SQL;


-- ******************  FUNCOES SMARTCARD PENDENCIA ONLINE (CONEX E GERENCIADOR) ******************** 

@@ATSMART2.SQL;
@@GRVLIMPAT.SQL;
@@GRVEXPATU.SQL;

@@ATUFORC.SQL;
@@G_LeAtuPend2.sql
@@InsPendon007.sql;
@@AT2PEND002.SQL;
@@LEPEND003.SQL;
@@LEPEND004.SQL;
@@LEPEND005.SQL;
@@ATPEND002_LPZ.SQL;
@@ATPEND002_ONOFF.SQL;
@@ATPEND002_OFF.SQL;
@@SmAtualizado.sql;

@@SP2A_STATUSOFF.sql;
@@SP2A_STATUSON.sql;
@@SP_CRIARLISTALIMPAOFF.SQL;
@@SP_CARTAOATUALIZADO.SQL;
@@SP_CRIARPENDENCIAS.SQL;
@@F_LIMP_EXCED.SQL;
@@SP2_EXPIROUPENDENCIA.sql;

@@SP2A_CRIARLISTAPENDENCIA.sql
@@SP2A_CRIARLISTAPENDENCIA_OFF.sql;


@@CRIARPENDENCIAS.SQL;
@@LOGENVLPZ.SQL;
@@LOGENVOFF.SQL;
@@LOGENVON.SQL;

@@RecAplPend.sql;



-- ******************************  FUNCOES  VERI ****************************** 

@@AtuDIGIT_VERI_CNX.SQL;
@@IDENTNIV_VERI.SQL;
@@BuscaVeri_Bio2.sql;

-- ******************************  FUNCOES  GEOMOK ****************************** 

@@AtuDIGIT_OMOK_CNX.SQL;
@@CONSCOACAO_OMOK.SQL;
@@BuscaOMOK_Bio.sql;

-- ******************************  FUNCOES  SAGEM ****************************** 

@@AtuDIGIT_Sagem_Cnx2.SQL
@@ConsCoa_Sagem.SQL;
@@NivGeomokSag2.SQL;
@@BuscaSagem_Bio2.sql;


-- ******************************  FUNCOES  HANDKEY ****************************** 

@@AtuDIGIT_Handkey.SQL;
@@ConsDig_Handkey2.sql;
@@ProcTemp_handkey.SQL;


-- ******************************  FUNCOES  tsi1 ****************************** 

@@AtuDIGIT_Tsi1_cnx2.SQL;
@@ConsCoa_tsi1.sql;
@@BuscaTsi1_Bio2.sql;


-- ******************************  FUNCOES  DIGAUTO ****************************** 

@@G3G5_TRIGSITCONT5.sql;
@@G3G5_TRIGMATNGRUPO2.sql;
@@TRIGMGRUPO2.SQL;

@@AuxTrgDigMatCod2.sql;
@@TRIGMATCOD2.sql;

@@G3G5_Prep4_Tsi1.sql;
@@G3G5_Prep4_Sagem.sql;
@@G3G5_Prep3_Palmv.sql;
@@Prep3_OutrosBios.sql

@@LoadDig4.sql;
--@@AplDig.sql;
@@FIMDIG002.SQL;
@@LeExclAutoDigit3.sql;
@@FimExcAutoDigit3.sql;
@@LeCargaAutoDigit3.sql;
@@RespAutoPalmv.sql;
@@FimPalmv.sql;


@@LeCargaAutoPalmV.sql;
@@LeExclAutoIpPV.sql;
@@FimExcAutoPalmv.sql;
@@FimInsAutoPalmv.sql;

@@FimInsAutoBinaryBios.sql;

@@Trata4_sagem.sql;
@@Trata4_tsi1.sql;
@@Trata3_palmv.sql;
@@Trata_OutrosBios.sql;

@@HoraGerBio.sql;

@@G3G5_P_Gerdigital6.sql;

-- ******************************  FUNCOES  Mensagens ****************************** 

--@@vDspMensCA.sql;
--@@vDspMensREP.sql;
--@@GRVMENS.sql;

-- ******************************  FUNCOES  BDCC / CPF_NS_ICARD ****************************** 

@@grvbloc99_tcp.sql


-- ******************************  FUNCOES  LIC  ****************************** 

@@GETDATA.sql;


-- ******************************  FUNCOES  PONTO  ****************************** 

@@VerRepPto.sql;
@@FxaJornsAntPos.SQL;
@@SelDHRepPto.SQL;
@@TRIGREPPTO2.SQL;
@@TRIGROFFREPPTO.SQL;


-- ******************************  FUNCOES  PALMVEIN  ****************************** 

@@LeBDPalmV.sql;
@@GrvBDPalmv.sql;
@@ProcDig_PalmV.sql;



-- ******************************  FUNCOES  VIRDI  ****************************** 
 
@@AtuOutrosBios.sql;
@@BuscaOutros_Bio.sql;

-- ******************************  FUNCOES  OUTROS BIOS  ****************************** 

@@ProcDig_BinaryBios.sql;
@@GrvBDBinaryBios.SQL;


-- ******************************  FUNCOES  ICARD+NUMERIAL  ****************************** 
@@PrepOrdIcardNS.sql;
@@LeIcardNSOrd.sql;

-- ******************************

@@MatGrupo_Tcp.SQL;

@@ConsDig_Sagem4It.SQL;
@@ConNivel_SagemIt.SQL;

@@ConsVagasEstac3.SQL;
@@AtuVagasEstac3.SQL;

@@ConsListaVagasEstac.SQL;

@@ConsCont512.SQL;
@@AtuCont512.SQL;

@@GrvListaMat.SQL;
@@InfoErroDig.SQL;


-- ******************************  FUNCOES  Variaveis ****************************** 

@@G3G5_Term_geral_tcp18.sql;
@@G3G5_Term_repp_off18.sql;


-- ************************   ATUALIZACAO VERSAO   **************************

@@Ins_versao_186700.SQL;






