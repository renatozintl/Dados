CREATE OR REPLACE PROCEDURE P_RepGerDigital5 (nQtd NUMBER) IS

nQtdPend NUMBER;

begin


	nQtdPend := 0;

	--AntePrep_RSagem;		-- PREPARA TABELAS DE SAGEM DIG001 / DIG101
	ANTEPREP3_RSAGEM (nQtd);

	--AntePrep_RTsi1;			-- PREPARA TABELAS DE TSI1 DIG003 / DIG103
	AntePrep3_RTsi1 (nQtd);

	AntePrep2_ROutrosBios (nQtd);			-- PREPARA TABELAS DE VIRDI DIG004 / DIG104

	--Prep_RepDigit3 (nQtd);
	Prep_RepDigit5 (nQtd);

	BEGIN
		SELECT 1 INTO nQtdPend FROM REPNDIGAUTO000 WHERE STATUS <> '0' AND ROWNUM = 1;

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			trata4_RepSagem;				-- TRATA sagem

			trata4_RepTsi1;					-- TRATA suprema

			trata3_RepOutrosBios;			-- TRATA outros

		WHEN OTHERS THEN
			NULL;
	END;

end P_RepGerDigital5 ;
/

