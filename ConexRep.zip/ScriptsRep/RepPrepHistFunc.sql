CREATE OR REPLACE FUNCTION sqlprephist_RStF (cLisMat VARCHAR2, cEndIp VARCHAR2, cModo CHAR, nTotal NUMBER)   
RETURN NUMBER IS

Retfun NUMBER;
nCont NUMBER;
nPos NUMBER;
cFunc VARCHAR2(12);
cPis VARCHAR2(12);

BEGIN


	Retfun := 0;      -- assume que achou o icard
	nCont := 0;
	
	WHILE (nCont < nTotal) LOOP
		nPos := (nCont * 12) + 1;
		cFunc := SUBSTR (cLisMat, nPos, 12);

		BEGIN
			SELECT PIS INTO cPis 
				FROM REPAUXEMPR
				WHERE END_IP = cEndIp AND 
					  TIPO = cModo AND 
					  IFUNC = cFunc  FOR UPDATE NOWAIT;
		
			UPDATE REPAUXEMPR SET ST = '1' 
				WHERE END_IP = cEndIp AND 
					  TIPO = cModo AND 
					  IFUNC = cFunc ;
					  
		EXCEPTION
			WHEN NO_DATA_FOUND THEN 
				null;
				
			WHEN OTHERS THEN 
				Retfun := -1;
				null;
		END;
		nCont := nCont + 1;

	END LOOP;
	
	COMMIT;
	
	return (Retfun);
	
END sqlprephist_RStF;
/


