-- INICIO5TCPARL.SQL: Criacao de usuarios

SPOOL RESULT5.LOG;

CONNECT TELEMAT/TELEMAT;

-- 1)Criar usuarios usutcp01, causu (quantos achar necessario) 
-- 2)atribuir 'create session' para os usuarios criados
-- 3)atribuir privilegio de criacao de sinoonimos
-- 4)Atribuir privelegio de EXECFUNTCP para usuarios USUTCP (01, 02, 03, ...)
-- 4)Atribuir privelegio de EXECFUNPRI para usuario CAUSU

-- *****************  A R L  -  O N  ***********************************


-- ******************** CAUSU ******************************

CREATE USER CAUSU IDENTIFIED BY CAUSUX DEFAULT TABLESPACE ACESDATA 
TEMPORARY TABLESPACE ACESTMP;

GRANT CREATE SESSION TO CAUSU;
GRANT CREATE SYNONYM TO CAUSU;
GRANT EXECFUNPRI TO CAUSU;




-- ****************** USUARIO USUTCP01 *****************************

CREATE USER USUTCP01 IDENTIFIED BY USUTCP DEFAULT TABLESPACE ACESDATA 
TEMPORARY TABLESPACE ACESTMP;

GRANT CREATE SESSION TO USUTCP01;
GRANT CREATE SYNONYM TO USUTCP01;
GRANT EXECFUNTCP TO USUTCP01;

-- ****************** USUARIO USUTCP02 *****************************

CREATE USER USUTCP02 IDENTIFIED BY USUTCP DEFAULT TABLESPACE ACESDATA 
TEMPORARY TABLESPACE ACESTMP;

GRANT CREATE SESSION TO USUTCP02;
GRANT CREATE SYNONYM TO USUTCP02;
GRANT EXECFUNTCP TO USUTCP02;


SPOOL OFF;

-- continue com Inicio6TcpArl.SQL : preenchimento da tabela sbbe

