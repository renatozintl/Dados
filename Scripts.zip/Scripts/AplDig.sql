CREATE or REPLACE FUNCTION sqlapl_digauto (cEndIp in VARCHAR2) 
RETURN NUMBER IS

Ret NUMBER;
cAuxIp VARCHAR2(15);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

BEGIN

	Ret := 0;
	BEGIN
		SELECT END_IP into cAuxIp from DIG002 
			WHERE END_IP = cEndIp FOR UPDATE NOWAIT;
		UPDATE DIG002 set STATUS = '5'
			WHERE END_IP = cEndIp and
				STATUS = '6';			
	EXCEPTION
		WHEN NO_DATA_FOUND then Ret := 0;
		WHEN reco_lock then Ret := 0;
		WHEN OTHERS then Ret := -1;
	END;

	BEGIN
		SELECT END_IP into cAuxIp from DIG102 
			WHERE END_IP = cEndIp FOR UPDATE NOWAIT;
		UPDATE DIG102 set STATUS = '5'
			WHERE END_IP = cEndIp and
				STATUS = '6';			
	EXCEPTION
		WHEN NO_DATA_FOUND then Ret := 0;
		WHEN reco_lock then Ret := 0;
		WHEN OTHERS then Ret := -1;
	END;

	BEGIN
		SELECT END_CTRLPALMV into cAuxIp from PALMV004 
			WHERE END_CTRLPALMV = cEndIp FOR UPDATE NOWAIT;
		UPDATE PALMV004 set STATUS = '5'
			WHERE END_CTRLPALMV = cEndIp and
				STATUS = '6';			
	EXCEPTION
		WHEN NO_DATA_FOUND then Ret := 0;
		WHEN reco_lock then Ret := 0;
		WHEN OTHERS then Ret := -1;
	END;

	BEGIN
		SELECT END_CTRLPALMV into cAuxIp from PALMV005 
			WHERE END_CTRLPALMV = cEndIp FOR UPDATE NOWAIT;
		UPDATE PALMV005 set STATUS = '5'
			WHERE END_CTRLPALMV = cEndIp and
				STATUS = '6';			
	EXCEPTION
		WHEN NO_DATA_FOUND then Ret := 0;
		WHEN reco_lock then Ret := 0;
		WHEN OTHERS then Ret := -1;
	END;
	
	COMMIT;
	
	return (Ret);
END sqlapl_digauto;
/
