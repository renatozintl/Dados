CREATE or REPLACE FUNCTION sqlload_Rlistadig4 (cMatric in VARCHAR2, cEndIp in VARCHAR2, cNumRep VARCHAR2, cStatus in VARCHAR2, cErro in VARCHAR2) 
RETURN NUMBER IS

Ret NUMBER;
cAux VARCHAR2(12);
cAuxIp VARCHAR2(15);
cBioTipo VARCHAR2(5);
cStExc VARCHAR2(1);
cNovoStat VARCHAR2(1);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

BEGIN

	Ret := 0;
	cBioTipo := '0';
	cNovoStat := cStatus;
	
	BEGIN
		SELECT BIO_TIPO into cBioTipo FROM RDIG002
			WHERE END_IP = cEndIp FOR update nowait;
	
		UPDATE RDIG002 SET DATA_LOAD = sysdate 
			WHERE END_IP = cEndIp;
			
	
	EXCEPTION
		WHEN NO_DATA_FOUND then 
			Ret := 0;
		WHEN reco_lock then
			Ret := -1;
		WHEN OTHERS then
			Ret := -1;
	END;
	
	
	IF (cBioTipo = '6' or cBioTipo = '7') THEN		-- (SAGEM)
		-- *************  NOVO
		-- SE ESTIVER PENDENTE, DEVE VERIFICAR SE H� ALGUM COMANDO DE EXCLUSAO DESSE FUNCION�RIO PARA O EQUIPAMENTO A SER EXECUTADO.
		-- SE HOUVER, DEVE-SE IGNORAR ESTA PENDENCIA DE INCLUSAO E TORNA-LA STATUS '4', PARA QUE O GERENCIADOR DE CARGA AUTOM�TICA ANULE ESTA PENDENCIA
		if (cStatus = '3') then
			BEGIN 
				SELECT STATUS INTO cStExc FROM RDIG101 
					WHERE IFUNC = cMatric and END_IP = cEndIp AND STATUS <> '0' ;

				-- ENCONTROU COMANDO MAIS RECENTE DE EXCLUSAO, ENT�O NOVO VALOR DE 	RDIG001.STATUS SER� '4', PARA ESTA CARGA SER DESCARTADA, E N�O TRATAR� COMO PENDENCIA.					
				cNovoStat := '4';
						
			EXCEPTION
				WHEN NO_DATA_FOUND then 
					null;
				WHEN OTHERS then 
					null;
			END;
		end if;
		-- *************  FIM NOVO
		BEGIN
			SELECT IFUNC into cAux FROM RDIG001 
				where IFUNC = cMatric and
					  END_IP = cEndIp FOR update nowait;
	
			--UPDATE RDIG001 SET STATUS = cStatus 
			UPDATE RDIG001 SET STATUS = cNovoStat 		-- ******** NOVO 
				where IFUNC = cMatric and
					  END_IP = cEndIp;

		EXCEPTION
			WHEN NO_DATA_FOUND then 
				Ret := 0;
			WHEN reco_lock then
				Ret := -1;
			WHEN OTHERS then
				Ret := -1;
		END;

	ELSIF (cBioTipo = '8') THEN		-- BIOTIPO = '8' (TSI1)
		-- *************  NOVO
		-- SE ESTIVER PENDENTE, DEVE VERIFICAR SE H� ALGUM COMANDO DE EXCLUSAO DESSE FUNCION�RIO PARA O EQUIPAMENTO A SER EXECUTADO.
		-- SE HOUVER, DEVE-SE IGNORAR ESTA PENDENCIA DE INCLUSAO E TORNA-LA STATUS '4', PARA QUE O GERENCIADOR DE CARGA AUTOM�TICA ANULE ESTA PENDENCIA
		if (cStatus = '3') then
			BEGIN 
				SELECT STATUS INTO cStExc FROM RDIG103 
					WHERE IFUNC = cMatric and END_IP = cEndIp AND STATUS <> '0' ;

				-- ENCONTROU COMANDO MAIS RECENTE DE EXCLUSAO, ENT�O NOVO VALOR DE 	RDIG003.STATUS SER� '4', PARA ESTA CARGA SER DESCARTADA, E N�O TRATAR� COMO PENDENCIA.					
				cNovoStat := '4';
						
			EXCEPTION
				WHEN NO_DATA_FOUND then 
					null;
				WHEN OTHERS then 
					null;
			END;
		end if;
		-- *************  FIM NOVO
		BEGIN
			SELECT IFUNC into cAux FROM RDIG003 
				where IFUNC = cMatric and
					  END_IP = cEndIp FOR update nowait;

			--UPDATE RDIG003 SET STATUS = cStatus 
			UPDATE RDIG003 SET STATUS = cNovoStat 		-- ******** NOVO 
				where IFUNC = cMatric and
					  END_IP = cEndIp;

		EXCEPTION
			WHEN NO_DATA_FOUND then 
				Ret := 0;
			WHEN reco_lock then
				Ret := -1;
			WHEN OTHERS then
				Ret := -1;
		END;

	--ELSIF (cBioTipo = '9') THEN		-- BIOTIPO = '9' (VIRDI)
	ELSIF (cBioTipo != '0') THEN		-- BIOTIPO = '9' (VIRDI), E OUTROS 
		-- *************  NOVO
		-- SE ESTIVER PENDENTE, DEVE VERIFICAR SE H� ALGUM COMANDO DE EXCLUSAO DESSE FUNCION�RIO PARA O EQUIPAMENTO A SER EXECUTADO.
		-- SE HOUVER, DEVE-SE IGNORAR ESTA PENDENCIA DE INCLUSAO E TORNA-LA STATUS '4', PARA QUE O GERENCIADOR DE CARGA AUTOM�TICA ANULE ESTA PENDENCIA
		if (cStatus = '3') then
			BEGIN 
				SELECT STATUS INTO cStExc FROM RDIG104 
					WHERE IFUNC = cMatric and END_IP = cEndIp AND STATUS <> '0' ;

				-- ENCONTROU COMANDO MAIS RECENTE DE EXCLUSAO, ENT�O NOVO VALOR DE 	RDIG004.STATUS SER� '4', PARA ESTA CARGA SER DESCARTADA, E N�O TRATAR� COMO PENDENCIA.					
				cNovoStat := '4';
						
			EXCEPTION
				WHEN NO_DATA_FOUND then 
					null;
				WHEN OTHERS then 
					null;
			END;
		end if;
		-- *************  FIM NOVO
	
	
		BEGIN
			SELECT IFUNC into cAux FROM RDIG004 
				where IFUNC = cMatric and
					  END_IP = cEndIp FOR update nowait;

			--UPDATE RDIG004 SET STATUS = cStatus 
			UPDATE RDIG004 SET STATUS = cNovoStat 			-- ******** NOVO 
				where IFUNC = cMatric and
					  END_IP = cEndIp;

		EXCEPTION
			WHEN NO_DATA_FOUND then 
				Ret := 0;
			WHEN reco_lock then
				Ret := -1;
			WHEN OTHERS then
				Ret := -1;
		END;
	END IF;		


	-- NOVO
	IF (cStatus = '0') THEN
		INSERT INTO HISTREPDIG (IFUNC, END_IP, BIO_TIPO, INSEXC, MODO) VALUES (cMatric, cEndIp, cBioTipo, 'I', 'A');		-- TIPO:'I'= INCLUSAO, 'E'=EXCLUSAO; MODO:'A'=AUTOMATICO, 'M'=MANUAL
		
		BEGIN
			SELECT END_IP INTO cAuxIp FROM REPLASTCOM WHERE END_IP = cEndIp for update nowait;
			UPDATE REPLASTCOM SET DATA_INS = SYSDATE WHERE END_IP = cEndIp;
		EXCEPTION
			WHEN NO_DATA_FOUND THEN 
				INSERT INTO REPLASTCOM (END_IP, DATA_INS) VALUES (cEndIp, SYSDATE);
			WHEN reco_lock then
				NULL;
			WHEN OTHERS THEN 
				NULL;
		END;
	ELSE
		--IF (cStatus = '4') THEN 	-- ERRO DE CARGA (devido a memoria cheiia, minucia errada: que nao adianta enviar a digital novamente ao equipamento ), ou nao implementado
			INSERT INTO REPDIGLOAD001 (END_IP, REP, IFUNC, BIO_TIPO, NERRO) VALUES (cEndIp, cNumRep, cMatric, cBioTipo, cErro);
		--END IF;
	END IF;
	-- FIM NOVO
	
	COMMIT;

		
	RETURN (Ret);
END sqlload_Rlistadig4;
/
