create or replace view TabGrpSetFx
 (End_Ip, BlueB, Laces, Codin, Tip_Term, Grupo, FxPerm)
as
   select Dat07.End_Ip, Dat07.BlueB, Dat07.Laces, Dat07.Codin, Dat07.Tip_Term, 
	  Dat08.Grupo, Dat08.FxPerm
   from Dat07, Dat08
   where TO_NUMBER(Dat07.Laces) = TO_NUMBER(Dat08.Laces) AND
	 TO_NUMBER(Dat07.Planta) = TO_NUMBER(Dat08.Planta);

