CREATE or REPLACE FUNCTION sqller_autoExclDigit3
(
cEndIp in VARCHAR2,
cListaMat in out VARCHAR2
) 
RETURN NUMBER IS

xCont NUMBER;
cStatus VARCHAR2(1);
cBio_Tipo VARCHAR2(1);
cAux VARCHAR2(12);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);


begin
    xCont := 0;

	BEGIN
		SELECT STATUS, BIO_TIPO into cStatus, cBio_Tipo 
			FROM DIG102 
			WHERE END_IP = cEndIp for update nowait;

		DECLARE
		cursor ldigit_cur1 is 					-- DIGITAIS SUPREMA A SEREM EXCLUIDAS
			SELECT ICARD, STATUS FROM DIG101 
				WHERE END_IP = cEndIp AND 
					  STATUS != '0' AND STATUS != '2' 
				order by ICARD 
				for update of STATUS;

		cursor ldigit_cur3 is 					-- DIGITAIS TSI1 A SEREM EXCLUIDAS
			SELECT ICARD, STATUS FROM DIG103 
				WHERE END_IP = cEndIp AND 
					  STATUS != '0' AND STATUS != '2' 
				order by ICARD 
				for update of STATUS;

		cursor ldigit_cur4 is 					-- DIGITAIS VIRDI/OUTROS A SEREM EXCLUIDAS
			SELECT ICARD, STATUS FROM DIG104 
				WHERE END_IP = cEndIp AND 
					  STATUS != '0' AND STATUS != '2' AND
					  BIO_TIPO = cBio_Tipo  
				order by ICARD 
				for update of STATUS;

		BEGIN
		IF (cStatus = '1') THEN 
			IF (cBio_Tipo =  '6') or (cBio_Tipo =  '7') THEN
				FOR r in ldigit_cur1 LOOP
					cListaMat := cListaMat || r.Icard;
					update DIG101 set STATUS = '2' where current of ldigit_cur1 ;
					xCont := xCont+1;
					IF (xCont >= 90) THEN 
						Exit;
					END IF;
				END LOOP;
			ELSIF (cBio_Tipo =  '8')THEN
				FOR r in ldigit_cur3 LOOP
					cListaMat := cListaMat || r.Icard;
					update DIG103 set STATUS = '2' where current of ldigit_cur3 ;
					xCont := xCont+1;
					IF (xCont >= 90) THEN 
						Exit;
					END IF;
				END LOOP;
			ELSIF (cBio_Tipo !=  '0') THEN		-- VIRDI / OUTROS
				FOR r in ldigit_cur4 LOOP
					cListaMat := cListaMat || r.Icard;
					update DIG104 set STATUS = '2' where current of ldigit_cur4 ;
					xCont := xCont+1;
					IF (xCont >= 90) THEN 
						Exit;
					END IF;
				END LOOP;
			END IF;
			
			IF (xCont = 0) THEN
				UPDATE DIG102 SET STATUS = '0' WHERE END_IP = cEndIp;
			ELSE
				cListaMat := cListaMat || ';';
				UPDATE DIG102 SET STATUS = '2', DATA_LOAD = SYSDATE WHERE END_IP = cEndIp;
			END IF;

		ELSE
			COMMIT;
			return (0);
		END IF;					
		END;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			xCont := 0;
		WHEN reco_lock THEN
			xCont := 0;
		WHEN OTHERS THEN
			xCont := 0;
	END;
	
	COMMIT;
	return (xCont);
		
END sqller_autoExclDigit3;
/

