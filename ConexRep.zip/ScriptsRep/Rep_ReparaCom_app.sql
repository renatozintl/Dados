CREATE OR REPLACE FUNCTION sqlrepara_comando_APPL (cEndIp in VARCHAR2, masc in varchar2, cOldSt in VARCHAR2, cNewSt  in VARCHAR2)
RETURN NUMBER IS
	Ret NUMBER;
	cAuxEndIp VARCHAR2(15);
	stm1 VARCHAR2(400);
	stm2 VARCHAR2(400);
     
	reco_lock EXCEPTION;
	PRAGMA EXCEPTION_INIT (reco_lock, -54);  

BEGIN
	Ret := 1;
	-- repara tabela CP_NB

	-- monta comando de SELECT em stm1
	stm1 := 'SELECT End_Ip FROM ' || masc || 
			' WHERE End_Ip = :1 AND Tipo_cc = :2 and St = :3 FOR UPDATE NOWAIT';
	
	-- monta comando de UPDATE em stm2
	stm2 := 'UPDATE '|| masc || ' SET ST = :1 ' ||
			'WHERE End_Ip = :2 AND Tipo_cc = :3 and St = :4' ;
	
	BEGIN
		-- executa comando
		EXECUTE IMMEDIATE stm1 
   			INTO cAuxEndIp 
   			USING cEndIp, '0', cOldSt;
   
		EXECUTE IMMEDIATE stm2 
   			USING cNewSt , cEndIp, '0', cOldSt;
		
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			Ret := 0;
		WHEN reco_lock THEN
			Ret := -1;
		WHEN OTHERS THEN
			Ret := -1;
	END;


	BEGIN
		SELECT End_Ip INTO cAuxEndIp FROM repidpis002 
			WHERE End_Ip = cEndIp AND
				St = '1' 
		FOR UPDATE NOWAIT;

		UPDATE repidpis002 
			SET  ST = '2'      -- ATUALIZA STATUS DE COLETA IDPIS como erro
			WHERE End_Ip = cEndIp AND
				St = '1';

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			Ret := 0;
		WHEN reco_lock THEN
			Ret := -1;
		WHEN OTHERS THEN
			Ret := -1;
	END;

	COMMIT;

	return (Ret);
	
END sqlrepara_comando_APPL;
/

