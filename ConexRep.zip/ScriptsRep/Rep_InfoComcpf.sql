CREATE OR REPLACE FUNCTION sqlrinfo_comcpf (nome in varchar2, masc in varchar2, mensInfo in out varchar2) 
    RETURN NUMBER IS
	Retorno NUMBER;
	status VARCHAR2(1);
	comando VARCHAR2(2);
	acaox VARCHAR2(15);
	informx VARCHAR2(100);
	tipo VARCHAR2(1);
	endereco VARCHAR2(15);
	
	cmd VARCHAR2(400);
	reco_lock EXCEPTION;
	PRAGMA EXCEPTION_INIT (reco_lock, -54);  

BEGIN
    endereco := nome;
    Retorno := 1;

	BEGIN   
     		-- verifica tabela auxiliar de comandos
		--cmd := 'SELECT inform  FROM ' || masc || 'AUX' ||
		cmd := 'SELECT informauto  FROM ' || masc || 'AUX' ||
			' WHERE end_ip = :1  ' ;
	
		execute immediate cmd 
		into informx   
		using endereco ;
	
		mensInfo := informx;
	
    EXCEPTION
		WHEN NO_DATA_FOUND THEN
			Retorno := 0;
		WHEN OTHERS THEN
			Retorno := -1;
    END;
    
    return (Retorno);

END sqlrinfo_comcpf;
/