CREATE or REPLACE FUNCTION sqlcons_10dig(cEndIp VARCHAR2, cNumRep VARCHAR2, cMat in VARCHAR2,cTipoBio in VARCHAR2, nPrim NUMBER,
cListaDig1 in out VARCHAR2, cListaDig2 in out VARCHAR2, cListaDig3 in out VARCHAR2, cListaDig4 in out VARCHAR2, cListaDig5 in out VARCHAR2) 
RETURN NUMBER IS

xTotal NUMBER;
xCont NUMBER;
nBloco NUMBER;
xDigital VARCHAR2(1000);
cListaDig VARCHAR2(2000);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

cursor CURSOR_DIG10 is
	select 
		TO_CHAR(DIGITAL) 
	from CONTDIG_LOBTSI1 
	WHERE ICARD = cMat
	ORDER BY NUMDEDO;    

begin
    xCont := 0;
    xTotal := 0;
    SELECT COUNT(*) INTO xTotal FROM CONTDIG_LOBTSI1 WHERE ICARD = cMat;
	nBloco := 1;
	xDigital := NULL;
	cListaDig := NULL;
	cListaDig1 := NULL;
	cListaDig2 := NULL;
	cListaDig3 := NULL;
	cListaDig4 := NULL;
	cListaDig5 := NULL;
	
	if (nPrim = 1) THEN 
		DELETE  REP10DIG001 WHERE END_IP = cEndIp and REP = cNumRep;
		commit;
	
	END IF;
	
	IF (xTotal = 10) then
		OPEN CURSOR_DIG10;
		LOOP
			fetch CURSOR_DIG10 INTO xDigital;
			EXIT when CURSOR_DIG10%NOTFOUND;
		
			cListaDig := cListaDig || xDigital;		-- TO_CHAR PARA TRANSFORMAR BLOB EM CHAR
			xCont := xCont+1;
			IF (xCont >= 2) THEN
				IF (nBloco = 1) THEN
					cListaDig1 := cListaDig;
					nBloco := nBloco+1;
					cListaDig := NULL;
				ELSIF (nBloco = 2) THEN
					cListaDig2 := cListaDig;
					nBloco := nBloco+1;
					cListaDig := NULL;
				ELSIF (nBloco = 3) THEN
					cListaDig3 := cListaDig;
					nBloco := nBloco+1;
					cListaDig := NULL;
				ELSIF (nBloco = 4) THEN
					cListaDig4 := cListaDig;
					nBloco := nBloco+1;
					cListaDig := NULL;
				ELSIF (nBloco = 5) THEN
					cListaDig5 := cListaDig;
					nBloco := nBloco+1;
					cListaDig := NULL;
				END IF;	
				xCont := 0;
			END IF;
			
		END LOOP;
		CLOSE CURSOR_DIG10;
	ELSE
		INSERT INTO REP10DIG001 (END_IP, REP, IFUNC, DIA) 
			VALUES (cEndIp, cNumRep, cMat, SYSDATE);	
		COMMIT;
	END IF;
	
	RETURN (xTotal);
END sqlcons_10dig;
/

