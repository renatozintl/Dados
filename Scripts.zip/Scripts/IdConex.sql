CREATE OR REPLACE FUNCTION sqlident_conex (userx VARCHAR2)
RETURN NUMBER IS

   sid_num NUMBER;

BEGIN
    sid_num := 0;
    BEGIN
        SELECT sid INTO SID_NUM FROM SYS.V_$mystat where rownum = 1; 
    EXCEPTION
	WHEN NO_DATA_FOUND THEN
	    sid_num := -1;
        WHEN OTHERS THEN
	    sid_num := -2;
    END;	

    return (sid_num);

END sqlident_conex;
/
