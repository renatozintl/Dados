@echo off
if "%1" == "?" goto sintaxe
if "%1" == "/?" goto sintaxe
if "%1" == "-?" goto sintaxe
if "%1" == "" goto sintaxe

@echo off
if not "%1" == "" goto Server
goto sintaxe

:Server
cls


echo - ATUALZACAO VERSAO
OSQL /UTELESSVR /PSSVRTELE /S%1 /dACESSOTA /iC:\ACESSOSS\Scripts\S_Ins_versao_186803.sql >> C:\ACESSOSS\Scripts\ATU1.log
echo.

echo Fim de ATU.
echo Verifique C:\ACESSOSS\Scripts\ATU1.log
goto limpa

:sintaxe
@echo Sintaxe:
@echo ATU {server_name}
@echo.
goto fim

:limpa
echo.
doskey /reinstall
@echo off

:fim
