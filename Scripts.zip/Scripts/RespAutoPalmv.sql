CREATE or REPLACE FUNCTION sqlresp_autopalmv (cMatric in VARCHAR2, cEndIp in VARCHAR2, cStatus in VARCHAR2, cErro in VARCHAR2) 
RETURN NUMBER IS

Ret NUMBER;
cAux VARCHAR2(12);
cAuxIp VARCHAR2(15);
cBioTipo VARCHAR2(5);
cStAux VARCHAR2(2);
reco_lock EXCEPTION;
PRAGMA EXCEPTION_INIT (reco_lock, -54);

BEGIN

	Ret := 0;
	cBioTipo := '0';
	
	BEGIN
		SELECT STATUS into cStAux FROM PALMV004
			WHERE END_CTRLPALMV = cEndIp FOR update nowait;
	
		UPDATE PALMV004 SET DATA_LOAD = sysdate 
			WHERE END_CTRLPALMV = cEndIp;
			
	
	EXCEPTION
		WHEN NO_DATA_FOUND then 
			Ret := 0;
		WHEN reco_lock then
			Ret := -1;
		WHEN OTHERS then
			Ret := -1;
	END;
	
				  
	BEGIN
		SELECT Icard into cAux FROM PALMV014 
			where ICARD = cMatric and
				  END_CTRLPALMV = cEndIp FOR update nowait;

		UPDATE PALMV014 SET STATUS = cStatus 
			where ICARD = cMatric and
				  END_CTRLPALMV = cEndIp;


		EXCEPTION
			WHEN NO_DATA_FOUND then 
				Ret := 0;
			WHEN reco_lock then
				Ret := -1;
			WHEN OTHERS then
				Ret := -1;
	END;

	
	-- NOVO
	IF (cStatus = '0') THEN
		INSERT INTO HISTDIG (IFUNC, END_IP, BIO_TIPO, INSEXC, MODO) VALUES (cMatric, cEndIp, 'A', 'I', 'A');		-- INSEXC:'I'= INCLUSAO, 'E'=EXCLUSAO; MODO:'A'=AUTOMATICO, 'M'=MANUAL
	ELSE
		IF (cStatus = '4') THEN 	-- ERRO DE CARGA (devido a memoria cheiia, minucia errada: que nao adianta enviar a digital novamente ao equipamento ), ou nao implementado
			INSERT INTO DIGLOAD001 (END_IP, ICARD, BIO_TIPO, NERRO) VALUES (cEndIp, cMatric, 'A', cErro);
		END IF;
	END IF;
	-- FIM NOVO
	
	COMMIT;
	
		
	RETURN (Ret);
END sqlresp_autopalmv;
/
