CREATE OR REPLACE FUNCTION sqlrperm_novocomando (cEndIp varchar2) 
   RETURN NUMBER IS

Ret    NUMBER;
cHoraBD date;	
   
BEGIN
	
    Ret := 1;
	
	BEGIN
		SELECT DATA_INS INTO cHoraBD 
			FROM REPLASTCOM
			WHERE END_IP = CEndIp ;
		
		IF ((cHoraBD + (20 / (24 * 60 * 60))) <= sysdate ) then		 -- verifica se cHoraBD + 20 segundos � menor q a data/hora atual
			Ret := 1;
		ELSE
			Ret := 0;
		END IF;
		
	EXCEPTION
		-- CASO NAO ENCONTRE, INDICA QUE TEM PERMISSAO 
		WHEN NO_DATA_FOUND then Ret := 1;
		WHEN OTHERS then Ret := 0;
	END;
	
   	return (Ret);		

END sqlrperm_novocomando;
/

