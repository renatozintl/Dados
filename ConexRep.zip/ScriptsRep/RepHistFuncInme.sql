CREATE OR REPLACE FUNCTION sqlhist_RfuncInme (cEndIp VARCHAR2, cInsDel CHAR, CNumModo CHAR)   
RETURN NUMBER IS

Retfun NUMBER;
cFunc VARCHAR2(12);
cAuxIp VARCHAR2(15);
cAcao CHAR(1);
cModo CHAR(1);
RECO_LOCK EXCEPTION;
PRAGMA EXCEPTION_INIT(RECO_LOCK, -54);


cursor lhistinme_cur is 
		SELECT IFUNC, ST FROM REPAUXEMPR 
			WHERE END_IP = cEndIp AND 
				  TIPO = cNumModo AND 
				  ST = '2'
			ORDER by IFUNC;

BEGIN


	Retfun := 0;      -- assume que achou o icard
	
	IF (cInsDel = '3') THEN
		cAcao := 'I';
	ELSE
		cAcao := 'E';
	END IF;
		
	IF (cNumModo = '0') THEN
		cModo := 'M';
	ELSE
		cModo := 'A';
	END IF;
	
	
	FOR r in lhistinme_cur LOOP
		INSERT INTO HISTREPFUN (IFUNC, END_IP, INSEXC, MODO) 
			VALUES (r.IFUNC , cEndIp, cAcao, cModo);
	END LOOP;


	BEGIN
		SELECT END_IP INTO cAuxIp FROM REPLASTCOM WHERE END_IP = cEndIp FOR UPDATE NOWAIT;
		UPDATE REPLASTCOM SET DATA_INS = SYSDATE WHERE END_IP = cEndIp;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN 
			INSERT INTO REPLASTCOM (END_IP, DATA_INS) VALUES (cEndIp, SYSDATE);
			WHEN RECO_LOCK THEN 
				NULL;
		WHEN OTHERS THEN 
			NULL;
	END;
	
	COMMIT;	
	
	
	return (Retfun);
	
END sqlhist_RfuncInme;
/


