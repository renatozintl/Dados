CREATE OR REPLACE FUNCTION sqlfxa_jornspontoantpos (cMatric VARCHAR2, cDiaWeek NUMBER, cFxaPonto IN OUT VARCHAR2, cFxaPontoAnt IN OUT VARCHAR2, cFxaPontoPos IN OUT VARCHAR2) 
RETURN NUMBER IS

   Ret  NUMBER;
   cFxa CHAR(8);
   cMatAux char (12);

BEGIN
	
    Ret := 0;
    cFxa := '24002400';

    cFxaPonto 	 := cFxa||cFxa||cFxa||cFxa||cFxa||cFxa||cFxa;		-- 7 faixas de '24002400'
    cFxaPontoAnt := cFxa||cFxa||cFxa||cFxa||cFxa||cFxa||cFxa;		-- 7 faixas de '24002400'
    cFxaPontoPos := cFxa||cFxa||cFxa||cFxa||cFxa||cFxa||cFxa;		-- 7 faixas de '24002400'

	BEGIN
		-- PROCURA PELA MATRICULA EM FXHORARIA
		SELECT ICARD INTO cMatAux FROM FXHORARIA WHERE ICARD = cMatric;
		Ret := 1;


   		SELECT case cDiaWeek
			when 1 then FX_DOM_P
			when 2 then FX_SEG_P
			when 3 then FX_TER_P
			when 4 then FX_QUA_P
			when 5 then FX_QUI_P
			when 6 then FX_SEX_P
			when 7 then FX_SAB_P
       		end 
       	    INTO cFxaPonto FROM FXHORARIA WHERE ICARD = cMatric;

   		SELECT case cDiaWeek
			when 1 then FX_SAB_P
			when 2 then FX_DOM_P
			when 3 then FX_SEG_P
			when 4 then FX_TER_P
			when 5 then FX_QUA_P
			when 6 then FX_QUI_P
			when 7 then FX_SEX_P
       		end 
       	    INTO cFxaPontoAnt FROM FXHORARIA WHERE ICARD = cMatric;

   		SELECT case cDiaWeek
			when 1 then FX_SEG_P
			when 2 then FX_TER_P
			when 3 then FX_QUA_P
			when 4 then FX_QUI_P
			when 5 then FX_SEX_P
			when 6 then FX_SAB_P
			when 7 then FX_DOM_P
       		end 
       	    INTO cFxaPontoPos FROM FXHORARIA WHERE ICARD = cMatric;

	EXCEPTION
		WHEN NO_DATA_FOUND then Null;
		WHEN others then Null;

	END;
	return ret;
END sqlfxa_jornspontoantpos;
/


