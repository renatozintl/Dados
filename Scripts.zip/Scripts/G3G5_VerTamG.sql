CREATE OR REPLACE FUNCTION sqlver_TamG3G5  
RETURN NUMBER IS
nTamG NUMBER;

BEGIN

	BEGIN
		select data_length INTO nTamG 
			from   user_tab_columns
			where  table_name = 'CONTROLE' and	column_name = 'GRUPO';
	EXCEPTION
		WHEN OTHERS THEN 
			nTamG := 3;		-- ASSUME TAMANHO DO CAMPO LACES COM 3 DIGITOS
	END;
      
   return (nTamG);
END sqlver_TamG3G5;
/


