CREATE OR REPLACE FUNCTION sqlfinal_histRStF (cLisMat VARCHAR2, cEndIp VARCHAR2, cModo CHAR, nTotal NUMBER)   
RETURN NUMBER IS

Retfun NUMBER;
nCont NUMBER;
nPos NUMBER;
cFunc VARCHAR2(12);
cPis VARCHAR2(12);

BEGIN


	Retfun := 0;      -- assume que achou o icard
	nCont := 0;
	
	WHILE (nCont < nTotal) LOOP
		nPos := (nCont * 12) + 1;
		cPis := SUBSTR (cLisMat, nPos, 12);

		FOR r in (SELECT IFUNC from REPAUXEMPR  
					WHERE END_IP = cEndIp AND 
						  TIPO = cModo AND 
						  PIS = cPIS AND 
						  ST = '1'
			ORDER by IFUNC)

		LOOP		
			UPDATE REPAUXEMPR SET ST = '2' 
				WHERE END_IP = cEndIp AND 
						TIPO = cModo AND 
						PIS = cPIS AND
						ST = '1' AND 
						IFUNC = r.IFUNC ;
				
		END LOOP;
							  
		nCont := nCont + 1;
		
	END LOOP;
	
	COMMIT;
	
	return (Retfun);
	
END sqlfinal_histRStF;
/


