CREATE OR REPLACE TRIGGER trgaltSITGRP
    AFTER DELETE OR INSERT OR UPDATE OF grupo, grupo1, grupo2, grupo3, grupo_sab, grupo_dom, grupo_fer, situa, ver_digit  ON CONTROLE
    FOR EACH ROW

BEGIN

	IF (DELETING) THEN
		UPDATE CONTDIG_SAGEM 	SET STATUS = '8' WHERE ICARD = :OLD.icard;
		UPDATE CONTDIG_TSI1  	SET STATUS = '8' WHERE ICARD = :OLD.icard;
		UPDATE PALMV001 	 	SET ST = '8'     WHERE ICARD = :OLD.icard;
		UPDATE CONTDIG_OUTROS 	SET STATUS = '8' WHERE ICARD = :OLD.icard;		-- pode alterar mais de 1 linha, pois podera ter mais de 1 tipo de digital por matricula

	END IF;
	
	IF (INSERTING) THEN
		--IF (:NEW.situa = '1') OR (:NEW.ver_digit = '1') then			-- INVALIDO SITUACAO  OU  NAO VERIFICA BIOMETRIA 
		IF (:NEW.situa = '1') OR (:NEW.ver_digit = '1') OR (:NEW.ver_digit = '3') then			-- INVALIDO SITUACAO  OU  NAO VERIFICA BIOMETRIA ou  VER_DIGIT '3' (BIO 1:1). OBS VER_DIGT '2' = (BIO 1:N)
			UPDATE CONTDIG_SAGEM 	SET STATUS = '8' WHERE ICARD = :new.icard;
			UPDATE CONTDIG_TSI1  	SET STATUS = '8' WHERE ICARD = :new.icard;
			UPDATE PALMV001 	 	SET ST = '8'     WHERE ICARD = :new.icard;
			UPDATE CONTDIG_OUTROS 	SET STATUS = '8' WHERE ICARD = :new.icard;
		
		ELSIF (:NEW.situa = '0' OR :NEW.situa = '7' OR :NEW.ver_digit = '2')  THEN 
			UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :new.icard;
			UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :new.icard;
			UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :new.icard;
			UPDATE CONTDIG_OUTROS	SET STATUS = '3' WHERE ICARD = :new.icard;
		END IF;
	END IF;

	-- (UPDATING)
	IF (:OLD.situa != :NEW.situa) OR 
	   (:OLD.ver_digit != :NEW.ver_digit) THEN
		--IF (:NEW.situa = '1') OR (:NEW.ver_digit = '1') then
		IF (:NEW.situa = '1') OR (:NEW.ver_digit = '1') OR (:NEW.ver_digit = '3') then		-- INVALIDO SITUACAO  OU  NAO VERIFICA BIOMETRIA ou  VER_DIGIT '3' (BIO 1:1). OBS VER_DIGT '2' = (BIO 1:N)
			UPDATE CONTDIG_SAGEM 	SET STATUS = '8' WHERE ICARD = :new.icard;
			UPDATE CONTDIG_TSI1  	SET STATUS = '8' WHERE ICARD = :new.icard;
			UPDATE PALMV001 	 	SET ST = '8'     WHERE ICARD = :new.icard;
			UPDATE CONTDIG_OUTROS	SET STATUS = '8' WHERE ICARD = :new.icard;

		--ELSIF (:NEW.situa = '0' OR :NEW.situa = '7') THEN 
		ELSIF (:NEW.situa = '0' OR :NEW.situa = '4' OR :NEW.situa = '7') and (:NEW.ver_digit = '2') AND (:OLD.situa != '8') THEN 
			UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :new.icard;
			UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :new.icard;
			UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :new.icard;
			UPDATE CONTDIG_OUTROS	SET STATUS = '3' WHERE ICARD = :new.icard;

		ELSIF (	TO_NUMBER(:OLD.grupo)  	!= TO_NUMBER(:NEW.grupo) or
				TO_NUMBER(:OLD.grupo1) 	!= TO_NUMBER(:NEW.grupo1) or
				TO_NUMBER(:OLD.grupo2) 	!= TO_NUMBER(:NEW.grupo2) or
				TO_NUMBER(:OLD.grupo3) 	!= TO_NUMBER(:NEW.grupo3) or
				TO_NUMBER(:OLD.grupo_sab) 	!= TO_NUMBER(:NEW.grupo_sab) or
				TO_NUMBER(:OLD.grupo_dom) 	!= TO_NUMBER(:NEW.grupo_dom) or
				TO_NUMBER(:OLD.grupo_fer) 	!= TO_NUMBER(:NEW.grupo_fer) ) THEN 

			UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :new.icard AND STATUS != '8';
			UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :new.icard AND STATUS != '8';
			UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :new.icard AND ST != '8';
			UPDATE CONTDIG_OUTROS  	SET STATUS = '3' WHERE ICARD = :new.icard AND STATUS != '8';

		END IF;

	ELSIF (	TO_NUMBER(:OLD.grupo)  	!= TO_NUMBER(:NEW.grupo) or
			TO_NUMBER(:OLD.grupo1) 	!= TO_NUMBER(:NEW.grupo1) or
			TO_NUMBER(:OLD.grupo2) 	!= TO_NUMBER(:NEW.grupo2) or
			TO_NUMBER(:OLD.grupo3) 	!= TO_NUMBER(:NEW.grupo3) or
			TO_NUMBER(:OLD.grupo_sab) 	!= TO_NUMBER(:NEW.grupo_sab) or
			TO_NUMBER(:OLD.grupo_dom) 	!= TO_NUMBER(:NEW.grupo_dom) or
			TO_NUMBER(:OLD.grupo_fer) 	!= TO_NUMBER(:NEW.grupo_fer)) THEN 

		UPDATE CONTDIG_SAGEM 	SET STATUS = '3' WHERE ICARD = :new.icard AND STATUS != '8';
		UPDATE CONTDIG_TSI1  	SET STATUS = '3' WHERE ICARD = :new.icard AND STATUS != '8';
		UPDATE PALMV001      	SET ST = '3'     WHERE ICARD = :new.icard AND ST != '8';
		UPDATE CONTDIG_OUTROS	SET STATUS = '3' WHERE ICARD = :new.icard AND STATUS != '8';
	END IF;

END;
/
