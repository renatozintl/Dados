CREATE OR REPLACE FUNCTION sqlatu_10tsi1_clob (cMatric in VARCHAR2, templ1 in VARCHAR2, templ2 in VARCHAR2, 
templ3 in VARCHAR2, templ4 in VARCHAR2, templ5 in VARCHAR2, nTipo in NUMBER, cNumDedo in VARCHAR2, cNivel in VARCHAR2)
   RETURN NUMBER IS
   nNovo NUMBER;
   nDedo NUMBER;
   cAux   VARCHAR2(15);
   reco_lock EXCEPTION;
   PRAGMA EXCEPTION_INIT (reco_lock,-54);  -- erro quando registro lockado 

BEGIN

    nDedo := to_number(cNumDedo);
    
    IF (nDedo > 10) or (nDedo < 1) THEN
    	return (0);
    END IF;
    
    IF (nDedo = 1) THEN
		BEGIN
			SELECT ICARD INTO cAux FROM CONTDIG_LOBTSI1 WHERE ICARD = cMatric 
				for update nowait;

			DELETE FROM CONTDIG_LOBTSI1 WHERE ICARD = cMatric ;    		

		EXCEPTION
			WHEN NO_DATA_FOUND THEN
				nNovo := 1;
			WHEN reco_lock THEN
				return (-1);
			WHEN others THEN
				return (-1);
		END;
	END IF;

	INSERT INTO CONTDIG_LOBTSI1 (ICARD, NUMDEDO, DIGITAL)  
		VALUES (cMatric, nDedo, to_clob(templ1 || templ2 || templ3 || templ4 || substr (templ5,1,128)) );

	COMMIT;    
	
    return (1);

END;
/

